<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

chdir( "../" );
include( "include/config.inc.php" );
$ap_sec_code = $_POST['ap_securitycode'];
if ( $ap_sec_code )
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    $arr_ALERTPAY = get_currency_data( "", "alertpay" );
    $ramz = new RamzNegar( );
    $arr_ALERTPAY['ALT_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_ALERTPAY['ALT_PASSWORD'] );
}
if ( strcmp( $arr_ALERTPAY['ALT_PASSWORD'], $ap_sec_code ) == 0 )
{
    $PAYEE_ACCOUNT = $_POST['ap_merchant'];
    $PAYMENT_ID = $_POST['apc_1'];
    $PAYMENT_AMOUNT = $_POST['ap_amount'];
    $PAYMENT_BATCH_NUM = $_POST['ap_referencenumber'];
    $PAID_WORTH_VALUE = $_POST['ap_currency'];
    $Message_log[] = "ALERTPAY Sectine 1";
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    if ( Refrence2eid( $PAYMENT_ID ) )
    {
        if ( $PAYEE_ACCOUNT == $arr_ALERTPAY['ACCOUNT'] && db_if_exists( "SELECT eid From {$_exchange_lines} WHERE exchange_refrence='{$PAYMENT_ID}' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}' and src_amount='{$PAYMENT_AMOUNT}'" ) )
        {
            SEND_EXHCANGE_MAIL( $PAYMENT_ID, "receive" );
            commit_exchange( $PAYMENT_ID, $PAYMENT_BATCH_NUM, "", $PAID_WORTH_VALUE );
            $Message_log[] = "ALERTPAY ADD TO DATABSE EXCHANGE";
        }
    }
    else if ( $PAYEE_ACCOUNT == $arr_ALERTPAY['ACCOUNT'] && db_if_exists( "SELECT * from {$_lines} where id='{$PAYMENT_ID}' and status='{$STATUS_ENUM_DISABLE}' and amount='{$PAYMENT_AMOUNT}'" ) )
    {
        SEND_INVEST_RECEIVE_MAIL( $PAYMENT_ID, $PAYER_ACCOUNT );
        commit_transaction( $PAYMENT_ID, $PAYMENT_BATCH_NUM );
        $Message_log[] = "ALERTPAY ADD TO DATABSE INVEST";
    }
    db_close( $dbconn );
}
else
{
    $Message_log[] = "ALERTPAY FAILED!!!!!!!!!!!";
}
Write_File( );
unset( $arr_ALERTPAY );
?>
