<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "public.inc.php" );
if ( !session_admin( ) )
{
    @header( "Location: ".$CONFIG['SITE_URL'] );
}
$FIELD_VIEW = 3;
$FIELD_NUMBER = 12;
$count = 0;
if ( $_GET['getreserved'] )
{
    $reserved_amounts = get_all_reserved_amounts( );
}
if ( $_POST['Action'] == "Save" && !$demo_mode )
{
    foreach ( $_POST as $key => $value )
    {
        list( $fieldname, $cid ) = fieldname ;       if ( !empty( $fieldname ) )
        {
            if ( $count == $FIELD_NUMBER - $FIELD_VIEW )
            {
                $update_query .= "{$fieldname}='{$value}' WHERE cid='{$cid}'";
                $Query = "UPDATE {$_currencies} SET {$update_query};";
                $result = db_query( $Query, "&nbsp;" );
                $update_query = "";
                $count = 0;
            }
            else
            {
                $update_query .= "{$fieldname}='{$value}', ";
                if ( !$value && $fieldname == "exchange_accept_limit" )
                {
                    $update_query .= "{$fieldname}=NULL, ";
                }
                ++$count;
            }
        }
    }
    $Success[] = "Currencies sucessfully updated";
}
if ( $_POST['Action'] == "Save" && $demo_mode )
{
    $Error_div[] = "Some features are not active in Demo Version.";
}
$arr_data_currencies = array( );
$x = 0;
$query = "SELECT cid, currency_name, currency_metal_name, exchange_status, exchange_accept_limit, exchange_max_fee, exchange_min, exchange_max, reserve_amount, no_interface_message, show_as_source, show_as_destination, exchange_automatic  From {$_currencies} WHERE cid<>'50' Order By cid Asc;";
$result = db_query( $query, "&nbsp;" );
while ( $row = db_fetch_array( $result, MYSQL_BOTH ) )
{
    if ( $x <= $FIELD_NUMBER )
    {
        $f_type[$x] = mysql_field_type( $result, $x );
        $f_name[$x] = mysql_field_name( $result, $x );
    }
    array_push( $arr_data_currencies, $row );
    ++$x;
}
db_free_result( $result );
$query = "SELECT cid, currency_name, currency_metal_value, currency_metal_name, currency_worth_name, reserve_amount FROM {$_currencies} WHERE reserve_amount<='100' AND exchange_status='{$STATUS_ENUM_ENABLE}' AND cid<>'{$INTERNAL_CID}'";
$result = db_query( $query, "&nbsp;" );
if ( db_num_rows( $result ) )
{
    $low_reserve_amount = "<b>Warning: your reserve amount in folowing currencies is lower than 100 unit: </b><br>";
    while ( $line = db_fetch_array( $result, MYSQL_BOTH ) )
    {
        $low_reserve_amount .= ucfirst( $line['currency_name'] )." (".$Var_3792['currency_metal_name'].") Remains: ".$line['reserve_amount']." ".$line['currency_worth_name']."<br>";
    }
}
db_free_result( $result );
$query = "SELECT cid, currency_name, currency_metal_value, currency_metal_name, currency_worth_name, exchange_accept_limit FROM {$_currencies} WHERE exchange_accept_limit Is Not Null AND exchange_accept_limit<='100' AND exchange_status='{$STATUS_ENUM_ENABLE}' AND cid<>'{$INTERNAL_CID}'";
$result = db_query( $query, "&nbsp;" );
if ( db_num_rows( $result ) )
{
    $low_accept_limit = "<br><b>Warning: your Exchange accept limit in  folowing currencies is lower than 100 unit: </b><br>";
    while ( $line = db_fetch_array( $result, MYSQL_BOTH ) )
    {
        $low_accept_limit .= ucfirst( $line['currency_name'] )." (".$line['currency_metal_name'].") Remains: ".$line['exchange_accept_limit']." ".$line['currency_worth_name']."<br>";
    }
}
db_free_result( $result );
echo "\r\n";
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."adm_currencies.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "adm_currencies.html";
    $page->assign( "low_accept_limit", $low_accept_limit );
    $page->assign( "low_reserve_amount", $low_reserve_amount );
    $page->assign( "reserved_amounts", $reserved_amounts );
    $currency_table = "<table border=\"0\" cellspacing=\"1\" cellpadding=\"0\" class=\"rates\" width=\"99%\"><tr class=\"tablefirstrow\">";
    $x = 0;
    while ( $x <= $FIELD_NUMBER )
    {
        $currency_table .= "<td nowrap style=font-size:11px;>".ucfirst( str_replace( "_", "<br>", $f_name[$x] ) )."</td>";
        ++$x;
    }
    $currency_table .= "</tr>";
    foreach ( $arr_data_currencies as $line )
    {
        fmod( $count, 2 ) == 1 ? ( $Var_6264 = "col0" ) : ( $class = "col1" );
        ++$count;
        if ( !$line[exchange_status] )
        {
            $class = "#9A9A9A";
        }
        $currency_table .= "<tr class=".$class.">";
        $x = 0;
        while ( $x <= $FIELD_NUMBER )
        {
            $currency_table .= "<td>";
            if ( $x < $FIELD_VIEW )
            {
                $currency_table .= ucfirst( $line[$x] );
            }
            else if ( $f_type[$x] == "string" )
            {
                if ( $line[$x] == $STATUS_ENUM_LOCKED )
                {
                    $currency_table .= "<input type=\"hidden\" name=\"".$f_name[$x]."|".$line[cid]."\" value=\"".$STATUS_ENUM_LOCKED."\" />";
                }
                else
                {
                    $currency_table .= "<select name=\"".$f_name[$x]."|".$line[cid]."\"><option value=\"1\" ".show_input_selected( 1, $line[$x] )." >Yes</option><option value=\"0\" ".show_input_selected( 0, $line[$x] ).">No</option></select>";
                }
            }
            else
            {
                $currency_table .= "<input type='text' name='".$f_name[$x]."|".$line[cid]."' value='".$line[$x]."' size=5 />";
            }
            $currency_table .= "</td>";
            ++$x;
        }
        $currency_table .= "</tr>";
    }
    $currency_table .= "</table>";
    $page->assign( "currency_table", $currency_table );
    require( "include/engine_run.php" );
}
?>
