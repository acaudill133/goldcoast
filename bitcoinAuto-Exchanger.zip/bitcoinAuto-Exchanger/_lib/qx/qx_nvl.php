<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_nvl( $param, $default )
{
    if ( strlen( $param ) )
    {
        return $param;
    }
    return $default;
}

?>
