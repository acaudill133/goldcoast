<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function check_sha256( )
{
    $ver = explode( ".", phpversion( ) );
    if ( $ver[0] == 4 )
    {
        return true;
    }
    if ( @bin2hex( @mhash( MHASH_SHA256, "test" ) ) && @hash( "sha256", "test" ) )
    {
        return true;
    }
}

function parse_mysql_dump_install( $url, $db_perfix = "", $ignoreerrors = false )
{
    global $Error;
    global $Sql;
    $file_content = preg_split( "/\n/", $Sql );
    $query = "";
    foreach ( $file_content as $sql_line )
    {
        $tsl = trim( stripslashes( $sql_line ) );
        if ( $sql_line != "" && substr( $tsl, 0, 2 ) != "--" && substr( $tsl, 0, 1 ) != "#" )
        {
            $sql_line = str_replace( "dbperfix_", $_POST['db_perfix'], $sql_line );
            $query .= $sql_line;
            if ( preg_match( "/;\\s*\$/", $sql_line ) )
            {
                ++$querycount;
                $query = str_replace( ";", "", "{$query}" );
                $result = mysql_query( $query );
                if ( !$result )
                {
                    $queryerrors .= ""."Line ".$querycount." - ".mysql_error( )."<br>";
                    continue;
                }
                $query = "";
            }
        }
    }
    if ( $queryerrors )
    {
        $Error[] = "Please open a ticket with the debug information below for support<br><br>File: ".$filename."<br>".$queryerrors;
    }
    else
    {
    }
    return true;
}

$Sql = "\r\n\r\nDROP TABLE IF EXISTS `dbperfix_countries`;\r\nCREATE TABLE IF NOT EXISTS `dbperfix_countries` (\r\n  `countries_id` int(11) NOT NULL AUTO_INCREMENT,\r\n  `countries_name` varchar(64) NOT NULL DEFAULT '',\r\n  `countries_iso` char(2) NOT NULL DEFAULT '',\r\n  PRIMARY KEY (`countries_id`),\r\n  KEY `IDX_COUNTRIES_NAME` (`countries_name`)\r\n) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=240 ;\r\n\r\n--\r\n-- Dumping data for table `dbperfix_countries`\r\n--\r\n\r\nINSERT INTO `dbperfix_countries` (`countries_id`, `countries_name`, `countries_iso`) VALUES\r\n(1, 'Afghanistan', 'AF'),\r\n(2, 'Albania', 'AL'),\r\n(3, 'Algeria', 'DZ'),\r\n(4, 'American Samoa', 'AS'),\r\n(5, 'Andorra', 'AD'),\r\n(6, 'Angola', 'AO'),\r\n(7, 'Anguilla', 'AI'),\r\n(8, 'Antarctica', 'AQ'),\r\n(9, 'Antigua and Barbuda', 'AG'),\r\n(10, 'Argentina', 'AR'),\r\n(11, 'Armenia', 'AM'),\r\n(12, 'Aruba', 'AW'),\r\n(13, 'Australia', 'AU'),\r\n(14, 'Austria', 'AT'),\r\n(15, 'Azerbaijan', 'AZ'),\r\n(16, 'Bahamas', 'BS'),\r\n(17, 'Bahrain', 'BH'),\r\n(18, 'Bangladesh', 'BD'),\r\n(19, 'Barbados', 'BB'),\r\n(20, 'Belarus', 'BY'),\r\n(21, 'Belgium', 'BE'),\r\n(22, 'Belize', 'BZ'),\r\n(23, 'Benin', 'BJ'),\r\n(24, 'Bermuda', 'BM'),\r\n(25, 'Bhutan', 'BT'),\r\n(26, 'Bolivia', 'BO'),\r\n(27, 'Bosnia and Herzegowina', 'BA'),\r\n(28, 'Botswana', 'BW'),\r\n(29, 'Bouvet Island', 'BV'),\r\n(30, 'Brazil', 'BR'),\r\n(31, 'British Indian Ocean Territory', 'IO'),\r\n(32, 'Brunei Darussalam', 'BN'),\r\n(33, 'Bulgaria', 'BG'),\r\n(34, 'Burkina Faso', 'BF'),\r\n(35, 'Burundi', 'BI'),\r\n(36, 'Cambodia', 'KH'),\r\n(37, 'Cameroon', 'CM'),\r\n(38, 'Canada', 'CA'),\r\n(39, 'Cape Verde', 'CV'),\r\n(40, 'Cayman Islands', 'KY'),\r\n(41, 'Central African Republic', 'CF'),\r\n(42, 'Chad', 'TD'),\r\n(43, 'Chile', 'CL'),\r\n(44, 'China', 'CN'),\r\n(45, 'Christmas Island', 'CX'),\r\n(46, 'Cocos (Keeling) Islands', 'CC'),\r\n(47, 'Colombia', 'CO'),\r\n(48, 'Comoros', 'KM'),\r\n(49, 'Congo', 'CG'),\r\n(50, 'Cook Islands', 'CK'),\r\n(51, 'Costa Rica', 'CR'),\r\n(52, 'Cote D''Ivoire', 'CI'),\r\n(53, 'Croatia', 'HR'),\r\n(54, 'Cuba', 'CU'),\r\n(55, 'Cyprus', 'CY'),\r\n(56, 'Czech Republic', 'CZ'),\r\n(57, 'Denmark', 'DK'),\r\n(58, 'Djibouti', 'DJ'),\r\n(59, 'Dominica', 'DM'),\r\n(60, 'Dominican Republic', 'DO'),\r\n(61, 'East Timor', 'TP'),\r\n(62, 'Ecuador', 'EC'),\r\n(63, 'Egypt', 'EG'),\r\n(64, 'El Salvador', 'SV'),\r\n(65, 'Equatorial Guinea', 'GQ'),\r\n(66, 'Eritrea', 'ER'),\r\n(67, 'Estonia', 'EE'),\r\n(68, 'Ethiopia', 'ET'),\r\n(69, 'Falkland Islands (Malvinas)', 'FK'),\r\n(70, 'Faroe Islands', 'FO'),\r\n(71, 'Fiji', 'FJ'),\r\n(72, 'Finland', 'FI'),\r\n(73, 'France', 'FR'),\r\n(74, 'France, Metropolitan', 'FX'),\r\n(75, 'French Guiana', 'GF'),\r\n(76, 'French Polynesia', 'PF'),\r\n(77, 'French Southern Territories', 'TF'),\r\n(78, 'Gabon', 'GA'),\r\n(79, 'Gambia', 'GM'),\r\n(80, 'Georgia', 'GE'),\r\n(81, 'Germany', 'DE'),\r\n(82, 'Ghana', 'GH'),\r\n(83, 'Gibraltar', 'GI'),\r\n(84, 'Greece', 'GR'),\r\n(85, 'Greenland', 'GL'),\r\n(86, 'Grenada', 'GD'),\r\n(87, 'Guadeloupe', 'GP'),\r\n(88, 'Guam', 'GU'),\r\n(89, 'Guatemala', 'GT'),\r\n(90, 'Guinea', 'GN'),\r\n(91, 'Guinea-bissau', 'GW'),\r\n(92, 'Guyana', 'GY'),\r\n(93, 'Haiti', 'HT'),\r\n(94, 'Heard and Mc Donald', 'HM'),\r\n(95, 'Honduras', 'HN'),\r\n(96, 'Hong Kong', 'HK'),\r\n(97, 'Hungary', 'HU'),\r\n(98, 'Iceland', 'IS'),\r\n(99, 'India', 'IN'),\r\n(100, 'Indonesia', 'ID'),\r\n(101, 'Iran (Islamic Republic of)', 'IR'),\r\n(102, 'Iraq', 'IQ'),\r\n(103, 'Ireland', 'IE'),\r\n(104, 'Israel', 'IL'),\r\n(105, 'Italy', 'IT'),\r\n(106, 'Jamaica', 'JM'),\r\n(107, 'Japan', 'JP'),\r\n(108, 'Jordan', 'JO'),\r\n(109, 'Kazakhstan', 'KZ'),\r\n(110, 'Kenya', 'KE'),\r\n(111, 'Kiribati', 'KI'),\r\n(112, 'Korea, Democratic Republic', 'KP'),\r\n(113, 'Korea, Republic of', 'KR'),\r\n(114, 'Kuwait', 'KW'),\r\n(115, 'Kyrgyzstan', 'KG'),\r\n(116, 'Lao Democratic Republic', 'LA'),\r\n(117, 'Latvia', 'LV'),\r\n(118, 'Lebanon', 'LB'),\r\n(119, 'Lesotho', 'LS'),\r\n(120, 'Liberia', 'LR'),\r\n(121, 'Libyan Arab Jamahiriya', 'LY'),\r\n(122, 'Liechtenstein', 'LI'),\r\n(123, 'Lithuania', 'LT'),\r\n(124, 'Luxembourg', 'LU'),\r\n(125, 'Macau', 'MO'),\r\n(126, 'Macedonia', 'MK'),\r\n(127, 'Madagascar', 'MG'),\r\n(128, 'Malawi', 'MW'),\r\n(129, 'Malaysia', 'MY'),\r\n(130, 'Maldives', 'MV'),\r\n(131, 'Mali', 'ML'),\r\n(132, 'Malta', 'MT'),\r\n(133, 'Marshall Islands', 'MH'),\r\n(134, 'Martinique', 'MQ'),\r\n(135, 'Mauritania', 'MR'),\r\n(136, 'Mauritius', 'MU'),\r\n(137, 'Mayotte', 'YT'),\r\n(138, 'Mexico', 'MX'),\r\n(139, 'Micronesia, Federated', 'FM'),\r\n(140, 'Moldova, Republic of', 'MD'),\r\n(141, 'Monaco', 'MC'),\r\n(142, 'Mongolia', 'MN'),\r\n(143, 'Montserrat', 'MS'),\r\n(144, 'Morocco', 'MA'),\r\n(145, 'Mozambique', 'MZ'),\r\n(146, 'Myanmar', 'MM'),\r\n(147, 'Namibia', 'NA'),\r\n(148, 'Nauru', 'NR'),\r\n(149, 'Nepal', 'NP'),\r\n(150, 'Netherlands', 'NL'),\r\n(151, 'Netherlands Antilles', 'AN'),\r\n(152, 'New Caledonia', 'NC'),\r\n(153, 'New Zealand', 'NZ'),\r\n(154, 'Nicaragua', 'NI'),\r\n(155, 'Niger', 'NE'),\r\n(156, 'Nigeria', 'NG'),\r\n(157, 'Niue', 'NU'),\r\n(158, 'Norfolk Island', 'NF'),\r\n(159, 'Northern Mariana Islands', 'MP'),\r\n(160, 'Norway', 'NO'),\r\n(161, 'Oman', 'OM'),\r\n(162, 'Pakistan', 'PK'),\r\n(163, 'Palau', 'PW'),\r\n(164, 'Panama', 'PA'),\r\n(165, 'Papua New Guinea', 'PG'),\r\n(166, 'Paraguay', 'PY'),\r\n(167, 'Peru', 'PE'),\r\n(168, 'Philippines', 'PH'),\r\n(169, 'Pitcairn', 'PN'),\r\n(170, 'Poland', 'PL'),\r\n(171, 'Portugal', 'PT'),\r\n(172, 'Puerto Rico', 'PR'),\r\n(173, 'Qatar', 'QA'),\r\n(174, 'Reunion', 'RE'),\r\n(175, 'Romania', 'RO'),\r\n(176, 'Russian Federation', 'RU'),\r\n(177, 'Rwanda', 'RW'),\r\n(178, 'Saint Kitts and Nevis', 'KN'),\r\n(179, 'Saint Lucia', 'LC'),\r\n(180, 'Saint Vincent', 'VC'),\r\n(181, 'Samoa', 'WS'),\r\n(182, 'San Marino', 'SM'),\r\n(183, 'Sao Tome and Principe', 'ST'),\r\n(184, 'Saudi Arabia', 'SA'),\r\n(185, 'Senegal', 'SN'),\r\n(186, 'Seychelles', 'SC'),\r\n(187, 'Sierra Leone', 'SL'),\r\n(188, 'Singapore', 'SG'),\r\n(189, 'Slovakia (Slovak Republic)', 'SK'),\r\n(190, 'Slovenia', 'SI'),\r\n(191, 'Solomon Islands', 'SB'),\r\n(192, 'Somalia', 'SO'),\r\n(193, 'South Africa', 'ZA'),\r\n(194, 'South Georgia', 'GS'),\r\n(195, 'Spain', 'ES'),\r\n(196, 'Sri Lanka', 'LK'),\r\n(197, 'St. Helena', 'SH'),\r\n(198, 'St. Pierre and Miquelon', 'PM'),\r\n(199, 'Sudan', 'SD'),\r\n(200, 'Suriname', 'SR'),\r\n(201, 'Svalbard', 'SJ'),\r\n(202, 'Swaziland', 'SZ'),\r\n(203, 'Sweden', 'SE'),\r\n(204, 'Switzerland', 'CH'),\r\n(205, 'Syrian Arab Republic', 'SY'),\r\n(206, 'Taiwan', 'TW'),\r\n(207, 'Tajikistan', 'TJ'),\r\n(208, 'Tanzania, United Republic of', 'TZ'),\r\n(209, 'Thailand', 'TH'),\r\n(210, 'Togo', 'TG'),\r\n(211, 'Tokelau', 'TK'),\r\n(212, 'Tonga', 'TO'),\r\n(213, 'Trinidad and Tobago', 'TT'),\r\n(214, 'Tunisia', 'TN'),\r\n(215, 'Turkey', 'TR'),\r\n(216, 'Turkmenistan', 'TM'),\r\n(217, 'Turks and Caicos Islands', 'TC'),\r\n(218, 'Tuvalu', 'TV'),\r\n(219, 'Uganda', 'UG'),\r\n(220, 'Ukraine', 'UA'),\r\n(221, 'United Arab Emirates', 'AE'),\r\n(222, 'United Kingdom', 'GB'),\r\n(223, 'United States', 'US'),\r\n(224, 'United States Minor Islands', 'UM'),\r\n(225, 'Uruguay', 'UY'),\r\n(226, 'Uzbekistan', 'UZ'),\r\n(227, 'Vanuatu', 'VU'),\r\n(228, 'Vatican City State', 'VA'),\r\n(229, 'Venezuela', 'VE'),\r\n(230, 'Viet Nam', 'VN'),\r\n(231, 'Virgin Islands (British)', 'VG'),\r\n(232, 'Virgin Islands (U.S.)', 'VI'),\r\n(233, 'Wallis and Futuna Islands', 'WF'),\r\n(234, 'Western Sahara', 'EH'),\r\n(235, 'Yemen', 'YE'),\r\n(236, 'Yugoslavia', 'YU'),\r\n(237, 'Zaire', 'ZR'),\r\n(238, 'Zambia', 'ZM'),\r\n(239, 'Zimbabwe', 'ZW');\r\n\r\n-- --------------------------------------------------------\r\n\r\n--\r\n-- Table structure for table `dbperfix_currency`\r\n--\r\n\r\nDROP TABLE IF EXISTS `dbperfix_currency`;\r\nCREATE TABLE IF NOT EXISTS `dbperfix_currency` (\r\n  `cid` int(2) NOT NULL DEFAULT '0',\r\n  `currency_name` char(32) DEFAULT NULL,\r\n  `currency_worth_name` char(10) DEFAULT NULL,\r\n  `currency_worth_value` char(8) DEFAULT NULL,\r\n  `currency_metal_name` char(32) DEFAULT NULL,\r\n  `currency_metal_value` char(16) DEFAULT NULL,\r\n  `currency_merchant_url` char(128) DEFAULT NULL,\r\n  `invest_status` enum('0','1') DEFAULT '1',\r\n  `exchange_status` enum('0','1') DEFAULT '1',\r\n  `exchange_add_fee` double DEFAULT '0',\r\n  `exchange_accept_limit` double DEFAULT NULL,\r\n  `exchange_max_fee` double DEFAULT '0',\r\n  `exchange_min` double DEFAULT '3',\r\n  `exchange_max` double DEFAULT '5000',\r\n  `reserve_amount` double DEFAULT '0',\r\n  `exchange_automatic` enum('2','1','0') DEFAULT '0',\r\n  `payout_automatic` enum('2','1','0') DEFAULT '0',\r\n  `no_interface_message` longtext,\r\n  `show_as_source` enum('0','1') DEFAULT '1',\r\n  `show_as_destination` enum('1','0') DEFAULT '1',\r\n  `transaction_name` char(32) DEFAULT NULL,\r\n  `CURRENCY_VERIFIER` char(64) DEFAULT NULL,\r\n  `ACCOUNT` char(64) DEFAULT NULL,\r\n  `ACCOUNT_NAME` text,\r\n  `MAIN_PASSWORD` text,\r\n  `ALT_PASSWORD` text,\r\n  `THIRD_PASSWORD` text,\r\n  `PIN_NUMBER` text,\r\n  `API_NAME` char(32) DEFAULT NULL,\r\n  `PAYEE_NAME` char(32) DEFAULT NULL\r\n) ENGINE=MyISAM DEFAULT CHARSET=latin1;\r\n\r\n--\r\n-- Dumping data for table `dbperfix_currency`\r\n--\r\n\r\nINSERT INTO `dbperfix_currency` (`cid`, `currency_name`, `currency_worth_name`, `currency_worth_value`, `currency_metal_name`, `currency_metal_value`, `currency_merchant_url`, `invest_status`, `exchange_status`, `exchange_add_fee`, `exchange_accept_limit`, `exchange_max_fee`, `exchange_min`, `exchange_max`, `reserve_amount`, `exchange_automatic`, `payout_automatic`, `no_interface_message`, `show_as_source`, `show_as_destination`, `transaction_name`, `CURRENCY_VERIFIER`, `ACCOUNT`, `ACCOUNT_NAME`, `MAIN_PASSWORD`, `ALT_PASSWORD`, `THIRD_PASSWORD`, `PIN_NUMBER`, `API_NAME`, `PAYEE_NAME`) VALUES\r\n(1, 'e-gold', 'usd', '1', 'Gold', '1', 'https://www.e-gold.com/sci_asp/payments.asp', '0', '1', 0, 0, 0, 5, 5000, 1000, '1', '0', '', '1', '1', 'Batch No', 'hsh_bnk/hsh_egold.php', '', '', '', '', '', '', '', ''),\r\n(2, 'e-gold', 'usd', '1', 'Silver', '2', 'https://www.e-gold.com/sci_asp/payments.asp', '0', '1', 0, 0, 0, 5, 5000, 1000, '1', '0', '', '1', '1', 'Batch No', 'hsh_bnk/hsh_egold.php', '', '', '', '', '', '', '', ''),\r\n(3, 'libertyreserve', 'usd', 'LRUSD', 'Usd', '', 'https://sci.libertyreserve.com', '0', '1', 0, 0, 0, 5, 5000, 1000, '1', '0', '', '1', '1', 'Batch', 'hsh_bnk/hsh_liberty.php', '', '', '', '', '', '', '', ''),\r\n(4, 'libertyreserve', 'euro', 'LREUR', 'Euro', '', 'https://sci.libertyreserve.com', '0', '1', 0, 0, 0, 5, 5000, 1000, '1', '0', '', '1', '1', 'Batch', 'hsh_bnk/hsh_liberty.php', '', '', '', '', '', '', '', ''),\r\n(5, 'c-gold', 'usd', 'USD', 'Usd', '', 'https://c-gold.com/clicktopay/', '0', '1', 0, 0, 0, 5, 5000, 1000, '1', '0', '', '1', '1', 'Transaction id', 'hsh_bnk/hsh_cgold.php', '', '', '', '', '', '', '', ''),\r\n(6, 'perfectmoney', 'usd', 'USD', 'Usd', '', 'https://perfectmoney.com/api/step1.asp', '0', '1', 0, 0, 0, 5, 5000, 1000, '1', '0', '', '1', '1', 'Batch', 'hsh_bnk/hsh_perfectmoney.php', '', '', '', '', '', '', '', ''),\r\n(7, 'pecunix', 'usd', 'USD', 'Usd', '', 'https://pri.pecunix.com/money.refined', '0', '1', 0, 0, 0, 5, 5000, 1000, '1', '0', '', '1', '1', 'Record Id', 'hsh_bnk/hsh_pecunix.php', '', '', '', '', '', '', '', ''),\r\n(8, 'v-money', 'usd', '', 'usd', '', 'https://www.v-money.net/vmi.php', '0', '1', 0, 0, 0, 5, 5000, 1000, '1', '0', '', '1', '1', 'Batch', 'hsh_bnk/hsh_vmoney.php', '', '', '', '', '', '', '', ''),\r\n(9, 'webmoney', 'usd', 'WMZ', 'WMZ', '', 'https://merchant.wmtransfer.com/lmi/payment.asp', '0', '1', 0, 0, 0, 5, 5000, 1000, '1', '0', '', '1', '1', 'Transaction id', 'hsh_bnk/hsh_webmoney.php', '', '', '', '', '', '', '', ''),\r\n(10, 'webmoney', 'euro', 'WME', 'WME', '', 'https://merchant.wmtransfer.com/lmi/payment.asp', '0', '1', 0, 0, 0, 5, 5000, 1000, '1', '0', '', '1', '1', 'Transaction id', 'hsh_bnk/hsh_webmoney.php', '', '', '', '', '', '', '', ''),\r\n(11, 'webmoney', 'rur', 'WMR', 'WMR', '', 'https://merchant.wmtransfer.com/lmi/payment.asp', '0', '1', 0, 0, 0, 5, 5000, 1000, '1', '0', '', '1', '1', 'Transaction id', 'hsh_bnk/hsh_webmoney.php', '', '', '', '', '', '', '', ''),\r\n(12, 'webmoney', 'wmu', 'WMU', 'WMU', '', 'https://merchant.wmtransfer.com/lmi/payment.asp', '0', '1', 0, 0, 0, 5, 5000, 1000, '1', '0', '', '1', '1', 'Transaction id', 'hsh_bnk/hsh_webmoney.php', '', '', '', '', '', '', '', ''),\r\n(13, 'alertpay', 'usd', 'USD', 'Usd', '', 'https://www.alertpay.com/PayProcess.aspx', '0', '1', 0, 0, 0, 5, 5000, 1000, '2', '0', '', '1', '1', 'Reference no', 'hsh_bnk/hsh_alertpay.php', '', '', '', '', '', '', '', ''),\r\n(14, 'moneybookers', 'usd', 'USD', 'Usd', '', 'https://www.moneybookers.com/app/payment.pl', '0', '1', 0, 0, 0, 5, 5000, 1000, '2', '0', 'Please just write <b>#%s</b> in subject line of your payment.', '1', '1', 'Payment ID', 'hsh_bnk/hsh_moneybookers.php', '', '', '', '', '', '', '', ''),\r\n(15, 'paypal', 'usd', 'USD', 'Usd', '', 'https://www.paypal.com/cgi-bin/webscr', '0', '1', 0, 0, 0, 5, 5000, 1000, '1', '0', '', '1', '1', 'Transaction id', 'hsh_bnk/hsh_paypal.php', '', '', '', '', '', '', 'sandbox', ''),\r\n(16, 'paypal', 'euro', 'EUR', 'Euro', '', 'https://www.paypal.com/cgi-bin/webscr', '0', '1', 0, 0, 0, 5, 5000, 1000, '1', '0', '', '1', '1', 'Transaction id', 'hsh_bnk/hsh_paypal.php', '', '', '', '', '', '', 'sandbox', ''),\r\n(41, 'debit card', 'usd', 'USD', 'Usd', '', '', '0', '1', 0, 0, 0, 5, 5000, 1000, '2', '0', 'Please just write <b>#%s</b> in subject line of your payment.', '1', '1', 'Payment no', '', '', '', '', '', '', '', '', ''),\r\n(42, 'debit card', 'euro', 'EUR', 'Euro', '', '', '0', '1', 0, 0, 0, 5, 5000, 1000, '2', '0', 'Please just write <b>#%s</b> in subject line of your payment.', '1', '1', 'Payment no', '', '', '', '', '', '', '', '', ''),\r\n(50, 'Internal', 'usd', 'USD', 'Usd', '', '', '0', '0', 0, 0, 0, 0, 0, 0, '0', '0', '', '0', '0', '', '', '', '', '', '', '', '', '', '');\r\n\r\n-- --------------------------------------------------------\r\n\r\n--\r\n-- Table structure for table `dbperfix_exchange_lines`\r\n--\r\n\r\nDROP TABLE IF EXISTS `dbperfix_exchange_lines`;\r\nCREATE TABLE IF NOT EXISTS `dbperfix_exchange_lines` (\r\n  `eid` int(11) NOT NULL AUTO_INCREMENT,\r\n  `uid` int(11) DEFAULT '0',\r\n  `src_cid` tinyint(4) DEFAULT NULL,\r\n  `src_amount` double DEFAULT NULL,\r\n  `src_account` varchar(64) DEFAULT NULL,\r\n  `src_date` datetime DEFAULT NULL,\r\n  `src_batch` varchar(64) DEFAULT NULL,\r\n  `src_status` enum('2','1','0') DEFAULT '0',\r\n  `dst_cid` tinyint(4) DEFAULT NULL,\r\n  `dst_amount` double DEFAULT NULL,\r\n  `dst_date` datetime DEFAULT NULL,\r\n  `dst_batch` varchar(64) DEFAULT NULL,\r\n  `dst_account` varchar(64) DEFAULT NULL,\r\n  `dst_status` enum('7','6','5','4','3','2','1','0') DEFAULT '0',\r\n  `exchange_email_address` varchar(64) DEFAULT NULL,\r\n  `exchange_note` longtext,\r\n  `exchange_refrence` varchar(255) DEFAULT NULL,\r\n  `ref_uid` int(11) DEFAULT NULL,\r\n  `dst_account_name` varchar(64) DEFAULT NULL,\r\n  PRIMARY KEY (`eid`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;\r\n\r\n--\r\n-- Dumping data for table `dbperfix_exchange_lines`\r\n--\r\n\r\n\r\n-- --------------------------------------------------------\r\n\r\n--\r\n-- Table structure for table `dbperfix_exchange_rate`\r\n--\r\n\r\nDROP TABLE IF EXISTS `dbperfix_exchange_rate`;\r\nCREATE TABLE IF NOT EXISTS `dbperfix_exchange_rate` (\r\n  `cid` int(2) NOT NULL DEFAULT '0',\r\n  `1` char(255) DEFAULT NULL,\r\n  `2` char(255) DEFAULT NULL,\r\n  `3` char(255) DEFAULT NULL,\r\n  `4` char(255) DEFAULT NULL,\r\n  `5` char(255) DEFAULT NULL,\r\n  `6` char(255) DEFAULT NULL,\r\n  `7` char(255) DEFAULT NULL,\r\n  `8` char(255) DEFAULT NULL,\r\n  `9` char(255) DEFAULT NULL,\r\n  `10` char(255) DEFAULT NULL,\r\n  `11` char(255) DEFAULT NULL,\r\n  `12` char(255) DEFAULT NULL,\r\n  `13` char(255) DEFAULT NULL,\r\n  `14` char(255) DEFAULT NULL,\r\n  `15` char(255) DEFAULT NULL,\r\n  `16` char(255) DEFAULT NULL,\r\n  `41` char(255) DEFAULT NULL,\r\n  `42` char(255) DEFAULT NULL,\r\n  `50` char(255) DEFAULT NULL,\r\n  PRIMARY KEY (`cid`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=latin1;\r\n\r\n--\r\n-- Dumping data for table `dbperfix_exchange_rate`\r\n--\r\n\r\nINSERT INTO `dbperfix_exchange_rate` (`cid`, `1`, `2`, `3`, `4`, `5`, `6`, `7`, `8`, `9`, `10`, `11`, `12`, `13`, `14`, `15`, `16`, `41`, `42`, `50`) VALUES\r\n(1, '', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.95'),\r\n(2, '1:0.982', '', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.95'),\r\n(3, '1:0.982', '1:0.982', '', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.95'),\r\n(4, '1:0.982', '1:0.982', '1:0.982', '', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.95'),\r\n(5, '1:0.982', '1:0.982', '1:0.982', '1:0.982', '', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.95'),\r\n(6, '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.95'),\r\n(7, '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.95'),\r\n(8, '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.95'),\r\n(9, '0:0', '0:0', '0:0', '0:0', '0:0', '0:0', '0:0', '0:0', '', '1:0.50', '1:0.50', '1:0.50', '0:0', '0:0', '0:0', '0:0', '0:0', '0:0', '1:0.95'),\r\n(10, '0:0', '0:0', '0:0', '0:0', '0:0', '0:0', '0:0', '0:0', '1:0.50', '', '1:0.50', '1:0.50', '0:0', '0:0', '0:0', '0:0', '0:0', '0:0', '1:0.95'),\r\n(11, '0:0', '0:0', '0:0', '0:0', '0:0', '0:0', '0:0', '0:0', '1:0.50', '1:0.50', '', '1:0.50', '0:0', '0:0', '0:0', '0:0', '0:0', '0:0', '1:0.95'),\r\n(12, '0:0', '0:0', '0:0', '0:0', '0:0', '0:0', '0:0', '0:0', '1:0.50', '1:0.50', '1:0.50', '', '0:0', '0:0', '0:0', '0:0', '0:0', '0:0', '1:0.95'),\r\n(13, '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.95'),\r\n(14, '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.95'),\r\n(15, '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', NULL, '1:0.982', '1:0.982', '1:0.982', '1:0.95'),\r\n(16, '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', NULL, '1:0.982', '1:0.982', '1:0.95'),\r\n(41, '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', NULL, '1:0.982', '1:0.95'),\r\n(42, '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', '1:0.982', NULL, '1:0.95'),\r\n(50, '1:1', '1:1', '1:1', '1:1', '1:1', '1:1', '1:1', '1:1', '1:1.1', '1:1', '1:1.1', '1:1', '1:1', '1:1', '1:1', '1:1', '1:1', '1:1', NULL);\r\n\r\n-- --------------------------------------------------------\r\n\r\n--\r\n-- Table structure for table `dbperfix_balance_lines`\r\n--\r\n\r\nDROP TABLE IF EXISTS `dbperfix_balance_lines`;\r\nCREATE TABLE IF NOT EXISTS `dbperfix_balance_lines` (\r\n  `id` bigint(20) NOT NULL AUTO_INCREMENT,\r\n  `uid` bigint(20) NOT NULL DEFAULT '0',\r\n  `plan_type` enum('0','1','2','3','d','w','b','m','y') NOT NULL DEFAULT '0',\r\n  `pmt_type` enum('a','s','w','t','i','c','b','p','x','z','be','bs','ba','he','e') NOT NULL DEFAULT 's',\r\n  `amount` double NOT NULL DEFAULT '0',\r\n  `exchange` double NOT NULL DEFAULT '0',\r\n  `cid` tinyint(4) DEFAULT NULL,\r\n  `status` enum('0','1','2','3','4') NOT NULL DEFAULT '0',\r\n  `turing_id` varchar(6) NOT NULL DEFAULT '',\r\n  `user_note` varchar(64) NOT NULL DEFAULT '',\r\n  `pmt_note` varchar(255) NOT NULL DEFAULT '',\r\n  `pmt_id` bigint(20) NOT NULL DEFAULT '0',\r\n  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',\r\n  `related_id` bigint(20) DEFAULT NULL,\r\n  PRIMARY KEY (`id`),\r\n\r\n  KEY `id` (`id`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;\r\n\r\n--\r\n-- Dumping data for table `dbperfix_balance_lines`\r\n--\r\n\r\n\r\n-- --------------------------------------------------------\r\n\r\n--\r\n-- Table structure for table `dbperfix_news`\r\n--\r\n\r\nDROP TABLE IF EXISTS `dbperfix_news`;\r\nCREATE TABLE IF NOT EXISTS `dbperfix_news` (\r\n  `id` int(11) NOT NULL AUTO_INCREMENT,\r\n  `fld_date` date DEFAULT NULL,\r\n  `fld_title` varchar(255) DEFAULT NULL,\r\n  `fld_body` longtext,\r\n  `type` enum('1','3','4','2') CHARACTER SET latin1 DEFAULT '1',\r\n  `pdfurl` varchar(50) CHARACTER SET latin1 DEFAULT NULL,\r\n  `status` enum('0','1') CHARACTER SET latin1 DEFAULT '0',\r\n  `fld_language` varchar(18) CHARACTER SET latin1 DEFAULT NULL,\r\n  `related_id` int(11) DEFAULT NULL,\r\n  PRIMARY KEY (`id`)\r\n) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=268 ;\r\n\r\n--\r\n-- Dumping data for table `dbperfix_news`\r\n--\r\n\r\nINSERT INTO `dbperfix_news` (`id`, `fld_date`, `fld_title`, `fld_body`, `type`, `pdfurl`, `status`, `fld_language`, `related_id`) VALUES\r\n(1, '2009-01-01', 'FAQ', '<h2>How can I exchange one e-currency for another?</h2>\r\n<p>You can easily do it using our three-step exchange interface.<br /><strong><br />Step 1.</strong> Start the transaction by filling in the exchange form. You can order exchange even if you are not registered. <br />You select the source and destination e-currencies, type in either of the amounts, destination account number and your e-mail. <br /><br /><strong>Step 2.</strong> Check the details of your order, read and accept our User agreement, and confirm your order. <br /><br /><strong>Step 3.</strong> You''ll be redirected to the site of the e-currency system where you should make the payment. Also, you will get a confirmation email with the payment instructions and a link that you can use if you''d like to make the payment later. Please note that all the unpaid orders are cancelled in 1 hour. <br /><br />You can check the status of your transaction as you log in and enter our Members area (you will find the password in the email that we will send to you upon the confirmation of your order). <br />Normally, you''ll get your e-currency account funded within several minutes. <br /><br /></p>\r\n<h2>How can I sell or buy e-currency with you?</h2>\r\n<p>You must fill our currency order page: <a href=\"place_order.php?Action=currency_buy\">Buy e-currency</a><br /><br /></p>\r\n<h2>What does the commission I pay include?</h2>\r\n<p>After you have selected both the source and the destination e-currencies, you will see our commission displayed in the exchange form (it normally falls within the limits of 0-50%). Please take into account, however, that the commission total and, therefore, the final exchange rate include also the fees charged by the payment systems. <br /><br /><br /></p>\r\n<h2>What status can my order have?</h2>\r\n<p><strong>open</strong> - you have placed a new Order and you are welcome to make the specified spending. <br /><strong>received</strong> - we have received the money from you, according to your Order. <br /><strong>sent</strong> - we have sent money to the payee''s account. <br /><strong>closed</strong> - your Order is completed. <br /><strong>manual_processing</strong> - your Order will be processed by operator. <br /><strong>cancelled</strong> - the Order is cancelled by the User''s request. <br /><strong>expired</strong> - the Order has expired. This status is inherit from the status of ''open'' if the User has not made the specified spending within the said period of time. <br /><strong>declined</strong> - in case if we suspect fraud or other violation of the User agreement, we reserve the right to decline the transaction. <br /><strong>refunded</strong> - the money has been returned to the User. <br /><br /><br /></p>\r\n<h2>How many e-mails do I receive during the execution of an order?</h2>\r\n<p>Every time your order changes its status, our system informs of it by e-mail. Normally, this means that you receive three e-mails as follows: <br />Your Order has been accepted. The Order is Open.<br />We have received the money you sent us. The Order is being processed.<br />We have sent money to your destination account. The Order is complete <br /><br /><br /></p>\r\n<h2>Why should I register at [SITE_NAME]?!</h2>\r\n<p>You can access our exchange services without registration and logging in into the member area but for being our affiliate, update profile and receive our weekly newsletter you need to be registered.</p>', '2', '', '1', 'english', 1),\r\n(2, '2009-01-01', 'About us', '<p>A brief about your experienses, abilities, phone numbers and contact address .<br />Sample: <br /><span class=\"style20\"><span style=\"font-family: Geneva, Arial, Helvetica, san-serif;\">[SITE_NAME] Provider around the growing market of electronic currencies.<br /><br />Our services are Simple, Secure, Fast &amp; Efficient with Competitive Rates and gives our customer a quick, easy and most importantly, safe method to Buy ,Sell and Exchange their ecurrency.<br /><br /><strong>Phone Number: XX-XXXX-XXX<br />Fax Number: XX-XXXX-XXX<br />Address: ......<br />Icq: ...<br />Yahoo: ...<br />E-mail adress: .... </strong></span></span></p>', '2', '', '1', 'english', 2),\r\n(3, '2009-01-01', 'Terms of services', '<p>This Agreement sets forth the terms and conditions under which [SITE_NAME] provides its services. This Agreement describes the user''s rights and obligations when using these services. The User should read it carefully and make sure he/she understands these terms and conditions. [SITE_NAME] may change terms and conditions of this Agreement at any time at its sole discretion.</p><p>Use of any service provided by [SITE_NAME] means that the User accepts all the terms and conditions of this Agreement.</p><p>The parties to this Agreement are [SITE_NAME] and the User.</p><h4>Terms and Conditions</h4><ol><li>Definition of terms. <ul><li>\"[SITE_NAME]\" is the trademark and the name of the system owned by the Universal Valuables Ltd., Seychelles, accessible via Internet through the interface located at [SITE_URL]. </li><li>\"User\" is any visitor to the website [SITE_URL], who uses any services provided by [SITE_NAME] at his/her own free will. </li><li>\"E-currency\" is a non-interest bearing instrument, designed to circulate as a media of exchange. </li><li>\"Accepted e-currency\" is any e-currency listed at [SITE_URL] for which [SITE_NAME] provides its services. </li><li>\"Payment\" is the transfer of electronic or conventional currency from the payer to the payee. </li><li>\"Payment method\" is any of the means of funds transfer listed at [SITE_URL], including e-currency to e-currency transfer and bank wire transfer. </li></ul></li><li>[SITE_NAME] provides services of <ul><li>Exchanging of one accepted e-currency type for another. </li><li>Selling of accepted e-currency to the User, </li><li>Buying of accepted e-currency from the User. Certain restrictions may apply to particular operation types as listed at [SITE_URL]. </li></ul></li><li>[SITE_NAME] renders its services to any User of any e-currency system supported by the system. </li><li>By using services provided by [SITE_NAME], the User confirms that: <ul><li>The source and origin of funds and e-currencies involved in the transactions he/she orders are legal and do not fall under any local or international legal restrictions. </li><li>The User is authorized and has legal power to move the funds and e-currencies engaged in the transaction he/she orders. </li></ul></li><li>The information given by the user during the fulfillment of his/her order is confidential and shall not be disclosed to any third parties, unless requested to do so by law by appropriate authorities or by the administration of one of the payment systems involved. </li><li>[SITE_NAME] reserves the right to require the User to confirm his/her identity in order to verify that he/she does not break conditions listed in p. 4. If the User fails to comply with verification requirements, his/her order may be declined at the sole discretion of [SITE_NAME]. </li><li>If in order to complete a transaction [SITE_NAME] requires that the User''s banking accounts involved in it must be verified, and the User confirms the order, it means that he/she understands and agrees at his/her own free will that : <ul><li>the verification procedure may include gathering personal information and enquiries about his/her rights, legal power and authorization to access and control this banking account; </li><li>these actions do not violate his/her privacy; </li><li>the decision if verification succeeds or fails is taken by [SITE_NAME] at its sole discretion and is not subject to discussion or reviewing. </li></ul></li><li>Transactions effected by [SITE_NAME] are irrevocable. These transactions comply with the terms of service of the involved e-currency systems. </li><li>E-currency systems are solely responsible for their users&rsquo; assets entrusted to them. [SITE_NAME] service is no party to the agreement between an e-currency system and its user and in no case will be held liable for any misuse of any e-currency system. The rights and obligations of the user and the e-currency system are governed exclusively by the terms of service of the respective system. </li><li>[SITE_NAME] does not verify whether the sender and the receiver of e-currency or funds engaged in the transaction are the same entity or individual, but in no way [SITE_NAME] is responsible for interrelations between the sender and the receiver, does not act as intermediary and does not provide escrow services. </li><li>The User of [SITE_NAME] services agrees that [SITE_NAME] is only liable for the amount of funds involved in the transaction. </li><li>[SITE_NAME] provides its services \"as is\" and denies any other implied, express, or legislated warranties. [SITE_NAME] disavows any other obligation to the User. </li><li>[SITE_NAME] acts as a principal and as such it engages in transactions with the User on its own behalf. Exchange rates and fees are established by [SITE_NAME] and published at its website. These rates may be changed at the sole discretion of [SITE_NAME]. </li><li>Any fees or obligations related to the use of any e-currency system are considered to be the User''s sole responsibility. </li><li>[SITE_NAME] shall not be responsible for any delays or failures in the transmission, receipt or execution of orders or payments due to events beyond its control, including the events related to the payment systems. </li><li>The User is subject to all local, municipal, state, provincial, federal, and international laws and regulations. The User agrees that his activities shall not violate any of these laws or regulations. </li><li>The User''s rights to use the Service are individual. The User agrees not to resell or make any commercial use of the Service without the express consent of [SITE_NAME]. The User acknowledges that the content of [SITE_URL] website may be protected by copyrights, trademarks or other proprietary or personal rights and that the use of this content is governed by the laws which create those rights and provide for their enforcement. The User agrees not to forge communications transmitted through the Service. </li><li>Any tax consequences of [SITE_NAME] transactions are the sole responsibility of the User. </li><li>The User agrees to indemnify [SITE_NAME], its agents, affiliates, officers, directors and employees for any claim or demand whatsoever relating to or arising from the use of [SITE_NAME] services, except for any loss caused by negligence or willful misconduct of [SITE_NAME]. </li></ol>', '2', '', '1', 'english', 3),\r\n(4, '2009-01-01', 'Free Affiliate program', '<h2>[SITE_NAME] offers free affiliate program 10% for each exchange.</h2><p>[SITE_NAME] is introducing new affiliate program: you have unique opportunity to join our affiliate program and earn 10% for each exchange orders. You can start earning money today easily without spending months for training and be sure that [SITE_NAME] affiliate program will bring you profit in the nearest future. Become an affiliate and earn your commissions from your downline!</p><p><span style=\"VERTICAL-ALIGN: top; PADDING-TOP: 20px\"><h2><br />Get your own Exchange box</h2><p><p>Your own website is very simple to remember: [SITE_URL]/rid=1234 where 1234 is replaced with your account number. You should give this link to your friends, pals, partners, etc. in order to sign up for [SITE_NAME] account. Once they sign up&nbsp;- you will be able to track their activity and your commissions earned from each member in the Refferals page.</p></p></span></p><p><p>&nbsp;</p></p><p>&nbsp;</p><p>&nbsp;</p><h2>You never know</h2><p>You never know how many transactions they will make, what can bring you much profit. Do not loose this profitable business opportunity. [SITE_NAME] is growing and developing, offering new features within [SITE_NAME] online payment system and boosting new markets and countries, increasing your affiliation profit as well. Join [SITE_NAME] online affiliate program today. With this business opportunity you will get lucrative compensation plan. As a member of [SITE_NAME] marketing team you receive a marketing website the same as this one to promote your business.</p><h2><br />Affiliate making money online</h2><p>Participation is free for all [SITE_NAME] members and does not have regional, country, gender or even money!. To join our affiliate program you simply have to become our member - go to Sign Up, fill the online application and follow the instructions. You will get your [SITE_NAME] account instant and free. <br /><br /><span class=\"ErrorMessage\"><strong>NOTE: </strong></span>opening accounts one under another by the same person is prohibited and will not comply with the terms. <br /><br /><a href=\"signup.php\">Click here</a> to open your [SITE_NAME] account now.</p>', '2', '', '1', 'english', 4),\r\n(5, '2009-01-01', 'Affiliate Links', '<p>Place your banners or links here:<br /><br /> \r\nAnd use this code in your template : <br /> <span style=\"font-size:10px\"><u>&lt;a href=''&#123;dynamic_link:&quot;Affiliate Links&quot;&#125;''&gt;Affiliate Links&lt;/a&gt;</u></span><br /> <br /> \r\nSample link: <a href=''{dynamic_link:\"Affiliate Links\"}''>Affiliate Links</a>', '2', '', '1', 'english', 5);\r\n\r\n-- --------------------------------------------------------\r\n\r\n--\r\n-- Table structure for table `dbperfix_referals`\r\n--\r\n\r\nDROP TABLE IF EXISTS `dbperfix_referals`;\r\nCREATE TABLE IF NOT EXISTS `dbperfix_referals` (\r\n  `id` bigint(20) NOT NULL AUTO_INCREMENT,\r\n  `uid` bigint(20) NOT NULL DEFAULT '0',\r\n  `uid_referal` bigint(20) NOT NULL DEFAULT '0',\r\n  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',\r\n  PRIMARY KEY (`id`),\r\n  UNIQUE KEY `id_referal` (`uid_referal`),\r\n  KEY `id` (`id`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;\r\n\r\n--\r\n-- Dumping data for table `dbperfix_referals`\r\n--\r\n\r\n\r\n-- --------------------------------------------------------\r\n\r\n--\r\n-- Table structure for table `dbperfix_settings`\r\n--\r\n\r\nDROP TABLE IF EXISTS `dbperfix_settings`;\r\nCREATE TABLE IF NOT EXISTS `dbperfix_settings` (\r\n  `setting` varchar(255) NOT NULL DEFAULT '',\r\n  `value` text NOT NULL,\r\n  `type` varchar(255) DEFAULT NULL\r\n) ENGINE=MyISAM DEFAULT CHARSET=utf8;\r\n\r\n--\r\n-- Dumping data for table `dbperfix_settings`\r\n--\r\n\r\nINSERT INTO `dbperfix_settings` (`setting`, `value`, `type`) VALUES\r\n('SITE_URL', '', 'char'),\r\n('SITE_URL_SECURE', '', 'char'),\r\n('SITE_NAME', '', 'char'),\r\n('ADMIN_MAIL', 'support@domain.com', 'char'),\r\n('REPORT_MAIL', 'noreply@domain.com', 'char'),\r\n('EXCHANGE_REF_COMISSION', '10', 'integer'),\r\n('MIN_EXCHANGE_FEE', '0', 'integer'),\r\n('DEF_LANGUAGE', 'english', 'char'),\r\n('SITE_TEMPLATE', 'default', 'char'),\r\n('LANGUAGE_MENU', '1', 'enum'),\r\n('NEWS_NUMBER', '4', 'integer'),\r\n('recordsnumperpage', '20', 'integer'),\r\n('caching_status', '0', 'enum'),\r\n('keys_folder', 'hsh_bnk/keys', 'char'),\r\n('EXCLUDE_CURRENCIES', '', 'char'),\r\n('temporary_close', '0', 'enum'),\r\n('FRIENDLY_URL', '0', 'enum'),\r\n('MAIL_FORMAT', 'html', 'char'),\r\n('adminemailnotification', '1', 'enum'),\r\n('adminloginlimitip', '', 'char'),\r\n('secretadminlogin', '', 'char'),\r\n('FULL_REGISTRATION', '0', 'enum'),\r\n('LOGIN_TURNING', '0', 'enum'),\r\n('SUPPORT_TURNING', '0', 'enum'),\r\n('SIGNUP_TURNING', '0', 'enum'),\r\n('tinymce_editor', '1', 'enum'),\r\n('MAIL_TYPE', 'smtp', 'enum'),\r\n('MAIL_SMTP_PORT', '25', 'char'),\r\n('MAIL_SMTP_USER', '', 'char'),\r\n('MAIL_SMTP_PASS', '', 'char'),\r\n('MAIL_SMTP_HOST', '', 'char'),\r\n('REPORT_MAIL_NAME', 'No Reply', 'char');\r\n\r\n\r\n-- --------------------------------------------------------\r\n\r\n--\r\n-- Table structure for table `dbperfix_users`\r\n--\r\n\r\nDROP TABLE IF EXISTS `dbperfix_users`;\r\nCREATE TABLE IF NOT EXISTS `dbperfix_users` (\r\n  `uid` bigint(20) NOT NULL AUTO_INCREMENT,\r\n  `login` varchar(32) NOT NULL DEFAULT '',\r\n  `password` varchar(255) NOT NULL DEFAULT '****************',\r\n  `permit` char(1) NOT NULL DEFAULT 'i',\r\n  `status` enum('0','1','2') NOT NULL DEFAULT '0',\r\n  `ip` varchar(16) NOT NULL DEFAULT '',\r\n  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',\r\n  `language` varchar(16) NOT NULL DEFAULT 'english.inc.php',\r\n  `session_id` varchar(32) DEFAULT NULL,\r\n  `compound` smallint(6) DEFAULT '0',\r\n  PRIMARY KEY (`uid`),\r\n  UNIQUE KEY `login` (`login`),\r\n  KEY `uid` (`uid`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;\r\n\r\n--\r\n-- Dumping data for table `dbperfix_users`\r\n--\r\n\r\n\r\n-- --------------------------------------------------------\r\n\r\n--\r\n-- Table structure for table `dbperfix_users_details`\r\n--\r\n\r\nDROP TABLE IF EXISTS `dbperfix_users_details`;\r\nCREATE TABLE IF NOT EXISTS `dbperfix_users_details` (\r\n  `uid` bigint(20) NOT NULL DEFAULT '0',\r\n  `uid_referer` bigint(20) NOT NULL DEFAULT '0',\r\n  `fullname` varchar(64) CHARACTER SET utf8 DEFAULT NULL,\r\n  `money_account` varchar(64) DEFAULT NULL,\r\n  `cid` tinyint(4) DEFAULT '1',\r\n  `email` varchar(64) NOT NULL DEFAULT '',\r\n  `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',\r\n  `suspended` enum('0','1') DEFAULT '0',\r\n  `alt_password` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',\r\n  `compound_pct_rate` int(2) NOT NULL DEFAULT '0',\r\n  `Phone` varchar(32) DEFAULT NULL,\r\n  `Zip` varchar(32) DEFAULT NULL,\r\n  `State` varchar(4) DEFAULT NULL,\r\n  `City` varchar(12) DEFAULT NULL,\r\n  `StreetAddress` varchar(32) DEFAULT NULL,\r\n  `Country_short` varchar(4) DEFAULT NULL,\r\n  `click_counter` int(11) NOT NULL DEFAULT '0',\r\n  UNIQUE KEY `uid` (`uid`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=latin1;\r\n\r\n--\r\n-- Dumping data for table `dbperfix_users_details`\r\n--\r\n\r\n\r\n-- --------------------------------------------------------\r\n\r\n--\r\n-- Table structure for table `dbperfix_users_logs`\r\n--\r\n\r\nDROP TABLE IF EXISTS `dbperfix_users_logs`;\r\nCREATE TABLE IF NOT EXISTS `dbperfix_users_logs` (\r\n  `id` bigint(20) NOT NULL AUTO_INCREMENT,\r\n  `uid` bigint(20) NOT NULL DEFAULT '0',\r\n  `ip` varchar(16) NOT NULL DEFAULT '',\r\n  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',\r\n  `login_attempts` int(11) NOT NULL DEFAULT '0',\r\n  `logout_date` datetime DEFAULT NULL,\r\n  `session_id` varchar(32) DEFAULT NULL,\r\n  PRIMARY KEY (`id`),\r\n  KEY `id` (`id`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;\r\n\r\n\r\n--\r\n-- Table structure for table `dbperfix_order_lines`\r\n--\r\n\r\nCREATE TABLE IF NOT EXISTS `dbperfix_order_lines` (\r\n  `oid` int(11) NOT NULL AUTO_INCREMENT,\r\n  `uid` int(11) DEFAULT '0',\r\n  `cid` tinytext,\r\n  `order_amount` double DEFAULT NULL,\r\n  `currency_account` tinytext,\r\n  `account_name` text,\r\n  `email_address` text,\r\n  `payment_method` text,\r\n  `dst_amount` double DEFAULT NULL,\r\n  `full_name` text,\r\n  `phone_number` text,\r\n  `country` text,\r\n  `order_detail` longtext,\r\n  `dst_status` enum('7','6','5','4','3','2','1','0') DEFAULT '0',\r\n  `src_status` enum('7','6','5','4','3','2','1','0') DEFAULT '0',\r\n  `order_date` datetime DEFAULT NULL,\r\n  `order_note` varchar(255) DEFAULT NULL,\r\n  `order_type` text,\r\n  `dst_date` datetime DEFAULT NULL,\r\n  `src_date` datetime DEFAULT NULL,\r\n  PRIMARY KEY (`oid`)\r\n) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;\r\n\r\n--\r\n-- Dumping data for table `dbperfix_order_lines`\r\n--\r\n\r\n";
echo "\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\r\n<html>\r\n\t<head>\r\n\t\t<title>Auto-Exchanger Installation : ";
echo $step;
echo "</title>\r\n";
echo "<s";
echo "tyle>\r\n*{\r\n\tpadding: 0px;\r\n\tmargin: 0px;\r\n}\r\nbody\r\n{\r\n\tbackground-color: #EEEEEE;\r\n\tfont-family: arial;\r\n\tfont-size: 100%; /* Enables font size scaling in MSIE */\r\n\tmargin: 0px;\r\n\tpadding: 0px;\r\n\tmargin-top:27px;\r\n\ttext-align: center;\r\n\r\n}\t\t\r\ndiv#container\t\t\r\n{\r\n\r\n\tdisplay:block;\r\n\tmargin: 1em auto;\r\n\twidth: 807px;\r\n\ttext-align: left;\r\n}\r\n\r\n.header \r\n{\r\n\tbackground-position: left top;\r\n\tbackground";
echo "-image: url(images/instal_header.gif);\r\n\theight: 124px;\r\n\r\n}\r\n.header .steps\r\n{\r\n\tposition: relative;\r\n\tfloat: left;\r\n\twidth: 800px;\r\n\ttop: 72px;\r\n\tleft: 4px;\r\n\tfont-size: 24px;\r\n\tline-height: normal;\r\n\tcolor:#F4F87C;\r\n\tmargin:0; padding-bottom:0;\r\n\t\r\n\tfont-variant:small-caps;\r\n\tpadding-left:20px;\r\n\tfont-family:Arial, Helvetica, sans-serif;\r\n}\r\n\r\n.footer{\r\n\tpadding:10px;\r\n\tcolor:#F9F9F9;\r\n    clea";
echo "r: both;\r\n\tbackground-position: left top;\r\n\tbackground-image: url(images/install_footer.gif);\r\n\tbackground-repeat: no-repeat;\r\n\theight: 94px;\r\n\tborder-bottom: 2px solid #e7e7e7;\r\n}\r\n.footer a\r\n{\r\n\tcolor: #fff;\r\n\ttext-decoration: none;\r\n}\r\n\r\n#content{\r\n    \r\n\r\n}\r\n* html body div#content  /*ie hack*/\r\n{\r\n\tpadding-left:0px;\r\n}\r\n.content_container{\r\n    padding:0 24px 0 24px;\r\n    padding-bottom:20px;";
echo "\r\n    margin-top: -20px;\r\n    padding-top: 10px;\r\n    background-color: #fff;\r\n    font-size: 12px;\r\n}\r\n.content_container ul\r\n{\r\n\tposition: relative;\r\n\tpadding-left: 24px;\r\n\tpadding-bottom: 12px;\r\n}\r\n\r\np {\r\n\tmargin-top: 10px;\r\n\tmargin-bottom: 10px;\r\n\t\r\n}\r\n.success_message{font-size:12px; color:#009900; font-weight:bold}\r\n.error_box\r\n{\r\n\tborder: 1px solid #992A2A;\r\n\tcolor: #992A2A;\r\n\tpadding: 6px;";
echo "\r\n\tbackground-color: #F2DDDD;\r\n\tfont-weight: bold;\r\n\tfont-size: 12px;\r\n\t-moz-border-radius: 5px;\r\n\tmargin:0 5px 5px 0;\r\n\tline-height:24px;\r\n}\r\n\r\n.error_box p\r\n{\t\r\n\tfont-weight: bold;\r\n\tfont-size: 16px;\r\n\tborder-bottom: 1px solid #C80000;\r\n\tbackground-color: #F2DDDD;\r\n\t\r\n\r\n}\r\nbody, table, tr, td, a, p, h1, h2, h3, h4, h5 { font-family: Tahoma, Arial, verdana, sans-serif; margin:0; padding:0; font-s";
echo "ize: 12px;}\r\nh1, h2, h3, h4, h5, h6 {  margin:0;padding:0;font-weight:normal;}\r\nh1{ font-size:24px; font-weight:bold; font-family:Garamond, Georgia, serif; margin:6px; color:#3266A9}\r\nh2{ font-size:17px; color:#945A03; line-height:24px; padding-top:10px;}\r\nh3{ font-size:14px; font-family:Arial;}\r\nform{padding:0;margin:0;}\r\nselect, input, textarea, password{ border: 1px solid #C2C0C0; background-co";
echo "lor: #FFFFFF; font-family: Arial,helvetica,sans-serif; font-size: 12px;}\r\nselect{ font-size: 13px; height:24px; }\r\ninput{ border: 1px solid #CCCCCC; height: 21px; }\r\ninput.button{\r\n   color:#0B0B0B;\r\n   font-size:100%;\r\n   font-weight:bold;\r\n   BORDER: #0c4b9c 1px solid;\r\n   padding:0 8px 0 8px;\r\n   margin:3px 5px 0 5px;\r\n   height:22px;\r\n   background-color:#F7F7F7;\r\n\r\n}\t\r\n\r\n</style>\r\n";
$CONFIG['SITE_URL'] = "auto-exchanger.com";
$CONFIG['SITE_URL_FULL'] = "http://www.auto-exchanger.com";
$CONFIG['SITE_NAME'] = "Auto-Exchanger ";
$CONFIG['ADMIN_MAIL'] = "support@auto-currency.com";
$CONFIG['PRODUCT_NAME'] = "Auto Exchanger ";
$CONFIG['COMPANY'] = "Protect Host Media Inc.";
$Success = array( );
$Error = array( );
if ( !file_exists( "../include/vars.inc.php" ) || !file_exists( "../include/function.fmt.inc.php" ) )
{
    exit( "Please upload site package completely.</b>" );
}
if ( !file_exists( "../configuration.php" ) )
{
    exit( "Rename <b>configuration.php.rename</b> in root to <b>configuration.php</b>" );
}
include( "../include/vars.inc.php" );
include( "../include/function.fmt.inc.php" );
if ( !$_POST[step] )
{
    include( "../configuration.php" );
    if ( $hostname && $database && $db_login && $db_pass )
    {
        $_POST[step] = 5;
        $Error[] = "Already Installed.";
    }
}
$title = "License agreement";
$next_button_name = "Countinue";
$step = 1;
if ( $_POST[step] == 1 )
{
    $step = 1;
    if ( !$_POST[toc_agree] )
    {
        $Error[] = "You must agree to the license in order to continue!";
    }
    else
    {
        $step = 2;
        $next_button_name = "Begin Installation";
        $title = "System software compability check";
    }
}
else if ( $_POST[step] == 2 )
{
    $step = 2;
    if ( $_POST['error'] )
    {
        $Error[] = "You need to fix current errors before going next step.";
        $next_button_name = "Try Again";
    }
    else
    {
        $step = 3;
        $next_button_name = "Next >>";
        $title = "Validate license key & create database";
    }
}
else if ( $_POST[step] == 3 )
{
    $step = 3;
    if ( $_REQUEST['licensekey'] == "Nulled By AtakanCan" )
    {
        $Error[] = "Please enter your valid license key and try again.";
    }
    if ( !$Error )
    {
        if ( !get_license_info( "install", $_REQUEST['licensekey'] ) )
        {
            $Error[] = "Auto-Exchanger can not be installed untill you provide valid license key.";
        }
        else
        {
            $testlink = mysql_connect( $_POST['hostname'], $_POST['db_login'], $_POST['db_pass'] );
            if ( !$testlink )
            {
                $Error[] = "Mysql error: ".mysql_error( );
            }
            else
            {
                $db_selected = mysql_select_db( $_POST['database'], $testlink );
                if ( !$db_selected )
                {
                    $Error[] = "Mysql error: ".mysql_error( );
                }
                mysql_close( $testlink );
            }
        }
        if ( !$Error )
        {
            $output = "<?php\r\n\$license=\"".$_POST['licensekey']."\";\r\n\$hostname = \"".$_POST['hostname']."\";\r\n\$db_login = \"".$_POST['db_login']."\";\r\n\$db_pass = \"".$_POST['db_pass']."\";\r\n\$database = \"".$_POST['database']."\";\r\n\$db_prefix = \"".$_POST['db_perfix']."\";\r\n//-------------------------\r\n?>";
            $fp = fopen( "../configuration.php", "w" );
            fwrite( $fp, $output );
            fclose( $fp );
            $Success[] = "Your license key verified successfully.";
            if ( @chmod( "../configuration.php", 420 ) )
            {
                $Success[] = "Configuration.php status changed to read only successfully.";
            }
        }
        include( "../configuration.php" );
        $link = @mysql_connect( $hostname, $db_login, $db_pass );
        if ( !mysql_select_db( $database ) && !$Error )
        {
            $Error[] = "Could not connect to the database - check the database connection details you entered and correct them if necessary";
        }
        else if ( !$Error )
        {
            $arr_cur_page = get_url( );
            $sql_url = str_replace( "index.php", "sql_lines.php", $arr_cur_page['url'] );
            if ( parse_mysql_dump_install( $sql_url, $db_prefix ) )
            {
                $Success[] = "Database create successfully.";
            }
            else
            {
                $fp = fopen( "../configuration.php", "w" );
                fwrite( $fp, $output );
                fclose( $fp );
            }
        }
        if ( !$Error )
        {
            $step = 4;
            $next_button_name = " Finish ";
            $title = "Create superuser account";
        }
    }
}
else if ( $_POST[step] == 4 )
{
    $step = 4;
    if ( !$_POST[fullname] )
    {
        $Error[] = "Write admin Full name";
    }
    if ( !$_POST[email] )
    {
        $Error[] = "Write admin E-mail address";
    }
    if ( !$_POST[username] || strlen( $_POST[username] ) < 6 )
    {
        $Error[] = "Enter admin Username again, can not be less than 6 character";
    }
    if ( !$_POST[password] || strlen( $_POST[password] ) < 6 )
    {
        $Error[] = "Enter admin Password again, can not be less than 6 character";
    }
    include( "../configuration.php" );
    $link = mysql_connect( $hostname, $db_login, $db_pass );
    if ( !mysql_select_db( $database ) )
    {
        $Error[] = "Could not connect to the database - check the database connection details you entered and correct them if necessary";
    }
    else if ( !$Error )
    {
        $arr_cur_page = get_url( );
        $this_site_url = str_replace( "/install/index.php", "", $arr_cur_page['url'] );
        $v_password = crypt( $_POST[password] );
        $_users = $db_prefix."users";
        $_users_details = $db_prefix."users_details";
        $_settings = $db_prefix."settings";
        if ( !( $result = mysql_query( "insert into {$_users} (login,password,permit,status,ip,date) values ('{$_POST['username']}','{$v_password}','{$PMT_INFO_ADMIN}', '{$STATUS_ENUM_ENABLE}','{$_SERVER['REMOTE_ADDR']}',now())" ) ) )
        {
            $Error[] = mysql_error( );
        }
        $uid = mysql_insert_id( );
        if ( !( $result = mysql_query( "insert into {$_users_details} (uid,fullname,email,reg_date) values ('{$uid}','{$_POST['fullname']}','{$_POST['email']}',now())" ) ) )
        {
            $Error[] = mysql_error( );
        }
        if ( !( $result = mysql_query( "UPDATE {$_settings} SET value='{$this_site_url}' WHERE setting='SITE_URL'" ) ) )
        {
            $Error[] = mysql_error( );
        }
        if ( !( $result = mysql_query( "UPDATE {$_settings} SET value='{$_POST['email']}' WHERE setting='ADMIN_MAIL'" ) ) )
        {
            $Error[] = mysql_error( );
        }
        if ( !$result )
        {
            $Error[] = "MySql error ,please try again or contact our support team (support@auto-currency.com)";
        }
    }
    if ( $result && !$Error )
    {
        $step = 5;
        $title = "Congratulations! installation complete successfully.";
    }
}
else if ( $_POST[step] == 5 )
{
    $step = 5;
    $Success[] = "Installation complete successfully.";
    if ( !chmod( "../configuration.php", 420 ) )
    {
        $Error[] = "DO NOT forget to change Configuration.php status to 644 or readonly, for security reason.";
    }
    if ( is_dir( "../install" ) )
    {
        $Error[] = "You must delete install folder for security reasons.";
    }
}
echo "\t\r\n<meta http-equiv=\"Content-Type\" content=\"text/html;charset=utf-8\">\r\n</head>\r\n\t<body>\r\n<div id=\"container\">\r\n\r\n\t<div class=\"header\"><div class=\"steps\"><b style=\"color:#EFEFEF\">Step ";
echo $step;
echo "</b> - ";
echo $title;
echo "</div></div>\r\n\t<div id=\"content\">\r\n\t  <div class=\"content_container\">\r\n\t\t<form id='install-form' action='";
echo $_SERVER['PHP_SELF'];
echo "' method='post'>\r\n\t\t\t<input type='hidden' name='step' value='";
echo !$step ? 1 : $step;
echo "' />\r\n\r\n\r\n\t  ";
if ( $Success )
{
    echo "<div class=success_message>";
    foreach ( $Success as $value )
    {
        echo $value."<br>";
    }
    echo "</div>";
}
echo "\t  ";
if ( $Error )
{
    echo "<div class=\"error_box\"><p>Error occurred:</p>";
    foreach ( $Error as $value )
    {
        echo $value."<br>";
    }
    echo "</div>";
}
echo "\t  <br>\r\n\t  \r\n\t  \r\n";
if ( $step == 1 )
{
    echo "    \r\n\t  \r\n\t  \r\n\r\n\t\t\t\t\t\r\n\t\t\t<h2>";
    echo $CONFIG['PRODUCT_NAME'];
    echo " Installation:  v";
    echo $CONFIG['Version'];
    echo "</h2>\r\n\t\t\t<p>";
    echo $CONFIG['SITE_URL'];
    echo "<br />\r\n\t\t\t";
    echo $CONFIG['PRODUCT_NAME'];
    echo " Software<br />\r\n\t\t\tEnd User License Agreement</p>\r\n\t\t\t\r\n\t\t\t<p><h2>LICENSE</h2>";
    echo $CONFIG['SITE_URL'];
    echo " grants you a non-exclusive license to use the ";
    echo $CONFIG['PRODUCT_NAME'];
    echo " Software \r\n\t\t\tthrough one installation on one domain name only, subject to the provisions of this License Agreement in it's entirety.</p>\r\n\t\t\t\r\n\t\t\t<p><h2>TERM</h2>";
    echo $CONFIG['PRODUCT_NAME'];
    echo " Software is offered under multiple licensing arrangements, including licenses that must be \r\n\t\t\trenewed and licenses that do not require renewal.  Your license agreement can be changed at any time\r\n\t\t\tfor any reason, as necessary and applicable.  The current copy of our license agreement can always be found on our website,\r\n\t\t\tand is available upon request.<br />\r\n\t\t\tIf your license expires and yo";
    echo "u choose not to renew it, the software will remain functional.<br />\r\n\t\t\tShould you allow your license to expire, technical support and updates will NOT be available to you.<br />\r\n\t\t\tTechnical support licensing arrangements can be included with your software purchase, and/or purchased separately.</p>\r\n\t\t\t\r\n\t\t\t<p><h2>SCOPE OF GRANT</h2>\r\n\t\t\t<dl>\r\n\t\t\t\t<dt><em>You may:</em></dt>\r\n\t\t\t\t<dd>\r\n\t\t\t\t\t<ul>\r\n\t\t\t\t\t<li> Us";
    echo "e the software for it's original purpose as intended</li>\r\n\t\t\t\t\t<li> Configure the software as allowed through the web interface</li>\r\n\t\t\t\t\t<li> Produce and distribute html skin changes for any skinnable sections, translate displayed (viewable from the web\r\n\t\t\t\t\t\t interface) strings to any desired language, and modify any sections of code that are not encoded</li>\r\n\t\t\t\t\t<li> Create applications which in";
    echo "terface and/or enhance the software</li>\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t</dd>\r\n\t\t\t\t<dt><em>You may not:</em></dt>\r\n\t\t\t\t<dd>\r\n\t\t\t\t\t<ul> \r\n\t\t\t\t\t<li> Share, distribute, sub-license, sell, or otherwise permit any other individuals to access of the software except under the terms listed above</li>\r\n\t\t\t\t\t<li> Reverse engineer, disassemble, or create derivative works based on the software for distribution or usage outside of the ";
    echo "domain your software is licensed to</li>\r\n\t\t\t\t\t<li> Use the software on more than one domain name or installation without a separate license key for each domain</li>\r\n\t\t\t\t\t<li> Use the software in any fashion that violates the laws of your country, or the United States of America</li>\r\n\t\t\t\t\t<li> Alter or remove any copyright notices of this software from any files, or from any of your web pages</li>\r\n\t\t\t";
    echo "\t\t<li> Distribute any portion of the software to any person other than the license holder</li>\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t</dd>\r\n\t\t\t</dl></p>\r\n\t\t\t\r\n\t\t\t<p><h2>DISCLAIMER OF WARRANTY</h2>The software is provided on an \"AS IS\" \r\n\t\t\tbasis, without warranty of any kind, including, without limitation, the \r\n\t\t\twarranties of merchantability, fitness for a particular purpose, and \r\n\t\t\tnon-infringement. The entire risk as to";
    echo " the quality, security, and performance of \r\n\t\t\tthe software is borne by you. You assume all responsibilities in using the software. \r\n\t\t\tThis disclaimer of warranty constitutes an essential part of the License Agreement.</p>\r\n\t\t\t\r\n\t\t\t<p><h2>TITLE</h2>Title, ownership rights, and intellectual property \r\n\t\t\trights in the software shall remain with ";
    echo $CONFIG['SITE_URL'];
    echo " (";
    echo $CONFIG['COMPANY'];
    echo "). The software is protected \r\n\t\t\tby copyright laws and treaties.</p>\r\n\t\t\t\r\n\t\t\t<p><h2>TERMINATION</h2>This software, the information, code and/or executables as well as the accompanying files provided are provided \"as is\" \r\nwithout warranty of any kind, either expressed or implied, including but not limited to the implied warranties of \r\nmerchantability and fitness for a particular purpose. In no even";
    echo "t shall the author or seller be liable for any damages \r\nwhatsoever including direct, indirect, incidental, consequential, loss of data, loss of business profits or special damages, \r\neven if the author or seller has been advised of the possibility of such damages. Good data processing procedure dictates \r\nthat any program be thoroughly tested with non-critical data before relying on it. The user ";
    echo "must assume the entire risk of \r\nusing the program. </p>\r\n\t\t\t\r\n\t\t\t<p><h2>MISCELLANEOUS</h2>";
    echo $CONFIG['SITE_URL'];
    echo " reserves the right to publish a selected \r\n\t\t\tlist of users of the software. ";
    echo $CONFIG['SITE_URL'];
    echo " (";
    echo $CONFIG['COMPANY'];
    echo ") reserves the right to change the \r\n\t\t\tterms of this Agreement at any time. Changes to the Agreement will be \r\n\t\t\tposted on our website, and available upon request.  Additionally, all customers \r\n\t\t\twho have provided us with a current, valid email address will be notified through \r\n\t\t\temails from ";
    echo $CONFIG['SITE_URL'];
    echo ". Failure to receive notification of a change does not \r\n\t\t\trender any changes to the license agreement invalid. A current copy of this Agreement \r\n\t\t\twill be available on the ";
    echo $CONFIG['SITE_URL'];
    echo " web site.</p>\r\n\t\t\t\r\n\t\t\t<p><h2>GOVERNING LAW</h2>This Agreement shall be governed by the Laws of \r\n\t\t\tthe State of Lousiana and the Laws of the United States of \r\n\t\t\tAmerica. Any action that violates or questios any provision of this Agreement shall be \r\n\t\t\tinstituted and litigated in the State of Lousiana. Each party bound by this Agreement \r\n\t\t\thereby consents to said jurisdiction and agrees that se";
    echo "rvice of process as provided by the \r\n\t\t\tstates and rules of civil procedures of the State of Lousiana shall be sufficient.</p>\r\n\t\t\t\r\n\t\t\t<p><h2>MANUFACTURER</h2>\r\n\t\t  For questions or comments, please email us \r\n\t\t\tat: <a href='mailto:sales@auto-currency.com'>sales@auto-currency.com</a>.</p>\r\n\t\t\t\r\n\t\t\t<br />\r\n\t\t\t<p>";
    echo "<s";
    echo "trong>I agree to this License Agreement</strong>&nbsp;<input type='checkbox' name='toc_agree' value='1' /></p>\r\n\r\n\t\t\t\t\t\r\n\t\t\t\r\n\t  \r\n";
}
else if ( $step == 2 )
{
    echo "\r\n\r\n\r\n<p><h2>SYSTEM CHECK</h2>\r\n<h3>\r\n";
    $systemcheck = true;
    if ( $systemcheck )
    {
        echo "<br><b>General Info</b><br>".$CONFIG['PRODUCT_NAME']." Version: ".$CONFIG['Version']."<br>PHP Version: ".phpversion( )."<br>Server Software: ".$_SERVER['SERVER_SOFTWARE']."<br><br><b>System Requirement Checks</b><br>PHP Version: ";
        if ( "4.2.0" <= phpversion( ) )
        {
            echo "<font color=#006600><b>Passed</b></font>";
        }
        else
        {
            echo "<font color=#990000><b>Needs Upgrading</b>, Your PHP version needs to be upgraded to at least V4.2.0 before you can use ".$CONFIG['PRODUCT_NAME'].".</font>";
            $error = "1";
        }
        echo "<br>SHA256: ";
        if ( check_sha256( ) )
        {
            echo "<font color=#006600><b>Passed</b></font>";
        }
        else
        {
            echo "<font color=#FF9933><b>Needs installation</b>, sha256 is not installed you need that to install sha256 to enable accept and payout via libertyreserve system.</font>";
        }
        echo "<br>MySQL Version: ";
        if ( function_exists( "mysql_connect" ) )
        {
            echo "<font color=#006600><b>Passed</b></font>";
        }
        else
        {
            echo "<font color=#990000><b>Not Installed</b>, MySQL support is not available in this PHP installation.  It is required by ".$CONFIG['PRODUCT_NAME']." for it to function.</font>";
            $error = "1";
        }
        echo "<br>CURL: ";
        if ( function_exists( "curl_init" ) )
        {
            echo "<font color=#006600><b>Passed</b></font>";
        }
        else
        {
            echo "<font color=#990000><b>Not Installed</b>, You must have CURL installed with SSL Support for WHMCS to function correctly<font>";
            $error = "1";
        }
        echo "<br><br><b>Permissions Checks</b><br>Configuration File: ";
        if ( is_writable( "../configuration.php" ) )
        {
            echo "<font color=#006600><b>Passed</b></font>";
        }
        else
        {
            echo "<font color=#990000><b>configuration.php is not Writeable</b>, You must set permissions for the configuration.php file so it can be written to (CHMOD 777)</font>";
            $error = "1";
        }
        echo "<br>Templates Folder Permissions: ";
        if ( is_writable( "../_skins_tmp/" ) )
        {
            echo "<font color=#006600><b>Passed</b></font>";
        }
        else
        {
            echo "<font color=#990000><b>_skins_tmp folder is not Writeable</b>, You must set permissions for the <u>_skins_tmp</u> folder so it can be written to (CHMOD 777)</font>";
            $error = "1";
        }
    }
    echo "<input type=\"hidden\" name=\"error\" value=\"";
    echo $error;
    echo "\" />\r\n</h3>\r\n</p>\r\n\r\n";
}
else if ( $step == 3 )
{
    echo " \r\n<p>";
    echo "<s";
    echo "trong>License Key</strong>\r\n\r\n<p>Enter you license key if you didn't buy software yet please order from <a href=\"";
    echo $CONFIG['SITE_URL_FULL'];
    echo "\">here</a>.\r\nIf your key is invalid, the ";
    echo $CONFIG['PRODUCT_NAME'];
    echo " software will not install and function on your site. \r\n<TABLE>\r\n  <TBODY>\r\n    <TR>\r\n      <TD width=\"120\">License Key</TD>\r\n      <TD><INPUT name=\"licensekey\" size=\"80\"></TD>\r\n    </TR>\r\n  </TBODY>\r\n</TABLE>\r\n<br />\r\n<br />\r\n<p>";
    echo "<s";
    echo "trong>Database Connection Details</strong></p>\r\n<p>You must now create a MySQL database in your control panel and assign a user   to it. Once this is complete, enter the connection details below.</p>\r\n<TABLE>\r\n  <TBODY>\r\n    <TR>\r\n      <TD width=\"120\">Database Host</TD>\r\n      <TD><INPUT name=\"hostname\" value=\"";
    echo $_POST['hostname'] ? $_POST['hostname'] : "localhost";
    echo "\" style=\"width:150px;\"></TD>\r\n    </TR>\r\n    <TR>\r\n      <TD>Database Name</TD>\r\n      <TD><INPUT name=\"database\" style=\"width:150px;\"></TD>\r\n    </TR>\r\n    <TR>\r\n      <TD>Database Username</TD>\r\n      <TD><INPUT name=\"db_login\" style=\"width:150px;\"></TD>\r\n    </TR>\r\n    <TR>\r\n      <TD>Database Password</TD>\r\n      <TD><INPUT name=\"db_pass\" type=\"password\" style=\"width:150px;\"></TD>\r\n    </TR>\r\n\t<TR>\r\n      <TD>Table Na";
    echo "me Prefix:</TD>\r\n      <TD><INPUT name=\"db_perfix\" id=\"db_perfix\" value=\"";
    echo !$_POST['db_perfix'] ? "autoex_" : "";
    echo "\" style=\"width:150px;\"></TD>\r\n    </TR>\r\n  </TBODY>\r\n</TABLE>\t  \r\n\t  \r\n\t  \r\n\t  \r\n\r\n\r\n";
}
else if ( $step == 4 )
{
    echo "  \r\n\t  \r\n\t  \r\n<H2>Setup Administrator Account</H2><br>\r\n  <p>Please use the form below to create your Superuser account.</p>\r\n  <TABLE>\r\n    <TBODY>\r\n      <TR>\r\n        <TD width=\"120\">Full Name:</TD>\r\n        <TD><INPUT name=\"fullname\" id=\"fullname\" value=\"";
    echo $_POST['fullname'];
    echo "\"></TD>\r\n      </TR>\r\n      <TR>\r\n        <TD>Email:</TD>\r\n        <TD><INPUT name=\"email\" value=\"";
    echo $_POST['email'];
    echo "\"></TD>\r\n      </TR>\r\n      <TR>\r\n        <TD>Username(admin):</TD>\r\n        <TD><INPUT name=\"username\">\r\n          Can not be less than 6 character. </TD>\r\n      </TR>\r\n      <TR>\r\n        <TD>Password(admin):</TD>\r\n        <TD nowrap=\"nowrap\"><INPUT type=\"password\" value=\"\" name=\"password\">\r\n          Can not be less than 6 character. </TD>\r\n      </TR>\r\n    </TBODY>\r\n  </TABLE>\t  \r\n\t  \r\n\t  \r\n\t  \r\n\t  \r\n";
}
else if ( $step == 5 )
{
    echo "  \r\n\t  \r\n\t  \r\n\t  \r\n\t  \r\n<H2>";
    echo $CONFIG['PRODUCT_NAME'];
    echo " Installation:  v";
    echo $CONFIG['Version'];
    echo "</H2>\r\n<br>\r\n<p>&nbsp;</p>\r\n<p><font color=#006600 size=\"+1\"><b>Setup  complete successfully.</b></font></p>\r\n<p><br />\r\n  <br />\r\n  <br />\r\n  Please don't forget to complete folowing steps:<br />\r\n  <br />\r\n</p>\r\n<p>";
    echo "<s";
    echo "trong>1- </strong>Make sure you <font color=\"#990000\"><b>delete the install directory</b></font> from your server now  leaving it on your server is a big security risk.</p>\r\n<p>";
    echo "<s";
    echo "trong>2- </strong>Change <font color=\"#990000\"><b>configuration.php permisssion to read only(644)</b></font>.<br />\r\n  <br />\r\n  <br />\r\n</p>\r\nNow you can login to  <A href=\"../\" target=\"_blank\">Admin Control Panel</A> and   configure the site settings.<br />\r\n<br />\r\n<br />\r\n<br />\r\n<br>\r\n<p>";
    echo "<s";
    echo "trong>Thank you for choosing ";
    echo $CONFIG['PRODUCT_NAME'];
    echo " </strong></p>\r\n\t  \r\n\t  \r\n\t  \r\n\t  \r\n\t  \r\n\t  \r\n\t  \r\n\t  \r\n";
}
echo "\t  \r\n\t  \r\n\t <br><br><br> \r\n\t  ";
if ( $error == "1" )
{
    echo "<p><font color=#990000><b>Error! Some Pre installation Checks Failed. You must correct the errors above before you can continue with installation.</b></font></p><br>";
}
echo "\t  \t";
if ( $step != 5 )
{
    echo "\t\t\t<div class='buttons'>\r\n\t\t\t\t<div style='float: left'>\r\n\t\t\t\t\t<input type='button' class='button' value='Cancel' onclick=\"window.location='index.php';return false;\" />\r\n\t\t\t\t</div>\r\n\t\t\t\t<input type='submit' value='";
    echo $next_button_name;
    echo "' class='button' />\r\n\t\t\t</div>\r\n\t\t";
}
echo "\r\n\t  \r\n\t  </form>\r\n\t  </div>\r\n  </div>\r\n\t\r\n\t<div class=\"footer\">\r\n";
echo $CONFIG['SITE_URL'];
echo ", Copyright &copy; 2014-";
echo date( "Y" );
echo " Nulled by AtakanCan & All rights reserved by ";
echo $CONFIG['COMPANY'];
echo ". </div>\r\n\r\n</div>\r\n</body>\r\n</html>\r\n";
?>
