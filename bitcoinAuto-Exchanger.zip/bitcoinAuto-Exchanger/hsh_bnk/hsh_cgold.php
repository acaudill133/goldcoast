<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

chdir( "../" );
include( "include/config.inc.php" );
$payment_worth_value = split( " ", $_POST['payment_units'] );
if ( $_POST['transaction_id'] )
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    $arr_CGOLD = get_currency_data( "", "c-gold", $payment_worth_value[0] );
    $ramz = new RamzNegar( );
    $arr_CGOLD['ALT_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_CGOLD['ALT_PASSWORD'] );
}
$Cgold_array = array(
    $_POST['transaction_id'],
    $_POST['pay_from'],
    $_POST['payee_account'],
    $_POST['payment_amount'],
    $_POST['payment_units'],
    $arr_CGOLD['ALT_PASSWORD']
);
$Cgold_hash = md5( implode( ":", $Cgold_array ) );
$PAYEE_ACCOUNT = $_POST['payee_account'];
$PAYMENT_ID = $_POST['payment_id'];
$PAYMENT_AMOUNT = $_POST['payment_amount'];
$PAYMENT_BATCH_NUM = $_POST['transaction_id'];
$PAYER_ACCOUNT = $_POST['pay_from'];
$PAYMENT_UNITS = $_POST['payment_units'];
$PAID_WORTH_VALUE = str_replace( " worth", "", $_POST['payment_units'] );
if ( $Cgold_hash != $_POST['verify_hash'] )
{
    $Message_log[] = "C-GOLD FAILED!!!!!!!!!!!\n {$Cgold_hash} = {$_POST['verify_hash']}";
}
else
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    if ( Refrence2eid( $PAYMENT_ID ) )
    {
        if ( $PAYEE_ACCOUNT == $arr_CGOLD['ACCOUNT'] && db_if_exists( "SELECT eid From {$_exchange_lines} WHERE exchange_refrence='{$PAYMENT_ID}' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND src_amount='{$PAYMENT_AMOUNT}'" ) )
        {
            SEND_EXHCANGE_MAIL( $PAYMENT_ID, "receive" );
            commit_exchange( $PAYMENT_ID, $PAYMENT_REC_ID );
            $Message_log[] = "C-GOLD ADD TO DATABSE";
        }
    }
    else
    {
        if ( $PAYEE_ACCOUNT == $arr_CGOLD['ACCOUNT'] && db_if_exists( "select * from {$_lines} where id='{$PAYMENT_ID}' and amount='{$PAYMENT_AMOUNT}' AND status='{$STATUS_ENUM_DISABLE}'" ) )
        {
            SEND_INVEST_RECEIVE_MAIL( $PAYMENT_ID, $PAYER_ACCOUNT, $PAID_WORTH_VALUE );
            commit_transaction( $PAYMENT_ID, $PAYMENT_REC_ID );
            $Message_log[] = "C-GOLD ADD TO DATABSE";
        }
        $Message_log[] = "C-GOLD ACCEPTED";
    }
    db_close( $dbconn );
}
Write_File( );
unset( $arr_CGOLD );
?>
