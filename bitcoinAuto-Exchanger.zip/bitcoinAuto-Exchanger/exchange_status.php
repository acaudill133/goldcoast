<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "public.inc.php" );
$str_tool = new string_tool( );
$REFERENCE_ID = trim( $str_tool->remove_dangerous_chars( $_REQUEST['referenceid'] ) );
if ( $REFERENCE_ID && db_if_exists( "SELECT eid FROM {$_exchange_lines} WHERE exchange_refrence='{$REFERENCE_ID}'" ) )
{
    $Success[] = $LANG_msg['exchange_029']."<br><br><b>".$LANG_msg['exchange_030']."</b><br>";
    $arr_EXCHANGE_DATA = array( );
    $nvar = db_get_array( "SELECT src_cid, src_amount, src_batch, dst_cid, dst_amount, dst_batch, dst_account, dst_status, exchange_email_address, exchange_refrence, exchange_note, src_account, src_date, dst_date FROM {$_exchange_lines} WHERE exchange_refrence='{$REFERENCE_ID}'" );
    $arr_EXCHANGE_DATA['SRC_CID'] = $nvar[0];
    $arr_EXCHANGE_DATA['SRC_AMOUNT'] = $nvar[1];
    $arr_EXCHANGE_DATA['SRC_BATCH'] = $nvar[2];
    $arr_EXCHANGE_DATA['DST_CID'] = $nvar[3];
    $arr_EXCHANGE_DATA['DST_AMOUNT'] = $nvar[4];
    $arr_EXCHANGE_DATA['DST_BATCH'] = $nvar[5];
    $arr_EXCHANGE_DATA['DST_ACCOUNT'] = $nvar[6];
    $arr_EXCHANGE_DATA['DST_STATUS'] = $nvar[7];
    $arr_EXCHANGE_DATA['EMAIL'] = $nvar[8];
    $arr_EXCHANGE_DATA['REFRENCE'] = $nvar[9];
    $arr_EXCHANGE_DATA['NOTE'] = $nvar[10];
    $arr_EXCHANGE_DATA['SRC_ACCOUNT'] = $nvar[11];
    $arr_EXCHANGE_DATA['SRC_DATE'] = $nvar[12];
    $arr_EXCHANGE_DATA['DST_DATE'] = $nvar[13];
    if ( $_POST['x_status'] )
    {
        $arr_EXCHANGE_DATA['STATUS_LINK'] = exchange_status_link( $arr_EXCHANGE_DATA['REFRENCE'] );
    }
    $arr_SRC = array( );
    $nvar = db_get_array( "SELECT currency_name, currency_worth_name, currency_metal_name FROM {$_currencies} WHERE cid='{$arr_EXCHANGE_DATA['SRC_CID']}'" );
    $arr_SRC['NAME'] = $nvar[0];
    $arr_SRC['METAL_NAME'] = $nvar[1];
    $arr_SRC['WORTH_NAME'] = $nvar[2];
    $arr_SRC['FULL_NAME'] = $arr_SRC['NAME']." ".$arr_SRC['METAL_NAME']." ".$Var_3624['WORTH_NAME'];
    $arr_DST = array( );
    $nvar = db_get_array( "SELECT currency_name, currency_worth_name, currency_metal_name FROM {$_currencies} WHERE cid='{$arr_EXCHANGE_DATA['DST_CID']}'" );
    $arr_DST['NAME'] = $nvar[0];
    $arr_DST['WORTH_NAME'] = $nvar[1];
    $arr_DST['METAL_NAME'] = $nvar[2];
    $arr_DST['FULL_NAME'] = $arr_DST['NAME']." ".$arr_DST['METAL_NAME']." ".$arr_DST['WORTH_NAME'];
    $DB_EXIST = true;
}
if ( $REFERENCE_ID && !$Success && !db_if_exists( "SELECT eid FROM {$_exchange_lines} WHERE exchange_refrence='{$REFERENCE_ID}'" ) )
{
    $Error[] = LANG.exchange_041;
}
if ( $_POST['x_status'] == "Failed" && !$Success )
{
    $Error[] = $LANG_msg['exchange_032'];
}
if ( !$REFERENCE_ID && $_POST['x_status'] == "Successfull" && !$Success )
{
    $Success[] = $LANG_msg['exchange_031'];
}
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."exchange_status.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "exchange_status.html";
    $arr_EXCHANGE_DATA['src_status_name'] = $STATUS_EXCHANGE[$arr_EXCHANGE_DATA['SRC_STATUS']];
    $arr_EXCHANGE_DATA['dst_status_name'] = $STATUS_EXCHANGE[$arr_EXCHANGE_DATA['DST_STATUS']];
    $arr_EXCHANGE_DATA['src_NAME'] = $arr_SRC['NAME'];
    $arr_EXCHANGE_DATA['src_METAL_NAME'] = $arr_SRC['METAL_NAME'];
    $arr_EXCHANGE_DATA['src_WORTH_NAME'] = $arr_SRC['WORTH_NAME'];
    $arr_EXCHANGE_DATA['src_FULL_NAME'] = ucfirst( $arr_SRC['FULL_NAME'] );
    $arr_EXCHANGE_DATA['dst_NAME'] = $arr_DST['NAME'];
    $arr_EXCHANGE_DATA['dst_WORTH_NAME'] = $arr_DST['WORTH_NAME'];
    $arr_EXCHANGE_DATA['dst_METAL_NAME'] = $arr_DST['METAL_NAME'];
    $arr_EXCHANGE_DATA['dst_FULL_NAME'] = ucfirst( $arr_DST['FULL_NAME'] );
    $arr_EXCHANGE_DATA['SRC_AMOUNT'] = set_money_color( FormatPrice( $arr_EXCHANGE_DATA['SRC_AMOUNT'] ), 1, $arr_SRC['WORTH_NAME'] );
    $arr_EXCHANGE_DATA['DST_AMOUNT'] = set_money_color( FormatPrice( $arr_EXCHANGE_DATA['DST_AMOUNT'] ), 1, $arr_DST['WORTH_NAME'] );
    $page->assign( "arr_EXCHANGE_DATA", array(
        $arr_EXCHANGE_DATA
    ) );
    $page->assign( "arr_SRC", array(
        $arr_SRC
    ) );
    $page->assign( "arr_DST", array(
        $arr_DST
    ) );
    $page->assign( "DB_EXIST", $DB_EXIST );
    require( "include/engine_run.php" );
}
?>
