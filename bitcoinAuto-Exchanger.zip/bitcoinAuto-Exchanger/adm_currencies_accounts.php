<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function currency_status_boxes( $merchant_name, $metal_name = "" )
{
    global $_currencies;
    if ( $merchant_name )
    {
        $sql = " Where currency_name='{$merchant_name}'";
    }
    $query = "SELECT exchange_status, exchange_automatic, currency_metal_name From {$_currencies} ".$sql;
    $result = db_query( $query, "&nbsp;" );
    while ( $line = db_fetch_array( $result ) )
    {
        $field_name = "Exchange Status (".ucfirst( $line['currency_metal_name'] )."): ";
        if ( $line['exchange_status'] )
        {
            $status .= $field_name."<span style=\"color: #006600;\">Active</span><br>";
        }
        else
        {
            $status .= $field_name."<span class=\"ErrorMessage\">Disable</span><br>";
        }
    }
    db_free_result( $result );
    return $status;
}

function upload_api_file( $field_name, $upload_dir )
{
    ( $field_name );
    if ( $handle->uploaded )
    {
        $handle->file_auto_rename = false;
        $handle->file_overwrite = true;
        $handle->no_script = false;
        $handle->mime_check = false;
        $handle->process( $upload_dir );
        if ( $handle->processed )
        {
            return "<span class=SuccessMessage>".$handle->file_dst_name." Uploaded successfully.</span>";
        }
        return "<span class=ErrorMessage>"."error : ".$handle->error." ".$handle->file_dst_path."</span>";
    }
}

function get_dir_files( $inc_dir )
{
    $n = array( );
    if ( $dir = @opendir( $inc_dir ) )
    {
        while ( $file = @readdir( $dir ) )
        {
            if ( 3 < strlen( $file ) )
            {
                array_push( $n, $file );
            }
        }
        @closedir( $Var_504 );
    }
    return $n;
}

function inArray( $array, $key )
{
    if ( func_num_args( ) == 2 && is_string( $key ) )
    {
        return in_array( $key, $array );
    }
    if ( func_num_args( ) == 2 && is_array( $key ) )
    {
        $r = true;
        $i = 0;
        while ( $i < count( $key ) )
        {
            $r = !in_array( $key[$i], $array ) ? false : $r;
            ++$i;
        }
        return $r;
    }
    if ( 2 < func_num_args )
    {
        $args = func_get_args( );
        $r = true;
        $i = 1;
        while ( $i < count( $args ) )
        {
            $r = !in_array( $args[$i], $array ) ? $Tmp_59 : $r;
            ++$i;
        }
        return $r;
    }
}

require( "public.inc.php" );
if ( !session_admin( ) )
{
    @header( "Location: ".$CONFIG['SITE_URL'] );
}
$upload_dir = substr( $_SERVER['SCRIPT_FILENAME'], 0, 0 - strlen( $cur_page ) ).$CONFIG['keys_folder'];
if ( $_GET['Action'] == "webmoney_upagain" )
{
    if ( $demo_mode )
    {
        $Error_div[] = "Some features are not active in Demo Version.";
    }
    else if ( unlink( $upload_dir."/key.kwm" ) )
    {
        $Success[] = "Webmoney key file delete successfully.";
    }
}
$exist_value = "****************";
$arr_hashed_fields = array( "ALT_PASSWORD", "MAIN_PASSWORD", "THIRD_PASSWORD", "PIN_NUMBER" );
if ( $_POST['Action'] == "Save" && $_POST['submit'] && !$demo_mode )
{
    $first_SQL = "UPDATE ".$_currencies." SET ";
    foreach ( $_POST as $key => $value )
    {
        if ( strpos( $value, "'" ) || strpos( $value, "\$" ) || strpos( $value, "\"" ) )
        {
            $Error[] = "Please do not use these characters:<span style=font-size:16px> ' \$ `</span> on your entered data, this value:<b>{$value}</b> ignored, please change and fill it again.";
        }
        else
        {
            list( $merchant_name, $fld_name, $uniq_field ) = merchant_name  ;          $ramz = new RamzNegar( );
            if ( in_array( $fld_name, $arr_hashed_fields ) && $Tmp_93 )
            {
                $value = $ramz->encrypt( ramzkey( "number1" ), $value );
            }
            if ( $fld_name != "CURRENCY_VERIFIER" && $merchant_name )
            {
                if ( $Var_2496 && $exist_value != $value )
                {
                    $arr_uniq_fields[$uniq_field][$fld_name] = $value;
                }
                else if ( $exist_value != $value )
                {
                    $Var_2856 .= $fld_name."='".$value."', ";
                }
            }
            else if ( $merchant_name )
            {
                if ( is_array( $arr_uniq_fields ) )
                {
                    foreach ( $arr_uniq_fields as $dif_key_value => $arr_value )
                    {
                        foreach ( $arr_value as $dfield_name => $dvalue )
                        {
                            $full_sql = "UPDATE ".$_currencies." SET ".$update_SQL." ".$dfield_name."='".$dvalue."' WHERE currency_metal_name='".$dif_key_value."' AND currency_name='{$merchant_name}'";
                            db_exec( $full_sql );
                            unset( $full_sql );
                        }
                    }
                }
                else
                {
                    $full_sql = "UPDATE ".$_currencies." SET ".$update_SQL." ".$fld_name."='".$value."' WHERE currency_name='{$merchant_name}'";
                }
                if ( $full_sql )
                {
                    db_exec( $full_sql );
                }
                unset( $arr_uniq_fields );
                unset( $update_SQL );
                unset( $full_sql );
            }
        }
    }
    foreach ( $_FILES as $key => $value )
    {
        list( $merchant_name, $file_name ) = merchant_name ;       if ( $_FILES[$key]['name'] )
        {
            $Error[] = upload_api_file( $_FILES[$key], $upload_dir );
        }
    }
    $Success[] = "Currency values update successfully.";
}
if ( $_POST['Action'] == "Save" && $_POST['submit'] && $demo_mode )
{
    $Error_div[] = "Some features are not active in Demo Version.";
}
$query = "SELECT currency_name, currency_metal_name, CURRENCY_VERIFIER, ACCOUNT, ACCOUNT_NAME, MAIN_PASSWORD, ALT_PASSWORD, PIN_NUMBER, THIRD_PASSWORD, API_NAME, PAYEE_NAME From {$_currencies} WHERE cid<>'50' Order By cid Asc";
$result = db_query( $query, "&nbsp;" );
while ( $line = db_fetch_array( $result ) )
{
    $merchant_name = $line['currency_name'];
    foreach ( $line as $key => $value )
    {
        if ( in_array( $key, $arr_hashed_fields ) && !empty( $value ) )
        {
            $value = $exist_value;
        }
        if ( $merchant_name == "webmoney" && $key == "ACCOUNT" )
        {
            $arr_CURRENCIE[$merchant_name."|".$key."|".$line[currency_metal_name]] = $value;
        }
        else
        {
            $arr_CURRENCIE[$merchant_name."|".$key] = $value;
        }
    }
}
db_free_result( $result );
$arr_webmoney_files = array( "key.kwm" );
$arr_UPLOADED = get_dir_files( $upload_dir );
if ( inArray( $arr_UPLOADED, $arr_webmoney_files ) )
{
    $webmoney_file_exist = true;
}
if ( is_writable( $upload_dir ) && $webmoney_file_exist )
{
    $Error[] = "Your ".$CONFIG['keys_folder']." contains important files, So folder permission can not be writable for security reasons.";
}
echo "\r\n";
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."adm_currencies_accounts.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "adm_currencies_accounts.html";
    $arr_CURRENCIE = array( );
    $query = "SELECT currency_name, currency_metal_name, CURRENCY_VERIFIER, ACCOUNT, ACCOUNT_NAME, MAIN_PASSWORD, ALT_PASSWORD, PIN_NUMBER, THIRD_PASSWORD, API_NAME, PAYEE_NAME From {$_currencies} WHERE cid<>'50' Order By cid Asc";
    $result = db_query( $query, "&nbsp;" );
    while ( $line = db_fetch_array( $result ) )
    {
        $merchant_name = $line['currency_name'];
        foreach ( $line as $key => $value )
        {
            if ( in_array(  ) && !empty( $value ) )
            {
                $value = $exist_value;
            }
            if ( $merchant_name == "webmoney" && $key == "ACCOUNT" )
            {
                $arr_CURRENCIE[$merchant_name."_".$key."_".$line[currency_metal_name]] = $value;
            }
            else
            {
                $arr_CURRENCIE[str_replace( "-", "", $merchant_name )."_".$key] = $value;
            }
        }
    }
    db_free_result( $result );
    $page->assign( "arr_CURRENCIE", $arr_CURRENCIE );
    $page->assign( "webmoney_file_exist", $webmoney_file_exist );
    $page->assign( "key_folder_writable", $key_folder_writable );
    $page->assign( "Post_selectedtab", $_POST['selectedtab'] );
    require( "include/engine_run.php" );
}
?>
