<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "public.inc.php" );
if ( !session_admin( ) )
{
    @header( "Location: ".$CONFIG['SITE_URL'] );
}
$arr_STATICS['active_members'] = db_count_records( $_users, "permit='{$PMT_INFO_MEMBER}' AND status='{$STATUS_ENUM_ENABLE}'" );
$arr_STATICS['suspend_members'] = db_count_records( $_users, "permit='{$PMT_INFO_MEMBER}' AND status='{$STATUS_ENUM_LOCKED}'" );
$arr_STATICS['today_members'] = db_count_records( $_users_details, "reg_date>='now()'" );
$arr_STATICS['today_pending_order'] = db_count_records( $_exchange_lines, "src_status='{$STATUS_ENUM_ENABLE}' AND dst_status='{$STATUS_ENUM_ENABLE}' AND to_days(src_date)=to_days(now()) AND src_cid<>'{$INTERNAL_CID}'" );
$arr_STATICS['today_open_order'] = db_count_records( $_exchange_lines, "src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND to_days(src_date)=to_days(now())  AND src_cid<>'{$INTERNAL_CID}'" );
$arr_STATICS['today_exchange_order'] = db_get_id( "SELECT sum(src_amount) FROM {$_exchange_lines} WHERE src_status='{$STATUS_ENUM_ENABLE}' AND src_cid<>'{$INTERNAL_CID}' AND to_days(src_date)=to_days(now())" );
$arr_STATICS['today_complete_order'] = db_count_records( $_exchange_lines, "src_status='{$STATUS_ENUM_ENABLE}' AND dst_status='{$STATUS_ENUM_ENABLE}' AND to_days(src_date)=to_days(now())  AND src_cid<>'{$INTERNAL_CID}'" );
$arr_STATICS['total_exchange_order'] = db_get_id( "SELECT sum(src_amount) FROM {$_exchange_lines} WHERE src_status='{$STATUS_ENUM_ENABLE}' AND src_cid<>'{$INTERNAL_CID}'" );
$arr_STATICS['total_exchange_paid'] = db_get_id( "SELECT sum(dst_amount) FROM {$_exchange_lines} WHERE dst_status='{$STATUS_ENUM_ENABLE}' AND dst_cid<>'{$INTERNAL_CID}'" );
$arr_STATICS['total_exchange_profit'] = $total_exchange_paid - $total_exchange_order;
$arr_STATICS['total_open_order'] = db_count_records( $_exchange_lines, "src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND src_cid<>'{$INTERNAL_CID}'" );
$arr_STATICS['total_pending_order'] = db_count_records( $_exchange_lines, "src_status='{$STATUS_ENUM_ENABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND src_cid<>'{$INTERNAL_CID}'" );
$arr_STATICS['total_complete_order'] = db_count_records( $_exchange_lines, "src_status='{$STATUS_ENUM_ENABLE}' AND dst_status='{$STATUS_ENUM_ENABLE}' AND src_cid<>'{$INTERNAL_CID}'" );
$arr_STATICS['pending_commissions'] = db_get_id( "SELECT sum(amount) FROM {$_lines} WHERE pmt_type='{$TRANS_ENUM_WITHDRAW}' AND status='{$STATUS_ENUM_ENABLE}' AND cid<>'{$INTERNAL_CID}'" );
foreach ( $arr_STATICS as $key => $value )
{
    if ( !$value )
    {
        $arr_STATICS[$key] = 0;
    }
}
if ( $arr_STATICS['total_complete_order'] < 0 )
{
    $Success[] = "You have some pending Exchange order <a href=".get_link( "adm_exchanges.php" ).">Click here</a> to proccess exchange orders.";
}
if ( $arr_STATICS['pending_commissions'] < 0 )
{
    $Success[] = "You have pending comission Withdraw request <a href=".get_link( "adm_payouttousr.php" ).">Click here</a> to proccess withdraw requests.";
}
echo "\r\n\r\n";
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."adm_status.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "adm_status.html";
    $page->assign( "arr_STATICS", $arr_STATICS );
    $query = "SELECT * FROM {$_settings}";
    $result = db_query( $query, "&nbsp;" );
    while ( $line = db_fetch_array( $result ) )
    {
        $setting = $line['setting'];
        $page->assign( $setting, $line['value'] );
    }
    db_free_result( $result );
    require( "include/engine_run.php" );
}
?>
