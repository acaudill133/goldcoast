<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "public.inc.php" );
if ( $_POST['submit'] && ( !$_POST['user'] || !$_POST['uname'] || !$_POST['acc'] ) )
{
    $Error[] = $LANG_msg['forgot_008'];
}
if ( isset( $_POST['user'] ) && $_POST['uname'] && $_POST['acc'] )
{
    $str_tool = new string_tool( );
    $user = $str_tool->remove_dangerous_chars( trim( $_POST['user'] ) );
    $acc = $str_tool->remove_dangerous_chars( trim( $_POST['acc'] ) );
    $uname = $str_tool->remove_dangerous_chars( trim( $_POST['uname'] ) );
    $nvar = db_get_array( "SELECT u.uid, u.login, d.email FROM {$_users} u, {$_users_details} d WHERE u.uid=d.uid AND d.email='{$user}' AND d.money_account='{$acc}' AND u.login='{$uname}' AND u.status='{$STATUS_ENUM_ENABLE}' AND u.permit='{$PMT_INFO_MEMBER}'" );
    $fuid = $nvar[0];
    $flogin = $nvar[1];
    $fmail = $nvar[2];
    if ( 1 < $fuid && $fmail )
    {
        $newpassw = rand( 1000, 9999 ).rand( 1000, 9999 );
        $newpassw_crypt = crypt( $newpassw );
        if ( SEND_REGULAR_MAIL( $fuid, "forgot", $newpassw ) )
        {
            db_exec( "UPDATE {$_users} SET password='{$newpassw_crypt}' WHERE uid='{$fuid}'" );
        }
        $mail_sent = true;
    }
    else
    {
        $Error[] = $LANG_msg['forgot_006']."<br><br><a href=".$CONFIG['SITE_URL'].">".$LANG_msg['signup_050']."</a>";
    }
}
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."forgot.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "forgot.html";
    $page->assign( "mail_sent", $mail_sent );
    require( "include/engine_run.php" );
}
?>
