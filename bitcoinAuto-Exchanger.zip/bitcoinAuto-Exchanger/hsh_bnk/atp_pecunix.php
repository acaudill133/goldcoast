<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

echo "\r\n\t<input type=\"hidden\" name=\"PAYEE_ACCOUNT\" value=\"";
echo $payee_account;
echo "\">\r\n";
if ( $amount == "ask" )
{
    echo "    Amount you want to pay: <INPUT type='text' name=\"PAYMENT_AMOUNT\">\r\n";
}
else
{
    echo "    <input type=\"hidden\" name=\"PAYMENT_AMOUNT \" value=\"";
    echo $amount;
    echo "\">\r\n";
}
echo "\t<input type=\"hidden\" name=\"PAYMENT_URL\" value=\"";
echo $response_ok;
echo "\">\r\n\t<input type=\"hidden\" name=\"NOPAYMENT_URL\" value=\"";
echo $response_no;
echo "\">\r\n\t<input type=\"hidden\" name=\"STATUS_TYPE\" value=\"FORM\">\r\n\t<input type=\"hidden\" name=\"STATUS_URL\" value=\"";
echo $status_url;
echo "\">\r\n\t<input type=\"hidden\" name=\"PAYMENT_URL_METHOD\" value=\"POST\">\r\n\t<input type=\"hidden\" name=\"NOPAYMENT_URL_METHOD\" value=\"POST\">\r\n\t<input type=\"hidden\" name=\"PAYMENT_UNITS\" value=\"";
echo $arr_PAYMENT['WORTH_VALUE'];
echo "\">\r\n\t<input type=\"hidden\" name=\"WHO_PAYS_FEES\" value=\"PAYEE\">\r\n\t<input type=\"hidden\" name=\"PAYMENT_ID\" value=\"";
echo $payment_id;
echo "\">\r\n\t\r\n\t<input type=\"hidden\" name=\"SUGGESTED_MEMO\" value=\"";
echo $suggested_memo;
echo "\">";
?>
