Highcharts.setOptions({
 	global: {
 		useUTC: false
 	}
 	plotOptions: {
   	candlestick: {
   	 color: 'blue',
   	 upColor: 'red'
                       
   	}
   }
 });


