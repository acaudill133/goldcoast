<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_topercent( $full_rate, $free = false )
{
    if ( $free )
    {
        return "FREE";
    }
    $explode = explode( ":", $value );
    $src_rate = $explode[0];
    $dst_rate = $explode[1];
    if ( $src_rate == 1000 && ( $dst_rate = 1000 ) || !$src_rate && !$dst_rate )
    {
        return "--";
    }
    $percent = 100 * $dst_rate / $src_rate;
    if ( $percent < 100 )
    {
        $percent = 100 - $percent;
    }
    else
    {
        $percent = $percent - 100;
        $symbol = "+";
    }
    return "%".$symbol.$percent;
}

?>
