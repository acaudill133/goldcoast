<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

class html2text
{

    public $html = NULL;
    public $text = NULL;
    public $width = 70;
    public $search = array
    (
        0 => "/\r/",
        1 => "/[\n\t]+/",
        2 => "/[ ]{2,}/",
        3 => "/<script[^>]*>.*?<\\/script>/i",
        4 => "/<style[^>]*>.*?<\\/style>/i",
        5 => "/<h[123][^>]*>(.*?)<\\/h[123]>/ie",
        6 => "/<h[456][^>]*>(.*?)<\\/h[456]>/ie",
        7 => "/<p[^>]*>/i",
        8 => "/<br[^>]*>/i",
        9 => "/<b[^>]*>(.*?)<\\/b>/ie",
        10 => "/<strong[^>]*>(.*?)<\\/strong>/ie",
        11 => "/<i[^>]*>(.*?)<\\/i>/i",
        12 => "/<em[^>]*>(.*?)<\\/em>/i",
        13 => "/(<ul[^>]*>|<\\/ul>)/i",
        14 => "/(<ol[^>]*>|<\\/ol>)/i",
        15 => "/<li[^>]*>(.*?)<\\/li>/i",
        16 => "/<li[^>]*>/i",
        17 => "/<a [^>]*href=\"([^\"]+)\"[^>]*>(.*?)<\\/a>/ie",
        18 => "/<hr[^>]*>/i",
        19 => "/(<table[^>]*>|<\\/table>)/i",
        20 => "/(<tr[^>]*>|<\\/tr>)/i",
        21 => "/<td[^>]*>(.*?)<\\/td>/i",
        22 => "/<th[^>]*>(.*?)<\\/th>/ie",
        23 => "/&(nbsp|#160);/i",
        24 => "/&(quot|rdquo|ldquo|#8220|#8221|#147|#148);/i",
        25 => "/&(apos|rsquo|lsquo|#8216|#8217);/i",
        26 => "/&gt;/i",
        27 => "/&lt;/i",
        28 => "/&(amp|#38);/i",
        29 => "/&(copy|#169);/i",
        30 => "/&(trade|#8482|#153);/i",
        31 => "/&(reg|#174);/i",
        32 => "/&(mdash|#151|#8212);/i",
        33 => "/&(ndash|minus|#8211|#8722);/i",
        34 => "/&(bull|#149|#8226);/i",
        35 => "/&(pound|#163);/i",
        36 => "/&(euro|#8364);/i",
        37 => "/&[^&;]+;/i",
        38 => "/[ ]{2,}/"
    );
    public $replace = array
    (
        0 => "",
        1 => " ",
        2 => " ",
        3 => "",
        4 => "",
        5 => "strtoupper(\"\n\n\\1\n\n\")",
        6 => "ucwords(\"\n\n\\1\n\n\")",
        7 => "\n\n\t",
        8 => "\n",
        9 => "strtoupper(\"\\1\")",
        10 => "strtoupper(\"\\1\")",
        11 => "_\\1_",
        12 => "_\\1_",
        13 => "\n\n",
        14 => "\n\n",
        15 => "\t* \\1\n",
        16 => "\n\t* ",
        17 => "\$this->_build_link_list(\"\\1\", \"\\2\")",
        18 => "\n-------------------------\n",
        19 => "\n\n",
        20 => "\n",
        21 => "\t\t\\1\n",
        22 => "strtoupper(\"\t\t\\1\n\")",
        23 => " ",
        24 => "\"",
        25 => "'",
        26 => ">",
        27 => "<",
        28 => "&",
        29 => "(c)",
        30 => "(tm)",
        31 => "(R)",
        32 => "--",
        33 => "-",
        34 => "*",
        35 => "\xA3",
        36 => "EUR",
        37 => "",
        38 => " "
    );
    public $allowed_tags = "";
    public $url = NULL;
    public $_converted = FALSE;
    public $_link_list = "";
    public $_link_count = 0;

    public function html2text( $source = "", $from_file = FALSE )
    {
        if ( !empty( $source ) )
        {
            $this->set_html( $source, $from_file );
        }
        $this->set_base_url( );
    }

    public function set_html( $source, $from_file = FALSE )
    {
        $this->html = $source;
        if ( $from_file && file_exists( $source ) )
        {
            $fp = fopen( $source, "r" );
            $this->html = fread( $fp, filesize( $source ) );
            fclose( $fp );
        }
        $this->_converted = FALSE;
    }

    public function get_text( )
    {
        if ( !$this->_converted )
        {
            $this->_convert( );
        }
        return $this->text;
    }

    public function print_text( )
    {
        print $this->get_text( );
    }

    public function p( )
    {
        print $this->get_text( );
    }

    public function set_allowed_tags( $allowed_tags = "" )
    {
        if ( !empty( $allowed_tags ) )
        {
            $this->allowed_tags = $allowed_tags;
        }
    }

    public function set_base_url( $url = "" )
    {
        if ( empty( $url ) )
        {
            if ( !empty( $_SERVER['HTTP_HOST'] ) )
            {
                $this->url = "http://".$_SERVER['HTTP_HOST'];
            }
            else
            {
                $this->url = "";
            }
        }
        else
        {
            if ( substr( $url, 0 - 1 ) == "/" )
            {
                $url = substr( $url, 0, 0 - 1 );
            }
            $this->url = $url;
        }
    }

    public function _convert( )
    {
        $this->_link_count = 0;
        $this->_link_list = "";
        $text = trim( stripslashes( $this->html ) );
        $text = preg_replace( $this->search, $this->replace, $text );
        $text = strip_tags( $text, $this->allowed_tags );
        $text = preg_replace( "/\n\\s+\n/", "\n\n", $text );
        $text = preg_replace( "/[\n]{3,}/", "\n\n", $text );
        if ( !empty( $this->_link_list ) )
        {
            $text .= "\n\nLinks:\n------\n".$this->_link_list;
        }
        if ( 0 < $this->width )
        {
            $text = wordwrap( $text, $this->width );
        }
        $this->text = $text;
        $this->_converted = TRUE;
    }

    public function _build_link_list( $link, $display )
    {
        if ( substr( $link, 0, 7 ) == "http://" || substr( $link, 0, 8 ) == "https://" || substr( $link, 0, 7 ) == "mailto:" )
        {
            $this->_link_count++;
            $this->_link_list .= "[".$this->_link_count."] {$link}\n";
            $additional = " [".$this->_link_count."]";
        }
        else if ( substr( $link, 0, 11 ) == "javascript:" )
        {
            $additional = "";
        }
        else
        {
            $this->_link_count++;
            $this->_link_list .= "[".$this->_link_count."] ".$this->url;
            if ( substr( $link, 0, 1 ) != "/" )
            {
                $this->_link_list .= "/";
            }
            $this->_link_list .= "{$link}\n";
            $additional = " [".$this->_link_count."]";
        }
        return $display.$additional;
    }

}

?>
