<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function get_link( $link, $type = "", $title = "" )
{
    global $language;
    global $CONFIG;
    global $cur_page;
    if ( !$CONFIG['FRIENDLY_URL'] )
    {
        return $CONFIG['SITE_URL']."/".$link;
    }
    if ( preg_match( "/(gif|jpg|png)/", strtolower( $link ) ) )
    {
        return $CONFIG['SITE_URL']."/".$final_link;
    }
    $pieces = explode( ".php", $link );
    $final_link = $pieces[0];
    $pieces[1] = str_replace( "&", "=", $pieces[1] );
    $link_vars = explode( "=", str_replace( "?", "", $pieces[1] ) );
    foreach ( $link_vars as $i => $value )
    {
        if ( $value )
        {
            $final_link .= "/".$value;
        }
    }
    $final_link = $CONFIG['SITE_URL']."/".$final_link."/";
    if ( $title )
    {
        $final_link .= $type."/".urlencode( $title )."/";
    }
    return $final_link;
}

function dynamic_link( $row_id )
{
    global $language;
    global $CONFIG;
    global $_news;
    global $DEF_DOCS_TYPE;
    global $language;
    if ( is_numeric( $row_id ) )
    {
        $cause = "id='{$row_id}'";
    }
    else
    {
        $row_id = urldecode( $row_id );
        $cause = "fld_title='{$row_id}'";
    }
    $nvar = db_get_array( "SELECT type, fld_title, related_id FROM {$_news} WHERE {$cause}" );
    $doc_type = $DEF_DOCS_TYPE[$nvar[0]];
    $doc_title = $nvar[1];
    $doc_related_id = $nvar[2];
    return get_link( "nview.php?id=".$doc_related_id, $doc_type, $doc_title );
}

function get_title( $url )
{
    $list = array( "%", "\$", "\\'", "\"", "\\", "_", "-" );
    $url = str_replace( $list, " ", $url );
    $pieces = explode( "/", $url );
    return strtoupper( end( $pieces ) );
}

function get_monitors_id( $id )
{
    global $_rate;
    $query = "SELECT monitor_user_id FROM {$_rate} WHERE monitor_user_id = '{$id}' AND comission_divid='{$STATUS_ENUM_ENABLE}'";
    $result = db_if_exists( $query );
    return $result;
}

function make_ref_link( $uid, $image_link = false )
{
    global $CONFIG;
    if ( !$image_link )
    {
        $ref_link = "<a href=\"{$CONFIG['SITE_URL']}/?rid={$uid}\" target=\"_blank\">{$CONFIG['SITE_URL']}/?rid={$uid}</a>";
    }
    else
    {
        $ref_link = "<a href=\"{$CONFIG['SITE_URL']}/?rid={$uid}\" target=\"_blank\">";
    }
    return $ref_link;
}

function lang_selected( $string )
{
    $pieces = explode( ".inc.php", $string );
    return $pieces[0];
}

?>
