<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

ini_set( "magic_quotes_gpc", "Off" );
ini_set( "magic_quotes_runtime", "Off" );
ini_set( "output_buffering", "0" );
ini_set( "register_globals", "0" );
if ( @ini_get( "zlib.output_compression" ) && ini_get( "zlib.output_compression_level" ) != 5 )
{
    @ini_set( "zlib.output_compression_level", "5" );
    ob_start( );
}
else if ( strstr( $_SERVER['HTTP_ACCEPT_ENCODING'], "gzip" ) )
{
    ob_start( "ob_gzhandler" );
}
else
{
    ob_start( );
}
if ( !file_exists( "include/config.inc.php" ) )
{
    chdir( dirname( __FILE__ )."/.." );
}
if ( !file_exists( "configuration.php" ) )
{
    exit( "Rename <b>configuration.php_rename</b> in root to <b>configuration.php</b>" );
}
if ( !file_exists( "include/config.inc.php" ) || !file_exists( "include/vars.inc.php" ) )
{
    exit( "Please upload all package files." );
}
else
{
    require_once( "configuration.php" );
}
if ( !$hostname || !$database || !$db_login )
{
    exit( "Seems you are using Auto-Exchanger for first time, Please <a href='install/index.php'>click here</a> to <b>start installation</b> process." );
}
if ( file_exists( "-Reserved-files" ) )
{
    error_reporting( E_ALL ^ E_NOTICE );
}
else
{
    $uploaded = true;
}
if ( !file_exists( "_ERRORS_PHPSYSTEM.html" ) )
{
    ini_set( "display_errors", "Off" );
    error_reporting( 0 );
}
if ( file_exists( "_ERRORS_LOGING.html" ) )
{
    @set_error_handler( "log_handler" );
}
if ( file_exists( "_ERRORS_SKIN.html" ) )
{
    $debug_skin = true;
}
if ( $_SERVER['HTTP_HOST'] == "demo.auto-exchanger.com" && !file_exists( "SYSTEM_PHERRORS_.html" ) )
{
    $demo_mode = true;
}
if ( isset( $_SERVER['HTTP_HOST'] ) )
{
    $domain = ".".preg_replace( "`^www.`", "", $_SERVER['HTTP_HOST'] );
    if ( 2 < count( explode( ".", $domain ) ) )
    {
        ini_set( "session.cookie_domain", $domain );
    }
}
session_start( );
$_lines = $db_prefix."balance_lines";
$_referals = $db_prefix."referals";
$_users = $db_prefix."users";
$_users_details = $db_prefix."users_details";
$_news = $db_prefix."news";
$_countries = $db_prefix."countries";
$Var_2448 = $db_prefix."users_logs";
$_currencies = $db_prefix."currency";
$_exchange_rate = $db_prefix."exchange_rate";
$_exchange_lines = $db_prefix."exchange_lines";
$_settings = $db_prefix."settings";
$_orders = $db_prefix."order_lines";
require_once( "include/vars.inc.php" );
require_once( "include/function.fmt.inc.php" );
require_once( "include/function.db.inc.php" );
if ( !$dbconn )
{
    $dbconn = db_open( );
}
$query = "SELECT * FROM {$_settings}";
$result = db_query( $query, "&nbsp;" );
while ( $line = db_fetch_array( $result ) )
{
    $setting = $line['setting'];
    $value = $line['value'];
    $CONFIG["".$setting] = "".$value;
}
db_free_result( $result );
unset( $query );
require_once( "include/function.fmt.pte.inc.php" );
require_once( "include/function.link.inc.php" );
require_once( "include/class.stringtool.php" );
require_once( "include/function.session.inc.php" );
require_once( "include/function.currency.inc.php" );
require_once( "include/class.pager.php" );
require_once( "include/class.upload.php" );
require_once( "include/function.security.inc.php" );
require_once( "include/function.pte.inc.php" );
require_once( "include/function.exchange.inc.php" );
fncSecurityCheck( );
if ( $_GET['Error'] == "cookie" )
{
    $Error_div[] = "Your browser must be cookie enabled";
}
if ( is_dir( "install" ) && $uploaded )
{
    $Error_div[] = "You must delete install folder for security reasons.";
}
if ( !is_writable( "_skins_tmp" ) )
{
    $Error_div[] = "Change _skins_tmp folder permisssion writable (777).";
}
$page = explode( "/", $_SERVER['PHP_SELF'] );
$cur_page = $page[count( $page ) - 1];
$cur_folder = $page[count( $page ) - 2];
if ( session_admin( ) )
{
    $time_start = microtime_float( );
}
if ( empty( $CONFIG['SITE_URL_SECURE'] ) )
{
    $CONFIG['SITE_URL_SECURE'] = $CONFIG['SITE_URL'];
}
if ( $_SERVER['SERVER_PORT'] == 443 && $_GET['goto'] != "normalsite" && !empty( $CONFIG['SITE_URL_SECURE'] ) )
{
    $CONFIG['SITE_URL'] = $CONFIG['SITE_URL_SECURE'];
}
$DEF_DIR_LANGUAGE = "languages";
if ( !isset( $_GET['lang'] ) && !isset( $_SESSION['language'] ) )
{
    $language = $CONFIG['DEF_LANGUAGE'];
}
else if ( $_GET['lang'] )
{
    $language = $_GET['lang'];
    $_SESSION['language'] = $language;
}
else
{
    $language = $_SESSION['language'];
}
if ( file_exists( $DEF_DIR_LANGUAGE."/{$language}.inc.php" ) )
{
    require_once( $DEF_DIR_LANGUAGE."/{$language}.inc.php" );
}
else
{
    require_once( $DEF_DIR_LANGUAGE."/{$CONFIG['DEF_LANGUAGE']}.inc.php" );
}
$lang = get_inc_names( $DEF_DIR_LANGUAGE );
sort( $lang );
if ( $_GET['rid'] )
{
    db_exec( "update {$_users_details} set click_counter=(click_counter + 1) WHERE uid='{$_GET['rid']}'" );
}
$Var_6984 = "_skins";
$images = $CONFIG['SITE_URL']."/images";
$CONFIG['SKIN_FOLDER'] = $Template_folder."/".$CONFIG['SITE_TEMPLATE']."/";
$CONFIG['CACHE_FOLDER'] = $Template_folder."_tmp/";
$CONFIG['SKIN_URL'] = $CONFIG['SITE_URL']."/".$CONFIG['SKIN_FOLDER'];
$CONFIG['SKIN_JS'] = $CONFIG['SITE_URL']."/".$CONFIG['SKIN_FOLDER']."tpljs";
$CONFIG['SKIN_CSS'] = $CONFIG['SITE_URL']."/".$CONFIG['SKIN_FOLDER']."tplcss";
$CONFIG['SKIN_IMAGES'] = $CONFIG['SITE_URL']."/".$CONFIG['SKIN_FOLDER']."tplimgs";
?>
