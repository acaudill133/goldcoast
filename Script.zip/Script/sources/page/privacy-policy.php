<h3><?php echo $lang['privacy_policy']; ?></h3>

<?php echo $settings['p_poilcy']; ?>