<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

class upload
{

    public $file_src_name = NULL;
    public $file_src_name_body = NULL;
    public $file_src_name_ext = NULL;
    public $file_src_mime = NULL;
    public $file_src_size = NULL;
    public $file_src_error = NULL;
    public $file_src_pathname = NULL;
    public $file_src_temp = NULL;
    public $file_dst_path = NULL;
    public $file_dst_name = NULL;
    public $file_dst_name_body = NULL;
    public $file_dst_name_ext = NULL;
    public $file_dst_pathname = NULL;
    public $image_src_x = NULL;
    public $image_src_y = NULL;
    public $image_src_bits = NULL;
    public $image_src_pixels = NULL;
    public $image_src_type = NULL;
    public $image_dst_x = NULL;
    public $image_dst_y = NULL;
    public $image_supported = NULL;
    public $file_is_image = NULL;
    public $uploaded = NULL;
    public $no_upload_check = NULL;
    public $processed = NULL;
    public $error = NULL;
    public $log = NULL;
    public $file_new_name_body = NULL;
    public $file_name_body_add = NULL;
    public $file_new_name_ext = NULL;
    public $file_safe_name = NULL;
    public $mime_check = NULL;
    public $mime_magic_check = NULL;
    public $no_script = NULL;
    public $file_auto_rename = NULL;
    public $dir_auto_create = NULL;
    public $dir_auto_chmod = NULL;
    public $dir_chmod = NULL;
    public $file_overwrite = NULL;
    public $file_max_size = NULL;
    public $image_resize = NULL;
    public $image_convert = NULL;
    public $image_x = NULL;
    public $image_y = NULL;
    public $image_ratio = NULL;
    public $image_ratio_crop = NULL;
    public $image_ratio_fill = NULL;
    public $image_ratio_pixels = NULL;
    public $image_ratio_no_zoom_in = NULL;
    public $image_ratio_no_zoom_out = NULL;
    public $image_ratio_x = NULL;
    public $image_ratio_y = NULL;
    public $image_max_width = NULL;
    public $image_max_height = NULL;
    public $image_max_pixels = NULL;
    public $image_max_ratio = NULL;
    public $image_min_width = NULL;
    public $image_min_height = NULL;
    public $image_min_pixels = NULL;
    public $image_min_ratio = NULL;
    public $jpeg_quality = NULL;
    public $jpeg_size = NULL;
    public $preserve_transparency = NULL;
    public $image_is_transparent = NULL;
    public $image_transparent_color = NULL;
    public $image_background_color = NULL;
    public $image_default_color = NULL;
    public $image_is_palette = NULL;
    public $image_brightness = NULL;
    public $image_contrast = NULL;
    public $image_threshold = NULL;
    public $image_tint_color = NULL;
    public $image_overlay_color = NULL;
    public $image_overlay_percent = NULL;
    public $image_negative = NULL;
    public $image_greyscale = NULL;
    public $image_text = NULL;
    public $image_text_direction = NULL;
    public $image_text_color = NULL;
    public $image_text_percent = NULL;
    public $image_text_background = NULL;
    public $image_text_background_percent = NULL;
    public $image_text_font = NULL;
    public $image_text_position = NULL;
    public $image_text_x = NULL;
    public $image_text_y = NULL;
    public $image_text_padding = NULL;
    public $image_text_padding_x = NULL;
    public $image_text_padding_y = NULL;
    public $image_text_alignment = NULL;
    public $image_text_line_spacing = NULL;
    public $image_reflection_height = NULL;
    public $image_reflection_space = NULL;
    public $image_reflection_color = NULL;
    public $image_reflection_opacity = NULL;
    public $image_flip = NULL;
    public $image_rotate = NULL;
    public $image_crop = NULL;
    public $image_bevel = NULL;
    public $image_bevel_color1 = NULL;
    public $image_bevel_color2 = NULL;
    public $image_border = NULL;
    public $image_border_color = NULL;
    public $image_frame = NULL;
    public $image_frame_colors = NULL;
    public $image_watermark = NULL;
    public $image_watermark_position = NULL;
    public $image_watermark_x = NULL;
    public $image_watermark_y = NULL;
    public $allowed = NULL;
    public $forbidden = NULL;
    public $translation = NULL;
    public $language = NULL;

    public function init( )
    {
        $this->file_new_name_body = "";
        $this->file_name_body_add = "";
        $this->file_new_name_ext = "";
        $this->file_safe_name = true;
        $this->file_overwrite = false;
        $this->file_auto_rename = true;
        $this->dir_auto_create = true;
        $this->dir_auto_chmod = true;
        $this->dir_chmod = 511;
        $this->mime_check = true;
        $this->mime_magic_check = false;
        $this->no_script = true;
        $val = trim( ini_get( "upload_max_filesize" ) );
        $last = strtolower( $val[strlen( $val ) - 1] );
        switch ( $last )
        {
        case "g" :
            $val *= 1024;
        case "m" :
            $val *= 1024;
        case "k" :
            $val *= 1024;
        }
        $this->file_max_size = $val;
        $this->image_resize = false;
        $this->image_convert = "";
        $this->image_x = 150;
        $this->image_y = 150;
        $this->image_ratio = false;
        $this->image_ratio_crop = false;
        $this->image_ratio_fill = false;
        $this->image_ratio_pixels = false;
        $this->image_ratio_no_zoom_in = false;
        $this->image_ratio_no_zoom_out = false;
        $this->image_ratio_x = false;
        $this->image_ratio_y = false;
        $this->jpeg_quality = 85;
        $this->jpeg_size = null;
        $this->preserve_transparency = false;
        $this->image_is_transparent = false;
        $this->image_transparent_color = null;
        $this->image_background_color = null;
        $this->image_default_color = "#ffffff";
        $this->image_is_palette = false;
        $this->image_max_width = null;
        $this->image_max_height = null;
        $this->image_max_pixels = null;
        $this->image_max_ratio = null;
        $this->image_min_width = null;
        $this->image_min_height = null;
        $this->image_min_pixels = null;
        $this->image_min_ratio = null;
        $this->image_brightness = null;
        $this->image_contrast = null;
        $this->image_threshold = null;
        $this->image_tint_color = null;
        $this->image_overlay_color = null;
        $this->image_overlay_percent = null;
        $this->image_negative = false;
        $this->image_greyscale = false;
        $this->image_text = null;
        $this->image_text_direction = null;
        $this->image_text_color = "#FFFFFF";
        $this->image_text_percent = 100;
        $this->image_text_background = null;
        $this->image_text_background_percent = 100;
        $this->image_text_font = 5;
        $this->image_text_x = null;
        $this->image_text_y = null;
        $this->image_text_position = null;
        $this->image_text_padding = 0;
        $this->image_text_padding_x = null;
        $this->image_text_padding_y = null;
        $this->image_text_alignment = "C";
        $this->image_text_line_spacing = 0;
        $this->image_reflection_height = null;
        $this->image_reflection_space = 2;
        $this->image_reflection_color = "#ffffff";
        $this->image_reflection_opacity = 60;
        $this->image_watermark = null;
        $this->image_watermark_x = null;
        $this->image_watermark_y = null;
        $this->image_watermark_position = null;
        $this->image_flip = null;
        $this->image_rotate = null;
        $this->image_crop = null;
        $this->image_bevel = null;
        $this->image_bevel_color1 = "#FFFFFF";
        $this->image_bevel_color2 = "#000000";
        $this->image_border = null;
        $this->image_border_color = "#FFFFFF";
        $this->image_frame = null;
        $this->image_frame_colors = "#FFFFFF #999999 #666666 #000000";
        $this->forbidden = array( );
        $this->allowed = array( "application/rar", "application/x-rar-compressed", "application/arj", "application/excel", "application/gnutar", "application/octet-stream", "application/pdf", "application/powerpoint", "application/postscript", "application/plain", "application/rtf", "application/vocaltec-media-file", "application/wordperfect", "application/x-bzip", "application/x-bzip2", "application/x-compressed", "application/x-excel", "application/x-gzip", "application/x-latex", "application/x-midi", "application/x-msexcel", "application/x-rtf", "application/x-sit", "application/x-stuffit", "application/x-shockwave-flash", "application/x-troff-msvideo", "application/x-zip-compressed", "application/xml", "application/zip", "application/msword", "application/mspowerpoint", "application/vnd.ms-excel", "application/vnd.ms-powerpoint", "application/vnd.ms-word", "application/vnd.ms-word.document.macroEnabled.12", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-word.template.macroEnabled.12", "application/vnd.openxmlformats-officedocument.wordprocessingml.template", "application/vnd.ms-powerpoint.template.macroEnabled.12", "application/vnd.openxmlformats-officedocument.presentationml.template", "application/vnd.ms-powerpoint.addin.macroEnabled.12", "application/vnd.ms-powerpoint.slideshow.macroEnabled.12", "application/vnd.openxmlformats-officedocument.presentationml.slideshow", "application/vnd.ms-powerpoint.presentation.macroEnabled.12", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/vnd.ms-excel.addin.macroEnabled.12", "application/vnd.ms-excel.sheet.binary.macroEnabled.12", "application/vnd.ms-excel.sheet.macroEnabled.12", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel.template.macroEnabled.12", "application/vnd.openxmlformats-officedocument.spreadsheetml.template", "audio/*", "image/*", "video/*", "multipart/x-zip", "multipart/x-gzip", "text/richtext", "text/plain", "text/xml" );
    }

    public function upload( $file, $lang = "en_GB" )
    {
        $this->file_src_name = "";
        $this->file_src_name_body = "";
        $this->file_src_name_ext = "";
        $this->file_src_mime = "";
        $this->file_src_size = "";
        $this->file_src_error = "";
        $this->file_src_pathname = "";
        $this->file_src_temp = "";
        $this->file_dst_path = "";
        $this->file_dst_name = "";
        $this->file_dst_name_body = "";
        $this->file_dst_name_ext = "";
        $this->file_dst_pathname = "";
        $this->image_src_x = null;
        $this->image_src_y = null;
        $this->image_src_bits = null;
        $this->image_src_type = null;
        $this->image_src_pixels = null;
        $this->image_dst_x = 0;
        $this->image_dst_y = 0;
        $this->uploaded = true;
        $this->no_upload_check = false;
        $this->processed = true;
        $this->error = "";
        $this->log = "";
        $this->allowed = array( );
        $this->forbidden = array( );
        $this->file_is_image = false;
        $this->init( );
        $info = null;
        $this->translation = array( );
        $this->translation['file_error'] = "File error. Please try again.";
        $this->translation['local_file_missing'] = "Local file doesn't exist.";
        $this->translation['local_file_not_readable'] = "Local file is not readable.";
        $this->translation['uploaded_too_big_ini'] = "File upload error (the uploaded file exceeds the upload_max_filesize directive in php.ini).";
        $this->translation['uploaded_too_big_html'] = "File upload error (the uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the html form).";
        $this->translation['uploaded_partial'] = "File upload error (the uploaded file was only partially uploaded).";
        $this->translation['uploaded_missing'] = "File upload error (no file was uploaded).";
        $this->translation['uploaded_unknown'] = "File upload error (unknown error code).";
        $this->translation['try_again'] = "File upload error. Please try again.";
        $this->translation['file_too_big'] = "File too big.";
        $this->translation['no_mime'] = "MIME type can't be detected.";
        $this->translation['incorrect_file'] = "Incorrect type of file.";
        $this->translation['image_too_wide'] = "Image too wide.";
        $this->translation['image_too_narrow'] = "Image too narrow.";
        $this->translation['image_too_high'] = "Image too high.";
        $this->translation['image_too_short'] = "Image too short.";
        $this->translation['ratio_too_high'] = "Image ratio too high (image too wide).";
        $this->translation['ratio_too_low'] = "Image ratio too low (image too high).";
        $this->translation['too_many_pixels'] = "Image has too many pixels.";
        $this->translation['not_enough_pixels'] = "Image has not enough pixels.";
        $this->translation['file_not_uploaded'] = "File not uploaded. Can't carry on a process.";
        $this->translation['already_exists'] = "%s already exists. Please change the file name.";
        $this->translation['temp_file_missing'] = "No correct temp source file. Can't carry on a process.";
        $this->translation['source_missing'] = "No correct uploaded source file. Can't carry on a process.";
        $this->translation['destination_dir'] = "Destination directory can't be created. Can't carry on a process.";
        $this->translation['destination_dir_missing'] = "Destination directory doesn't exist. Can't carry on a process.";
        $this->translation['destination_path_not_dir'] = "Destination path is not a directory. Can't carry on a process.";
        $this->translation['destination_dir_write'] = "Destination directory can't be made writeable. Can't carry on a process.";
        $this->translation['destination_path_write'] = "Destination path is not a writeable. Can't carry on a process.";
        $this->translation['temp_file'] = "Can't create the temporary file. Can't carry on a process.";
        $this->translation['source_not_readable'] = "Source file is not readable. Can't carry on a process.";
        $this->translation['no_create_support'] = "No create from %s support.";
        $this->translation['create_error'] = "Error in creating %s image from source.";
        $this->translation['source_invalid'] = "Can't read image source. Not an image?.";
        $this->translation['gd_missing'] = "GD doesn't seem to be present.";
        $this->translation['watermark_no_create_support'] = "No create from %s support, can't read watermark.";
        $this->translation['watermark_create_error'] = "No %s read support, can't create watermark.";
        $this->translation['watermark_invalid'] = "Unknown image format, can't read watermark.";
        $this->translation['file_create'] = "No %s create support.";
        $this->translation['no_conversion_type'] = "No conversion type defined.";
        $this->translation['copy_failed'] = "Error copying file on the server. copy() failed.";
        $this->translation['reading_failed'] = "Error reading the file.";
        $this->lang = $lang;
        if ( $this->lang != "en_GB" && file_exists( "lang/class.upload.".$lang.".php" ) )
        {
            $translation = null;
            include( "lang/class.upload.".$lang.".php" );
            if ( is_array( $translation ) )
            {
                $this->translation = array_merge( $this->translation, $translation );
            }
            else
            {
                $this->lang = "en_GB";
            }
        }
        $this->image_supported = array( );
        if ( $this->gdversion( ) )
        {
            if ( imagetypes( ) & IMG_GIF )
            {
                $this->image_supported['image/gif'] = "gif";
            }
            if ( imagetypes( ) & IMG_JPG )
            {
                $this->image_supported['image/jpg'] = "jpg";
                $this->image_supported['image/jpeg'] = "jpg";
                $this->image_supported['image/pjpeg'] = "jpg";
            }
            if ( imagetypes( ) & IMG_PNG )
            {
                $this->image_supported['image/png'] = "png";
                $this->image_supported['image/x-png'] = "png";
            }
            if ( imagetypes( ) & IMG_WBMP )
            {
                $this->image_supported['image/bmp'] = "bmp";
                $this->image_supported['image/x-ms-bmp'] = "bmp";
                $this->image_supported['image/x-windows-bmp'] = "bmp";
            }
        }
        if ( empty( $this->log ) )
        {
            $this->log .= "<b>system information</b><br />";
            $inis = ini_get_all( );
            $open_basedir = array_key_exists( "open_basedir", $inis ) && array_key_exists( "local_value", $inis['open_basedir'] ) && !empty( $inis['open_basedir']['local_value'] ) ? $inis['open_basedir']['local_value'] : false;
            $gd = $this->gdversion( ) ? $this->gdversion( true ) : "GD not present";
            $supported = ( ( in_array( "png", $this->image_supported ) ? "png" : "" )." ".( trim( "jpg", $this->image_supported ) ? "jpg" : "" )." ".( in_array( "gif", $this->image_supported ) ? "gif" : "" )." ".( in_array( "bmp", $this->image_supported ) ? "bmp" : "" ) );
            $this->log .= "-&nbsp;GD version              : ".$gd."<br />";
            $this->log .= "-&nbsp;supported image types   : ".( !empty( $supported ) ? $supported : "none" )."<br />";
            $this->log .= "-&nbsp;open_basedir            : ".( !empty( $open_basedir ) ? $open_basedir : "no restriction" )."<br />";
            $this->log .= "-&nbsp;language                : ".$this->lang."<br />";
        }
        if ( !$file )
        {
            $this->uploaded = false;
            $this->error = $this->translate( "file_error" );
        }
        if ( !is_array( $file ) )
        {
            if ( empty( $file ) )
            {
                $this->uploaded = false;
                $this->error = $this->translate(  );
            }
            else
            {
                $this->no_upload_check = TRUE;
                $this->log .= "<b>".$this->translate( "source is a local file" )." ".$file."</b><br />";
                $this->uploaded = false;
                $this->error = $this->translate( "local_file_missing" );
                if ( $this->uploaded && !is_readable( $file ) )
                {
                    $this->uploaded = false;
                    $this->error = $this->translate( "local_file_not_readable" );
                }
                if ( $this->uploaded )
                {
                    $this->file_src_pathname = $file;
                    $this->file_src_name = basename( $file );
                    $this->log .= "- local file name OK<br />";
                    ereg( "\\.([^\\.]*\$)", $this->file_src_name, $extension );
                    if ( is_array( $extension ) )
                    {
                        $this->file_src_name_ext = strtolower( $extension[1] );
                        $this->file_src_name_body = substr( $this->file_src_name, 0, strlen( $this->file_src_name ) - strlen( $this->file_src_name_ext ) - 1 );
                    }
                    else
                    {
                        $this->file_src_name_ext = "";
                        $this->file_src_name_body = $this->file_src_name;
                    }
                    $this->file_src_size = file_exists( $file ) ? filesize( $file ) : 0;
                    $info = getimagesize( $this->file_src_pathname );
                    $this->file_src_mime = is_array( $info ) && array_key_exists( "mime", $info ) ? null : ;
                    if ( empty( $this->file_src_mime ) )
                    {
                        $mime = is_array( $info ) && array_key_exists( 2, $info ) ? $info[2] : null;
                        $this->file_src_mime = $mime == IMAGETYPE_GIF ? "image/gif" : $mime == IMAGETYPE_JPEG ? "image/jpeg" : $mime == IMAGETYPE_PNG ? "image/png" : $mime == IMAGETYPE_BMP ? "image/bmp" : null;
                    }
                    if ( empty( $this->file_src_mime ) && function_exists( "mime_content_type" ) )
                    {
                        $this->file_src_mime = mime_content_type( $this->file_src_pathname );
                    }
                    $this->file_src_error = 0;
                    if ( array_key_exists( $this->file_src_mime, $this->image_supported ) )
                    {
                        $this->file_is_image = true;
                        $this->image_src_type = $this->image_supported[$this->file_src_mime];
                    }
                }
            }
        }
        else
        {
            $this->log .= "<b>source is an uploaded file</b><br />";
            if ( $this->uploaded )
            {
                $this->file_src_error = $file['error'];
                switch ( $this->file_src_error )
                {
                case 0 :
                    $this->log .= "- upload OK<br />";
                    break;
                case 1 :
                    $this->uploaded = false;
                    $this->error = $this->translate( "uploaded_too_big_ini" );
                    break;
                case 2 :
                    $this->uploaded = false;
                    $this->error = $this->translate( "uploaded_too_big_html" );
                    break;
                case 3 :
                    $this->uploaded = false;
                    $this->error = $this->translate( "uploaded_partial" );
                    break;
                case 4 :
                    $this->uploaded = false;
                    $this->error = $this->translate( "uploaded_missing" );
                    break;
                default :
                    $this->uploaded = false;
                    $this->error = $this->translate( "uploaded_unknown" );
                }
            }
            if ( $this->uploaded )
            {
                $this->file_src_pathname = $file['tmp_name'];
                $this->file_src_name = $file['name'];
                if ( $this->file_src_name == "" )
                {
                    $this->uploaded = false;
                    $this->error = $this->translate( "try_again" );
                }
            }
            if ( $this->uploaded )
            {
                $this->log .= "- file name OK<br />";
                ereg( "\\.([^\\.]*\$)", $this->file_src_name, $extension );
                if ( is_array( $extension ) )
                {
                    $this->file_src_name_ext = strtolower( $extension[1] );
                    $this->file_src_name_body = ( $this->file_src_name, 0, substr( $this->file_src_name ) - strlen( $this->file_src_name_ext ) - 1 );
                }
                else
                {
                    $this->file_src_name_ext = "";
                    $this->file_src_name_body = $this->file_src_name;
                }
                $this->file_src_size = $file['size'];
                $this->file_src_mime = $file['type'];
                if ( array_key_exists( $this->file_src_mime, $this->image_supported ) )
                {
                    $this->file_is_image = true;
                    $this->image_src_type = $this->image_supported[$this->file_src_mime];
                    $info = @getimagesize( $this->file_src_pathname );
                }
            }
        }
        if ( $this->file_is_image )
        {
            if ( is_array( $info ) )
            {
                $this->image_src_x = $info[0];
                $this->image_src_y = $info[1];
                $this->image_src_pixels = $this->image_src_x * $this->image_src_y;
                $this->image_src_bits = array_key_exists( "bits", $info ) ? $info['bits'] : null;
            }
            else
            {
                $this->log .= "- can't retrieve image information. open_basedir restriction in place?<br />";
            }
        }
        $this->log .= "- source variables<br />";
        $this->log .= "&nbsp;&nbsp;&nbsp;&nbsp;file_src_name         : ".$this->file_src_name."<br />";
        $this->log .= "&nbsp;&nbsp;&nbsp;&nbsp;file_src_name_body    : ".$this->file_src_name_body."<br />";
        $this->log .= "&nbsp;&nbsp;&nbsp;&nbsp;file_src_name_ext     : ".$this->file_src_name_ext."<br />";
        $this->log .= "&nbsp;&nbsp;&nbsp;&nbsp;file_src_pathname     : ".$this->file_src_pathname."<br />";
        $this->log .= "&nbsp;&nbsp;&nbsp;&nbsp;file_src_mime         : ".$this->file_src_mime."<br />";
        $this->log .= "&nbsp;&nbsp;&nbsp;&nbsp;file_src_size         : ".$this->file_src_size." (max= ".$this->file_max_size.")<br />";
        $this->log .= "&nbsp;&nbsp;&nbsp;&nbsp;file_src_error        : ".$this->file_src_error."<br />";
        if ( $this->file_is_image )
        {
            $this->log .= "- source file is an image<br />";
            $this->log .= "&nbsp;&nbsp;&nbsp;&nbsp;image_src_x           : ".$this->image_src_x."<br />";
            $this->log .= "&nbsp;&nbsp;&nbsp;&nbsp;image_src_y           : ".$this->image_src_y."<br />";
            $this->log .= "&nbsp;&nbsp;&nbsp;&nbsp;image_src_pixels      : ".$this->image_src_pixels."<br />";
            $this->log .= "&nbsp;&nbsp;&nbsp;&nbsp;image_src_type        : ".$this->image_src_type."<br />";
            $this->log .= "&nbsp;&nbsp;&nbsp;&nbsp;image_src_bits        : ".$this->image_src_bits."<br />";
        }
    }

    public function gdversion( $full = false )
    {
        static $gd_version = null;
        static $gd_full_version = null;
        if ( $gd_version === null )
        {
            if ( function_exists( "gd_info" ) )
            {
                $gd = gd_info( );
                $gd = $gd['GD Version'];
                $regex = "/([\\d\\.]+)/i";
            }
            else
            {
                ob_start( );
                phpinfo( 8 );
                $gd = ob_get_contents( );
                ob_end_clean( );
                $regex = "/\\bgd\\s+version\\b[^\\d\n\r]+?([\\d\\.]+)/i";
            }
            if ( preg_match( $regex, $gd, $m ) )
            {
                $gd_full_version = ( boolean )$m[1];
                $gd_version = ( double )$m[1];
            }
            else
            {
                $gd_full_version = "none";
                $gd_version = 0;
            }
        }
        if ( $full )
        {
            return $gd_full_version;
        }
        return $gd_version;
    }

    public function rmkdir( $path, $mode = 511 )
    {
        return is_dir( $path ) || $this->rmkdir( dirname( $path ), $mode ) && $this->_mkdir( $path, $mode );
    }

    public function _mkdir( $path, $mode = 511 )
    {
        $old = umask( 0 );
        $res = @mkdir( $path, $mode );
        umask( $old );
        return $res;
    }

    public function translate( $str, $tokens = array( ) )
    {
        if ( array_key_exists( $str, $this->translation ) )
        {
            $str = $this->translation[$str];
        }
        if ( is_array( $tokens ) && 0 < sizeof( $tokens ) )
        {
            $str = vsprintf( $str, $tokens );
        }
        return $str;
    }

    public function imagecreatenew( $x, $y, $fill = true, $trsp = false )
    {
        if ( 2 <= $this->gdversion( ) && !$this->image_is_palette )
        {
            $dst_im = imagecreatetruecolor( $x, $y );
            if ( empty( $this->image_background_color ) || $trsp )
            {
                imagealphablending( $dst_im, false );
                imagefilledrectangle( $dst_im, 0, 0, $x, $y, imagecolorallocatealpha( $dst_im, 0, 0, 0, 127 ) );
            }
        }
        else
        {
            $dst_im = imagecreate( $x, $y );
            if ( $fill && $this->image_is_transparent && empty( $this->image_background_color ) || $trsp )
            {
                imagefilledrectangle(  );
                imagecolortransparent( $dst_im, $this->image_transparent_color );
            }
        }
        if ( $fill && !empty( $this->image_background_color ) && !$trsp )
        {
            sscanf( $this->image_background_color, "#%2x%2x%2x", $red, $green, $blue );
            $background_color = imagecolorallocate( $dst_im, $red, $green, $blue );
        }
        return $dst_im;
    }

    public function imagetransfer( $src_im, $dst_im )
    {
        if ( is_resource( $dst_im ) )
        {
            imagedestroy( $dst_im );
        }
        $dst_im =& $src_im;
        return $dst_im;
    }

    public function imagecopymergealpha( &$dst_im, &$src_im, $dst_x, $dst_y, $src_x, $src_y, $src_w, $src_h, $pct = 0 )
    {
        $dst_x = ( integer )$dst_x;
        $dst_y = ( integer )$dst_y;
        $src_x = ( integer )$src_x;
        $src_y = ( integer )$src_y;
        $src_w = ( integer )$src_w;
        $src_h = ( integer )$src_h;
        $pct = ( integer )$pct;
        $dst_w = imagesx( $dst_im );
        $dst_h = imagesy( $dst_im );
        $y = $src_y;
        while ( $y < $src_h )
        {
            $x = $src_x;
            while ( $x < $src_w )
            {
                if ( 0 <= $x && $x <= $Var_1536 && 0 <= $y && $y <= $dst_h )
                {
                    $dst_pixel = imagecolorsforindex( $dst_im, imagecolorat( $dst_im, $x + $dst_x, $y + $dst_y ) );
                    $src_pixel = imagecolorsforindex( $src_im, imagecolorat( $src_im, $x + $src_x, $y + $src_y ) );
                    $src_alpha = 1 - $src_pixel['alpha'] / 127;
                    $dst_alpha = 1 - $Var_2448['alpha'] / 127;
                    $opacity = $src_alpha * $pct / 100;
                    if ( $opacity <= $dst_alpha )
                    {
                        $alpha = $dst_alpha;
                    }
                    if ( $dst_alpha < $opacity )
                    {
                        $alpha = $opacity;
                    }
                    if ( 1 < $alpha )
                    {
                        $alpha = 1;
                    }
                    if ( 0 < $opacity )
                    {
                        $dst_red = round( $dst_pixel['red'] * $dst_alpha * ( 1 - $opacity ) );
                        $dst_green = round( $dst_pixel['green'] * $dst_alpha * ( 1 - $opacity ) );
                        $dst_blue = round( $dst_pixel['blue'] * $dst_alpha * ( 1 - $opacity ) );
                        $src_red = round( $src_pixel['red'] * $opacity );
                        $src_green = round( $src_pixel['green'] * $opacity );
                        $src_blue = round( $src_pixel['blue'] * $opacity );

[exception occured]

================================
Exception code[ C0000005 ]
Compiler[ 00845C18 ]
Executor[ 00846120 ]
OpArray[ 020480C0 ]
File< C:\dezenders\dezend\_decoded\include\class.upload.php >
Class< upload >
Function< imagecopymergealpha >
Stack[ 001482A0 ]
Step[ 7 ]
Offset[ 240 ]
LastOffset[ 334 ]
   240  DIV                          [-]   0[0] $Tmp_192 - $Tmp_185 - $Tmp_191
================================
?>
