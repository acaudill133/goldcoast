<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

if ( !$CONFIG )
{
    require( "include/config.inc.php" );
}
$query = "Select cid, currency_name, exchange_min, reserve_amount, currency_worth_name, currency_metal_name, exchange_max_fee, exchange_accept_limit , show_as_destination, show_as_source From {$_currencies}\r\n\t\t\tWhere exchange_status='{$STATUS_ENUM_ENABLE}' AND cid<>'50' {$currencies_clause} Order By cid Asc";
$arr_currency_ID = array( );
$arr_currency_NAME = array( );
$arr_currency_MINIMUM = array( );
$arr_currency_RESERVE = array( );
$arr_currency_WORTH = array( );
$arr_currency_METAL = array( );
$result = db_query( $query, "&nbsp;" );
$TOTAL_EX_CURRENCIES = mysql_num_rows( $result );
while ( $line = db_fetch_array( $result ) )
{
    $x = $line[cid];
    $arr_currency_ID[] = $line[cid];
    $arr_currency_NAME[] = ucfirst( $line[currency_name] );
    $arr_currency_MINIMUM[] = $line[exchange_min];
    $arr_currency_RESERVE[] = $line[reserve_amount];
    $arr_currency_WORTH[] = $line[currency_worth_name];
    $arr_currency_METAL[] = $line[currency_metal_name];
    $arr_currency_MAX_FEE[] = $line[exchange_max_fee];
    $arr_currency_EX_LIMIT[] = $line[exchange_accept_limit];
    $arr_AS_DST[] = $line[show_as_destination];
    $arr_AS_SRC[] = $line[show_as_source];
}
$result = db_query( $query, "&nbsp;" );
db_free_result( $result );
$js_string = "<SCRIPT language=\"JavaScript\">";
$js_string .= "var rate = new Array();";
$coloumns = implode( ",".$_exchange_rate.".", $arr_currency_ID );
$coloumns = $_exchange_rate.".".$coloumns;
$query = "Select {$_exchange_rate}.cid, {$coloumns} From {$_exchange_rate} Inner Join {$_currencies} ON {$_exchange_rate}.cid = {$_currencies}.cid\r\n\t\t\tWhere {$_currencies}.exchange_status = '{$STATUS_ENUM_ENABLE}' AND {$_exchange_rate}.cid<'50' {$currencies_clause} Order By {$_currencies}.cid Asc";
$result = db_query( $query, "&nbsp;" );
while ( $line = mysql_fetch_assoc( $result ) )
{
    foreach ( $arr_currency_ID as $key => $value )
    {
        $current_currency_ID = current( $arr_currency_ID );
        if ( !current( $arr_currency_ID ) )
        {
            $current_currency_ID = 1;
        }
        $js_string .= "rate[".( ( $line['cid'] + $line['cid'] ) * $line['cid'] * count( $arr_currency_ID ) + $current_currency_ID )."]  = {'src':".rate_parser( $line[$current_currency_ID], "src" ).", 'dst':".rate_parser( $line[$current_currency_ID], "dst" )."}; ";
        next( $arr_currency_ID );
    }
}
db_free_result( $result );
echo "  \r\n\r\n\r\n";
$js_string .= "var Reserve = new Array();";
echo "  ";
foreach ( $arr_currency_ID as $key => $cid )
{
    $js_string .= "Reserve[".$cid."] = ".$arr_currency_RESERVE[$key]."; ";
}
echo "\r\n";
$js_string .= "var minAmt = new Array();";
echo "  ";
foreach ( $arr_currency_ID as $key => $cid )
{
    $js_string .= "minAmt[".$cid."] = ".$arr_currency_MINIMUM[$key]."; ";
}
echo "\r\n";
$js_string .= "var ValName = new Array();";
echo "  ";
foreach ( $arr_currency_ID as $key => $cid )
{
    $js_string .= "ValName[".$cid."] = '".$arr_currency_NAME[$key]." (".( $arr_currency_METAL[$key] ? ucfirst( $arr_currency_METAL[$key] ) : ucfirst( $arr_currency_WORTH[$key] ) ).")'; ";
}
$js_string .= "var MaxFee = new Array();";
echo "  ";
foreach ( $arr_currency_ID as $key => $cid )
{
    $js_string .= "MaxFee[".$cid."] = ".$arr_currency_MAX_FEE[$key]."; ";
}
echo "\r\n";
$js_string .= "var limitAmt = new Array();";
echo "  ";
foreach ( $arr_currency_ID as $key => $cid )
{
    $js_string .= "limitAmt[".$cid."] = ".( !$arr_currency_EX_LIMIT[$key] ? "'false'" : $arr_currency_EX_LIMIT[$key] )."; ";
}
echo "  \r\n\r\n";
$js_string .= "var langErr = new Array();";
$js_string .= "langErr[1] = \"".$LANG_msg['exchange_085']."\";";
$js_string .= "langErr[2] = \"".$LANG_msg['exchange_028']."\";";
$js_string .= "langErr[3] = \"".$LANG_msg['exchange_054']." ".$LANG_msg['exchange_055']."\";";
$js_string .= "var curCnt = ".$TOTAL_EX_CURRENCIES.";";
$js_string .= "var min_comm = ".$CONFIG['MIN_EXCHANGE_FEE'].";";
$js_string .= "</SCRIPT>";
echo "\r\n\r\n";
if ( $NoTemp )
{
    echo "\t\r\n\t\t";
    echo "CRIPT  language=\"JavaScript\">";
    echo $js_string;
    echo "</SCRIPT>\r\n        ";
    echo "<S";
    echo "CRIPT language=\"JavaScript\" src=\"";
    echo $CONFIG['SKIN_JS'];
    echo "/exchange.js\"></SCRIPT>\r\n        ";
    include( $CONFIG['SKIN_FOLDER']."exchange_box.php" );
    echo "\t\r\n";
}
else
{
    foreach ( $arr_currency_ID as $key => $cid )
    {
        if ( $arr_AS_SRC[$key] )
        {
        }
    }
    $page->assign( "currencies_SRC", $currencies_SRC );
    foreach ( $arr_currency_ID as $key => $cid )
    {
        if ( $arr_AS_DST[$key] )
        {
            $currencies_DST[$cid] = $arr_currency_NAME[$key]." ".$arr_currency_METAL[$key];
        }
    }
    $page->assign( "currencies_DST", $currencies_DST );
    $page->assign( "post_srcID", $_POST['srcID'] );
    $page->assign( "post_dstID", $_POST['dstID'] );
    $page->assign( "js_string", $js_string );
}
echo "\r\n";
?>
