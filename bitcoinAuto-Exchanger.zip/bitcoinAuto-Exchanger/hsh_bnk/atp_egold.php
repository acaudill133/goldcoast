<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

echo "<INPUT type=hidden value=\"";
echo $response_ok;
echo "\" name=\"PAYMENT_URL\">\r\n<INPUT type=hidden value=\"";
echo $response_no;
echo "\" name=\"NOPAYMENT_URL\">\r\n<INPUT type=hidden value=\"";
echo $status_url;
echo "\" name=\"STATUS_URL\">\r\n<INPUT type=hidden value=\"";
echo $payee_account;
echo "\" name=\"PAYEE_ACCOUNT\">\r\n<INPUT type=hidden value=\"";
echo $user;
echo "\" name=\"PAYEE_NAME\">\r\n";
if ( $amount == "ask" )
{
    echo "    Amount you want to pay: <INPUT type=text value=\"\" name=\"PAYMENT_AMOUNT\">\r\n";
}
else
{
    echo "    <INPUT type=hidden value=\"";
    echo $amount;
    echo "\" name=\"PAYMENT_AMOUNT\">\r\n";
}
echo "<INPUT type=hidden value=\"";
echo $suggested_memo;
echo "\" name=\"SUGGESTED_MEMO\">\r\n<INPUT type=hidden value=\"";
echo $payment_id;
echo "\" name=\"PAYMENT_ID\">\r\n<INPUT type=hidden value=\"";
echo $def_payee_account;
echo "\" name=\"FORCED_PAYER_ACCOUNT\">\r\n<INPUT type=hidden value=\"";
echo $arr_PAYMENT['WORTH_VALUE'];
echo "\" name=\"PAYMENT_UNITS\"> \r\n<INPUT type=hidden value=\"";
echo $arr_PAYMENT['METAL_VALUE'];
echo "\" name=\"PAYMENT_METAL_ID\">\r\n<INPUT type=hidden value=POST name=\"PAYMENT_URL_METHOD\">\r\n<INPUT type=hidden value=POST name=\"NOPAYMENT_URL_METHOD\">\r\n";
?>
