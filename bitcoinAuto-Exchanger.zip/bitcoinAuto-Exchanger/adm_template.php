<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "public.inc.php" );
if ( !session_admin( ) )
{
    @header( "Location: ".$CONFIG['SITE_URL'] );
}
$tinymce_one_filed = false;
if ( ( $_REQUEST['Action'] == "Edit" || $_REQUEST['Action'] == "Add" ) && $CONFIG['tinymce_editor'] )
{
    if ( strstr( $_SERVER['HTTP_ACCEPT_ENCODING'], "gzip" ) )
    {
        $tiny_config_file = "jscripts/tiny_mce/tinymce_config_gzip.inc.js";
    }
    else
    {
        $tiny_config_file = "jscripts/tiny_mce/tinymce_config.inc.js";
    }
    $tiny_js = file_get_contents( $tiny_config_file );
    $tiny_js = str_replace( "[SITE_URL]", $CONFIG['SITE_URL'], $tiny_js );
    $tiny_js = str_replace( "[SKIN_CSS]", $CONFIG['SKIN_CSS'], $tiny_js );
    if ( $tinymce_one_filed )
    {
        $tiny_js = str_replace( "//[OPTIONAL],", "editor_selector : \"mceEditor\",", $tiny_js );
    }
}
if ( $NoTemp && $CONFIG['tinymce_editor'] )
{
    echo $tiny_js;
}
$Oid = $_GET['id'];
$body = $_POST['body'];
if ( $_POST['Action'] == "Edit" && !$demo_mode )
{
    $body = htmlspecialchars_decode( stripslashes( $body ) );
    $body = preg_replace(  );
    $filepath = realpath( $CONFIG['SKIN_FOLDER'].$_POST['id'] );
    if ( !is_writable( $filepath ) )
    {
        $Error[] = "The file (".$_POST['id'].") is not writable";
    }
    $handler = fopen( $filepath, "w" );
    if ( fputs( $handler, stripslashes( $body ) ) === FALSE )
    {
        $Error[] = "Can not write to file (".$_POST['id'].")";
    }
    else
    {
        $Success[] = $_POST['id'].", Update successfully";
    }
    fclose( $handler );
    if ( !touch( $filepath ) )
    {
        $Error[] = "The file (".$_POST['id'].") is not writable";
    }
    if ( !$Error && $CONFIG['caching_status'] )
    {
        empty_cache_folder( );
    }
}
if ( $_POST['Action'] == "Edit" && $demo_mode )
{
    $Error_div[] = "Some features are not active in Demo Version.";
}
if ( $_GET['Action'] == "Edit" )
{
    $filename = realpath( $CONFIG['SKIN_FOLDER'].$Oid );
    if ( !is_writable( $filename ) )
    {
        $Error[] = $Oid." is not writable, you need to update permission if you want to edit template file from here.";
    }
    if ( !file_exists( $filename ) )
    {
        $Error[] = $Oid." is does not exist.";
    }
    if ( !$Error )
    {
        $body = file_get_contents( $filename );
    }
}
else
{
    if ( !$_GET['section'] )
    {
        $template_section = array( "Administration", "Users" );
        foreach ( $template_section as $key => $value )
        {
            $Files_row .= "<tr><td nowrap=\"nowrap\" style=\"text-align:center\">[ <a href=\"".$_SERVER['PHP_SELF']."?section=".$value."\" style=\"color:#990000;\">Open</a> ] </td>\r\n\t\t\t<td><a href=\"".$_SERVER['PHP_SELF']."?section=".$value."\">".$value." section</a></td>\r\n\t\t\t<td align=\"center\" nowrap=\"nowrap\" class=\"italic\">-</td></tr>";
        }
    }
    else
    {
        $section = $_GET['section'];
        if ( $section == "Users" )
        {
            $exclude = "adm_";
            $include = "html";
            $css_file = "tplcss/style.php";
        }
        if ( $section == "Administration" )
        {
            $exclude = "nothing";
            $include = "adm_";
            $css_file = "tplcss/admin.css";
        }
        $template_files['filename'] = list_files( realpath( $CONFIG['SKIN_FOLDER'] ), $include, "_debug", $exclude );
        $url_addon = "Action=Edit&section=".$section;
        $css_file_mdate = date( "j-m-y h:i", filemtime( realpath( $CONFIG['SKIN_FOLDER'].$css_file ) ) );
        $Files_row .= "\r\n\t\t<tr><td nowrap=\"nowrap\" style=\"text-align:center\">[ <a href=\"".$_SERVER['PHP_SELF']."?id=".$css_file."&".$url_addon."\">Edit</a> ] </td>\r\n\t\t<td><a href=\"".$_SERVER['PHP_SELF']."?id=".$css_file."&".$url_addon."\"><img src=\"".$CONFIG['SKIN_IMAGES']."/ico/css.gif\" border=\"0\">Style Sheet</a></td>\r\n\t\t<td\t align=\"center\" nowrap=\"nowrap\"  style=\"font-size:10px\" class=\"italic\">".$css_file_mdate."</td></tr>";
        foreach ( $template_files['filename'] as $key => $value )
        {
            $template_files['modified_date'][] = date( "j-m-y h:i", filemtime( $CONFIG['SKIN_FOLDER'].$value ) );
            $Files_row .= ( "<tr class=\"col".$key % 2 )."\">\r\n\t\t\t\t<td nowrap=\"nowrap\" style=\"text-align:center\">[ <a href=\"".$_SERVER['PHP_SELF']."?id=".$value."&".$url_addon."\">Edit</a> ] </td>\r\n\t\t\t\t<td><a href=\"".$_SERVER['PHP_SELF']."?id=".$value."&".$url_addon."\"><img src=\"".$CONFIG['SKIN_IMAGES']."/ico/html.gif\" border=\"0\">".$value."</a></td>\r\n\t\t\t\t<td align=\"center\" nowrap=\"nowrap\"  style=\"font-size:10px\" class=\"italic\">".$template_files['modified_date'][$key]."</td>\r\n\t\t\t</tr>";
        }
    }
    if ( !$Files_row )
    {
        $Error[] = "There is not such template file.";
    }
}
echo "\r\n";
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."adm_template.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "adm_template.html";
    $page->assign( "Files_row", $Files_row );
    $page->assign( "Action", $_GET['Action'] );
    $page->assign( "section", $_GET['section'] );
    $page->assign( "filename", $Oid );
    $page->assign( "filebody", htmlspecialchars( $body ) );
    if ( strstr( $_GET['id'], "tplcss" ) == false )
    {
        $page->assign( "tiny_js", $tiny_js );
    }
    if ( $perpage < $total )
    {
        $pg = $pager->page;
        $page_navigation .= $pager->getButPrev( $pg );
        $range = 20;
        $page_navigation .= $pager->getButList( $range );
        $page_navigation .= $pager->getButNext( $pg );
        $page_navigation .= "<br><br><br>";
        $page_navigation .= $pager->getRangeInfo( );
    }
    $page->assign( "page_navigation", $page_navigation );
    require( "include/engine_run.php" );
}
echo "\r\n\r\n\r\n\r\n\r\n\r\n\r\n";
?>
