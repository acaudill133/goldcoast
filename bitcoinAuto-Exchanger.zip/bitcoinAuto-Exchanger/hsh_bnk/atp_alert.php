<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

echo "\r\n<input type='hidden' name='ap_purchasetype' value='Service'>\r\n<input type='hidden' name='ap_merchant' value='";
echo $payee_account;
echo "'>\r\n<input type='hidden' name='ap_itemname' value='";
echo $suggested_memo;
echo "'>\r\n<input type='hidden' name='ap_currency' value='";
echo "'>\r\n<input type='hidden' name='ap_quantity' value='1'>\r\n<input type='hidden' name='ap_description' value='";
echo $user;
echo "'>\r\n\r\n";
if ( $amount == "ask" )
{
    echo "    Amount you want to pay: <input type='text' name=\"ap_amount\">\r\n";
}
else
{
    echo "    <input type='hidden' name='ap_amount' value='";
    echo $amount;
    echo "'>\r\n";
}
echo "<input type='hidden' name='ap_returnurl' value='";
echo $response_ok;
echo "'>\r\n<input type='hidden' name='ap_cancelurl' value='";
echo $response_no;
echo "'>\r\n<input type='hidden' name='apc_1' value='";
echo $payment_id;
echo "'>\r\n";
?>
