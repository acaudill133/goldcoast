<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_formatprice( $string, $worth_name = "", $style_no = "1" )
{
    $string_original = $string;
    $Negative = 0;
    if ( preg_match( "/^\\-/", $string ) )
    {
        $Negative = 1;
        $string = preg_replace( "|\\-|", "", $string );
    }
    $string = preg_replace( "|\\,|", "", $string );
    $Full = split( "[\\.]", $string );
    $Count = count( $Full );
    if ( 1 < $Count )
    {
        $First = $Full[0];
        $Second = $Full[1];
        $NumDec = strlen( $Second );
        if ( $NumDec == 2 )
        {
        }
        else if ( $NumDec < 2 )
        {
            $Second = $Second."0";
        }
        else if ( 2 < $NumDec )
        {
            $Temp = substr( $Second, 0, 3 );
            $Second = substr( $Temp, 0, 2 );
        }
    }
    else
    {
        $First = $Full[0];
        $Second = "00";
    }
    $length = strlen( $First );
    if ( $length <= 3 )
    {
        $string = $First.".".$Second;
        if ( $Negative == 1 )
        {
            $string = "-".$string;
        }
        if ( $worth_name )
        {
            switch ( strtolower( $worth_name ) )
            {
            case "usd" :
                $sign = "\$";
                break;
            case "euro" :
            }
            $sign = "&#8364;";
            break;
            $sign = $worth_name." ";
            break;
            if ( 0 <= $string_original )
            {
                $famount = "<span class=\"money_".$style_no."\">".$sign.$string."</span>";
            }
            else
            {
                $famount = "<span class=\"money_r".$style_no."\">".$sign.$string."</span>";
            }
            return $famount;
        }
        return $string;
    }
    $loop = intval( $length / 3 );
    $section_length = 0 - 3;
    $i = 0;
    while ( $i < $loop )
    {
        $sections[$i] = substr( $First, $section_length, 3 );
        $section_length = $section_length - 3;
        ++$i;
    }
    $stub = $length % 3;
    if ( $stub != 0 )
    {
        $sections[$i] = substr( $First, 0, $stub );
    }
    $Done = implode( ",", array_reverse( $sections ) );
    $Done = $Done.".".$Second;
    if ( $Negative == 1 )
    {
        $Done = "-".$Done;
    }
    if ( $worth_name )
    {
        switch ( strtolower( $worth_name ) )
        {
        case "usd" :
            $sign = "\$";
            break;
        case "euro" :
        }
        $sign = "&#8364;";
        break;
        $sign = $worth_name." ";
        break;
        if ( 0 <= $string_original )
        {
            $famount = "<span class=\"money_".$style_no."\">".$sign.$Done."</span>";
        }
        else
        {
            $famount = "<span class=\"money_r".$style_no."\">".$sign.$Done."</span>";
        }
        return $famount;
    }
    return $Done;
}

?>
