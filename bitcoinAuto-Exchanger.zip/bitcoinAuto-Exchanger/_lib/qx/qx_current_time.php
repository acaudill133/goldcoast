<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_current_time( )
{
    global $_CONFIG;
    if ( empty( $_CONFIG['time_format'] ) )
    {
        $_CONFIG['time_format'] = "H:i:s";
    }
    return date( $_CONFIG['time_format'] );
}

?>
