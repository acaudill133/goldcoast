<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

class string_tool
{

    public function split_string( $src, $key )
    {
        if ( $src == NULL || $key == NULL )
        {
            return NULL;
        }
        return explode( $key, $src );
    }

    public function replace_string( $str, $replace, $by )
    {
        if ( $Tmp_5 || $replace == NULL || $by == NULL )
        {
            return NULL;
        }
        return str_replace( $replace, $by, $str );
    }

    public function get_item( $src, $key, $index )
    {
        $tmpArr = $this->split_string( $src, $key );
        if ( $tmpArr != NULL && 0 <= $index && $index < count( $tmpArr ) )
        {
            return $tmpArr[$index];
        }
        return NULL;
    }

    public function remove_dangerous_chars( $src )
    {
        $list = array( "\$", "\\'", "\"", "\\", "_REQUEST", "_GET", "_POST", "_COOKIE", "_FILES", "_SERVER", "_ENV", "GLOBALS", "_SESSION", "toupper" );
        if ( $src == NULL )
        {
            return NULL;
        }
        return str_replace( $list, "", $src );
    }

}

function wordCut( $sText, $iMaxLength, $sMessage )
{
    if ( $iMaxLength < strlen( $sText ) )
    {
        $sString = wordwrap( $sText, $iMaxLength - strlen( $sMessage ), "[cut]", 1 );
        $asExplodedString = explode( "[cut]", $sString );
        $sCutText = $asExplodedString[0];
        $sReturn = $sCutText.$sMessage;
        return strip_tags( $sReturn );
    }
    $sReturn = $sText;
    return strip_tags( $sReturn );
}

?>
