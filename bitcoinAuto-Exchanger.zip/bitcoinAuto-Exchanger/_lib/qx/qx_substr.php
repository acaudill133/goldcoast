<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_substr( $param, $lim0 = 0, $lim1 = 0 )
{
    if ( $lim1 )
    {
        return substr( $param, $lim0, $Var_144 );
    }
    return substr( $param, $lim0 );
}

?>
