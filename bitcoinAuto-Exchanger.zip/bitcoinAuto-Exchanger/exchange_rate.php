<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

include( "public.inc.php" );
$query = "Select * From {$_currencies} Where {$_currencies}.exchange_status = '1' AND {$_currencies}.cid<>'{$INTERNAL_CID}' {$currencies_clause} Order By cid Asc";
$arr_currency_ID = array( );
$arr_currency_FIELD = array( );
$result = db_query( $query, "&nbsp;" );
while ( $line = db_fetch_array( $result ) )
{
    $x = $line[cid];
    $arr_currency_ID[$x] = $line[cid];
}
db_free_result( $result );
foreach ( $arr_currency_ID as $key => $cid )
{
    if ( $cid != $x )
    {
        $coloumns .= $_exchange_rate.".".$cid.", ";
    }
    else
    {
        $coloumns .= $_exchange_rate.".".$cid." ";
    }
}
$count = 0;
$query = "Select {$_exchange_rate}.*, {$_currencies}.currency_name, {$_currencies}.currency_metal_name, {$_currencies}.currency_worth_name From {$_exchange_rate} Inner Join {$_currencies} ON {$_exchange_rate}.cid = {$_currencies}.cid\r\n\t\t\tWhere {$_currencies}.exchange_status = '{$STATUS_ENUM_ENABLE}' AND {$_exchange_rate}.cid<>'50' {$currencies_clause} Order By {$_currencies}.cid Asc;";
$result = db_query( $query, "&nbsp;" );
$arr_exhange_rate = mysql_push_data( $result );
db_free_result( $result );
echo "\r\n\r\n";
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."exchange_rate.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "exchange_rate.html";
    $page->assign( "arr_currency_ID", $arr_currency_ID );
    $page->assign( "arr_exchange_rate", $arr_exhange_rate );
    foreach ( $arr_exhange_rate as $line )
    {
        $Rate_Row .= "<tr class=col".fmod( $count, 2 ).">";
        $Rate_Row .= "<td style=text-align:left><b>".ucfirst( $line[currency_name] )." (".ucfirst( $line[currency_metal_name] ).")</b></td>";
        foreach ( $arr_currency_ID as $key => $x )
        {
            if ( !$line[$x] )
            {
                $Rate_Row .= "<td nowrap class='dst_rate'> --- </td>";
            }
            else if ( !rate_parser( $line[$x], "dst" ) && !rate_parser( $line[$x], "src" ) )
            {
                $Rate_Row .= "<td nowrap class='dst_rate'>x</td>";
            }
            else
            {
                $Rate_Row .= "<td nowrap class='dst_rate'>".rate_parser( $line[$x], "dst" )."</td>";
            }
        }
        $Rate_Row .= "</tr>";
        ++$count;
    }
    $page->assign( "Rate_Row", $Rate_Row );
    require( "include/engine_run.php" );
}
?>
