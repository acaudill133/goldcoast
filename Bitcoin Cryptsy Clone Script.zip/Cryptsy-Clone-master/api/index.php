<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="2;url=http://www.fbi.gov/">
 <title>
  you should not visit this page...
 </title>
</head>
<body>
<p>
you should not visit this page..., 
</p>
Your IP is logged
please visit our friends here ..</br>
<a href = "http://www.fbi.gov/"> http://www.fbi.gov/ </A> 
</br>
</body>
</html>