<?php
$b = protect($_GET['b']);
$id = protect($_GET['id']);
?>
<ol class="breadcrumb">
	<li><a href="./">WebAdmin</a></li>
	<li class="active">Companies</li>
</ol>

<div class="row">
	<div class="col-lg-12">
			<?php
			if($b == "setup_account") {
				$id = protect($_GET['id']);
				$query = $db->query("SELECT * FROM companies_list WHERE id='$id'");
				if($query->num_rows==0) { header("Location: ./?a=companies"); }
				$row = $query->fetch_assoc();
				?>
				<div class="panel panel-primary">
                  <div class="panel-heading"> 
						Setup account
				  </div>
                  <div class="panel-body">
					<?php
					$name = $row['name'];
					if($name == "PayPal") {
						if(isset($_POST['btn_setup'])) {
							$account = protect($_POST['account']);
							if(empty($account)) { echo error("Please enter your PayPal email address."); }
							elseif(!isValidEmail($account)) { echo error("Please enter valid PayPal email address."); }
							else {
								$update = $db->query("UPDATE companies_list SET account='$account' WHERE id='$row[id]'");
								header("Location: ./?a=companies");
							}
						}
						?>
						<form action="" method="POST">
							<div class="form-group">
								<label>Your PayPal email address</label>
								<input type="text" class="form-control" name="account" value="<?php echo $row['account']; ?>">
							</div>
							<button type="submit" class="btn btn-primary" name="btn_setup"><i class="fa fa-cog"></i> Setup</button>
						</form>
						<?php
					} elseif($name == "Skrill") {
						if(isset($_POST['btn_setup'])) {
							$account = protect($_POST['account']);
							$a_field_1 = protect($_POST['a_field_1']);
							if(empty($account)) { echo error("Please enter your Skrill email address."); }
							elseif(!isValidEmail($account)) { echo error("Please enter valid Skrill email address."); }
							elseif(empty($a_field_1)) { echo error("Please enter your Skrill secret key."); }
							else {
								$update = $db->query("UPDATE companies_list SET account='$account',a_field_1='$a_field_1' WHERE id='$row[id]'");
								header("Location: ./?a=companies");
							}
						}
						?>
						<form action="" method="POST">
							<div class="form-group">
								<label>Your Skrill email address</label>
								<input type="text" class="form-control" name="account" value="<?php echo $row['account']; ?>">
							</div>
							<div class="form-group">
								<label>Secret key</label>
								<input type="text" class="form-control" name="a_field_1" value="<?php echo $row['a_field_1']; ?>">
							</div>
							<button type="submit" class="btn btn-primary" name="btn_setup"><i class="fa fa-cog"></i> Setup</button>
						</form>
						<?php
					} elseif($name == "WebMoney") {
						if(isset($_POST['btn_setup'])) {
							$account = protect($_POST['account']);
							if(empty($account)) { echo error("Please enter your WebMoney account."); }
							elseif(strlen($account)<12) { echo error("Please enter valid WebMoney account."); }
							else {
								$update = $db->query("UPDATE companies_list SET account='$account' WHERE id='$row[id]'");
								header("Location: ./?a=companies");
							}
						}
						?>
						<form action="" method="POST">
							<div class="form-group">
								<label>Your WebMoney account</label>
								<input type="text" class="form-control" name="account" value="<?php echo $row['account']; ?>">
							</div>
							<button type="submit" class="btn btn-primary" name="btn_setup"><i class="fa fa-cog"></i> Setup</button>
						</form>
						<?php
					} elseif($name == "Payeer") {
						if(isset($_POST['btn_setup'])) {
							$account = protect($_POST['account']);
							$a_field_1 = protect($_POST['a_field_1']);
							if(empty($account)) { echo error("Please enter your Payeer account."); }
							elseif(strlen($account)<8) { echo error("Please enter valid Payeer account."); }
							elseif(empty($a_field_1)) { echo error("Please enter your Payeer secret key."); }
							else {
								$update = $db->query("UPDATE companies_list SET account='$account',a_field_1='$a_field_1' WHERE id='$row[id]'");
								header("Location: ./?a=companies");
							}
						}
						?>
						<form action="" method="POST">
							<div class="form-group">
								<label>Your Payeer</label>
								<input type="text" class="form-control" name="account" value="<?php echo $row['account']; ?>">
							</div>
							<div class="form-group">
								<label>Secret key</label>
								<input type="text" class="form-control" name="a_field_1" value="<?php echo $row['a_field_1']; ?>">
							</div>
							<button type="submit" class="btn btn-primary" name="btn_setup"><i class="fa fa-cog"></i> Setup</button>
						</form>
						<?php
					} elseif($name == "Perfect Money") {
						if(isset($_POST['btn_setup'])) {
							$account = protect($_POST['account']);
							if(empty($account)) { echo error("Please enter your Perfect Money account."); }
							elseif(strlen($account)<7) { echo error("Please enter valid Perfect Money account."); }
							else {
								$update = $db->query("UPDATE companies_list SET account='$account' WHERE id='$row[id]'");
								header("Location: ./?a=companies");
							}
						}
						?>
						<form action="" method="POST">
							<div class="form-group">
								<label>Your Perfect Money account</label>
								<input type="text" class="form-control" name="account" value="<?php echo $row['account']; ?>">
							</div>
							<button type="submit" class="btn btn-primary" name="btn_setup"><i class="fa fa-cog"></i> Setup</button>
						</form>
						<?php
					} elseif($name == "AdvCash") {
						if(isset($_POST['btn_setup'])) {
							$account = protect($_POST['account']);
							if(empty($account)) { echo error("Please enter your AdvCash email address."); }
							elseif(!isValidEmail($account)) { echo error("Please enter valid AdvCash email address."); }
							else {
								$update = $db->query("UPDATE companies_list SET account='$account' WHERE id='$row[id]'");
								header("Location: ./?a=companies");
							}
						}
						?>
						<form action="" method="POST">
							<div class="form-group">
								<label>Your AdvCash email address</label>
								<input type="text" class="form-control" name="account" value="<?php echo $row['account']; ?>">
							</div>
							<button type="submit" class="btn btn-primary" name="btn_setup"><i class="fa fa-cog"></i> Setup</button>
						</form>
						<?php
					} elseif($name == "OKPay") {
						if(isset($_POST['btn_setup'])) {
							$account = protect($_POST['account']);
							if(empty($account)) { echo error("Please enter your OKPay account."); }
							elseif(strlen($account)<12) { echo error("Please enter valid OKPay account."); }
							else {
								$update = $db->query("UPDATE companies_list SET account='$account' WHERE id='$row[id]'");
								header("Location: ./?a=companies");
							}
						}
						?>
						<form action="" method="POST">
							<div class="form-group">
								<label>Your OKPay account</label>
								<input type="text" class="form-control" name="account" value="<?php echo $row['account']; ?>">
							</div>
							<button type="submit" class="btn btn-primary" name="btn_setup"><i class="fa fa-cog"></i> Setup</button>
						</form>
						<?php
					} else {
						header("Location: ./?a=companies");
					}
					?>
				  </div>
				</div>
				<?php
			} elseif($b == "turn_on") {
				$id = protect($_GET['id']);
				$query = $db->query("SELECT * FROM companies_list WHERE id='$id'");
				if($query->num_rows==0) { header("Location: ./?a=companies"); }
				$update = $db->query("UPDATE companies_list SET allow_send='1' WHERE id='$id'");
				header("Location: ./?a=companies");
			} elseif($b == "turn_off") {
				$id = protect($_GET['id']);
				$query = $db->query("SELECT * FROM companies_list WHERE id='$id'");
				if($query->num_rows==0) { header("Location: ./?a=companies"); }
				$update = $db->query("UPDATE companies_list SET allow_send='0' WHERE id='$id'");
				header("Location: ./?a=companies");
			} elseif($b == "manage") {
				$id = protect($_GET['id']);
				$query = $db->query("SELECT * FROM companies_list WHERE id='$id'");
				if($query->num_rows==0) { header("Location: ./?a=companies"); }
				$row = $query->fetch_assoc();
				$c = protect($_GET['c']);
				$id2 = protect($_GET['id2']);
				if($c == "turn_on") {
				$query = $db->query("SELECT * FROM companies_list_receive WHERE id='$id2'");
				if($query->num_rows==0) { header("Location: ./?a=companies"); }
				$update = $db->query("UPDATE companies_list_receive SET allow_receive='1' WHERE id='$id2'");
				header("Location: ./?a=companies&b=manage&id=$id");
				} elseif($c == "turn_off") {
				$query = $db->query("SELECT * FROM companies_list_receive WHERE id='$id2'");
				if($query->num_rows==0) { header("Location: ./?a=companies"); }
				$update = $db->query("UPDATE companies_list_receive SET allow_receive='0' WHERE id='$id2'");
				header("Location: ./?a=companies&b=manage&id=$id");
				} elseif($c == "edit_rate") {
				$query2 = $db->query("SELECT * FROM companies_list_receive WHERE id='$id2'");
				if($query2->num_rows==0) { header("Location: ./?a=companies"); }
				$row2 = $query2->fetch_assoc();
				?>
				<div class="panel panel-primary">
                  <div class="panel-heading"> 
						Edit exchange rate
				  </div>
                  <div class="panel-body">
					<?php
					if(isset($_POST['btn_update'])) {
						$exchange_rate = protect($_POST['exchange_rate']);
						if(empty($exchange_rate)) { echo error("Please enter some value for exchange rate."); }
						elseif(!is_numeric($exchange_rate)) { echo error("Please enter valid value for exchange rate. Eg: 0.96 or 1.5"); }
						else {
							$update = $db->query("UPDATE companies_list_receive SET exchange_rate='$exchange_rate' WHERE id='$id2'");
							$redirect = './?a=companies&b=manage&id='.$id;
							header("Location: $redirect");
						}
					}
					?>
					<form action="" method="POST">
						<div class="form-group">
							<label>Rate</label>
							<div class="input-group">
							  <span class="input-group-addon" id="basic-addon1">1 = </span>
							  <input type="text" class="form-control" name="exchange_rate" value="<?php echo $row2['exchange_rate']; ?>">
							</div>
						</div>
						<button type="submit" class="btn btn-primary" name="btn_update"><i class="fa fa-check"></i> Update</button>
					</form>
				  </div>
				</form>
				<?php
				} else {
				?>
				<div class="panel panel-primary">
                  <div class="panel-heading"> 
						Management list of allowed exchange companies
				  </div>
                  <div class="panel-body">
					<table class="table table-hover">
						<thead>
							<tr>
								<td width="15%">User send</td>
								<td width="15%">User receive</td>
								<td width="15%">Allow user receive</td>
								<td width="15%">Exchange rate</td>
								<td width="40%">Currencies</td>
							</tr>
						</thead>
							<?php
							$query1 = $db->query("SELECT * FROM companies_list_receive WHERE cid='$id' ORDER BY id");
							if($query1->num_rows>0) {
								while($row1 = $query1->fetch_assoc()) {
									?>
									<tr>
										<td><?php echo $row['name']; ?></td>
										<td><?php echo $row1['name']; ?></td>
										<td>
											<?php
											if($row1['allow_receive'] == "1") {
												echo 'Yes (<a href="./?a=companies&b=manage&id='.$row[id].'&c=turn_off&id2='.$row1[id].'">Turn off</a>)';
											} else {
												echo 'No (<a href="./?a=companies&b=manage&id='.$row[id].'&c=turn_on&id2='.$row1[id].'">Turn on</a>)';
											}
											?>
										</td>
										<td>1 = <?php echo $row1['exchange_rate']; ?> (<a href="./?a=companies&b=manage&id=<?php echo $row['id']; ?>&c=edit_rate&id2=<?php echo $row1['id']; ?>">Edit</a>)</td>
										<td>
											<?php
											$get_list = $db->query("SELECT * FROM currencies WHERE cid1='$row[id]' and cid2='$row1[id]' and allow='1' ORDER BY id");
											if($get_list->num_rows>0) { 
												$list = '';
												$i = 1;
												while($get = $get_list->fetch_assoc()) {
													if($i == 1) {
														$list = $get['currency'];
													} else {
														$list = $list.', '.$get[currency];
													}
													$i++;
												}
												echo $list;
											} else {
												echo 'No have currencies.';
											}
											?>
										</td>
									</tr>
									<?php
								}
							} else {
								echo '<tr><td colspan="5">No have companies.</td></tr>';
							}
							?>
						</thead>
					</table>
				  </div>
				</div>
				<?php
				}
			} else {
				?>
				<div class="panel panel-primary">
                  <div class="panel-heading"> 
						<i class="fa fa-map-signs"></i> Companies 
				  </div>
                  <div class="panel-body">
					<table class="table table-hover">
						<thead>
							<tr>
								<td width="15%">Name</td>
								<td width="20%">Account</td>
								<td width="15%">Allow user send</td>
								<td width="50%">User receive in</td>
							</tr>
						</thead>
						<tbody>
							<?php
							$query = $db->query("SELECT * FROM companies_list ORDER BY id");
							if($query->num_rows>0) {
								while($row = $query->fetch_assoc()) {
									?>
									<tr>
										<td><?php echo $row['name']; ?></td>
										<td><?php if(empty($row['account'])) { echo '<a href="./?a=companies&b=setup_account&id='.$row[id].'">Set up account</a>'; } else { echo $row[account].' (<a href="./?a=companies&b=setup_account&id='.$row[id].'">Edit</a>)'; } ?></td>
										<td>
											<?php
											if($row['allow_send'] == "1") {
												echo 'Yes (<a href="./?a=companies&b=turn_off&id='.$row[id].'">Turn off</a>)';
											} else {
												echo 'No (<a href="./?a=companies&b=turn_on&id='.$row[id].'">Turn on</a>)';
											}
											?>
										</td>
										<td>	
											<?php
											$get_list = $db->query("SELECT * FROM companies_list_receive WHERE cid='$row[id]' and allow_receive='1' ORDER BY id");
											if($get_list->num_rows>0) { 
												$list = '';
												$i = 1;
												while($get = $get_list->fetch_assoc()) {
													if($i == 1) {
														$list = $get['name'];
													} else {
														$list = $list.', '.$get[name];
													}
													$i++;
												}
												$list = $list.' (<a href="./?a=companies&b=manage&id='.$row[id].'">Manage</a>)';
												echo $list;
											} else {
												echo 'No have companies.';
											}
											?>
										</td>
									</tr>
									<?php
								}
							} else {
								echo '<tr><td colspan="4">No have companies.</td></tr>';
							}
							?>
						</tbody>
					</table>
			      </div>
				</div>
				<?php
			}
			?>
	</div>
</div>