<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require_once( "include/config.inc.php" );
require_once( "include/class.rss_generator.php" );
$rss_channel = new rssGenerator_channel( );
$rss_channel->title = $LANG_msg['page_description'];
$rss_channel->link = $CONFIG['SITE_URL'];
$rss_channel->description = "E-currency reserved amount(s)";
$rss_channel->language = "en-us";
$rss_channel->generator = $CONFIG['SITE_NAME']." RSS Feed Generator 2.0";
$rss_channel->managingEditor = $CONFIG['REPORT_MAIL'];
$query = "Select {$_exchange_rate}.*, {$_currencies}.currency_name, {$_currencies}.currency_metal_name, {$_currencies}.currency_worth_name, {$_currencies}.reserve_amount From {$_exchange_rate} Inner Join {$_currencies} ON {$_exchange_rate}.cid = {$_currencies}.cid\r\n\tWhere {$_currencies}.exchange_status = '1' Order By {$_currencies}.cid Asc;";
if ( $result = db_query( $query ) )
{
    if ( 0 < db_num_rows( $result ) )
    {
        while ( $row = mysql_fetch_assoc( $result ) )
        {
            $item = new rssGenerator_item( );
            $item->title = ucfirst( $row['currency_name'] )." ".$row['currency_metal_name'];
            $item->description = $row['reserve_amount'] == 0 ? "Not available" : $row['reserve_amount']." ".strtoupper( $row['currency_worth_name'] );
            $item->pubDate = date( "Y-m-d, G:i:s T " );
            $rss_channel->items[] = $item;
        }
    }
    else
    {
        error( "There is not any results currently, please check again later." );
    }
}
else
{
}
mysql_free_result( $result );
$rss_feed = new rssGenerator_rss( );
$rss_feed->encoding = "UTF-8";
$rss_feed->version = "2.0";
@header( "Content-Type: text/xml" );
echo $rss_feed->createFeed( $rss_channel );
?>
