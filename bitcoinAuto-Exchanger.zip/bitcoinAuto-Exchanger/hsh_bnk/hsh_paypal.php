<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

chdir( "../" );
include( "include/config.inc.php" );
$req = "cmd=_notify-validate";
foreach ( $_POST as $key => $value )
{
    $value = urlencode( stripslashes( $value ) );
    $req .= "&{$key}={$value}";
}
$header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Content-Length: ".strlen( $req )."\r\n\r\n";
$fp = fsockopen( "ssl://www.paypal.com", 443, $errno, $errstr, 30 );
$item_name = $_POST['item_name'];
$PAYMENT_ID = $_POST['item_number'];
$payment_status = $_POST['payment_status'];
$payment_amount = $_POST['mc_gross'];
$PAYMENT_BATCH_NUM = $_POST['txn_id'];
$receiver_email = $_POST['receiver_email'];
$PAYER_ACCOUNT = $_POST['payer_email'];
$PAID_WORTH_VALUE = $_POST['mc_currency'];
if ( !$fp )
{
}
else
{
    fputs( $fp, $header.$req );
    while ( !feof( $fp ) )
    {
        $res = fgets( $fp, 1024 );
        if ( strcmp( $res, "VERIFIED" ) == 0 )
        {
            if ( !$dbconn )
            {
                $dbconn = db_open( );
            }
            $arr_PAYPAL = get_currency_data( "", "paypal", strtoupper( $PAID_WORTH_VALUE ) );
            if ( strtolower( $receiver_email ) == strtolower( $arr_PAYPAL['ACCOUNT'] ) && db_if_exists( "SELECT eid From {$_exchange_lines} WHERE exchange_refrence='{$PAYMENT_ID}' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND src_amount='{$payment_amount}'" ) )
            {
                SEND_EXHCANGE_MAIL( $PAYMENT_ID, "receive" );
                commit_exchange( $PAYMENT_ID, $PAYMENT_BATCH_NUM, $PAYER_ACCOUNT, $PAID_WORTH_VALUE );
                $Message_log[] = "PAYPAL ADD TO DATABSE";
            }
            $Message_log[] = "PAYPAL ACCEPTED";
            db_close( $dbconn );
        }
        else if ( strcmp( $res, "INVALID" ) == 0 )
        {
            $Message_log[] = "PAYPAL FAILED";
        }
    }
    fclose( $fp );
}
Write_File( );
?>
