<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_load_file( $filename )
{
    if ( is_file( $filename ) && ( $hd = @fopen( $filename, "r" ) ) )
    {
        $content = fread( $hd, filesize( $filename ) );
        fclose( $hd );
        return $content;
    }
}

?>
