<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

echo "<INPUT type=hidden value=\"";
echo $def_payee_account;
echo "\" name=FORCED_PAYER_ACCOUNT>\r\n\r\n\r\n\r\n\r\n<input type=\"hidden\" name=\"PAYEE_ACCOUNT\" value=\"";
echo $payee_account;
echo "\">\r\n<input type=\"hidden\" name=\"PAYEE_NAME\" value=\"";
echo $user;
echo "\">\r\n<input type=\"hidden\" name=\"PAYMENT_ID\" value=\"";
echo $payment_id;
echo "\">\r\n\r\n";
if ( $amount == "ask" )
{
    echo "    Amount you want to pay: <INPUT type='text' name=\"PAYMENT_AMOUNT\">\r\n";
}
else
{
    echo "    <input type=\"hidden\" name=\"PAYMENT_AMOUNT\" value=\"";
    echo $amount;
    echo "\">\r\n";
}
echo "<input type=\"hidden\" name=\"PAYMENT_UNITS\" value=\"";
echo $arr_PAYMENT['WORTH_VALUE'];
echo "\">\r\n<input type=\"hidden\" name=\"STATUS_URL\" value=\"";
echo $status_url;
echo "\">\r\n<input type=\"hidden\" name=\"PAYMENT_URL\" value=\"";
echo $response_ok;
echo "\">\r\n<input type=\"hidden\" name=\"PAYMENT_URL_METHOD\" value=\"POST\">\r\n<input type=\"hidden\" name=\"NOPAYMENT_URL\" value=\"";
echo $response_no;
echo "\">\r\n<input type=\"hidden\" name=\"NOPAYMENT_URL_METHOD\" value=\"POST\">\r\n<input type=\"hidden\" name=\"SUGGESTED_MEMO\" value=\"";
echo $suggested_memo;
echo "\">\r\n<input type=\"hidden\" name=\"BAGGAGE_FIELDS\" value=\"\">\r\n\r\n";
?>
