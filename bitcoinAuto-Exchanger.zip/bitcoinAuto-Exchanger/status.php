<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function check_amount( )
{
    global $amount;
    global $spend_min;
    global $sbalance;
    global $spendtype;
    global $index_by_balance;
    global $index_by_egold;
    if ( $amount <= 0 || $amount < $spend_min || $sbalance < $amount && $spendtype == $index_by_balance )
    {
        return false;
    }
    return true;
}

include( "public.inc.php" );
require( "include/user_ids_include.php" );
if ( session_member( ) )
{
    login_refresh( );
    $str_tool = new string_tool( );
    $nvar = db_get_array( "select money_account,cid,alt_password,email from {$_users_details} where uid='{$uid}' and suspended='0'" );
    $e_account = $nvar[0];
    $e_money = $nvar[1];
    $e_pass = $nvar[2];
    $e_email = $nvar[3];
    $merchant_name = convert_emoney( $e_money );
    if ( isset( $_POST['compound_rate'] ) && $_POST['compound_rate'] <= 100 )
    {
        $compound_rate = $str_tool->remove_dangerous_chars( $_POST['compound_rate'] );
        db_exec( "update {$_users} set compound = '{$compound_rate}' where uid='{$uid}'" );
        $compound_update = true;
    }
    $e_compound = db_get_id( "SELECT compound FROM {$_users} WHERE uid='{$uid}'" );
    $compound = get_sum( "", $STATUS_ENUM_ENABLE, $TRANS_ENUM_COMPBANK );
    $sbalance = get_sum( "", $STATUS_ENUM_ENABLE, $TRANS_ENUM_BANK ) + $compound;
    $commission = get_sum( "", $STATUS_ENUM_ENABLE, $TRANS_ENUM_COMMISSION );
    $withdraw_now = get_sum( "", $STATUS_ENUM_ENABLE, $TRANS_ENUM_EARNBANK );
    $withdraw_pending = get_sum( "", $STATUS_ENUM_DISABLE, $TRANS_ENUM_WITHDRAW, true );
    if ( !$withdraw_now )
    {
        $withdraw_now = 0;
    }
    if ( !$withdraw_pending )
    {
        $withdraw_pending = 0;
    }
    $type = trim( $str_tool->remove_dangerous_chars( $_POST['type'] ) );
    $amount = trim( $str_tool->remove_dangerous_chars( $_POST['amount'] ) );
    $confirm = trim( $str_tool->remove_dangerous_chars( $_POST['confirm'] ) );
    $DST_ID = trim( $str_tool->remove_dangerous_chars( $_POST['dstID'] ) );
    $DST_ACCOUNT = trim( $str_tool->remove_dangerous_chars( $_POST['DST_ACCOUNT'] ) );
    if ( $_POST['submit'] && $type )
    {
        if ( $withdraw_now < $amount || $amount <= 0 || !is_numeric( $amount ) )
        {
            $Error[] = $LANG_msg['withdraw_013'];
        }
        if ( $user_status != $STATUS_ENUM_ENABLE )
        {
            $Error[] = $LANG_msg['withdraw_019'];
        }
        if ( $type == "profit" && $amount < $def_minimum_withdraw )
        {
            $Error[] = $LANG_msg['withdraw_013'];
        }
        if ( $e_money != $DST_ID && $amount <= $CONFIG['MIN_EXCHANGE_FEE'] )
        {
            $Error[] = $LANG_msg['exchange_016']." ".FormatPrice( $CONFIG['MIN_EXCHANGE_FEE'] );
        }
        if ( !$Error && !db_if_exists( "SELECT status FROM {$_lines} WHERE uid='{$uid}' AND pmt_type='{$TRANS_ENUM_EARNBANK}' AND status='{$STATUS_ENUM_ENABLE}' AND amount >= abs({$amount})" ) )
        {
            $Error[] = $LANG_msg['withdraw_013'];
        }
        $turing_id = rand( 100000, 999999 );
        if ( $type == "profit" && !$Error && $confirm )
        {
            if ( $e_money != $DST_ID && ( $Tmp_215 || strlen( $DST_ACCOUNT ) < 5 ) )
            {
                $Error[] = $LANG_msg['exchange_002'];
            }
            if ( $e_pass != crypt( $_POST['altpassword'], $e_pass ) && $def_user_alternate_pass_enable || $Error )
            {
                $show_confrim = true;
                $Error[] = $LANG_msg['withdraw_008'];
            }
            else
            {
                $show_confrim = false;
                $exchange = get_exchange( $amount, $e_money, "profit" );
                $EARN_BANK = db_get_id( "SELECT amount FROM {$_lines} WHERE uid='{$uid}' AND pmt_type='{$TRANS_ENUM_EARNBANK}' AND status='{$STATUS_ENUM_ENABLE}'" );
                $REMAIN_EARN_AMOUNT = $EARN_BANK - $amount;
                if ( $DST_ID )
                {
                    $w_note = $LANG_msg['note_withdraw'];
                    db_exec( "insert into {$_lines} (uid,pmt_type,amount,exchange,cid,status,turing_id,user_note,pmt_note,date) \r\n\t\t\t\t\t\tvalues ('{$uid}','{$TRANS_ENUM_WITHDRAW}','-{$amount}','-{$exchange}','{$e_money}','{$STATUS_ENUM_DISABLE}','{$turing_id}','{$REMOTE_ADDR}','{$w_note}',now())" );
                }
                else if ( $CONFIG['exchange_profit'] && $DST_ID )
                {
                    while ( !$Exchange_Refrence_exist )
                    {
                        $Exchange_Refrence = rand( 1000000000, 1e+010 );
                        if ( !db_if_exists( "SELECT eid FROM {$_exchange_lines} WHERE exchange_refrence='{$Exchange_Refrence}'" ) )
                        {
                            $Exchange_Refrence_exist = true;
                        }
                    }
                    $w_note = " - ".$LANG_msg['note_exchange6']." ".convert_emoney(  );
                    $DST_AMOUNT = calculate_DST_amount( 50, $DST_ID, $amount );
                    db_exec( "insert into {$_exchange_lines} (uid, src_cid, src_amount, src_date, src_batch, src_status, dst_cid, dst_amount, dst_account, dst_status, exchange_email_address, exchange_note, exchange_refrence, ref_uid, dst_account_name) \r\n\t\t\t\tvalues ('{$uid}', '50', '{$amount}', now(), '{$turing_id}', '{$STATUS_ENUM_ENABLE}', '{$DST_ID}', '{$DST_AMOUNT}', '{$DST_ACCOUNT}', '{$STATUS_ENUM_DISABLE}', '{$e_email}','{$w_note}', '{$Exchange_Refrence}', '{$Exchange_referral}', '{$DST_ACCOUNT_NAME}')" );
                    db_exec( "insert into {$_lines} (uid,pmt_type,amount,exchange,cid,status,turing_id,user_note,pmt_note,date) \r\n\t\t\t\t\t\tvalues ('','{$TRANS_ENUM_WITHDRAW}','-{$amount}','-{$exchange}','{$e_money}','{$STATUS_ENUM_ENABLE}','{$turing_id}','{$REMOTE_ADDR}','{$w_note}, Order ID:{$Exchange_Refrence}',now())" );
                }
                else
                {
                    $Error[] = "Unkown error occured";
                }
                $payment_id = mysql_insert_id( );
                db_exec( "update {$_lines} set amount='{$REMAIN_EARN_AMOUNT}', exchange='{$REMAIN_EARN_AMOUNT}', user_note='Withdraw profit {$uid}' WHERE pmt_type='{$TRANS_ENUM_EARNBANK}' AND status='{$STATUS_ENUM_ENABLE}' AND uid='{$uid}'" );
                unset( $type );
                $Success[] = $LANG_msg['withdraw_031'];
            }
        }
        if ( $type == "principal" && !$Error && $confirm )
        {
            $exchange = get_exchange( $amount, $INTERNAL_CID, "compound" );
            $pmt_note = $LANG_msg['note_sprofit'];
            check_rows( $uid, $_POST['plid'], $payment_id );
            $EARN_BANK = db_get_id( "SELECT amount FROM {$_lines} where uid='{$uid}' and pmt_type='{$TRANS_ENUM_EARNBANK}' and status='{$STATUS_ENUM_ENABLE}'" );
            $REMAIN_EARN_AMOUNT = $EARN_BANK - $amount;
            $BANK_AMOUNT = db_get_id( "SELECT amount FROM {$_lines} where uid='{$uid}' and pmt_type='{$TRANS_ENUM_BANK}' and status='{$STATUS_ENUM_ENABLE}' AND plan_type='{$plid}'" );
            $TOTAL_BANK_AMOUNT = $BANK_AMOUNT + $amount;
            db_exec(  );
            $payment_id = mysql_insert_id( );
            db_exec( "update {$_lines} set amount='{$REMAIN_EARN_AMOUNT}', exchange='{$REMAIN_EARN_AMOUNT}', user_note='Withdraw principal {$uid}' WHERE pmt_type = '{$TRANS_ENUM_EARNBANK}' AND status='{$STATUS_ENUM_ENABLE}' AND uid='{$uid}'" );
            db_exec( "update {$_lines} set amount='{$TOTAL_BANK_AMOUNT}', exchange='{$TOTAL_BANK_AMOUNT}', date=now() WHERE pmt_type = '{$TRANS_ENUM_BANK}' AND status='{$STATUS_ENUM_ENABLE}' AND uid='{$uid}' AND plan_type='{$plid}'" );
            unset( $type );
            $Success[] = $err_Success_principal;
        }
        if ( $payment_id && $type == "principal" )
        {
            SEND_INVEST_RECEIVE_MAIL( $payment_id, "Profit" );
        }
        $sbalance = get_sum( "", $STATUS_ENUM_ENABLE, $TRANS_ENUM_BANK ) + $compound;
        $commission = get_sum( "", $STATUS_ENUM_ENABLE, $TRANS_ENUM_COMMISSION );
        $withdraw_now = get_sum( "", $STATUS_ENUM_ENABLE, $TRANS_ENUM_EARNBANK );
        $withdraw_pending = get_sum( "", $STATUS_ENUM_DISABLE, $TRANS_ENUM_WITHDRAW, true );
    }
}
if ( $_POST['x_status'] && ( eregi( $CONFIG['SITE_URL'], $_SERVER['HTTP_REFERER'] ) || eregi( $CONFIG['SITE_URL_SECURE'], $_SERVER['HTTP_REFERER'] ) ) )
{
    if ( $_POST['x_status'] == "Successfull" )
    {
        $Success[] = $LANG_msg['spend_010'];
    }
    else if ( $_POST['x_status'] == "Failed" )
    {
        $Error[] = $LANG_msg['spend_011'];
    }
}
if ( $_GET['message'] == "profile" )
{
    $Success[] = $LANG_msg['signup_052']."<Strong>".ucfirst( $fullname )."</Strong>".$LANG_msg['signup_027'];
}
if ( !$_GET && !$_POST )
{
    $top_message = true;
}
if ( $type && !$Error || $show_confrim )
{
    $confirm_box = true;
}
if ( !$_POST['submit'] )
{
    $page_title = $LANG_msg['menu_010'];
}
if ( $_POST['type'] == "principal" )
{
    $page_title = $LANG_msg['balance_002'];
}
if ( $_POST['type'] == "profit" )
{
    $page_title = $LANG_msg['balance_007'];
}
$US_HOLIDAYS = getHolidays2( date( "Y" ) );
if ( array_key_exists( date( "Y-m-d" ), $US_HOLIDAYS ) )
{
    $holiday_msg = htmlspecialchars( $US_HOLIDAYS[date( "Y-m-d" )] )."<br> ".$LANG_msg['balance_009'];
}
else if ( date( "D" ) == "Sat" || date( "D" ) == "Sun" )
{
    $holiday_msg = $LANG_msg['balance_010'];
}
echo "\r\n";
if ( $CONFIG['exchange_profit'] )
{
    $query = "SELECT cid, currency_name, currency_metal_name FROM {$_currencies} WHERE (exchange_status='{$STATUS_ENUM_ENABLE}' OR cid='{$e_money}') ORDER BY cid asc";
    $result = db_query( $query, "&nbsp;" );
    $arr_currency_ID = array( );
    $arr_currency_NAME = array( );
    $arr_currency_METAL = array( );
    while ( $line = db_fetch_array( $result ) )
    {
        $x = $line[cid];
        $arr_currency_ID[$x] = $line[cid];
        $arr_currency_NAME[$x] = ucfirst( $line[currency_name] );
        $arr_currency_METAL[$x] = ucfirst( $line[currency_metal_name] );
    }
    db_free_result( $result );
    $query = "Select {$_exchange_rate}.* From {$_exchange_rate} Inner Join {$_currencies} ON {$_exchange_rate}.cid = {$_currencies}.cid Where {$_exchange_rate}.cid='50' Order By {$_currencies}.cid Asc";
    $arr_exchange_PROFIT_RATE = array( );
    $result = db_query( $query, "&nbsp;" );
    $line = db_fetch_array( $result );
    foreach ( $arr_currency_ID as $key => $x )
    {
        $arr_exchange_PROFIT_RATE[$x] = $line[$x];
    }
    db_free_result( $result );
}
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."status.php" );
}
else
{
    $LANG_msg['withdraw_030'] = str_replace( "[merchant_name]", $merchant_name, $LANG_msg['withdraw_030'] );
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "status.html";
    $page->assign( "confirm_box", $confirm_box );
    $page->assign( "top_message", $top_message );
    $page->assign( "page_title", $page_title );
    if ( $e_money == $_POST['dstID'] )
    {
        $page->assign( "same_account", true );
    }
    if ( $DST_ID )
    {
        $page->assign( "dst_amount", calculate_DST_amount( 50, $DST_ID, $amount ) );
    }
    $page->assign( "merchant_name", convert_emoney( $e_money ) );
    $page->assign( "dst_merchant_name", convert_emoney( $DST_ID ) );
    $page->assign( "dst_worth", get_worth_name( $DST_ID ) );
    if ( $amount )
    {
        $Post['amount'] = $amount;
    }
    $page->assign( "e_money", $e_money );
    $page->assign( "e_account", $e_account );
    $page->assign( "altpass_enable", $def_user_alternate_pass_enable );
    $page->assign( "Exchange_Refrence", $Exchange_Refrence );
    $page->assign( "type", $type );
    $page->assign( "DST_ID", $DST_ID );
    $page->assign( "withdraw_now", $withdraw_now );
    $page->assign( "withdraw_pending", $withdraw_pending );
    $page->assign( "def_minimum_withdraw", $def_minimum_withdraw );
    $page->assign( "commission", $commission );
    $page->assign( "user_status", $user_status );
    $page->assign( "currencies_FNAME", $currencies_FNAME );
    require( "include/engine_run.php" );
}
?>
