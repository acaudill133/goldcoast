<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_options( $param, $default = "_DEFAULT_", $noindex = false )
{
    $output = "";
    if ( is_array( $param ) )
    {
        $keyindex = 0;
        foreach ( $param as $key => $value )
        {
            if ( $key == $keyindex++ && is_numeric( $key ) && !$noindex )
            {
                $output .= "<option value=\"".$value."\"".( $value == $default ? "  selected" : "" ).">".$value."</option>";
            }
            else
            {
                $output .= "<option value=\"".$key."\"".( $key == $default ? "  selected" : "" ).">".$value."</option>";
            }
        }
    }
    return $output;
}

?>
