<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function startElement( $parser, $name, $attrs )
{
    global $rss_channel;
    global $currently_writing;
    global $main;
    switch ( $name )
    {
    case "RSS" :
    case "RDF:RDF" :
    case "ITEMS" :
        $currently_writing = "";
        break;
    case "CHANNEL" :
        $main = "CHANNEL";
        break;
    case "IMAGE" :
        $main = "IMAGE";
        $rss_channel['IMAGE'] = array( );
        break;
    case "ITEM" :
    }
    $main = "ITEMS";
    break;
    $currently_writing = $name;
    break;
}

function endElement( $parser, $name )
{
    global $rss_channel;
    global $currently_writing;
    global $item_counter;
    $currently_writing = "";
    if ( $name == "ITEM" )
    {
        ++$item_counter;
    }
}

function characterData( $parser, $data )
{
    global $rss_channel;
    global $currently_writing;
    global $main;
    global $item_counter;
    if ( $currently_writing != "" )
    {
        switch ( $main )
        {
        case "CHANNEL" :
            do
            {
                if ( !isset( $rss_channel[$currently_writing] ) )
                {
                    break;
                }
                else
                {
                    $rss_channel[$currently_writing] .= $data;
                }
            } while ( 0 );
            $rss_channel[$currently_writing] = $data;
            break;
        case "IMAGE" :
            do
            {
                if ( !isset( $rss_channel[$main][$currently_writing] ) )
                {
                    break;
                }
                else
                {
                    $rss_channel[$main][$currently_writing] .= $data;
                }
            } while ( 0 );
            $rss_channel[$main][$currently_writing] = $data;
            break;
        case "ITEMS" :
            if ( isset( $rss_channel[$main][$item_counter][$currently_writing] ) )
            {
                $Var_1272[$main][$item_counter][$currently_writing] .= $data;
            }
            else
            {
                $rss_channel[$main][$item_counter][$currently_writing] = $data;
            }
        }
    }
}

set_time_limit( 0 );
$rss_channel = array( );
$currently_writing = "";
$main = "";
$item_counter = 0;
?>
