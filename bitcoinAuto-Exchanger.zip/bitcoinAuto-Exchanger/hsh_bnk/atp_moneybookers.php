<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

echo "\r\n<input type=\"hidden\" name=\"pay_to_email\" value=\"";
echo $payee_account;
echo "\">\r\n<input type=\"hidden\" name=\"language\" value=\"EN\">\r\n\r\n";
if ( $amount == "ask" )
{
    echo "    Amount you want to pay: <INPUT type='text' name=\"amount\">\r\n";
}
else
{
    echo "    <input type=\"hidden\" name=\"amount\" value=\"";
    echo $amount;
    echo "\">\r\n";
}
echo "<input type=\"hidden\" name=\"currency\" value=\"";
echo $arr_PAYMENT['WORTH_VALUE'];
echo "\">\r\n<input type=\"hidden\" name=\"transaction_id\" value=\"";
echo $payment_id;
echo "\">\r\n<input type=\"hidden\" name=\"return_url\" value=\"";
echo $response_ok;
echo "\">\r\n<input type=\"hidden\" name=\"cancel_url\" value=\"";
echo $response_no;
echo "\">\r\n<input type=\"hidden\" name=\"status_url\" value=\"";
echo $def_bookers_verifier;
echo "\">\r\n<input type=\"hidden\" name=\"detail1_description\" value=\"";
echo $payment_id;
echo "\">\r\n<input type=\"hidden\" name=\"detail1_text\" value=\"";
echo $suggested_memo;
echo "\">\r\n<input type=\"submit\" name=\"Pay\" value=\"Pay\">\r\n";
?>
