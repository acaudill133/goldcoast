<?php
ob_start();
session_start();
error_reporting(0);
include("../includes/config.php");
$db = new mysqli($CONF['host'], $CONF['user'], $CONF['pass'], $CONF['name']);
if ($db->connect_errno) {
    echo "Failed to connect to MySQL: (" . $db->connect_errno . ") " . $db->connect_error;
}
$db->set_charset("utf8");
$settingsQuery = $db->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
$settings = $settingsQuery->fetch_assoc();
include("../includes/functions.php");
include(getLanguage($settings['url'],null,2));
$receive = protect($_POST['receive']);
$email = protect($_POST['email']); 
$account = protect($_POST['account']);
$query = $db->query("SELECT * FROM companies_list_receive WHERE id='$receive'");
$row = $query->fetch_assoc();

if(!isValidEmail($email)) { $data['status'] = "err"; $data['msg'] = error($lang['error_10']); } 
elseif($row['name'] == "PayPal" && empty($account)) { $data['status'] = "err"; $data['msg'] = error($lang['error_28']); }
elseif($row['name'] == "PayPal" && !isValidEmail($account)) { $data['status'] = "err"; $data['msg'] = error($lang['error_29']); }
elseif($row['name'] == "Skrill" && empty($account)) { $data['status'] = "err"; $data['msg'] = error($lang['error_30']); }
elseif($row['name'] == "Skrill" && !isValidEmail($account)) { $data['status'] = "err"; $data['msg'] = error($lang['error_31']); }
elseif($row['name'] == "WebMoney" && empty($account)) { $data['status'] = "err"; $data['msg'] = error($lang['error_32']); }
elseif($row['name'] == "WebMoney" && strlen($account)<12) { $data['status'] = "err"; $data['msg'] = error($lang['error_33']); }
elseif($row['name'] == "Payeer" && empty($account)) { $data['status'] = "err"; $data['msg'] = error($lang['error_34']); }
elseif($row['name'] == "Payeer" && strlen($account)<8) { $data['status'] = "err"; $data['msg'] = error($lang['error_35']); }
elseif($row['name'] == "Perfect Money" && empty($account)) { $data['status'] = "err"; $data['msg'] = error($lang['error_36']); }
elseif($row['name'] == "Perfect Money" && strlen($account)<7) { $data['status'] = "err"; $data['msg'] = error($lang['error_37']); }
elseif($row['name'] == "AdvCash" && empty($account)) { $data['status'] = "err"; $data['msg'] = error($lang['error_38']); }
elseif($row['name'] == "AdvCash" && !isValidEmail($account)) { $data['status'] = "err"; $data['msg'] = error($lang['error_39']); }
elseif($row['name'] == "OKPay" && empty($account)) { $data['status'] = "err"; $data['msg'] = error($lang['error_40']); }
elseif($row['name'] == "OKPay" && strlen($account)<8) { $data['status'] = "err"; $data['msg'] = error($lang['error_41']); }
else {
	$data['status'] = "111";
	$data['msg'] = 'ok';
}
echo json_encode($data);
?>