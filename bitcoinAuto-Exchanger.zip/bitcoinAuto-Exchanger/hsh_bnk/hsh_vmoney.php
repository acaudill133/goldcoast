<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

chdir( "../" );
include( "include/config.inc.php" );
if ( $_POST['PMT_MERCHANT_ACCOUNT'] )
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    #$arr_VMONEY = ( "", "v-money" );
    $ramz = new RamzNegar( );
    $arr_VMONEY['ALT_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_VMONEY['ALT_PASSWORD'] );
}
$Vmoney_array = array(
    $_POST['PMT_MERCHANT_ACCOUNT'],
    $_POST['PMT_PAYER'],
    $_POST['PMT_AMOUNT'],
    $_POST['PMT_BATCH_NUM'],
    $_POST['PMT_TIMESTAMP'],
    md5( $arr_VMONEY['ALT_PASSWORD'] )
);
$Vmoney_hash = md5( implode( ";", $Vmoney_array ) );
$PAYMENT_ID = $_POST['PMT_PAYMENT_ID'];
$PAYMENT_AMOUNT = $_POST['PMT_AMOUNT'];
$PAYMENT_BATCH = $_POST['PMT_BATCH_NUM'];
$PAYER_ACCOUNT = $_POST['PMT_PAYER'];
if ( $Vmoney_hash != $_POST['PMT_VERIFY_HASH'] )
{
    $Message_log[] = "V-MONEY FAILED!!!!!!!!!!!\n {$Vmoney_hash} != {$_POST['PMT_VERIFY_HASH']}";
    exit( );
    exit( 1 );
}
else
{
    $Message_log[] = "V-MONEY HASH ACCEPTED\n";
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    if ( Refrence2eid( $PAYMENT_ID ) )
    {
        if ( db_if_exists( "SELECT eid From {$_exchange_lines} WHERE exchange_refrence='{$PAYMENT_ID}' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND src_amount='{$PAYMENT_AMOUNT}'" ) )
        {
            SEND_EXHCANGE_MAIL( $PAYMENT_ID, "receive" );
            commit_exchange(  );
            $Message_log[] = "V-MONEY ADD TO DATABSE EXCHANGE";
        }
    }
    else
    {
        if ( db_if_exists( "select * from {$_lines} where id='{$PAYMENT_ID}' and amount='{$PAYMENT_AMOUNT}' AND status='{$STATUS_ENUM_DISABLE}'" ) )
        {
            SEND_INVEST_RECEIVE_MAIL( $PAYMENT_ID, $PAYER_ACCOUNT );
            commit_transaction( $PAYMENT_ID, $PAYMENT_BATCH );
            $Message_log[] = "V-MONEY ADD TO DATABSE";
        }
        $Message_log[] = "V-MONEY ACCEPTED INVEST";
    }
    db_close( $dbconn );
}
Write_File( );
unset( $arr_VMONEY );
?>
