<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

chdir( "../" );
include( "include/config.inc.php" );
if ( $_POST['PAYMENT_REC_ID'] )
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    $arr_PECUNIX = get_currency_data( "", "pecunix", strtoupper( $_POST['PAYMENT_UNITS'] ) );
    $ramz = new RamzNegar( );
    $arr_PECUNIX['ALT_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_PECUNIX['ALT_PASSWORD'] );
}
$Pecunix_array = array(
    strtolower( $_POST['PAYEE_ACCOUNT'] ),
    $_POST['PAYMENT_AMOUNT'],
    strtoupper( $_POST['PAYMENT_UNITS'] ),
    strtolower( $_POST['PAYER_ACCOUNT'] ),
    $_POST['PAYMENT_REC_ID'],
    $_POST['PAYMENT_GRAMS'],
    $_POST['PAYMENT_ID'],
    $_POST['PAYMENT_FEE'],
    $_POST['TXN_DATETIME'],
    $arr_PECUNIX['ALT_PASSWORD']
);
$Pecunix_hash = strtoupper(  );
$PAYEE_ACCOUNT = $_POST['PAYEE_ACCOUNT'];
$PAYMENT_ID = $_POST['PAYMENT_ID'];
$PAYMENT_AMOUNT = $_POST['PAYMENT_AMOUNT'];
$SPENDTYPE = $_POST['SPENDTYPE'];
$PAYMENT_REC_ID = $_POST['PAYMENT_REC_ID'];
$PAYER_ACCOUNT = $_POST['PAYER_ACCOUNT'];
$PAID_WORTH_VALUE = $_POST['PAYMENT_UNITS'];
if ( $Pecunix_hash != $_POST['PAYMENT_HASH'] )
{
    $Message_log[] = "PECUNIX FAILED!!!!!!!!!!!\n {$Pecunix_hash} = {$_POST['PAYMENT_HASH']}";
}
else
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    if ( Refrence2eid( $PAYMENT_ID ) )
    {
        if ( $PAYEE_ACCOUNT == $arr_PECUNIX['ACCOUNT'] && db_if_exists( "SELECT eid From {$_exchange_lines} WHERE exchange_refrence='{$PAYMENT_ID}' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND src_amount='{$PAYMENT_AMOUNT}'" ) )
        {
            SEND_EXHCANGE_MAIL( $PAYMENT_ID, "receive" );
            commit_exchange( $PAYMENT_ID, $PAYMENT_REC_ID, $PAYER_ACCOUNT, $PAID_WORTH_VALUE );
            $Message_log[] = "PECUNIX ADD TO DATABSE";
        }
    }
    else
    {
        if ( $PAYEE_ACCOUNT == $arr_PECUNIX['ACCOUNT'] && db_if_exists( "select * from {$_lines} where id='{$PAYMENT_ID}' and amount='{$PAYMENT_AMOUNT}' AND status='{$STATUS_ENUM_DISABLE}'" ) )
        {
            SEND_INVEST_RECEIVE_MAIL( $PAYMENT_ID, $PAYER_ACCOUNT );
            commit_transaction( $PAYMENT_ID, $PAYMENT_REC_ID );
            $Message_log[] = "PECUNIX ADD TO DATABSE";
        }
        $Message_log[] = "PECUNIX ACCEPTED";
    }
    db_close( $dbconn );
}
Write_File( );
unset( $arr_PECUNIX );
?>
