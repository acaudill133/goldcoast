<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

$user_name = "";
if ( !session_member( ) && !session_admin( ) )
{
    header( "Location: ".get_link( $site_logout_page ) );
}
if ( session_member( ) )
{
    $user_name = $user_login;
}
else if ( session_admin( ) && $_GET['id'] )
{
    $uid = $_GET['id'];
    $user_name = db_get_name_by_id( $_users, "login", "uid", $_GET['id'] );
    $admin_view = true;
}
?>
