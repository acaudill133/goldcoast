<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

include_once( "_lib/class.quickskin.php" );
if ( session_admin( ) && $_GET['recache'] )
{
    $_POST['selectedtab'] = 2;
    empty_cache_folder( );
}
$page = new QuickSkin( "main.html" );
if ( $CONFIG['temporary_close'] && !session_admin( ) && ( !$_POST['submit_login'] || !$_POST['submit_login'] ) && ( empty( $_GET['_login'] ) || empty( $CONFIG['secretadminlogin'] ) || $_GET['_login'] != $CONFIG['secretadminlogin'] ) )
{
    $page = new QuickSkin( "temporary_close.html" );
}
if ( $CONFIG['caching_status'] )
{
    $page->set( "cache_lifetime", 600 );
    $page->set( "reuse_code", true );
}
else
{
    $page->set( "cache_lifetime", 0 );
    $page->set( "reuse_code", false );
}
$page->set( "template_dir", $CONFIG['SKIN_FOLDER'] );
$page->set( "temp_dir", $Template_folder."_tmp/" );
$page->set( "cache_dir", $Template_folder."_tmp/" );
$page->assign( "tpl_img", "tplimgs/" );
$page->assign( "url_img", $CONFIG['SITE_URL']."/".$Template_folder."/".$CONFIG['SITE_TEMPLATE']."/tplimgs/" );
$page->assign( "tpl_js", "tpljs/" );
$page->assign( "url_js", $CONFIG['SITE_URL']."/".$Template_folder."/".$CONFIG['SITE_TEMPLATE']."/tpljs/" );
$page->assign( "tpl_css", "tplcss/" );
$page->assign( "url_css", $CONFIG['SITE_URL']."/".$Template_folder."/".$CONFIG['SITE_TEMPLATE']."/tplcss/" );
if ( !$Post )
{
    $Post = array( );
}
foreach ( $_POST as $key => $value )
{
    list( $fieldname, $require ) = fieldname ;   $Post["".$fieldname.""] = $value;
}
$page->assign( "Post", $Post );
if ( $debug_skin )
{
    $page->debug( );
}
$page->assign( "LANG", $LANG_msg );
$page->assign( "CONFIG", $CONFIG );
$page->assign( "arr_lang", make_tmp_array( $lang, "lang" ) );
$page->assign( "language", $language );
$page->assign( "cur_page", $cur_page );
$page->assign( "session_admin", session_admin( ) );
$page->assign( "session_member", session_member( ) );
$page->assign( "session_active", session_active( ) );
$page->assign( "usergroup", $usergroup );
$page->assign( "SERVER", array(
    "SERVER_PORT" => $_SERVER['SERVER_PORT'],
    "REQUEST_URI" => $_SERVER['REQUEST_URI'],
    "REMOTE_ADDR" => $_SERVER['REMOTE_ADDR']
) );
$page->assign( "page_Error", make_tmp_array( $Error, "Error" ) );
$page->assign(  );
$page->assign( "user_lang", $user_lang );
$page->assign( "fullname", $fullname );
$page->assign( "user_status", $user_status );
$page->assign( "uid", $uid );
$page->assign( "arr_data_news_list", $arr_data_news_list );
$page->assign( "arr_Reserve", $arr_Reserve );
if ( $_SESSION['loginerror'] )
{
    $page->assign( "Sloginerror", $_SESSION['loginerror'] );
}
unset( $_SESSION['loginerror'] );
if ( $_GET['id'] )
{
    $cur_link .= "&id=".$_GET['id'];
}
if ( $_GET['Pages'] )
{
    $cur_link .= "&Pages=".urlencode( $_GET['Pages'] );
}
if ( $_GET['News'] )
{
    $cur_link .= "&News=".urlencode( $_GET['News'] );
}
if ( $_GET['title'] )
{
    $cur_link .= "&title=".urlencode( $_GET['title'] );
}
$page->assign( "cur_link", $cur_link );
?>
