<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

$CONFIG['Version'] = "3.1.0";
$PMT_INFO_ADMIN = 5;
$PMT_INFO_MEMBER = "i";
$INTERNAL_CID = 0;
$INVEST_SECTION = false;
$STATUS_ENUM_DISABLE = 0;
$STATUS_ENUM_ENABLE = 1;
$STATUS_ENUM_LOCKED = 2;
$STATUS_ENUM_CLEAR = 3;
$STATUS_EXCHANGE[0] = "Open";
$STATUS_EXCHANGE[1] = "Completed";
$STATUS_EXCHANGE[2] = "Manual_processing";
$STATUS_EXCHANGE[3] = "Closed";
$STATUS_EXCHANGE[4] = "Cancelled";
$STATUS_EXCHANGE[5] = "Expired";
$STATUS_EXCHANGE[6] = "Declined";
$STATUS_EXCHANGE[7] = "Refunded";
$PLAN_ID_UNKNOWN = 0;
$PLAN_ID_DAILY = 1;
$PLAN_ID_PERIOD = 2;
$PLAN_ID_SPC = 3;
$PLAN_ID_SPC_DAILY = "d";
$PLAN_ID_SPC_WEEKLY = "w";
$PLAN_ID_SPC_BIWEEKLY = "b";
$PLAN_ID_SPC_MONTHLY = "m";
$PLAN_ID_SPC_YEARLY = "y";
$PLAN_SPC_ENABLE_LIST = "'{$PLAN_ID_SPC_DAILY}','{$PLAN_ID_SPC_WEEKLY}','{$PLAN_ID_SPC_BIWEEKLY}','{$PLAN_ID_SPC_MONTHLY}','{$PLAN_ID_SPC_YEARLY}'";
$WEEKLY_PAYOUT_DAY = "Monday";
$TRANS_ENUM_SPEND = "s";
$TRANS_ENUM_WITHDRAW = "w";
$TRANS_ENUM_TRANSFER = "t";
$TRANS_ENUM_INTERNAL = "i";
$TRANS_ENUM_COMMISSION = "c";
$TRANS_ENUM_BONUS = "b";
$TRANS_ENUM_PENALTY = "p";
$TRANS_ENUM_EARNING = "e";
$TRANS_ENUM_COMPOUND = "a";
$TRANS_ENUM_BANK = "bs";
$TRANS_ENUM_EARNBANK = "be";
$TRANS_ENUM_COMPBANK = "ba";
$site_start_day = 6;
$site_start_month = 8;
$site_start_year = 2007;
$sid = session_id( );
$REMOTE_ADDR = $_SERVER['REMOTE_ADDR'];
$DEF_DOCS_TYPE[1] = "News";
$DEF_DOCS_TYPE[2] = "Pages";
if ( $_GET['rid'] )
{
    $_SESSION['rid'] = $_GET['rid'];
}
$accept_date = date( "D M j G:i:s" );
$def_list_maxshow = 80;
$def_list_maxshow_users = 25;
$def_dollar = "\$ US";
$Monitors_Divid_Ref_percenet = 3;
$SIGNUP_BONUS = 0;
$COMPOUND_ENABLE = true;
$RANDOM_RATES = true;
$THIS_SITE_PLAN_ID = $PLAN_ID_DAILY;
$def_show_paid_out = true;
$def_use_period_plan = false;
$def_use_special_plans = true;
$def_plan_spc_used = $PLAN_ID_SPC_MONTHLY;
$def_show_invest_combo = false;
$def_minimum_withdraw = 0.2;
$def_monitor_logins = true;
$def_getref_without_spending = true;
$def_compound_full_withdraw = true;
$def_compound_infect_principal = true;
$def_principal_full_withdraw = true;
$def_money_transfer_enable = false;
$def_principal_trading_enable = false;
$def_principal_force_withdraw_enable = true;
$def_principal_force_withdraw_percent = 30;
$Var_4512 = false;
$def_principal_guarantee_withdraw_days = 30;
$def_user_alternate_pass_enable = false;
$CONFIG['update_currency'] = true;
$site_logout_page = $CONFIG['SITE_URL']."?Action=logout";
?>
