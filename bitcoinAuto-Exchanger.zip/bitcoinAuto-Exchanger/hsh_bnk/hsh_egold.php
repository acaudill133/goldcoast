<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

chdir( "../" );
include( "include/config.inc.php" );
$V2_HASH = $_POST['V2_HASH'];
$PAYMENT_ID = $Var_168['PAYMENT_ID'];
$PAYEE_ACCOUNT = $_POST['PAYEE_ACCOUNT'];
$PAYMENT_AMOUNT = $_POST['PAYMENT_AMOUNT'];
$PAYMENT_UNITS = $_POST['PAYMENT_UNITS'];
$PAYMENT_METAL_ID = $_POST['PAYMENT_METAL_ID'];
$PAYMENT_BATCH_NUM = $_POST['PAYMENT_BATCH_NUM'];
$USD_PER_OUNCE = $_POST['USD_PER_OUNCE'];
$PAYER_ACCOUNT = $_POST['PAYER_ACCOUNT'];
$ACTUAL_PAYMENT_OUNCES = $_POST['ACTUAL_PAYMENT_OUNCES'];
$FEEWEIGHT = $_POST['FEEWEIGHT'];
$TIMESTAMPGMT = $_POST['TIMESTAMPGMT'];
$PAYMENT_BATCH_NUM = $_POST['PAYMENT_BATCH_NUM'];
if ( $_POST['PAYMENT_BATCH_NUM'] )
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    $arr_EGOLD = get_currency_data( "", "e-gold", "", "Gold" );
    $ramz = new RamzNegar( );
    $arr_EGOLD['ALT_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_EGOLD['ALT_PASSWORD'] );
    $arr_EGOLD['ALT_PASSWORD'] = strtoupper( md5( $arr_EGOLD['ALT_PASSWORD'] ) );
}
$hash = strtoupper( md5( "{$PAYMENT_ID}:{$PAYEE_ACCOUNT}:{$PAYMENT_AMOUNT}:{$PAYMENT_UNITS}:{$PAYMENT_METAL_ID}:{$PAYMENT_BATCH_NUM}:{$PAYER_ACCOUNT}:{$arr_EGOLD['ALT_PASSWORD']}:{$ACTUAL_PAYMENT_OUNCES}:{$USD_PER_OUNCE}:{$FEEWEIGHT}:{$TIMESTAMPGMT}" ) );
$Message_log[] = "{$PAYMENT_ID}:{$PAYEE_ACCOUNT}:{$PAYMENT_AMOUNT}:{$PAYMENT_UNITS}:{$PAYMENT_METAL_ID}:{$PAYMENT_BATCH_NUM}:{$PAYER_ACCOUNT}:{$AlternateMerchantPassphraseHash}:{$ACTUAL_PAYMENT_OUNCES}:{$USD_PER_OUNCE}:{$FEEWEIGHT}:{$TIMESTAMPGMT}";
$Message_log[] = "hash= ({$hash}  ==  {$V2_HASH})";
if ( $hash == strtoupper( $V2_HASH ) )
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    if ( Refrence2eid( $PAYMENT_ID ) )
    {
        if ( isset( $PAYEE_ACCOUNT ) && db_if_exists( "SELECT eid From {$_exchange_lines} WHERE exchange_refrence='{$PAYMENT_ID}' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND src_amount='{$PAYMENT_AMOUNT}'" ) )
        {
            SEND_EXHCANGE_MAIL( $PAYMENT_ID, "receive" );
            commit_exchange( $PAYMENT_ID, $PAYMENT_BATCH_NUM, $PAYER_ACCOUNT, $PAYMENT_UNITS );
            $Message_log[] = "E-GOLD ADD TO DATABSE";
        }
    }
    else if ( isset( $PAYEE_ACCOUNT ) && db_if_exists( "SELECT * FROM {$_lines} WHERE id='{$PAYMENT_ID}' AND amount='{$PAYMENT_AMOUNT}' AND status='{$STATUS_ENUM_DISABLE}' AND pmt_type='{$TRANS_ENUM_SPEND}'" ) )
    {
        SEND_INVEST_RECEIVE_MAIL( $PAYMENT_ID, $PAYER_ACCOUNT );
        commit_transaction( $PAYMENT_ID, $PAYMENT_BATCH_NUM );
        $Message_log[] = "E-GOLD ADD TO DATABSE";
    }
    $Message_log[] = "E-GOLD ACCEPTED";
    db_close( $dbconn );
}
Write_File( );
unset( $arr_EGOLD );
?>
