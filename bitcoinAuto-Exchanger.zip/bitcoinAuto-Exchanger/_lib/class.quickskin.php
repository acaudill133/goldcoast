<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

class QuickSkin
{

    public $reuse_code = true;
    public $template_dir = "_skins/";
    public $temp_dir = "_skins_tmp/";
    public $cache_dir = "_skins_tmp/";
    public $cache_lifetime = 600;
    public $extensions_dir = "_lib/qx";
    public $extension_prefix = "qx_";
    public $left_delimiter = "{";
    public $right_delimiter = "}";
    public $extension_tagged = array( );
    public $cache_filename = NULL;
    public $tpl_file = NULL;
    public $cpl_file = NULL;
    public $data = array( );
    public $parser = NULL;
    public $debugger = NULL;
    public $skins_sub_dir = NULL;

    public function QuickSkin( $template_filename = "" )
    {
        global $_CONFIG;
        if ( !empty( $_CONFIG['quickskin_compiled'] ) )
        {
            $this->temp_dir = $_CONFIG['quickskin_compiled'];
        }
        if ( !empty( $_CONFIG['quickskin_cache'] ) )
        {
            $this->cache_dir = $_CONFIG['quickskin_cache'];
        }
        if ( is_numeric( $_CONFIG['cache_lifetime'] ) )
        {
            $this->cache_lifetime = $_CONFIG['cache_lifetime'];
        }
        if ( !empty( $_CONFIG['template_dir'] ) && is_file( $_CONFIG['template_dir']."/".$template_filename ) )
        {
            $this->template_dir = $_CONFIG['template_dir'];
        }
        $this->tpl_file = $template_filename;
        if ( dirname( $this->tpl_file ) != "" )
        {
            $this->skins_sub_dir = dirname( $this->tpl_file );
        }
    }

    public function set_templatefile( $template_filename )
    {
        $this->tpl_file = $template_filename;
    }

    public function add_value( $name, $value )
    {
        $this->assign( $name, $value );
    }

    public function add_array( $name, $value )
    {
        $this->append( $name, $value );
    }

    public function getContents( $contents, $filename = "" )
    {
        if ( $contents == "" && $filename != "" && file_exists( $filename ) )
        {
            $contents = file_get_contents( $filename );
        }
        ob_start( );
        eval( "?>".$contents."<?php " );
        $contents = ob_get_contents( );
        ob_end_clean( );
        $lower_contents = strtolower( $contents );
        $bodytag_start = strpos( $lower_contents, "<body" );
        if ( $bodytag_start !== false )
        {
            $bodytag_end = strpos( $lower_contents, ">", $bodytag_start ) + 1;
            $contents = substr( $contents, $bodytag_end );
            $lower_contents = strtolower( $contents );
            $end_start = strpos( $lower_contents, "</body" );
            $end_end = strpos( $lower_contents, ">", $bodytag_start ) + 1;
            return $this->getExtensions( substr( $contents, 0, $end_start ) );
        }
        return $this->getExtensions( $contents );
    }

    public function processCmd( $tag )
    {
        if ( preg_match( "/^(.+) > ([a-zA-Z0-9_.]+)\$/", $tag, $tagvar ) )
        {
            $tag = $tagvar[1];
            list( $newblock, $newskalar ) = newblock ;           $cmd = "\${$newblock}"."['{$newskalar}']=";
        }
        else
        {
            $cmd = "echo";
        }
        $ret = array(
            $cmd,
            $tag
        );
        return $ret;
    }

    public function getExtensions( $contents )
    {
        if ( preg_match_all( "/".$this->left_delimiter."([a-zA-Z0-9_]+):([^}]*)".$this->right_delimiter."/", $contents, $var ) )
        {
            foreach ( $var[2] as $cnt => $tag )
            {
                list( $cmd, $tag ) = cmd   ;             $extension = $var[1][$cnt];
                $header .= "include_once \"".$this->extensions_dir."/".$this->extension_prefix."{$extension}.php\";\n";
                if ( !strlen( $tag ) )
                {
                    $code = "<?php\n{$cmd} ".$this->extension_prefix."{$extension}();\n?>\n";
                }
                else if ( substr( $tag, 0, 1 ) == "\"" )
                {
                    $code = "<?php\n{$cmd} ".$this->extension_prefix."{$extension}({$tag});\n?>\n";
                }
                else if ( strpos( $tag, "," ) )
                {
                    list( $tag, $addparam ) = tag    ;                list( $block, $skalar ) = block  ;                  if ( preg_match( "/^([a-zA-Z_]+)/", $addparam, $match ) )
                    {
                        $nexttag = $match[1];
                        list( $nextblock, $nextskalar ) = nextblock   ;                     $addparam = substr( $addparam, strlen( $nexttag ) );
                        $code = "<?php\n{$cmd} ".$this->extension_prefix."{$extension}(\${$block}"."['{$skalar}'],\${$nextblock}"."['{$nextskalar}']"."{$addparam});\n?>\n";
                    }
                    else
                    {
                        $code = "<?php\n{$cmd} ".$this->extension_prefix."{$extension}(\${$block}"."['{$skalar}'],{$addparam});\n?>\n";
                    }
                }
                else
                {
                    list( $block, $skalar ) = block ;                   $code = "<?php\n{$cmd} ".$this->extension_prefix."{$extension}(\${$block}"."['{$skalar}']);\n?>\n";
                }
                $contents = str_replace( $var[0][$cnt], $code, $contents );
            }
        }
        ob_start( );
        eval( $header );
        eval( "?>".$contents."<?php " );
        $contents = ob_get_contents( );
        ob_end_clean( );
        return $contents;
    }

    public function addtpl( $name, $value = "" )
    {
        if ( is_array( $name ) )
        {
            foreach ( $name as $k => $v )
            {
                $this->supptemplate[$k] = $v;
            }
        }
        else
        {
            $this->supptemplate[$name] = $value;
        }
    }

    public function assign( $name, $value = "" )
    {
        if ( is_array( $name ) )
        {
            foreach ( $name as $k => $v )
            {
                $this->data[$k] = $v;
            }
        }
        else
        {
            $this->data[$name] = $value;
        }
    }

    public function append( $name, $value )
    {
        if ( is_array( $value ) )
        {
            $this->data[$name][] = $value;
        }
        else if ( !is_array( $this->data[$name] ) )
        {
            $this->data[$name] .= $value;
        }
    }

    public function result( $_top = "" )
    {
        ob_start( );
        $this->output( $_top );
        $result = ob_get_contents( );
        ob_end_clean( );
        return $result;
    }

    public function output( $_top = "" )
    {
        global $_top;
        $data = $this->data;
        if ( is_array( $this->supptemplate ) && !empty( $this->supptemplate ) )
        {
            foreach ( $this->supptemplate as $key => $value )
            {
                $supp_templates[$key] = file_get_contents( $value );
            }
        }
        if ( strlen( $this->template_dir ) && substr( $this->template_dir, 0 - 1 ) != "/" )
        {
            $this->template_dir .= "/";
        }
        if ( strlen( $this->temp_dir ) && substr( $this->temp_dir, 0 - 1 ) != "/" )
        {
            $this->temp_dir .= "/";
        }
        if ( !is_array( $_top ) )
        {
            if ( strlen( $_top ) )
            {
                $this->tpl_file = $_top;
            }
            $_top = $this->data;
        }
        $_obj =& $_top;
        $_stack_cnt = 0;
        $_stack[$_stack_cnt++] = $_obj;
        $queryString = $_SERVER['QUERY_STRING'];
        $cpl_file_name = preg_replace( "/[:\\/.\\\\]/", "_", $this->tpl_file.$_SERVER['PHP_SELF']."?".$queryString );
        if ( 0 < strlen( $cpl_file_name ) )
        {
            $cpl_file_name = "qs_".md5( $cpl_file_name );
            $this->cpl_file = $this->temp_dir.$cpl_file_name.".php";
            $compile_template = true;
            if ( $this->reuse_code && is_file( $this->cpl_file ) && $this->mtime( $this->template_dir.$this->tpl_file ) < $this->mtime( $this->cpl_file ) )
            {
                $compile_template = false;
            }
            if ( $compile_template )
            {
                $this->parser = new QuickSkinParser( );
                $this->parser->template_dir = $this->template_dir;
                $this->parser->skins_sub_dir = $this->skins_sub_dir;
                $this->parser->tpl_file = $this->tpl_file;
                $this->parser->left_delimiter = $this->left_delimiter;
                $this->parser->right_delimiter = $this->right_delimiter;
                $this->parser->extensions_dir = $this->extensions_dir;
                $this->parser->extension_prefix = $this->extension_prefix;
                $this->parser->supp_templates = $this->supp_templates;
                if ( !$this->parser->compile( $this->cpl_file, $data, $supp_templates, $this->extensions_dir ) )
                {
                    exit( "QuickSkin Parser Error: ".$this->parser->error );
                }
            }
            include( $this->cpl_file );
        }
        else
        {
            exit( "QuickSkin Error: You must set a template file name" );
        }
        unset( $GLOBALS['_top'] );
    }

    public function debug( $_top = "" )
    {
        if ( !$_top )
        {
            $_top = $this->data;
        }
        if ( include_once( "class.quickskindebugger.php" ) )
        {
            $this->debugger = new QuickSkinDebugger( $this->template_dir.$this->tpl_file, $this->right_delimiter, $this->left_delimiter );
            $this->debugger->start( $_top );
        }
        else
        {
            exit( "QuickSkin Error: Cannot find class.quickskindebugger.php; check QuickSkin installation" );
        }
    }

    public function use_cache( $key = "" )
    {
        if ( empty( $_POST ) )
        {
            $this->cache_filename = $this->cache_dir."cache_".md5( $_SERVER['REQUEST_URI'].serialize( $key ) ).".ser";
            if ( $_SERVER['HTTP_CACHE_CONTROL'] != "no-cache" && $_SERVER['HTTP_PRAGMA'] != "no-cache" && time( ) - filemtime( $this->cache_filename ) < $this->cache_lifetime )
            {
                readfile( $this->cache_filename );
                exit( );
            }
            ob_start( array(
                $this,
                "cache_callback"
            ) );
        }
    }

    public function cache_callback( $output )
    {
        if ( $hd = @fopen( $this->cache_filename, "w" ) )
        {
            fwrite( $hd, $output );
            fclose( $hd );
        }
        else
        {
            $output = "QuickSkin Error: failed to open cache file \"".$this->cache_filename."\"";
        }
        return $output;
    }

    public function mtime( $filename )
    {
        if ( @is_file( $filename ) )
        {
            $ret = filemtime( $filename );
            return $ret;
        }
    }

    public function set( $name, $value = "" )
    {
        if ( isset( $this->$name ) )
        {
            $this->$name = $value;
        }
        else
        {
            exit( "QuickSkin Error: Attempt to set a non-existant class property: ".$name );
        }
    }

}

class QuickSkinParser
{

    public $error = NULL;
    public $template = NULL;
    public $tpl_file = NULL;
    public $template_dir = NULL;
    public $skins_sub_dir = NULL;
    public $extensions_dir = NULL;
    public $extension_tagged = array( );
    public $left_delimiter = NULL;
    public $right_delimiter = NULL;
    public $supp_templates = NULL;
    public $extension_prefix = NULL;

    public function QuickSkinParser( )
    {
    }

    public function replace_logic_expression( &$src_page )
    {
        if ( !strpos( $src_page, "||" ) && !strpos( $src_page, "&&" ) )
        {
            return;
        }
        if ( preg_match_all( "/<!-- (ELSE)?IF \\s*(\\(*).*[|&]{2}\\s*\\(*\\s*([a-zA-Z0-9_.]+)\\s*([!=<>]+)\\s*([\"]?[^\"]*?[\"]?)\\s*(\\)*)\\s* -->/", $src_page, $var ) )
        {
            foreach ( $var[3] as $cnt => $tag )
            {
                list( $parent, $block ) = parent   ;             $cmp = $var[4][$cnt];
                $val = $var[5][$cnt];
                $else = $var[1][$cnt] == "ELSE" ? "} else" : "";
                if ( $cmp == "=" )
                {
                    $cmp = "==";
                }
                if ( preg_match( "/\"([^\"]*)\"/", $val, $matches ) )
                {
                    $code_suffix = "\${$parent}"."['{$block}'] {$cmp} \"".$matches[1].$var[6][$cnt]."\"){\n?>";
                }
                else if ( preg_match( "/([^\"]*)/", $val, $matches ) )
                {
                    list( $parent_right, $block_right ) = parent_right  ;                  $code_suffix = "\$"."['{$block}'] {$cmp} \${$parent_right}"."['{$block_right}']".$var[6][$cnt]."){\\?>";
                }
                if ( preg_match_all( "/([a-zA-Z0-9_.]+)\\s*([!=<>]+)\\s*([\"]?[^\"]*?[\"]?)\\s*(\\)*\\s*[|&]{2}\\s*\\(*)\\s*/", $var[0][$cnt], $sub_var ) )
                {
                    $code_mid = "";
                    foreach ( $sub_var[1] as $sub_cnt => $sub_tag )
                    {
                        list( $sub_parent, $sub_block ) = sub_parent  ;                      $cmp = $sub_var[2][$sub_cnt];
                        $val = $sub_var[3][$sub_cnt];
                        $logic_exp = $sub_var[4][$sub_cnt];
                        if ( $cmp == "=" )
                        {
                            $cmp = "==";
                        }
                        if ( preg_match( "/\"([^\"]*)\"/", $val, $matches ) )
                        {
                            $code_mid = $code_mid."\${$sub_parent}"."['{$sub_block}'] {$cmp} \"".$matches[1]."\"".$logic_exp;
                        }
                        else if ( preg_match( "/([^\"]*)/", $val, $matches ) )
                        {
                            list( $sub_parent_right, $sub_block_right ) = sub_parent_right;                            $code_mid = $code_mid."\${$sub_parent}"."['{$sub_block}'] {$cmp} \${$sub_parent_right}"."['{$sub_block_right}']".$logic_exp;
                        }
                    }
                }
                $code = "<?php\n".$else."if (".$var[2][$cnt].$code_mid.$code_suffix;
                $src_page = str_replace( $var[0][$cnt], $code, $src_page );
            }
        }
    }

    public function compile( $compiled_template_filename = "", $data = "", $supp_templates = "", $extensions_dir = "" )
    {
        $this->extension_prefix = preg_quote( $this->extension_prefix );
        $template_filename = $this->template_dir.$this->tpl_file;
        if ( $hd = @fopen( $template_filename, "r" ) )
        {
            if ( filesize( $template_filename ) )
            {
                $this->template = fread( $hd, filesize( $template_filename ) );
                $this->left_delimiter = preg_quote( $this->left_delimiter );
                $this->right_delimiter = preg_quote( $this->right_delimiter );
            }
            else
            {
                $this->template = "QuickSkin Parser Error: File size is zero byte: ".$template_filename;
            }
            fclose( $hd );
        }
        else
        {
            $this->template = "QuickSkin Parser Error: File not found: ".$template_filename;
        }
        if ( empty( $this->template ) )
        {
            return;
        }
        $this->template = $this->worx_var_swap( $this->template, $data, $supp_templates );
        $header = "";
        while ( eregi( "<!-- INCLUDE", $this->template ) && 0 < $this->count_subtemplates( ) )
        {
            preg_match_all( "/<!-- INCLUDE ([a-zA-Z0-9\\-_.]+) -->/", $this->template, $tvar );
            foreach ( $tvar[1] as $subfile )
            {
                if ( file_exists( $this->template_dir."/".$this->skins_sub_dir."/".$subfile ) )
                {
                    $subst = implode( "", file( $this->template_dir."/".$this->skins_sub_dir."/".$subfile ) );
                }
                else
                {
                    $subst = "QuickSkin Parser Error: Subtemplate not found: '".$subfile."'";
                }
                $this->template = str_replace( "<!-- INCLUDE {$subfile} -->", $subst, $this->template );
            }
        }
        $page = preg_replace( "/<!-- ENDIF.+?-->/", "<?php\n}\n?>", $this->template );
        $page = preg_replace( "/<!-- END[ a-zA-Z0-9_.]* -->/", "<?php\n}\n\$_obj=\$_stack[--\$_stack_cnt];}\n?>", $page );
        $page = str_replace( "<!-- ELSE -->", "<?php\n} else {\n?>", $page );
        if ( preg_match_all( "/<!-- BEGIN ([a-zA-Z0-9_.]+) -->/", $page, $var ) )
        {
            foreach ( $var[1] as $tag )
            {
                list( $parent, $block ) = parent ;               $Var_2952 = "<?php\n"."if (!empty(\${$parent}"."['{$block}'])){\n"."if (!is_array(\${$parent}"."['{$block}']))\n"."\${$parent}"."['{$block}']=array(array('{$block}'=>\${$parent}"."['{$block}']));\n"."\$_stack[\$_stack_cnt++]=\$_obj;\n"."\$rowcounter = 0;\n"."foreach (\${$parent}"."['{$block}'] as \$rowcnt=>\${$block}) {\n"."\${$block}"."['ROWCNT']=(\$rowcounter);\n"."\${$block}"."['ALTROW']=\$rowcounter%2;\n"."\${$block}"."['ROWBIT']=\$rowcounter%2;\n"."\$rowcounter++;"."\$_obj=&\${$block};\n?>";
                $page = str_replace( "<!-- BEGIN {$tag} -->", $code, $page );
                break;
            }
        }
        $this->replace_logic_expression( $page );
        if ( preg_match_all( "/<!-- (ELSE)?IF ([a-zA-Z0-9_.]+)\\s*([!=<>]+)\\s*([\"]?[^\"]*[\"]?) -->/", $page, $var ) )
        {
            foreach ( $var[2] as $cnt => $tag )
            {
                list( $parent, $block ) = parent ;               $cmp = $var[3][$cnt];
                $val = $var[4][$cnt];
                $else = $var[1][$cnt] == "ELSE" ? "} else" : "";
                if ( $cmp == "=" )
                {
                    $cmp = "==";
                }
                if ( preg_match( "/\"([^\"]*)\"/", $val, $matches ) )
                {
                    $code = "<?php\n{$else}"."if (\${$parent}"."['{$block}'] {$cmp} \"".$matches[1]."\"){\n?>";
                }
                else if ( preg_match( "/([^\"]*)/", $val, $matches ) )
                {
                    list( $parent_right ) = parent_right   ;                 $code = "<?php\n{$else}"."if (\${$parent}"."['{$block}'] {$cmp} \${$parent_right}"."['{$block_right}']){\n?>";
                }
            }
        }
        if ( preg_match_all( "/<!-- (ELSE)?IF ([a-zA-Z0-9_.]+) -->/", $page, $var ) )
        {
            foreach ( $var[2] as $cnt => $tag )
            {
                $else = $var[1][$cnt] == "ELSE" ? "} else" : "";
                list( $parent, $block ) = parent  ;              $code = "<?php\n{$else}"."if (!empty(\$"."['{$block}'])){\n?>";
                $page = str_replace( $var[0][$cnt], $code, $page );
            }
        }
        if ( preg_match_all( "/<!-- (ELSE)?IF {([a-zA-Z0-9_]+):([^}]*)}\\s*([!=<>]+)\\s*([\"]?[^\"]*[\"]?) -->/", $page, $var ) )
        {
            foreach ( $var[2] as $cnt => $tag )
            {
                list( $parent, $block ) = parent   ;             $cmp = $var[4][$cnt];
                $val = $var[5][$cnt];
                $else = $var[1][$cnt] == "ELSE" ? "} else" : "";
                if ( $cmp == "=" )
                {
                    $cmp = "==";
                }
                $extension = $var[2][$cnt];
                $extension_var = $var[3][$cnt];
                if ( !isset( $this->extension_tagged[$extension] ) )
                {
                    $header .= "include_once  \"".$this->extensions_dir."/".$this->extension_prefix."{$extension}.php\";\n";
                    $this->extension_tagged[$extension] = true;
                }
                if ( !strlen( $extension_var ) )
                {
                    $code = "<?php\n{$else}"."if (".$this->extension_prefix."{$extension}() {$cmp} {$val}) {\n?>\n";
                }
                else if ( substr( $extension_var, 0, 1 ) == "\"" )
                {
                    $code = "<?php\n{$else}"."if (".$this->extension_prefix."{$extension}({$extension_var}) {$cmp} {$val}) {\n?>\n";
                }
                else if ( strpos( $extension_var, "," ) )
                {
                    list( $tag, $addparam ) = tag  ;                  list( $block, $skalar ) = block  ;                  if ( preg_match( "/^([a-zA-Z_]+)/", $addparam, $match ) )
                    {
                        $nexttag = $match[1];
                        list( $nextblock, $nextskalar ) = nextblock      ;                  $addparam = substr( $addparam, strlen( $nexttag ) );
                        $code = "<?php\n{$else}"."if (".$this->extension_prefix."{$extension}(\${$block}"."['{$skalar}'],\${$nextblock}"."['{$nextskalar}']"."{$addparam}) {$cmp} {$val}) {\n?>\n";
                    }
                    else
                    {
                        $code = "<?php\n{$else}"."if (".$this->extension_prefix."{$extension}(\${$block}"."['{$skalar}'],{$addparam}) {$cmp} {$val}) {\n?>\n";
                    }
                }
                else
                {
                    list( $block, $skalar ) = block  ;                  $code = "<?php\n{$else}"."if (".$this->extension_prefix."{$extension}(\${$block}"."['{$skalar}']) {$cmp} {$val}) {\n?>\n";
                }
                $page = str_replace( $var[0][$cnt], $code, $page );
            }
        }
        if ( preg_match_all( "/".$this->left_delimiter."([a-zA-Z0-9_. >]+)".$this->right_delimiter."/", $page, $var ) )
        {
            foreach ( $var[1] as $fulltag )
            {
                list( $cmd, $tag ) = cmd    ;            list( $block, $skalar ) = block;                $code = "<?php\n{$cmd} \${$block}"."['{$skalar}'];\n?>\n";
                $page = str_replace( stripslashes( $this->left_delimiter ).$fulltag.stripslashes( $this->right_delimiter ), $code, $page );
            }
        }
        if ( preg_match_all( "/<\"([a-zA-Z0-9_.]+)\">/", $page, $var ) )
        {
            foreach ( $var[1] as $tag )
            {
                list( $block, $skalar ) = block  ;              $code = "<?php\necho gettext('{$skalar}');\n?>\n";
                $page = str_replace( "<\"".$tag."\">", $code, $page );
            }
        }
        if ( preg_match_all( "/".$this->left_delimiter."([a-zA-Z0-9_]+):([^}]*)".$this->right_delimiter."/", $page, $var ) )
        {
            foreach ( $var[2] as $cnt => $tag )
            {
                list( $cmd, $tag ) = cmd   ;             $extension = $var[1][$cnt];
                if ( !isset( $this->extension_tagged[$extension] ) )
                {
                    $header .= "include_once \"".$this->extensions_dir."/".$this->extension_prefix."{$extension}.php\";\n";
                    $this->extension_tagged[$extension] = true;
                }
                if ( !strlen( $tag ) )
                {
                    $code = "<?php\n{$cmd} ".$this->extension_prefix."{$extension}();\n?>\n";
                }
                else if ( substr( $tag, 0, 1 ) == "\"" )
                {
                    $code = "<?php\n{$cmd} ".$this->extension_prefix."{$extension}({$tag});\n?>\n";
                }
                else if ( strpos( $tag, "," ) )
                {
                    list( $tag, $addparam ) = tag  ;                  list( $block, $skalar ) = block  ;                  if ( preg_match( "/^([a-zA-Z_]+)/", $addparam, $match ) )
                    {
                        $nexttag = $match[1];
                        list( $nextblock, $nextskalar ) = nextblock   ;                     $addparam = substr( $addparam, strlen( $nexttag ) );
                        $code = $Tmp_761."<?php\n{$cmd} ".$this->extension_prefix."{$extension}(\${$block}"."['{$skalar}'],\${$nextblock}"."['{$nextskalar}']"."{$addparam});\n?>\n";
                    }
                    else
                    {
                        $code = "<?php\n{$cmd} ".$this->extension_prefix."{$extension}(\${$block}"."['{$skalar}'],{$addparam});\n?>\n";
                    }
                }
                else
                {
                    list( $block, $skalar ) = block   ;                 $code = "<?php\n{$cmd} ".$this->extension_prefix."{$extension}(\${$block}"."['{$skalar}']);\n?>\n";
                }
                $page = str_replace( $var[0][$cnt], $code, $page );
            }
        }
        if ( !empty( $header ) )
        {
            $page = "<?php\n{$header}\n?>{$page}";
        }
        $page = $this->worx_tpl_swap( $page, $data, $supp_templates );
        if ( strlen( $compiled_template_filename ) )
        {
            if ( $hd = fopen( $compiled_template_filename, "w" ) )
            {
                fwrite( $hd, $page );
                fclose( $hd );
                return true;
            }
            $this->error = "Could not write compiled file.";
            return false;
        }
        return $page;
    }

    public function var_name( $tag )
    {
        $parent_level = 0;
        while ( substr( $tag, 0, 7 ) == "parent." )
        {
            $tag = substr( $tag, 7 );
            ++$parent_level;
        }
        if ( substr( $tag, 0, 4 ) == "top." )
        {
            $obj = "_stack[0]";
            $tag = substr( $tag, 4 );
        }
        else if ( $parent_level )
        {
            $obj = "_stack[\$_stack_cnt-".$parent_level."]";
        }
        else
        {
            $obj = "_obj";
        }
        while ( is_int( strpos( $tag, "." ) ) )
        {
            list( $parent, $tag ) = parent  ;          if ( is_numeric( $parent ) )
            {
                $obj .= "[".$parent."]";
            }
            else
            {
                $obj .= "['".$parent."']";
            }
        }
        $ret = array(
            $obj,
            $tag
        );
        return $ret;
    }

    public function cmd_name( $tag )
    {
        if ( preg_match( "/^(.+) > ([a-zA-Z0-9_.]+)\$/", $tag, $tagvar ) )
        {
            $tag = $tagvar[1];
            list( $newblock, $newskalar ) = newblock   ;         $cmd = "\${$newblock}"."['{$newskalar}']=";
        }
        else
        {
            $cmd = "echo";
        }
        $ret = array(
            $cmd,
            $tag
        );
        return $ret;
    }

    public function count_subtemplates( )
    {
        $ret = preg_match_all( "/<!-- INCLUDE ([a-zA-Z0-9_.]+) -->/", $this->template, $tvar );
        unset( $tvar );
        return $ret;
    }

    public function worx_var_swap( $tpldata, $data, $supp_templates )
    {
        if ( is_array( $supp_templates ) && !empty( $supp_templates ) )
        {
            foreach ( $supp_templates as $key => $val )
            {
                $tpldata = str_replace( "{".$key."}", $val, $tpldata );
            }
        }
        return $tpldata;
    }

    public function worx_tpl_swap( $tpldata, $data, $supp_templates )
    {
        if ( $data['tpl_img'] != "" && $data['url_img'] != "" )
        {
            $tpldata = str_replace( $data['tpl_img'], $data['url_img'], $tpldata );
            unset( $data['tpl_img'] );
            unset( $data['url_img'] );
        }
        else if ( defined( _URL_USRIMG ) )
        {
            $tpldata = str_replace( "tplimgs/", _URL_USRIMG, $tpldata );
        }
        if ( $data['tpl_js'] != "" && $data['url_js'] != "" )
        {
            $tpldata = str_replace( $data['tpl_js'], $data['url_js'], $tpldata );
            unset( $data['img_tpl'] );
            unset( $data['url_js'] );
        }
        else if ( defined( _URL_USRJS ) )
        {
            $tpldata = str_replace( "tpljs/", _URL_USRJS, $tpldata );
        }
        if ( $data['tpl_css'] != "" && $data['url_css'] != "" )
        {
            $tpldata = str_replace( $data['tpl_css'], $data['url_css'], $tpldata );
            unset( $data['tpl_css'] );
            unset( $data['url_css'] );
        }
        else if ( defined( _URL_USRCSS ) )
        {
            $tpldata = str_replace( "url_css/", _URL_USRCSS, $tpldata );
        }
        return $tpldata;
    }

}

?>
