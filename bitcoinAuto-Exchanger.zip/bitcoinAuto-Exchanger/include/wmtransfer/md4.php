<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

class MD4
{

    public $mode = 0;

    public function MD4( $selftest = TRUE )
    {
        if ( $selftest )
        {
            $this->SelfTest( );
        }
    }

    public function SelfTest( )
    {
        $result = $this->Calc( "12345678" ) == "012d73e0fab8d26e0f4d65e36077511e";
        $this->mode = $result ? 0 : 1;
        return $result;
    }

    public function rhex( $num )
    {
        $hex_chr = "0123456789abcdef";
        $str = "";
        $j = 0;
        for ( ; $j <= 3; $j++ )
        {
            $str .= $hex_chr[$num >> $j * 8 + 4 & 15].$hex_chr[$num >> $j * 8 & 15];
        }
        return $str;
    }

    public function str2blks( $str )
    {
        $nblk = ( strlen( $str ) + 8 >> 6 ) + 1;
        $i = 0;
        for ( ; $i < $nblk * 16; $i++ )
        {
            $blks[$i] = 0;
        }
        $i = 0;
        for ( ; $i < strlen( $str ); $i++ )
        {
            $blks[$i >> 2] |= ord( $str[$i] ) << $i % 4 * 8;
        }
        $blks[$i >> 2] |= 128 << $i % 4 * 8;
        $blks[$nblk * 16 - 2] = strlen( $str ) * 8;
        return $blks;
    }

    public function safe_add( $x, $y )
    {
        if ( $this->mode == 0 )
        {
            return $x + $y & 4.29497e+009;
        }

[exception occured]

================================
Exception code[ C0000005 ]
Compiler[ 00845C28 ]
Executor[ 00846130 ]
OpArray[ 01FFE4E8 ]
File< C:\dezenders\dezend\_decoded\include\wmtransfer\md4.php >
Class< MD4 >
Function< safe_add >
Stack[ 001482B0 ]
Step[ 7 ]
Offset[ 11 ]
LastOffset[ 24 ]
    11  ADD                          [-]   0[0] $Tmp_6 - $Tmp_4 - $Tmp_5
================================
?>
