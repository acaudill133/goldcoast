<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "phpmailer/class.phpmailer.php" );
class siteMAIL extends PHPMailer
{

    public $vars = array( );
    public $SMTPDebug = false;
    public $arrReplacer = array( );
    public $mail_title = NULL;

    public function siteMAIL( )
    {
        $this->IsSMTP( );
        $this->SMTPAuth = true;
        $this->Host = $GLOBALS['CONFIG']['MAIL_SMTP_HOST'];
        $this->Port = $GLOBALS['CONFIG']['MAIL_SMTP_PORT'];
        $this->Username = $GLOBALS['CONFIG']['MAIL_SMTP_USER'];
        $ramz = new RamzNegar( );
        $this->Password = $ramz->decrypt( ramzkey( "number1" ), $GLOBALS['CONFIG']['MAIL_SMTP_PASS'] );
        $this->From = $GLOBALS['CONFIG']['REPORT_MAIL'];
        $this->FromName = $GLOBALS['CONFIG']['REPORT_MAIL_NAME'];
        $this->AddReplyTo( $GLOBALS['CONFIG']['ADMIN_MAIL'], $GLOBALS['CONFIG']['SITE_NAME'] );
        if ( $GLOBALS['CONFIG']['adminemailnotification'] )
        {
            $this->AddCC( $GLOBALS['CONFIG']['ADMIN_MAIL'], $GLOBALS['CONFIG']['SITE_NAME']." Report" );
        }
    }

    public function bakeMail( $use_template = true )
    {
        if ( 0 < count( $this->arrReplacer ) )
        {
            foreach ( $this->arrReplacer as $key => $value )
            {
                if ( !$value )
                {
                    $value = " ";
                }
                if ( !empty( $value ) )
                {
                    $this->Subject = str_replace( ""."[".$key."]", $value, $this->Subject );
                }
                if ( !empty( $value ) )
                {
                    $this->Body = str_replace( ""."[".$key."]", $value, $this->Body );
                }
            }
        }
        if ( is_array( $this->vars[arr_Replace] ) )
        {
            foreach ( $this->vars[arr_Replace] as $key => $value )
            {
                $this->Body = str_replace( $key, $value, $this->Body );
            }
        }
        if ( $use_template )
        {
            $templfile = "_skins/".$GLOBALS['CONFIG']['SITE_TEMPLATE']."/mail_template.html";
            if ( file_exists( realpath( $templfile ) ) )
            {
                $html_template = file_get_contents( $templfile );
            }
            else
            {
                $this->error_handler( $templfile." Does not exists." );
            }
            $this->Body = str_replace( "[mail_message]", $this->Body, $html_template );
        }
        $this->Body = str_replace( "[mail_title]", $this->mail_title, $this->Body );
        $this->Body = str_replace( "[SITE_NAME]", $GLOBALS['CONFIG']['SITE_NAME'], $this->Body );
        $this->Body = str_replace( "[ADMIN_MAIL]", $GLOBALS['CONFIG']['ADMIN_MAIL'], $this->Body );
        $this->Body = str_replace( "[SITE_URL]", $GLOBALS['CONFIG']['SITE_URL'], $this->Body );
        $this->Body = str_replace( "[SITE_URL_SECURE]", $GLOBALS['CONFIG']['SITE_URL_SECURE'], $this->Body );
        $this->Body = str_replace( "[REPORT_MAIL]", $GLOBALS['CONFIG']['REPORT_MAIL'], $this->Body );
        if ( $GLOBALS['CONFIG']['MAIL_FORMAT'] == "html" )
        {
            $this->IsHTML( true );
        }
        else
        {
            $this->IsHTML( false );
            $h2t =& new html2text( $this->Body );
            $this->Body = $h2t->get_text( );
        }
    }

    public function addVariable( $varname, $varvalue = "" )
    {
        $this->vars[$varname] = $varvalue;
    }

    public function error_handler( $msg )
    {
        $GLOBALS['Error'][] = $msg;
        return $this->ErrorInfo;
    }

    public function __destruct( )
    {
        $this->ClearAddresses( );
    }

}

?>
