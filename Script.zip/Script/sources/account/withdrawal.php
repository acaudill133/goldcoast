<h3><?php echo $lang['make_withdrawal']; ?> <span class="pull-right"><?php echo $lang['current_earnings']; ?>: $<?php echo number_format(idinfo($_SESSION['suid'],"earnings"),2); ?></span></h3>
		
		<?php
		if(isset($_POST['btn_submit'])) {
			$amount = protect($_POST['amount']);
			$company = protect($_POST['company']);
			$account = protect($_POST['account']);
			$uearnings = idinfo($_SESSION['suid'],"earnings");
			if(empty($amount)) { echo error($lang['error_24']); }
			elseif(!is_numeric($amount)) { echo error($lang['error_25']); }
			elseif($amount<1) { echo error($lang['error_26']); }
			elseif($amount>$uearnings) { echo error("$lang[error_27] $$uearnings"); }
			elseif($company == "paypal" && empty($account)) { echo error($lang['error_28']); }
			elseif($company == "paypal" && !isValidEmail($account)) { echo error($lang['error_29']); }
			elseif($company == "skrill" && empty($account)) { echo error($lang['error_30']); }
			elseif($company == "skrill" && !isValidEmail($account)) { echo error($lang['error_31']); }
			elseif($company == "webmoney" && empty($account)) { echo error($lang['error_32']); }
			elseif($company == "webmoney" && strlen($account)<12) { echo error($lang['error_33']); }
			elseif($company == "payeer" && empty($account)) { echo error($lang['error_34']); }
			elseif($company == "payeer" && strlen($account)<8) { echo error($lang['error_35']); }
			elseif($company == "perfectponey" && empty($account)) { echo error($lang['error_36']); }
			elseif($company == "perfectponey" && strlen($account)<7) { echo error($lang['error_37']); }
			elseif($company == "advcash" && empty($account)) { echo error($lang['error_38']); }
			elseif($company == "advcash" && !isValidEmail($account)) { echo error($lang['error_39']); }
			elseif($company == "okpay" && empty($account)) { echo error($lang['error_40']); }
			elseif($company == "okpay" && strlen($account)<8 or !isValidEmail($account)) { echo error($lang['error_41']); }
			else {
				$insert = $db->query("INSERT withdrawals (uid,amount,account,to_company,status,time) VALUES ('$_SESSION[suid]','$amount','$account','$company','1','$time')");
				$update = $db->query("UPDATE users SET earnings=earnings-$amount WHERE id='$_SESSION[suid]'");
				$redirect = $settings['url']."account/withdrawals";
				header("Location: $redirect");
			}
		}
		?>
		
		<form id="form_withdrawal" method="POST" action="">
			<div class="form-group">
				<label><?php echo $lang['amount']; ?></label>
				<input type="text" class="form-control" name="amount">
			</div>
			<div class="form-group">
				<label><?php echo $lang['company']; ?></label>
				<select name="company" class="form-control">
					<option value="paypal">PayPal</option>
					<option value="perfectmoney">Perfect Money</option>
					<option value="okpay">OKPay</option>
					<option value="payeer">Payeer</option>
					<option value="advcash">AdvCash</option>
					<option value="webmoney">WebMoney</option>
					<option value="skrill">Skrill</option>
				</select>
			</div>	
			<div class="form-group">
				<label><?php echo $lang['account']; ?></label>
				<input type="text" class="form-control" name="account">
			</div>
			<button type="submit" class="btn btn-primary" name="btn_submit"><i class="fa fa-check"></i> <?php echo $lang['btn_8']; ?></button>
		</form>