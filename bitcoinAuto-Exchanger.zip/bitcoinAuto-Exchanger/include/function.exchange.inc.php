<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function rate_parser( $value, $part )
{
    $explode = explode( ":", $value );
    if ( !$explode[0] || !$explode[1] )
    {
        return 0;
    }
    if ( $part == "src" )
    {
        return $explode[0];
    }
    if ( $part == "dst" )
    {
        return $explode[1];
    }
}

function rate_to_percent( $full_rate, $free = false )
{
    if ( $free )
    {
        return "FREE";
    }
    $src_rate = rate_parser( $full_rate, "src" );
    $dst_rate = rate_parser( $full_rate, "dst" );
    if ( $src_rate == 0 && ( $dst_rate = 0 ) || !$src_rate && !$dst_rate )
    {
        return "--";
    }
    $percent = 100 * $dst_rate / $src_rate;
    if ( $percent < 100 )
    {
        $percent = 100 - $percent;
    }
    else
    {
        $percent = $percent - 100;
        $symbol = "+";
    }
    return "%".$symbol.$percent;
}

function calculate_DST_amount( $SRC_ID, $DST_ID, $SRC_AMOUNT )
{
    global $_exchange_rate;
    global $FULL_EXCHANGE_FEE;
    global $CONFIG;
    global $_currencies;
    global $Error;
    $FULL_EXCHANGE_FEE = db_get_id( "Select {$_exchange_rate}.{$DST_ID} From {$_exchange_rate} WHERE cid='{$SRC_ID}'" );
    if ( rate_parser( $FULL_EXCHANGE_FEE, "src" ) == 0 && rate_parser( $FULL_EXCHANGE_FEE, "dst" ) == 0 )
    {
        return false;
    }
    $DST_AMOUNT = $SRC_AMOUNT / rate_parser( $FULL_EXCHANGE_FEE, "src" ) * rate_parser( $FULL_EXCHANGE_FEE, "dst" );
    $MAX_EXCHANGE_FEE = db_get_id( "Select {$_currencies}.exchange_max_fee From {$_currencies} WHERE cid='{$DST_ID}'" );
    if ( $MAX_EXCHANGE_FEE < $SRC_AMOUNT - $DST_AMOUNT && 0 < $MAX_EXCHANGE_FEE )
    {
        $DST_AMOUNT = $SRC_AMOUNT - $MAX_EXCHANGE_FEE;
    }
    if ( $DST_AMOUNT < $SRC_AMOUNT && $SRC_AMOUNT - $DST_AMOUNT < $CONFIG['MIN_EXCHANGE_FEE'] && 0 < $CONFIG['MIN_EXCHANGE_FEE'] )
    {
        $DST_AMOUNT = $SRC_AMOUNT - $CONFIG['MIN_EXCHANGE_FEE'];
    }
    return $Var_1776;
}

function Refrence2eid( $Refrence )
{
    global $_exchange_lines;
    if ( 1000000000 < $Refrence )
    {
        return true;
    }
    return false;
}

function update_reserved( $SRC_ID, $SRC_AMOUNT, $DST_ID = "", $DST_AMOUNT = "" )
{
    global $_currencies;
    $RESERVE_SRC = db_get_id( "SELECT reserve_amount FROM {$_currencies} WHERE cid='{$SRC_ID}'" );
    if ( $RESERVE_SRC )
    {
        $RESERVE_SRC = $RESERVE_SRC + $SRC_AMOUNT;
        if ( $RESERVE_SRC < 0 )
        {
            $RESERVE_SRC = 0;
        }
        db_exec( "update {$_currencies} SET reserve_amount='{$RESERVE_SRC}' WHERE cid='{$SRC_ID}'" );
    }
    if ( $DST_ID && $DST_AMOUNT )
    {
        $RESERVE_DST = db_get_id( "SELECT reserve_amount FROM {$_currencies} WHERE cid='{$DST_ID}'" );
        $RESERVE_DST = $RESERVE_DST - $DST_AMOUNT;
        if ( $RESERVE_DST < 0 )
        {
            $RESERVE_DST = 0;
        }
        db_exec( "update {$_currencies} SET reserve_amount='{$RESERVE_DST}' WHERE cid='{$DST_ID}'" );
    }
    $ACCEPT_LIMIT = db_get_id( "SELECT exchange_accept_limit FROM {$_currencies} WHERE cid='{$SRC_ID}'" );
    db_exec( "update {$_currencies} SET exchange_accept_limit=(exchange_accept_limit - {$SRC_AMOUNT}) WHERE cid='{$SRC_ID}'" );
    return true;
}

function commit_exchange( global $_lines;
global $_exchange_lines;
global $_currencies;
global $SECURE_KEY;
global $LANG_msg;
global $Message_log;
global $TRANS_ENUM_SPEND;
global $TRANS_ENUM_EARNING;
global $TRANS_ENUM_BANK;
global $TRANS_ENUM_COMMISSION;
global $TRANS_ENUM_EARNBANK;
global $TRANS_ENUM_COMMISSION;
global $FULL_EXCHANGE_FEE;
global $STATUS_ENUM_ENABLE;
global $STATUS_ENUM_DISABLE;
global $STATUS_ENUM_LOCKED;
global $TRANS_ENUM_COMPOUND;
global $CONFIG;
global $arr_PAYMENT_RESULT;
global $CONFIG;
global $arr_DST;
$arr_EXCHANGE_DATA = array( );
$nvar = db_get_array( "SELECT eid, uid, src_cid, src_amount, dst_cid, dst_amount, dst_account, exchange_email_address, ref_uid, exchange_refrence FROM {$_exchange_lines} WHERE exchange_refrence='{$pmt_id}' AND dst_status='{$STATUS_ENUM_DISABLE}'" );
$arr_EXCHANGE_DATA['EXCHANGE_ID'] = $nvar[0];
$arr_EXCHANGE_DATA['UID'] = $nvar[1];
$arr_EXCHANGE_DATA['SRC_CID'] = $nvar[2];
$arr_EXCHANGE_DATA['SRC_AMOUNT'] = $nvar[3];
$arr_EXCHANGE_DATA['DST_CID'] = $nvar[4];
$arr_EXCHANGE_DATA['DST_AMOUNT'] = $nvar[5];
$arr_EXCHANGE_DATA['DST_ACCOUNT'] = $nvar[6];
$arr_EXCHANGE_DATA['EMAIL'] = $nvar[7];
$arr_EXCHANGE_DATA['REFERRER'] = $nvar[8];
$arr_EXCHANGE_DATA['REFRENCE'] = $nvar[9];
if ( $arr_EXCHANGE_DATA['SRC_CID'] )
{
    $DST_AMOUNT = calculate_dst_amount( $arr_EXCHANGE_DATA['SRC_CID'], $arr_EXCHANGE_DATA['DST_CID'], $arr_EXCHANGE_DATA['SRC_AMOUNT'] );
}
else
{
    $arr_PAYMENT_RESULT['ERROR'] = "Exchange line does not exists!";
}
if ( $paid_worth_value && strtoupper( trim( $paid_worth_value ) ) != strtoupper( trim( db_get_id( "SELECT currency_worth_value FROM  WHERE cid='{$arr_EXCHANGE_DATA['SRC_CID']}'" ) ) ) )
{
    $arr_PAYMENT_RESULT['ERROR'] .= "Invalid payment worth value (Maybe trying to hack)";
}
if ( $DST_AMOUNT + 0.3 < $arr_EXCHANGE_DATA['DST_AMOUNT'] )
{
    $arr_PAYMENT_RESULT['ERROR'] .= " Exchange line found but calculated dst amount is lower than destination amount must pay in database order";
}
if ( isset( $arr_EXCHANGE_DATA['EXCHANGE_ID'] ) && !$arr_PAYMENT_RESULT['ERROR'] )
{
    db_exec( "update {$_exchange_lines} SET src_status='{$STATUS_ENUM_ENABLE}', src_account='{$payer_acc}', src_batch='#{$pmt_transaction}', exchange_note=CONCAT(exchange_note, ' - {$LANG_msg['note_exchange1']}'), src_date=now() WHERE eid='{$arr_EXCHANGE_DATA['EXCHANGE_ID']}'" );
    if ( db_get_id( "SELECT exchange_automatic FROM {$_currencies} WHERE cid='{$arr_EXCHANGE_DATA['DST_CID']}'" ) )
    {
        $arr_DST = array( );
        $nvar = db_get_array( "SELECT currency_name, currency_worth_value, currency_worth_name,  currency_metal_name, currency_metal_value, exchange_min, exchange_max, reserve_amount, exchange_automatic, ACCOUNT, MAIN_PASSWORD, exchange_status FROM {$_currencies} WHERE cid='{$arr_EXCHANGE_DATA['DST_CID']}'" );
        $arr_DST['NAME'] = $nvar[0];
        $arr_DST['WORTH_VALUE'] = $nvar[1];
        $arr_DST['WORTH_NAME'] = $nvar[2];
        $arr_DST['METAL_NAME'] = $nvar[3];
        $arr_DST['METAL_VALUE'] = $nvar[4];
        $arr_DST['EXCHANGE_MIN'] = $nvar[5];
        $arr_DST['EXCHANGE_MAX'] = $nvar[6];
        $arr_DST['RESERVE_AMOUNT'] = $nvar[7];
        $arr_DST['EXCHANGE_AUTO'] = $nvar[8];
        $arr_DST['ACCOUNT'] = $nvar[9];
        $ramz = new RamzNegar( );
        $arr_DST['MAIN_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $nvar[10] );
        $arr_DST['EXCHANGE_STATUS'] = $nvar[11];
        $arr_DST['FULL_NAME'] = $arr_DST['NAME']." ".$arr_DST['METAL_NAME'];
    }
    if ( $arr_DST['EXCHANGE_AUTO'] == $STATUS_ENUM_ENABLE )
    {
        set_time_limit( 10 );
        $PAYMENT_ID = $arr_EXCHANGE_DATA['REFRENCE'];
        $MEMO = "Exchange by {$CONFIG['SITE_NAME']}";
        $merchant_name = $arr_DST['NAME'];
        switch ( $merchant_name )
        {
        case "e-gold" :
            $arr_PAYMENT_RESULT = egold_autopay( $arr_DST['ACCOUNT'], $arr_DST['MAIN_PASSWORD'], $arr_EXCHANGE_DATA['DST_ACCOUNT'], $arr_EXCHANGE_DATA['DST_AMOUNT'], $arr_DST['METAL_NAME'] );
            break;
        case "e-bullion" :
            break;
        case "pecunix" :
            $arr_PAYMENT_RESULT = pecunix_autopay( $arr_DST['ACCOUNT'], $arr_DST['MAIN_PASSWORD'], $arr_EXCHANGE_DATA['DST_ACCOUNT'], $arr_EXCHANGE_DATA['DST_AMOUNT'], $arr_DST['WORTH_VALUE'] );
            break;
        case "moneybookers" :
            break;
        case "libertyreserve" :
            $arr_PAYMENT_RESULT = liberty_autopay( $arr_DST['ACCOUNT'], $arr_DST['MAIN_PASSWORD'], $arr_EXCHANGE_DATA['DST_ACCOUNT'], $arr_EXCHANGE_DATA['DST_AMOUNT'], $arr_DST['WORTH_VALUE'] );
            break;
        case "alertpay" :
            break;
        case "v-money" :
            $arr_PAYMENT_RESULT = vmoney_autopay( $arr_DST['ACCOUNT'], $arr_DST['MAIN_PASSWORD'], $arr_EXCHANGE_DATA['DST_ACCOUNT'], $arr_EXCHANGE_DATA['DST_AMOUNT'], $arr_DST['WORTH_VALUE'] );
            break;
        case "perfectmoney" :
            $arr_PAYMENT_RESULT = perfectmoney_autopay( $arr_DST['ACCOUNT'], $arr_DST['MAIN_PASSWORD'], $arr_EXCHANGE_DATA['DST_ACCOUNT'], $arr_EXCHANGE_DATA['DST_AMOUNT'], $arr_DST['WORTH_VALUE'] );
            break;
        case "altergold" :
            $arr_PAYMENT_RESULT = altergold_autopay( $arr_DST['ACCOUNT'], $arr_DST['MAIN_PASSWORD'], $arr_EXCHANGE_DATA['DST_ACCOUNT'], $arr_EXCHANGE_DATA['DST_AMOUNT'], $arr_DST['WORTH_VALUE'] );
            break;
        case "c-gold" :
            $arr_PAYMENT_RESULT = cgold_autopay( $arr_DST['ACCOUNT'], $arr_DST['MAIN_PASSWORD'], $arr_EXCHANGE_DATA['DST_ACCOUNT'], $arr_EXCHANGE_DATA['DST_AMOUNT'], $arr_DST['WORTH_VALUE'] );
            break;
        case "webmoney" :
            $arr_PAYMENT_RESULT = webmoney_autopay( $arr_EXCHANGE_DATA['DST_ACCOUNT'], $arr_EXCHANGE_DATA['DST_AMOUNT'], $arr_DST['WORTH_VALUE'] );
            break;
        case "paypal" :
            $arr_PAYMENT_RESULT = paypal_autopay( $arr_EXCHANGE_DATA['DST_ACCOUNT'], $arr_EXCHANGE_DATA['DST_AMOUNT'], $arr_DST['WORTH_VALUE'] );
            break;
        default :
            $arr_PAYMENT_RESULT['ERROR'] .= "Invalid Source Currency in exchange order";
        }
        if ( $arr_PAYMENT_RESULT['BATCH'] )
        {
            $arr_EXCHANGE_DATA['SRC_BATCH'] = $pmt_transaction;
            $arr_EXCHANGE_DATA['DST_BATCH'] = $arr_PAYMENT_RESULT['BATCH'];
            db_exec( "update {$_exchange_lines} SET dst_status='{$STATUS_ENUM_ENABLE}', dst_batch='{$arr_PAYMENT_RESULT['BATCH']}', exchange_note=CONCAT(exchange_note,' - {$LANG_msg['note_exchange2']}'), dst_date=now() WHERE eid='{$arr_EXCHANGE_DATA['EXCHANGE_ID']}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND src_status='{$STATUS_ENUM_ENABLE}'" );
            update_reserved( $arr_EXCHANGE_DATA['SRC_CID'], $arr_EXCHANGE_DATA['SRC_AMOUNT'], $arr_EXCHANGE_DATA['DST_CID'], $arr_EXCHANGE_DATA['DST_AMOUNT'] );
            SEND_EXHCANGE_MAIL( $arr_EXCHANGE_DATA['REFRENCE'], "complete" );
            $Message_log[] = "<b>Exchange Complete</b>, Currency ".$merchant_name;
        }
        else if ( $arr_PAYMENT_RESULT['ERROR'] )
        {
            SEND_EXHCANGE_MAIL( $arr_EXCHANGE_DATA['REFRENCE'], "failed" );
            @mail( $CONFIG['ADMIN_MAIL'], "Automatic payout needs to CHECK MANUALLY : {$arr_DST['FULL_NAME']} - {$arr_EXCHANGE_DATA['DST_AMOUNT']}", $merchant_name." #".$arr_EXCHANGE_DATA['REFRENCE']." <br>Automatic Payout Failed:".@vardump( $arr_PAYMENT_RESULT )."<br><h3>You have to check this payment manually<h3>", "From: ".$CONFIG['REPORT_MAIL'] );
            db_exec( "update {$_exchange_lines} SET exchange_note=CONCAT(exchange_note,' - {$LANG_msg['note_exchange3']} > {$arr_PAYMENT_RESULT['ERROR']}') WHERE eid='{$arr_EXCHANGE_DATA['EXCHANGE_ID']}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND src_status='{$STATUS_ENUM_ENABLE}'" );
            $Message_log[] = "<b>Commit Exchange</b>, Detected currency ".$merchant_name." - AutoPayout system did not find Batch number - {$LANG_msg['note_exchange3']}";
            Write_File( $arr_PAYMENT_RESULT );
        }
    }
    else
    {
        db_exec( "update {$_exchange_lines} SET exchange_note=CONCAT(exchange_note,' - {$LANG_msg['note_exchange1']}') WHERE eid='{$arr_EXCHANGE_DATA['EXCHANGE_ID']}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND src_status='{$STATUS_ENUM_ENABLE}'" );
    }
    if ( $arr_EXCHANGE_DATA['REFERRER'] )
    {
        $referer = $arr_EXCHANGE_DATA['REFERRER'];
        $dst_exchange_rate_1 = rate_parser( $FULL_EXCHANGE_FEE, "src" );
        $dst_exchange_rate_2 = rate_parser( $FULL_EXCHANGE_FEE, "dst" );
        if ( $dst_exchange_rate_2 < $dst_exchange_rate_1 )
        {
            $different_currency_type = $dst_exchange_rate_2 / $dst_exchange_rate_1;
        }
        $ex_comission = ( $arr_EXCHANGE_DATA['SRC_AMOUNT'] - $arr_EXCHANGE_DATA['DST_AMOUNT'] ) * $different_currency_type * $CONFIG['EXCHANGE_REF_COMISSION'] / 100;
        if ( $ex_comission )
        {
            db_exec( "insert into {$_lines} (uid, pmt_type, amount, exchange, cid, user_note, pmt_note, status,date) \r\n\t\t\t\tvalues ('{$referer}','{$TRANS_ENUM_COMMISSION}','{$ex_comission}','{$ex_comission}','{$INTERNAL_CID}','{$REMOTE_ADDR}','EXCHANGE commission #{$arr_EXCHANGE_DATA['EXCHANGE_ID']} - Added to profit', '{$STATUS_ENUM_DISABLE}', now())" );
            db_exec( "update {$_lines} set amount=(amount + {$EX_COMISSION}), exchange=(exchange + {$EX_COMISSION}) WHERE pmt_type = '{$Var_12816}' AND status='{$STATUS_ENUM_ENABLE}' AND uid='{$referer_uid}'" );
        }
    }
}
Write_File( $arr_PAYMENT_RESULT, $arr_EXCHANGE_DATA );
unset( $arr_PAYMENT_RESULT );
}

function exchange_status_link( $refid )
{
    return get_link( "exchange_status.php" )."?referenceid=".$refid;
}

function MAIL_HEADER( $sender_name = "" )
{
    global $CONFIG;
    if ( !$sender_name )
    {
        $site_mail = $CONFIG['REPORT_MAIL'];
        $name = $CONFIG['REPORT_MAIL_NAME'];
    }
    else
    {
        $site_mail = $CONFIG['ADMIN_MAIL'];
        $name = $CONFIG['SITE_NAME']." Support";
    }
    if ( $sender_name )
    {
        $name = $CONFIG['SITE_NAME']." ".$sender_name;
    }
    if ( $CONFIG['MAIL_FORMAT'] == "html" )
    {
        $mail_headers = "MIME-Version: 1.0\r\n";
        $mail_headers .= "Content-type: text/html; charset=utf-8\r\n";
        $mail_headers .= "From: ".$CONFIG['SITE_NAME']." ".$name." <".$site_mail.">\r\n";
        $mail_headers .= "Reply-to: ".$site_mail."\r\n";
    }
    else
    {
        $mail_headers = "From: ".$site_mail.""."\r\n"."Reply-To: ".$site_mail.""."\r\n"."X-Mailer: PHP/".$site_mail;
    }
    return $mail_headers;
}

function SEND_EXHCANGE_MAIL( $REFRENCE, $section )
{
    global $accept_date;
    global $CONFIG;
    global $arr_PAYMENT_RESULT;
    global $_exchange_lines;
    global $_currencies;
    global $uploaded;
    global $STATUS_ENUM_ENABLE;
    global $STATUS_ENUM_DISABLE;
    global $STATUS_EXCHANGE;
    global $_users;
    global $DEF_DIR_LANGUAGE;
    global $LANG_mail;
    $arr_EXCHANGE_DATA = array( );
    $nvar = db_get_array( "SELECT src_cid, src_amount, dst_cid, dst_amount, dst_account, exchange_email_address, ref_uid, src_batch, dst_batch, uid, src_status, dst_status  FROM {$_exchange_lines} WHERE exchange_refrence='{$REFRENCE}'" );
    $arr_EXCHANGE_DATA['SRC_CID'] = $nvar[0];
    $arr_EXCHANGE_DATA['SRC_AMOUNT'] = $nvar[1];
    $arr_EXCHANGE_DATA['DST_CID'] = $nvar[2];
    $arr_EXCHANGE_DATA['DST_AMOUNT'] = $nvar[3];
    $arr_EXCHANGE_DATA['DST_ACCOUNT'] = $nvar[4];
    $arr_EXCHANGE_DATA['EMAIL'] = $nvar[5];
    $arr_EXCHANGE_DATA['REFERRER'] = $nvar[6];
    $arr_EXCHANGE_DATA['SRC_BATCH'] = $nvar[7];
    $arr_EXCHANGE_DATA['DST_BATCH'] = $nvar[8];
    $arr_EXCHANGE_DATA['UID'] = $nvar[9];
    $arr_EXCHANGE_DATA['SRC_STATUS'] = $nvar[10];
    $arr_EXCHANGE_DATA['DST_STATUS'] = $nvar[11];
    $nvar = db_get_array( "SELECT currency_name, currency_worth_name,  currency_metal_name FROM {$_currencies} WHERE cid='{$arr_EXCHANGE_DATA['DST_CID']}'" );
    $arr_DST['NAME'] = $nvar[0];
    $arr_DST['WORTH_NAME'] = $nvar[1];
    $arr_DST['METAL_NAME'] = $nvar[2];
    $arr_DST['FULL_NAME'] = $arr_DST['NAME']." ".$arr_DST['METAL_NAME'];
    $arr_SRC['NAME'] = $nvar[0];
    $arr_SRC['WORTH_NAME'] = $nvar[1];
    $arr_SRC['METAL_NAME'] = $nvar[2];
    $arr_SRC['FULL_NAME'] = $arr_SRC['NAME']." ".$arr_SRC['METAL_NAME'];
    if ( $arr_EXCHANGE_DATA['UID'] )
    {
        $user_lang = lang_selected( db_get_id( "SELECT language From {$_users} Where uid='{$arr_EXCHANGE_DATA['UID']}'" ) );
    }
    if ( $user_lang && file_exists( "{$DEF_DIR_LANGUAGE}/{$user_lang}.inc.php" ) )
    {
        require( "{$DEF_DIR_LANGUAGE}/{$user_lang}.inc.php" );
    }
    if ( $section == "receive" )
    {
        $subject = $LANG_mail['001'];
        $mail_title = $subject;
        $mail_body = $LANG_mail['002'];
    }
    else if ( $section == "complete" )
    {
        $subject = $LANG_mail['003'];
        $mail_title = $subject;
        $mail_body = $LANG_mail['004'];
    }
    else if ( $section == "failed" )
    {
        $subject = $LANG_mail['005'];
        $mail_title = $subject;
        $mail_body = $LANG_mail['006'];
    }
    $email_merge_fields['CompanyName'] = $CONFIG['SITE_NAME'];
    $email_merge_fields['SourceAmount'] = $arr_EXCHANGE_DATA['SRC_AMOUNT'];
    $email_merge_fields['SourceFullName'] = $arr_SRC['FULL_NAME'];
    $email_merge_fields['SourceBatch'] = $arr_EXCHANGE_DATA['SRC_BATCH'];
    $email_merge_fields['SourceCurrency'] = $arr_SRC['NAME'];
    $email_merge_fields['DestAmount'] = $arr_EXCHANGE_DATA['DST_AMOUNT'];
    $email_merge_fields['DestCurrencyFullName'] = $arr_DST['FULL_NAME'];
    $email_merge_fields['DestBatch'] = $arr_EXCHANGE_DATA['DST_BATCH'];
    $email_merge_fields['DestCurrency'] = $arr_DST['NAME'];
    $email_merge_fields['DestAccount'] = $arr_EXCHANGE_DATA['DST_ACCOUNT'];
    $email_merge_fields['RefrenceNo'] = $REFRENCE;
    $email_merge_fields['CustomerEmail'] = $arr_EXCHANGE_DATA['EMAIL'];
    $email_merge_fields['MinExchangeFee'] = $CONFIG['MIN_EXCHANGE_FEE'];
    $email_merge_fields['StatusLink'] = exchange_status_link( $REFRENCE );
    $email_merge_fields['AdminMail'] = $CONFIG['ADMIN_MAIL'];
    $email_merge_fields['Time'] = $accept_date;
    $email_merge_fields['DestStatus'] = $STATUS_EXCHANGE[$arr_EXCHANGE_DATA['DST_STATUS']];
    $email_merge_fields['SourceStatus'] = $STATUS_EXCHANGE[$arr_EXCHANGE_DATA['SRC_STATUS']];
    foreach ( $email_merge_fields as $key => $value )
    {
        if ( !$value )
        {
            $email_merge_fields[$key] = "--";
        }
    }
    db_get_array( );
    $mail = new siteMAIL( );
    $mail->AddAddress( $arr_EXCHANGE_DATA['EMAIL'], $arr_DST['FULL_NAME'] );
    $mail->Subject = $subject;
    $mail->Body = $Var_8184;
    $mail->mail_title = $subject;
    $mail->arrReplacer = $email_merge_fields;
    $mail->bakeMail( );
    if ( !$uploaded )
    {
        echo $arr_EXCHANGE_DATA['EMAIL']."<br>".$mail->Body;
    }
    else if ( $arr_EXCHANGE_DATA['EMAIL'] )
    {
        if ( $CONFIG['MAIL_TYPE'] == "smtp" )
        {
            if ( !$mail->Send( ) )
            {
                $Error[] = "There was an error sending the message: ".$mail->ErrorInfo;
            }
        }
        else
        {
            if ( !mail( $arr_EXCHANGE_DATA['EMAIL'], $mail->Subject, $mail->Body, mail_header( ) ) )
            {
                $Error[] = "There was an error sending the email by server php mail extension.";
            }
            if ( $CONFIG['adminemailnotification'] )
            {
                mail( $CONFIG['ADMIN_MAIL'], $mail->Subject, $mail->Body, mail_header( ) );
            }
        }
    }
}

function SEND_WITHDRAW_MAIL( $PAYMENT_ID )
{
    global $accept_date;
    global $arr_PAYMENT;
    global $arr_DST;
    global $arr_PAYMENT_RESULT;
    global $accept_date;
    global $CONFIG;
    global $uploaded;
    global $TRANS_ENUM_WITHDRAW;
    global $STATUS_ENUM_ENABLE;
    global $STATUS_ENUM_ENABLE;
    global $_lines;
    global $_users_details;
    global $LANG_msg;
    global $LANG_mail;
    $arr_PAYMENT = array( );
    $nvar = db_get_array( "Select {$_users_details}.fullname, {$_users_details}.email, {$_lines}.amount , {$_lines}.cid, {$_lines}.pmt_note, {$_users_details}.money_account From {$_lines} Inner Join {$_users_details} ON {$_lines}.uid = {$_users_details}.uid Where {$_lines}.id = '{$PAYMENT_ID}' AND pmt_type='{$TRANS_ENUM_WITHDRAW}'" );
    $arr_PAYMENT['FULLNAME'] = $nvar[0];
    $arr_PAYMENT['EMAIL'] = $nvar[1];
    $arr_PAYMENT['AMOUNT'] = $nvar[2];
    $arr_PAYMENT['SRC_CID'] = $nvar[3];
    if ( !$arr_PAYMENT['BATCH'] )
    {
        $arr_PAYMENT['BATCH'] = $nvar[4];
    }
    $arr_PAYMENT['DST_ACCOUNT'] = $nvar[5];
    if ( !$merchant_name && $arr_PAYMENT['SRC_CID'] )
    {
        $merchant_name = convert_emoney( $arr_PAYMENT['SRC_CID'] );
    }
    if ( $arr_PAYMENT['AMOUNT'] < 0 )
    {
        $arr_PAYMENT['AMOUNT'] = $arr_PAYMENT['AMOUNT'] * ( 0 - 1 );
    }
    $email_merge_fields['CustomerName'] = $arr_PAYMENT['FULLNAME'];
    $email_merge_fields['DestAmount'] = $arr_PAYMENT['AMOUNT'];
    $email_merge_fields['MerchantName'] = $merchant_name;
    $email_merge_fields['DestAccount'] = $arr_PAYMENT['DST_ACCOUNT'];
    $email_merge_fields['PaymentMemo'] = $arr_PAYMENT['BATCH'];
    $email_merge_fields['CompanyName'] = $CONFIG['SITE_NAME'];
    $email_merge_fields['AdminMail'] = $CONFIG['ADMIN_MAIL'];
    $email_merge_fields['Time'] = $accept_date;
    $subject = $LANG_mail['019'];
    $mail_title = $subject;
    $mail_body = $LANG_mail['020'];
    $mail = new siteMAIL( );
    $mail->AddAddress( $arr_PAYMENT['EMAIL'], $arr_PAYMENT['FULLNAME'] );
    $mail->Subject = $subject;
    $mail->Body = nl2br( $mail_body );
    $mail->mail_title = $subject;
    $mail->arrReplacer = $email_merge_fields;
    $mail->bakeMail( );
    if ( !$uploaded )
    {
        echo $arr_PAYMENT['EMAIL']."<br>".$mail->Body;
    }
    else if ( $arr_PAYMENT['EMAIL'] )
    {
        if ( $CONFIG['MAIL_TYPE'] == "smtp" )
        {
            if ( !$mail->Send( ) )
            {
                $Error[] = "There was an error sending the message: ".$mail->ErrorInfo;
            }
        }
        else
        {
            if ( !mail( $arr_PAYMENT['EMAIL'], $mail->Subject, $mail->Body, mail_header( ) ) )
            {
                $Error[] = "There was an error sending the email by server php mail extension.";
            }
            if ( $CONFIG['adminemailnotification'] )
            {
                mail( $CONFIG['ADMIN_MAIL'], $mail->Subject, $mail->Body, mail_header( ) );
            }
        }
    }
}

function SEND_INVEST_RECEIVE_MAIL( $PAYMENT_ID, $payer_acc = "" )
{
    global $accept_date;
    global $CONFIG;
    global $uploaded;
    global $arr_PAYMENT;
    global $arr_DST;
    global $LANG_pay;
    global $arr_PAYMENT_RESULT;
    global $_lines;
    global $_users_details;
    global $LANG_mail;
    global $TRANS_ENUM_SPEND;
    global $STATUS_ENUM_ENABLE;
    global $_currencies;
    global $accept_date;
    global $LANG_mail;
    $arr_PAYMENT = array( );
    $nvar = db_get_array( "Select {$_users_details}.fullname, {$_users_details}.email, {$_lines}.amount , {$_lines}.cid, {$_lines}.pmt_note From {$_lines} Inner Join {$_users_details} ON {$_lines}.uid = {$_users_details}.uid Where {$_lines}.id = '{$PAYMENT_ID}' AND {$_lines}.status='{$STATUS_ENUM_ENABLE}' AND pmt_type='{$TRANS_ENUM_SPEND}'" );
    $arr_PAYMENT['FULLNAME'] = $nvar[0];
    $arr_PAYMENT['EMAIL'] = $nvar[1];
    $arr_PAYMENT['AMOUNT'] = $nvar[2];
    $arr_PAYMENT['SRC_CID'] = $nvar[3];
    $arr_PAYMENT['BATCH'] = $nvar[4];
    $merchant_name = convert_emoney( $arr_PAYMENT['SRC_CID'] );
    $email_merge_fields['CompanyName'] = $CONFIG['SITE_NAME'];
    $email_merge_fields['AdminMail'] = $CONFIG['ADMIN_MAIL'];
    $email_merge_fields['IpAddress'] = $_SERVER['REMOTE_ADDR'];
    $email_merge_fields['Time'] = $accept_date;
    $email_merge_fields['InvestAmount'] = set_money_color( FormatPrice( $arr_PAYMENT['AMOUNT'] ), 1, get_worth_name( $arr_PAYMENT['SRC_CID'] ) );
    $email_merge_fields['CustomerName'] = $arr_PAYMENT['FULLNAME'];
    $email_merge_fields['PaymentId'] = $PAYMENT_ID;
    $email_merge_fields['MerchantName'] = $merchant_name;
    $email_merge_fields['PayerAccount'] = $payer_acc;
    $email_merge_fields['PaymentMemo'] = $arr_PAYMENT['BATCH'];
    $LANG_mail['017'] = "New Investment";
    $LANG_mail['018'] = "<br>Dear Member <b>[CustomerName]</b>,\r\n\t\r\n\tYour new investment to your <b>[CompanyName]</b> account, with this payment ID: <b>#[PaymentId]</b>\r\n\tAbout investing <b>[InvestAmount]</b> from your <b> [MerchantName] [PayerAccount]</b> account (<b>[PaymentMemo]</b>) accept successfully.\r\n\tDate: <b>[Time]</b>.";
    $LANG_mail['019'] = "New Investment from profit";
    $LANG_mail['020'] = "<br>Dear Member <b>[CustomerName]</b>,\r\n\t\r\n\tYour new investment to your <b>[CompanyName]</b> account, with this payment ID: <b>#[PaymentId]</b>\r\n\tAbout investing <b>[InvestAmount]</b> from your <b>Profit</b> accept successfully.\r\n\tDate: <b>[Time]</b>.";
    $subject = $LANG_mail['017'];
    $mail_title = $subject;
    $mail_body = $LANG_mail['018'];
    if ( $payer_acc == "Profit" )
    {
        $subject = $LANG_mail['019'];
        $mail_title = $subject;
        $mail_body = $LANG_mail['020'];
    }
    $mail = new siteMAIL( );
    $mail->AddAddress( $arr_PAYMENT['EMAIL'], $arr_PAYMENT['FULLNAME'] );
    $mail->Subject = $subject;
    $mail->Body = nl2br( $mail_body );
    $mail->mail_title = $subject;
    $mail->arrReplacer = $email_merge_fields;
    $mail->bakeMail( );
    if ( !$uploaded )
    {
        echo $arr_PAYMENT['EMAIL']."<br>".$mail->Body;
    }
    else if ( $arr_PAYMENT['EMAIL'] )
    {
        if ( $CONFIG['MAIL_TYPE'] == "smtp" )
        {
            if ( !$mail->Send( ) )
            {
                $Error[] = "There was an error sending the message: ".$mail->ErrorInfo;
            }
        }
        else
        {
            if ( !mail( $arr_PAYMENT['EMAIL'], $mail->Subject, $mail->Body, mail_header( ) ) )
            {
                $Error[] = "There was an error sending the email by server php mail extension.";
            }
            if ( $CONFIG['adminemailnotification'] )
            {
                mail( $CONFIG['ADMIN_MAIL'], $mail->Subject, $mail->Body, mail_header( ) );
            }
        }
    }
}

function SEND_REGULAR_MAIL( $uid, $section, $extra = "" )
{
    global $accept_date;
    global $LANG_msg;
    global $CONFIG;
    global $arr_PAYMENT_RESULT;
    global $uploaded;
    global $_referals;
    global $LANG_mail;
    global $STATUS_ENUM_ENABLE;
    global $STATUS_ENUM_DISABLE;
    global $_users;
    global $_users_details;
    global $DEF_DIR_LANGUAGE;
    global $_referal_plans;
    $nvar = db_get_array( "select fullname, email, uid from {$_users_details} where uid='{$uid}'" );
    $email_merge_fields['CustomerName'] = $nvar[0];
    $email_merge_fields['CustomerEmail'] = $nvar[1];
    $email_merge_fields['ReferralLink'] = make_ref_link( $nvar[2] );
    $email_merge_fields['UserName'] = db_get_id( "select login from {$_users} where uid='{$uid}'" );
    $email_merge_fields['SiteUrl'] = $CONFIG['SITE_URL'];
    $email_merge_fields['CompanyName'] = $CONFIG['SITE_NAME'];
    $email_merge_fields['AdminMail'] = $CONFIG['ADMIN_MAIL'];
    $email_merge_fields['IpAddress'] = $_SERVER['REMOTE_ADDR'];
    $email_merge_fields['Time'] = $accept_date;
    if ( $section == "new_ref" )
    {
        $rid = db_get_id( "SELECT uid FROM {$_referals} WHERE uid_referal='{$uid}'" );
        $nvar = db_get_array( "select fullname, email from {$_users_details} where uid='{$rid}' and suspended='0'" );
        $email_merge_fields['ReferralName'] = $nvar[0];
        $email_merge_fields['ReferralEmail'] = $nvar[1];
        $email_merge_fields['ReferralPercent'] = $CONFIG['EXCHANGE_REF_COMISSION'];
        $subject = $LANG_mail['007'];
        $mail_title = $subject;
        $mail_body = $LANG_mail['008'];
        $target_mail = $email_merge_fields['ReferralEmail'];
    }
    else if ( $section == "signup" )
    {
        if ( $uid )
        {
            $user_lang = lang_selected( db_get_id( "SELECT language From {$_users} Where uid='{$uid}'" ) );
        }
        if ( $user_lang && file_exists( "{$DEF_DIR_LANGUAGE}/{$user_lang}.inc.php" ) )
        {
            require( "{$DEF_DIR_LANGUAGE}/{$user_lang}.inc.php" );
        }
        $subject = $LANG_mail['009'];
        $mail_title = $subject;
        $mail_body = $LANG_mail['010'];
        $target_mail = $email_merge_fields['CustomerEmail'];
    }
    else if ( $section == "forgot" )
    {
        if ( $uid )
        {
            $user_lang = lang_selected( db_get_id( "SELECT language From {$_users} Where uid='{$uid}'" ) );
        }
        if ( $user_lang && file_exists( "{$DEF_DIR_LANGUAGE}/{$user_lang}.inc.php" ) )
        {
            require( "{$DEF_DIR_LANGUAGE}/{$user_lang}.inc.php" );
        }
        $sender_name = $LANG_msg['forgot_005'];
        $subject = $LANG_mail['011'];
        $mail_title = $subject;
        $email_merge_fields['CustomerPassword'] = $extra;
        $mail_body = $LANG_mail['012'];
        $target_mail = $email_merge_fields['CustomerEmail'];
    }
    $mail = new siteMAIL( );
    $mail->AddAddress( $target_mail, $email_merge_fields['CustomerName'] );
    $mail->Subject = $subject;
    $mail->Body = nl2br( $mail_body );
    $mail->mail_title = $subject;
    $mail->arrReplacer = $email_merge_fields;
    $mail->bakeMail( );
    if ( !$uploaded )
    {
        echo $target_mail."<br>".$mail->Body;
    }
    else if ( $target_mail )
    {
        if ( $CONFIG['MAIL_TYPE'] == "smtp" )
        {
            if ( !$mail->Send( ) )
            {
                $Error[] = "There was an error sending the message: ".$mail->ErrorInfo;
            }
        }
        else
        {
            if ( !mail( $target_mail, $mail->Subject, $mail->Body, mail_header( ) ) )
            {
                $Error[] = "There was an error sending the email by server php mail extension.";
            }
            if ( $CONFIG['adminemailnotification'] )
            {
                mail( $CONFIG['ADMIN_MAIL'], $mail->Subject, $mail->Body, mail_header( ) );
            }
        }
    }
}

function SEND_ORDER_MAIL( $OID, $section )
{
    global $accept_date;
    global $CONFIG;
    global $arr_PAYMENT_RESULT;
    global $_orders;
    global $_currencies;
    global $uploaded;
    global $STATUS_ENUM_ENABLE;
    global $STATUS_ENUM_DISABLE;
    global $STATUS_EXCHANGE;
    global $_users;
    global $DEF_DIR_LANGUAGE;
    global $LANG_mail;
    $arr_ORDER_DATA = array( );
    $result = db_query( "SELECT oid, uid, cid, order_amount, currency_account, email_address, payment_method, full_name, dst_status, src_status, order_type, order_date, dst_date, src_date, src_status, dst_status  FROM {$_orders} WHERE oid='{$OID}'" );
    $arr_ORDER_DATA = mysql_fetch_assoc( $result );
    $nvar = db_get_array( "SELECT currency_name, currency_worth_name,  currency_metal_name FROM {$_currencies} WHERE cid='{$arr_ORDER_DATA['cid']}'" );
    $arr_CURRENCY['NAME'] = $nvar[0];
    $arr_CURRENCY['WORTH_NAME'] = $nvar[1];
    $arr_CURRENCY['METAL_NAME'] = $nvar[2];
    $arr_CURRENCY['FULL_NAME'] = $arr_CURRENCY['NAME']." ".$arr_CURRENCY['METAL_NAME'];
    if ( $arr_ORDER_DATA['uid'] )
    {
        $user_lang = lang_selected( db_get_id( "SELECT language From {$_users} Where uid='{$arr_ORDER_DATA['uid']}'" ) );
    }
    if ( $user_lang && file_exists( "{$DEF_DIR_LANGUAGE}/{$user_lang}.inc.php" ) )
    {
        require( "{$DEF_DIR_LANGUAGE}/{$user_lang}.inc.php" );
    }
    if ( $section == "receive" )
    {
        $subject = $LANG_mail['013'];
        $mail_body = $LANG_mail['014'];
    }
    else if ( $section == "complete" )
    {
        $subject = $LANG_mail['015'];
        $mail_body = $LANG_mail['016'];
    }
    else if ( $section == "delete" )
    {
        $subject = $LANG_mail['017'];
        $mail_body = $LANG_mail['018'];
    }
    $email_merge_fields['CompanyName'] = $CONFIG['SITE_NAME'];
    $email_merge_fields['OrderType'] = $arr_ORDER_DATA['order_type'];
    $email_merge_fields['SourceAmount'] = $arr_ORDER_DATA['order_amount'];
    $email_merge_fields['CustomerName'] = $arr_ORDER_DATA['full_name'];
    $email_merge_fields['SourceCurrency'] = $arr_CURRENCY['NAME'];
    $email_merge_fields['SourceCurrencyFullName'] = $arr_CURRENCY['FULL_NAME'];
    $email_merge_fields['DestCurrency'] = $arr_ORDER_DATA['payment_method'];
    $email_merge_fields['DestAccount'] = $arr_ORDER_DATA['DST_ACCOUNT'];
    $email_merge_fields['RefrenceNo'] = $OID;
    $email_merge_fields['CustomerEmail'] = $arr_ORDER_DATA['email_address'];
    $email_merge_fields['AdminMail'] = $CONFIG['ADMIN_MAIL'];
    $email_merge_fields['Time'] = $accept_date;
    $email_merge_fields['DestStatus'] = $STATUS_EXCHANGE[$arr_ORDER_DATA['dst_status']];
    $email_merge_fields['SourceStatus'] = $STATUS_EXCHANGE[$arr_ORDER_DATA['src_status']];
    $subject = str_replace( "[OrderType]", $arr_ORDER_DATA['order_type'], $subject );
    $mail_title = $subject;
    $mail = new siteMAIL( );
    $mail->AddAddress( $arr_ORDER_DATA['email_address'], $arr_ORDER_DATA['full_name'] );
    $mail->Subject = $subject;
    $mail->Body = nl2br( $mail_body );
    $mail->mail_title = $subject;
    $mail->arrReplacer = $email_merge_fields;
    $mail->bakeMail( );
    if ( !$uploaded )
    {
        echo $arr_ORDER_DATA['email_address']."<br>".$mail->Body;
    }
    else if ( $arr_ORDER_DATA['email_address'] )
    {
        if ( $CONFIG['MAIL_TYPE'] == "smtp" )
        {
            if ( !$mail->Send( ) )
            {
                $Error[] = "There was an error sending the message: ".$mail->ErrorInfo;
            }
        }
        else
        {
            if ( !mail( $arr_ORDER_DATA['email_address'], $mail->Subject, $mail->Body, mail_header( ) ) )
            {
                $Error[] = "There was an error sending the email by server php mail extension.";
            }
            if ( $CONFIG['adminemailnotification'] )
            {
                mail( $CONFIG['ADMIN_MAIL'], $mail->Subject, $mail->Body, $Var_6528 );
            }
        }
    }
}

require_once( "class.mailing.php" );
?>
