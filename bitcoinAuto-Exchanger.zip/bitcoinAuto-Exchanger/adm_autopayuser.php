<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "public.inc.php" );
#if ( !( ) )
{
    @header( "Location: ".$CONFIG['SITE_URL'] );
}
error_reporting( E_ALL ^ E_NOTICE );
set_time_limit( 30 );
$subject = $LANG_msg['pay_013'];
$user = $_GET['user'];
$amount = $_GET['amount'];
$account = $_GET['account'];
$emoney = $_GET['emoney'];
$process = $_GET['process'];
$type = $_GET['Type'];
$id = $_GET['id'];
if ( isset( $_GET['act'] ) && $_GET['act'] == "bulk" && $_GET['bulk'] )
{
    $bulk = $_GET['bulk'];
    if ( $type == "withdraw" )
    {
        $query = "SELECT l.id, u.login, u.status, abs(l.exchange) AS amount, l.pmt_note, d.money_account,  d.cid, d.email FROM {$_lines} l, {$_users} u, {$_users_details} d \r\n\t\t\tWHERE l.id IN ({$bulk}) AND l.pmt_type='{$TRANS_ENUM_WITHDRAW}' AND l.status='{$STATUS_ENUM_DISABLE}' AND l.uid=u.uid and d.uid=u.uid AND d.suspended='0'";
    }
    else if ( $type == "exchange" )
    {
        $query = "SELECT eid, uid, src_cid, src_amount, dst_cid, dst_amount, dst_account, exchange_refrence, exchange_note FROM {$_exchange_lines} WHERE eid IN ({$bulk}) AND dst_status='{$STATUS_ENUM_DISABLE}'";
    }
    $db_result = db_query( $query, "&nbsp;" );
    $no = 1;
    while ( $line = db_fetch_array( $db_result ) )
    {
        if ( $type == "withdraw" )
        {
            $Success[] = $Tmp_90." - ID:".$line[id]." --- Note:(".$line[login].") --- ".$line[pmt_note]." --- <b><u>".convert_emoney( $line[cid] )."</u> ===> \$".FormatPrice( $line[amount], 2 )."</b><br>";
        }
        else if ( $type == "exchange" )
        {
            $Success[] = $no++."- <span style='font-weight:normal;font-size:11px'>Reference:#".$line[exchange_refrence]." - Note:(<span style='font-size:10px; color:#003'>".$line[exchange_note]."</span>)<br></span>".set_money_color( FormatPrice( $line[src_amount] ), 1, get_worth_name( $line[src_cid] ) )." ".convert_emoney( $line[src_cid] )."  => To: <b><u>".set_money_color( FormatPrice( $line[dst_amount] ), 1, get_worth_name( $line[dst_cid] ) )."</u> ".convert_emoney( $line[dst_cid] )."</b> Account:".$line[dst_account]."<br>";
        }
    }
}
else if ( isset( $_POST['act'] ) && ( $_POST['act'] && !$demo_mode ) )
{
    $bulk = $_POST['bulk'];
    if ( $type == "withdraw" )
    {
        $query = "SELECT l.id, u.login, u.status, abs(l.amount) AS amount, d.money_account, d.cid, d.email, d.fullname FROM ({$_lines} l, {$_users} u,  d) \r\n\t\t\tWHERE l.id in ({$bulk}) AND l.pmt_type='{$TRANS_ENUM_WITHDRAW}' AND l.status='{$STATUS_ENUM_DISABLE}' AND l.uid=u.uid AND d.uid=u.uid AND d.suspended='0'";
    }
    else if ( $type == "exchange" )
    {
        $query = "SELECT eid, uid, src_cid, src_amount, dst_cid AS cid, dst_amount AS amount, dst_account AS money_account, exchange_email_address, exchange_refrence FROM {$_exchange_lines} WHERE eid IN ({$bulk}) AND dst_status='{$STATUS_ENUM_DISABLE}'";
    }
    $db_result = db_query( $query, "&nbsp;" );
    while ( $line = db_fetch_array( $db_result ) )
    {
        $arr_DST = array( );
        $nvar = db_get_array( "SELECT currency_name, currency_worth_value, currency_worth_name, currency_metal_name, currency_metal_value, exchange_min, exchange_max, reserve_amount, exchange_automatic, ACCOUNT, MAIN_PASSWORD FROM {$_currencies} WHERE cid='{$line['cid']}'" );
        $arr_DST['NAME'] = $nvar[0];
        $arr_DST['WORTH_VALUE'] = $nvar[1];
        $arr_DST['WORTH_NAME'] = $nvar[2];
        $arr_DST['METAL_NAME'] = $nvar[3];
        $arr_DST['METAL_VALUE'] = $nvar[4];
        $arr_DST['EXCHANGE_MIN'] = $nvar[5];
        $arr_DST['EXCHANGE_MAX'] = $nvar[6];
        $arr_DST['RESERVE_AMOUNT'] = $nvar[7];
        $arr_DST['EXCHANGE_AUTO'] = $nvar[8];
        $arr_DST['ACCOUNT'] = $nvar[9];
        $ramz = new RamzNegar( );
        $arr_DST['MAIN_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $nvar[10] );
        $arr_DST['FULL_NAME'] = $arr_DST['NAME']." ".$arr_DST['METAL_NAME'];
        $merchant_name = $arr_DST['NAME'];
        if ( $line[status] != $STATUS_ENUM_ENABLE && $type == "withdraw" )
        {
            $Error[] = $line[login]." is not active or locked";
        }
        if ( !$line[amount] )
        {
            $Error[] = "Invalid withdrawal request <b>{$line['login']}</b><br>";
        }
        else if ( !$merchant_name )
        {
            $Error[] = "Missing currency type <b>{$line['login']}</b><br>";
        }
        else
        {
            $PAYMENT_ID = $line[id].$line[exchange_refrence];
            if ( $type == "withdraw" )
            {
                $MEMO = "Pay to {$line['login']} by ".$CONFIG['SITE_NAME'];
            }
            else if ( $type == "exchange" )
            {
                $MEMO = "Exchange by {$CONFIG['SITE_NAME']}";
            }
            switch ( $merchant_name )
            {
            case "e-gold" :
                $arr_PAYMENT_RESULT = egold_autopay( $arr_DST['ACCOUNT'], $arr_DST['MAIN_PASSWORD'], $line[money_account], $line[amount], $arr_DST['METAL_NAME'] );
                break;
            case "e-bullion" :
                $Error[] = "ERROR: THERE IS NOT AUTOPAY SYSTEM FOR ".ucfirst( $merchant_name );
                break;
            case "pecunix" :
                $arr_PAYMENT_RESULT = pecunix_autopay( $arr_DST['ACCOUNT'], $arr_DST['MAIN_PASSWORD'], $line[money_account], $line[amount], $arr_DST['WORTH_VALUE'] );
                break;
            case "moneybookers" :
                $Error[] = "ERROR: THERE IS NOT AUTOPAY SYSTEM FOR ".ucfirst( $merchant_name );
                break;
            case "libertyreserve" :
                $arr_PAYMENT_RESULT = liberty_autopay( strtoupper( $arr_DST['ACCOUNT'] ), $arr_DST['MAIN_PASSWORD'], $line[money_account], $line[amount], $arr_DST['WORTH_VALUE'] );
                break;
            case "alertpay" :
                $Error[] = "ERROR: THERE IS NOT AUTOPAY SYSTEM FOR ".ucfirst( $merchant_name );
                break;
            case "v-money" :
                $arr_PAYMENT_RESULT = vmoney_autopay( $arr_DST['ACCOUNT'], $arr_DST['MAIN_PASSWORD'], $line[money_account], $line[amount], $arr_DST['WORTH_VALUE'] );
                break;
            case "perfectmoney" :
                $arr_PAYMENT_RESULT = perfectmoney_autopay( $arr_DST['ACCOUNT'], $arr_DST['MAIN_PASSWORD'], $line[money_account], $line[amount], $arr_DST['WORTH_VALUE'] );
                break;
            case "altergold" :
                $arr_PAYMENT_RESULT = altergold_autopay( $arr_DST['ACCOUNT'], $arr_DST['MAIN_PASSWORD'], $line[money_account], $line[amount], $arr_DST['WORTH_VALUE'] );
                break;
            case "c-gold" :
                $arr_PAYMENT_RESULT = cgold_autopay( $arr_DST['ACCOUNT'], $arr_DST['MAIN_PASSWORD'], $line[money_account], $line[amount], $arr_DST['WORTH_VALUE'] );
                break;
            case "webmoney" :
                $arr_PAYMENT_RESULT = webmoney_autopay( $arr_EXCHANGE_DATA['DST_ACCOUNT'], $arr_EXCHANGE_DATA['DST_AMOUNT'], $arr_DST['WORTH_VALUE'] );
                break;
            case "paypal" :
                $arr_PAYMENT_RESULT = paypal_autopay( $arr_EXCHANGE_DATA['DST_ACCOUNT'], $arr_EXCHANGE_DATA['DST_AMOUNT'], $arr_DST['WORTH_VALUE'] );
                break;
            default :
                $Error[] = "ERROR: NOT FOUND CURRENCY";
            }
            if ( $arr_PAYMENT_RESULT['BATCH'] )
            {
                if ( $type == "withdraw" )
                {
                    $arr_PAYMENT['BATCH'] = $arr_PAYMENT_RESULT['BATCH'];
                    db_exec( "update {$_lines} set status='{$STATUS_ENUM_ENABLE}', pmt_note=CONCAT(pmt_note,'{$arr_PAYMENT['BATCH']}') WHERE id='{$line['id']}' AND pmt_type='{$TRANS_ENUM_WITHDRAW}'" );
                    SEND_WITHDRAW_MAIL( $line[id] );
                }
                else if ( $type == "exchange" )
                {
                    $arr_EXCHANGE_DATA['DST_BATCH'] = $arr_PAYMENT_RESULT['BATCH'];
                    db_exec( "update {$_exchange_lines} SET dst_status='{$STATUS_ENUM_ENABLE}', dst_batch='{$arr_PAYMENT_RESULT['BATCH']}', exchange_note=CONCAT(exchange_note,' - {$LANG_msg['note_exchange4']}'), dst_date=now() WHERE eid='{$line['eid']}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND src_status='{$STATUS_ENUM_ENABLE}'" );
                    SEND_EXHCANGE_MAIL( $arr_EXCHANGE_DATA['REFRENCE'], "complete" );
                }
                $Success[] = "<h1>{$merchant_name} Amount sent successfully</h1><br>";
                if ( $arr_PAYMENT_RESULT['BATCH'] )
                {
                    $Success[] = "<h2>Payment Baych = ".$arr_PAYMENT_RESULT['BATCH']."</h2><br>";
                }
                if ( $line[eid] )
                {
                    $Success[] = "Line ID = ".$line[id].$line[eid]."<br>";
                }
                if ( $line[fullname] )
                {
                    $Success[] = "Fullname = ".$line[fullname]."<br>";
                }
                if ( $line[amount] )
                {
                    $Success[] = "Amount = \$".$line[amount]."<br>";
                }
                if ( $line[money_account] )
                {
                    $Success[] = "Account = ".$line[money_account]."<br>DATABASE UPDATED<hr>";
                }
            }
            else
            {
                $Error[] = ucfirst( $merchant_name )." Payment FAILED, ID= {$line['id']} {$line['eid']} ==>  {$line['fullname']} => {$line['money_account']} : {$amount} <br>";
                if ( $arr_PAYMENT_RESULT )
                {
                    foreach ( $arr_PAYMENT_RESULT as $key => $value )
                    {
                        $Error[] = $key." = ".$value;
                    }
                }
                $Error[] = "<hr/>";
            }
            unset( $arr_PAYMENT_RESULT );
        }
    }
    db_free_result( $db_result );
    $Success[] = $msg_done;
}
else
{
}
if ( isset( $_POST['act'] ) && ( $_POST['act'] && $demo_mode ) )
{
    $Error_div[] = "Some features are not active in Demo Version.";
}
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."adm_autopayuser.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "adm_autopayuser.html";
    if ( !$Get )
    {
        $Get = array( );
    }
    foreach ( $_GET as $key => $value )
    {
        $Post["".$key.""] = $value;
    }
    $page->assign( "Get", $Post );
    if ( isset( $_GET['act'] ) && $_GET['act'] == "bulk" && $_GET['bulk'] )
    {
        $page->assign( "show_form", true );
    }
    require( "include/engine_run.php" );
}
?>
