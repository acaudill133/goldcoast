<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

echo "  \r\n<INPUT type=HIDDEN name=\"cmd\" value=\"_xclick\">\r\n<INPUT type=HIDDEN name=\"business\" value=\"";
echo $payee_account;
echo "\">\r\n<INPUT type=HIDDEN name=\"item_name\" value=\"";
echo $suggested_memo;
echo "\">\r\n<INPUT type=HIDDEN name=\"no_shipping\" value=\"2\">\r\n<INPUT type=HIDDEN name=\"return\" value=\"";
echo $status_url;
echo "\">\r\n<INPUT type=HIDDEN name=\"no_note\" value=\"1\">\r\n";
if ( $amount == "ask" )
{
    echo "    Amount you want to pay: <INPUT type='text' name=\"amount\">\r\n";
}
else
{
    echo $amount;
    echo "\">\r\n";
}
echo "<INPUT type=HIDDEN name=\"item_number\" value=\"";
echo $payment_id;
echo "\">\r\n<INPUT type=HIDDEN name=\"currency_code\" value=\"";
echo $arr_PAYMENT['WORTH_VALUE'];
echo "\">\r\n<INPUT type=HIDDEN name=\"cancel_ return\" value=\"";
echo $response_no;
echo "\">\r\n<INPUT type=HIDDEN name=\"return \" value=\"";
echo $response_ok;
echo "\">";
?>
