<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "public.inc.php" );
if ( !session_admin( ) )
{
    @header( "Location: ".$CONFIG['SITE_URL'] );
}
if ( $_POST['Action'] == "SaveAll" )
{
    foreach ( $_POST as $key => $value )
    {
        list( $oid, $fld_name ) = oid  ;      if ( $Tmp_32 && is_numeric( $oid ) )
        {
            $Error[] = "Order line {$oid} Does not exists";
        }
        else if ( $fld_name && is_numeric( $oid ) )
        {
            $current_status = db_get_id( "SELECT src_status FROM ".$_orders." WHERE oid='{$oid}'" );
            if ( $current_status == 0 && $value == 1 )
            {
                $update_SQL = "src_date=now(), ";
                SEND_ORDER_MAIL( $_GET['oid'], "receive" );
            }
            else if ( $value == 0 )
            {
                $update_SQL = "src_date='', ";
            }
            $update_SQL .= $fld_name."='".$value."' WHERE oid='{$oid}'; ";
            $full_sql = "UPDATE ".$_orders." SET ".$update_SQL;
            db_exec( $full_sql );
            unset( $update_SQL );
            unset( $full_sql );
        }
    }
    if ( !$Error )
    {
        $Success[] = "Order Status update successfully.";
    }
}
if ( $_POST['submit'] == "Update" && $_GET['oid'] )
{
    $count = 0;
    $total_fields = count( $_POST );
    foreach ( $_POST as $key => $value )
    {
        if ( $count < $total_fields - 2 )
        {
            $SQL .= "{$key}='{$value}' , ";
        }
        else if ( $key != "update" && $key != "submit" )
        {
            $SQL .= "{$key}='{$value}' WHERE oid='{$_GET['oid']}'";
        }
        ++$count;
    }
    if ( db_exec( "UPDATE {$_orders} SET {$SQL}" ) )
    {
        $Success[] = "Exchange Order updated successfully.";
    }
    $show_main = false;
}
if ( $_GET['Action'] == "Edit" && $_GET['oid'] )
{
    $query = "SELECT * FROM {$_orders} WHERE oid='{$_GET['oid']}'";
    $result = db_query( $query, "&nbsp;" );
    $arr_data_orders = mysql_push_data( $result );
    db_free_result( $result );
    $show_main = false;
}
if ( $_GET['Action'] == "Mark_Complete" && $_GET['oid'] )
{
    if ( db_exec( "UPDATE {$_orders} SET dst_status='{$STATUS_ENUM_ENABLE}', order_note=CONCAT(order_note,' - Your order manually complete') WHERE oid='{$_GET['oid']}'" ) )
    {
        SEND_ORDER_MAIL( $_GET['oid'], "complete" );
        $Success[] = "Order Marked Complete, email has been sent.";
    }
    else
    {
        $Error[] = "Error: You don't have buy/sell order with Open status as Source by this: {$_GET['oid']} ";
    }
    $show_main = true;
}
if ( $_GET['Action'] == "Delete" && $_GET['oid'] )
{
    if ( db_exec( "DELETE FROM {$_orders} WHERE oid='{$Var_4776['oid']}' AND src_status='{$STATUS_ENUM_DISABLE}'" ) )
    {
        $Success[] = "Order line: #{$_GET['oid']} Delete Successfully.";
        SEND_ORDER_MAIL( $_GET['oid'], "delete" );
    }
    else
    {
        $Error[] = "Error: Order line {$_GET['oid']} doesn't exists or is waiting to pay";
    }
    $show_main = true;
}
$order = $_GET['order'];
if ( !$order )
{
    $order = "ASC";
}
$key = $_GET['key'];
if ( !$key )
{
    $key = "{$_orders}.order_date";
}
$key = $key." ".$order;
$write_order = "Asc";
if ( $order == "Asc" )
{
    $write_order = "Desc";
}
if ( $_GET['Type'] == "source_pending" || !$_GET['Type'] )
{
    $SQL = "src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}'";
    $_GET['Type'] = "source_pending";
}
else if ( $_GET['Type'] == "complete" )
{
    $SQL = "src_status='{$STATUS_ENUM_ENABLE}' AND dst_status='{$STATUS_ENUM_ENABLE}'";
}
else if ( $_GET['Type'] == "pend_to_pay" )
{
    $SQL = "src_status='{$STATUS_ENUM_ENABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}'";
}
if ( $_GET['order_date'] == "today" )
{
    $SQL .= " AND to_days(order_date)=to_days(now())";
}
else if ( $_GET['order_date'] )
{
    $SQL .= " AND order_date='{$_GET['order_date']}'";
}
if ( !$SQL )
{
    $SQL = " oid>'1' ";
}
$no = 0;
$sum = 0;
if ( !$_GET['Action'] || $show_main )
{
    $query = "SELECT {$_orders}.*, {$_currencies}.exchange_automatic, {$_currencies}.currency_worth_name FROM {$_orders} Left Join {$_currencies} ON {$_orders}.cid = {$_currencies}.cid WHERE {$SQL} ORDER BY {$key} ";
    $page = $_GET['page'];
    $total = mysql_num_rows( mysql_query( $query ) );
    $perpage = $CONFIG['recordsnumperpage'];
    $url_string = $cur_page.( $_GET['Type'] ? "&Type={$_GET['Type']}" : "" );
    $url_string = get_link( $url_string );
    $pager = new pager( $total, $perpage, $url_string, $CONFIG['FRIENDLY_URL'] );
    if ( empty( $page ) )
    {
        $page = 1;
    }
    $from = $pager->getPageFrom( $page );
    $query = $query." limit {$from}, {$perpage}";
    $result = db_query( $query, "&nbsp;" );
    $arr_data_orders = mysql_push_data( $result );
    db_free_result( $result );
    $show_main = true;
    $page_title2 = str_replace( "_", " ", $_GET['Type'] )." ".$_GET['src_date']." ".$_GET['dst_date']." ";
    if ( !count( $arr_data_orders ) )
    {
        $Error[] = "There is not any ".ucfirst( $page_title2 )." Order";
    }
}
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."adm_buysell.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "adm_buysell.html";
    if ( $show_main )
    {
        if ( $perpage < $total )
        {
            $page->assign( "currencies_FNAME", $currencies_FNAME );
            $pg = $pager->page;
            $page_navigation .= $pager->getButPrev( $pg );
            $range = 20;
            $page_navigation .= $pager->getButList( $range );
            $page_navigation .= $pager->getButNext( $pg );
            $page_navigation .= "<br><br><br>";
            $page_navigation .= $pager->getRangeInfo( );
        }
        $page->assign( "page_navigation", $page_navigation );
        $page->assign( "total", $total );
    }
    else
    {
        $page->assign( "arr_currencies_ALL", $Allcurrencies );
        $page->assign( "STATUS_EXCHANGE", $STATUS_EXCHANGE );
        $page->assign( "Get", array(
            "Action" => $_GET['Action'],
            "oid" => $_GET['oid']
        ) );
    }
    if ( is_array( $arr_data_orders ) )
    {
        foreach ( $arr_data_orders as $key => $value )
        {
            if ( is_numeric( $arr_data_orders[$key]['cid'] ) )
            {
                $arr_data_orders[$key]['currency_name'] = $Allcurrencies[$arr_data_orders[$key]['cid']];
            }
            $arr_data_orders[$key]['order_detail'] = nl2br( $arr_data_orders[$key]['order_detail'] );
        }
    }
    $page->assign( "arr_data_orders", $arr_data_orders );
    $page->assign( "arr_CHOOSE", array( "1" => "Yes", "0" => "No" ) );
    $page->assign( "page_title2", $page_title2 );
    $page->assign( "show_main", $show_main );
    $page->assign( "Type", $_GET['Type'] );
    $page->assign( "write_order", $write_order );
    require( "include/engine_run.php" );
}
?>
