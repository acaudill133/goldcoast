<?php
ob_start();
session_start();
error_reporting(0);
include("../includes/config.php");
$db = new mysqli($CONF['host'], $CONF['user'], $CONF['pass'], $CONF['name']);
if ($db->connect_errno) {
    echo "Failed to connect to MySQL: (" . $db->connect_errno . ") " . $db->connect_error;
}
$db->set_charset("utf8");
$settingsQuery = $db->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
$settings = $settingsQuery->fetch_assoc();
include("../includes/functions.php");
include(getLanguage($settings['url'],null,2));
$send = protect($_GET['send']);
$receive = protect($_GET['receive']);
$amount = protect($_GET['amount']);
$currency = protect($_GET['currency']);
$receive_amount = protect($_GET['receive_amount']);
$account = protect($_GET['account']);
$email = protect($_GET['email']);
$query1 = $db->query("SELECT * FROM companies_list WHERE id='$send'");
$row1 = $query1->fetch_assoc();
$query2 = $db->query("SELECT * FROM companies_list_receive WHERE id='$receive' and cid='$send'");
$row2 = $query2->fetch_assoc();
$time = time();
$exchange_id = randomHash(4).'-'.randomHash(9).'-'.randomHash(3);
$exchange_rate = $row2['exchange_rate'];
$ip = $_SERVER['REMOTE_ADDR'];
if(checkSession()) { $uid = $_SESSION['suid']; } else { $uid = 0; }
if($_SESSION['refid']) { $refid = $_SESSION['refid']; } else { $refid = ''; }
if($row1['name'] == "PayPal") {
	$insert = $db->query("INSERT exchanges (c_send,c_receive,c_payee,a_send,a_receive,a_currency,a_rate,uid,ip,account,email,exchange_id,status,transaction_id,time,refid) VALUES ('$send','$receive','','$amount','$receive_amount','$currency','$exchange_rate','$uid','$ip','$account','$email','$exchange_id','1','','$time','$refid')");
	$getquery = $db->query("SELECT * FROM exchanges WHERE exchange_id='$exchange_id'");
	$get = $getquery->fetch_assoc();
	include("../includes/paypal_class.php");
	define('EMAIL_ADD', $row1['account']); // For system notification.
	define('PAYPAL_EMAIL_ADD', $row1['account']);

	// Setup class
	$p = new paypal_class( ); 				 // initiate an instance of the class.
	$p -> admin_mail = EMAIL_ADD; 
	$this_script = $settings['url']."index.php?a=check_payment&b=paypal";
	$p->add_field('business', PAYPAL_EMAIL_ADD); //don't need add this item. if your set the $p -> paypal_mail.
	$p->add_field('return', $this_script.'&action=success');
	$p->add_field('cancel_return', $this_script.'&action=cancel');
	$p->add_field('notify_url', $this_script.'&action=ipn');
	$p->add_field('item_name', 'Exchange '.$amount.' '.$currency);
	$p->add_field('item_number', $get['id']);
	$p->add_field('amount', $amount);
	$p->add_field('currency_code', $currency);
	$p->add_field('cmd', '_xclick');
	$p->add_field('rm', '2');	// Return method = POST
					 
	$p->submit_paypal_post(); // submit the fields to paypal
	$return = '<script type="text/javascript" src="'.$settings[url].'assets/js/jquery-1.9.1.js"></script>';
	$return .= '<script type="text/javascript">$(document).ready(function() { $("#paypal_form").submit(); });</script>';
	$return .= '<div class="alert alert-info"><i class="fa fa-spin fa-spinner"></i> '.$lang[processing].'</div>';
	echo $return;
} elseif($row1['name'] == "Skrill") {
	$insert = $db->query("INSERT exchanges (c_send,c_receive,c_payee,a_send,a_receive,a_currency,a_rate,uid,ip,account,email,exchange_id,status,transaction_id,time,refid) VALUES ('$send','$receive','','$amount','$receive_amount','$currency','$exchange_rate','$uid','$ip','$account','$email','$exchange_id','1','','$time','$refid')");
	$getquery = $db->query("SELECT * FROM exchanges WHERE exchange_id='$exchange_id'");
	$get = $getquery->fetch_assoc();
	$return = '<div style="display:none;"><form action="https://www.moneybookers.com/app/payment.pl" method="post" id="skrill_form">
					  <input type="hidden" name="pay_to_email" value="'.$row1[account].'"/>
					  <input type="hidden" name="status_url" value="'.$settings[url].'index.php?a=check_payment&b=skrill"/> 
					  <input type="hidden" name="language" value="EN"/>
					  <input type="hidden" name="amount" value="'.$amount.'"/>
					  <input type="hidden" name="currency" value="'.$currency.'"/>
					  <input type="hidden" name="detail1_description" value="Exchange '.$amount.' '.$currency.'"/>
					  <input type="hidden" name="detail1_text" value="'.$get[id].'"/>
					  <input type="submit" class="btn btn-primary" value="Click to pay."/>
					</form></div>';
	$return .= '<script type="text/javascript" src="'.$settings[url].'assets/js/jquery-1.9.1.js"></script>';
	$return .= '<script type="text/javascript">$(document).ready(function() { $("#skrill_form").submit(); });</script>';
	$return .= '<div class="alert alert-info"><i class="fa fa-spin fa-spinner"></i> '.$lang[processing].'</div>';
	echo $return;
} elseif($row1['name'] == "WebMoney") {
	include("../includes/webmoney.inc.php");
	$insert = $db->query("INSERT exchanges (c_send,c_receive,c_payee,a_send,a_receive,a_currency,a_rate,uid,ip,account,email,exchange_id,status,transaction_id,time,refid) VALUES ('$send','$receive','','$amount','$receive_amount','$currency','$exchange_rate','$uid','$ip','$account','$email','$exchange_id','1','','$time','$refid')");
	$getquery = $db->query("SELECT * FROM exchanges WHERE exchange_id='$exchange_id'");
	$get = $getquery->fetch_assoc();
	$paymentno = intval($get['id']);
	$wm_request = new WM_Request();
	  $wm_request->payment_amount = $amount;
	  $wm_request->payment_desc = 'Exchange '.$amount.' '.$currency;
	  $wm_request->payment_no = $paymentno;
	  $wm_request->payee_purse = $row1['account'];
	  $wm_request->sim_mode = WM_ALL_SUCCESS;
	  $wm_request->result_url = $settings['url']."index.php?a=check_payment&b=webmoney&c=result";
	  $wm_request->success_url = $settings['url']."index.php?a=check_payment&b=webmoney&c=success";
	  $wm_request->success_method = WM_POST;
	  $wm_request->fail_url = $settings['url']."index.php?a=check_payment&b=webmoney&c=fail";
	  $wm_request->fail_method = WM_POST;
	  $wm_request->extra_fields = array('FIELD1'=>'VALUE 1', 'FIELD2'=>'VALUE 2');
	  $wm_action = 'https://merchant.wmtransfer.com/lmi/payment.asp';
	  $wm_btn_label = 'Pay Webmoney';
	  $wm_request->SetForm();
	  	$return .= '<script type="text/javascript" src="'.$settings[url].'assets/js/jquery-1.9.1.js"></script>';
	$return .= '<script type="text/javascript">$(document).ready(function() { $("#webmoney_form").submit(); });</script>';
	$return .= '<div class="alert alert-info"><i class="fa fa-spin fa-spinner"></i> '.$lang[processing].'</div>';
	echo $return;
} elseif($row1['name'] == "Payeer") {
	$insert = $db->query("INSERT exchanges (c_send,c_receive,c_payee,a_send,a_receive,a_currency,a_rate,uid,ip,account,email,exchange_id,status,transaction_id,time,refid) VALUES ('$send','$receive','','$amount','$receive_amount','$currency','$exchange_rate','$uid','$ip','$account','$email','$exchange_id','1','','$time','$refid')");
	$getquery = $db->query("SELECT * FROM exchanges WHERE exchange_id='$exchange_id'");
	$get = $getquery->fetch_assoc();
	$m_shop = $row1['account'];
	$m_orderid = $get['id'];
	$m_amount = number_format($amount, 2, '.', '');
	$m_curr = $currency;
	$desc = 'Exchange '.$amount.' '.$currency;
	$m_desc = base64_encode($desc);
	$m_key = $row1['a_field_1'];

	$arHash = array(
		$m_shop,
		$m_orderid,
		$m_amount,
		$m_curr,
		$m_desc,
		$m_key
	);
	$sign = strtoupper(hash('sha256', implode(':', $arHash)));
	$return = '<div style="display:none;"><form method="GET" id="payeer_form" action="https://payeer.com/merchant/">
	<input type="hidden" name="m_shop" value="'.$m_shop.'">
	<input type="hidden" name="m_orderid" value="'.$m_orderid.'">
	<input type="hidden" name="m_amount" value="'.$m_amount.'">
	<input type="hidden" name="m_curr" value="'.$m_curr.'">
	<input type="hidden" name="m_desc" value="'.$m_desc.'">
	<input type="hidden" name="m_sign" value="'.$sign.'">
	<!--
	<input type="hidden" name="form[ps]" value="2609">
	<input type="hidden" name="form[curr[2609]]" value="USD">
	-->
	<input type="submit" name="m_process" value="Pay with Payeer" />
	</form></div>';
	$return .= '<script type="text/javascript" src="'.$settings[url].'assets/js/jquery-1.9.1.js"></script>';
	$return .= '<script type="text/javascript">$(document).ready(function() { $("#payeer_form").submit(); });</script>';
	$return .= '<div class="alert alert-info"><i class="fa fa-spin fa-spinner"></i> '.$lang[processing].'</div>';
	echo $return;
} elseif($row1['name'] == "Perfect Money") {
	$insert = $db->query("INSERT exchanges (c_send,c_receive,c_payee,a_send,a_receive,a_currency,a_rate,uid,ip,account,email,exchange_id,status,transaction_id,time,refid) VALUES ('$send','$receive','','$amount','$receive_amount','$currency','$exchange_rate','$uid','$ip','$account','$email','$exchange_id','1','','$time','$refid')");
	$getquery = $db->query("SELECT * FROM exchanges WHERE exchange_id='$exchange_id'");
	$get = $getquery->fetch_assoc();
	$return = '<div style="display:none;">
				<form action="https://perfectmoney.is/api/step1.asp" id="pm_form" method="POST">
					<input type="hidden" name="PAYEE_ACCOUNT" value="'.$row1[account].'">
					<input type="hidden" name="PAYEE_NAME" value="'.$settings[sitename].'">
					<input type="hidden" name="PAYMENT_ID" value="'.$get[id].'">
					<input type="text"   name="PAYMENT_AMOUNT" value="'.$amount.'"><BR>
					<input type="hidden" name="PAYMENT_UNITS" value="'.$currency.'">
					<input type="hidden" name="STATUS_URL" value="'.$settings[url].'index.php?a=check_payment&b=perfectmoney&b=status">
					<input type="hidden" name="PAYMENT_URL" value="'.$settings[url].'index.php?a=check_payment&b=perfectmoney&b=complete">
					<input type="hidden" name="PAYMENT_URL_METHOD" value="POST">
					<input type="hidden" name="NOPAYMENT_URL" value="'.$settings[url].'index.php?a=check_payment&b=perfectmoney&b=failed">
					<input type="hidden" name="NOPAYMENT_URL_METHOD" value="POST">
					<input type="hidden" name="SUGGESTED_MEMO" value="">
					<input type="hidden" name="BAGGAGE_FIELDS" value="IDENT"><br>
					<input type="submit" name="PAYMENT_METHOD" value="Pay Now!" class="tabeladugme"><br><br>
					</form></div>';
	$return .= '<script type="text/javascript" src="'.$settings[url].'assets/js/jquery-1.9.1.js"></script>';
	$return .= '<script type="text/javascript">$(document).ready(function() { $("#pm_form").submit(); });</script>';
	$return .= '<div class="alert alert-info"><i class="fa fa-spin fa-spinner"></i> '.$lang[processing].'</div>';
	echo $return;
} elseif($row1['name'] == "AdvCash") {
	$insert = $db->query("INSERT exchanges (c_send,c_receive,c_payee,a_send,a_receive,a_currency,a_rate,uid,ip,account,email,exchange_id,status,transaction_id,time,refid) VALUES ('$send','$receive','','$amount','$receive_amount','$currency','$exchange_rate','$uid','$ip','$account','$email','$exchange_id','1','','$time','$refid')");
	$getquery = $db->query("SELECT * FROM exchanges WHERE exchange_id='$exchange_id'");
	$get = $getquery->fetch_assoc();
	$arHash = array(
		$row1[account],
		$settings[sitename],
		$amount,
		$currency,
		$row1[a_field_1],
		$get[id]
	);
	$sign = strtoupper(hash('sha256', implode(':', $arHash)));
	$return = '<div style="display:none;">
				<form method="GET" id="advcash_form" action="https://wallet.advcash.com/sci/">
				<input type="hidden" name="ac_account_email" value="'.$row1[account].'">
				<input type="hidden" name="ac_sci_name" value="'.$settings[sitename].'">
				<input type="hidden" name="ac_amount" value="'.$amount.'">
				<input type="hidden" name="ac_currency" value="'.$currency.'">
				<input type="hidden" name="ac_order_id" value="'.$get[id].'">
				<input type="hidden" name="ac_sign"
				value="'.$sign.'">
				<input type="hidden" name="ac_success_url" value="'.$settings[url].'index.php?a=check_payment&b=advcash&b=success" />
				 <input type="hidden" name="ac_success_url_method" value="GET" />
				 <input type="hidden" name="ac_fail_url" value="'.$settings[url].'index.php?a=check_payment&b=advcash&b=fail" />
				 <input type="hidden" name="ac_fail_url_method" value="GET" />
				 <input type="hidden" name="ac_status_url" value="'.$settings[url].'index.php?a=check_payment&b=advcash&b=status" />
				 <input type="hidden" name="ac_status_url_method" value="GET" />
				<input type="hidden" name="ac_comments" value="Exchange '.$amount.' '.$currency.'">
				</form>
				</div>';
	$return .= '<script type="text/javascript" src="'.$settings[url].'assets/js/jquery-1.9.1.js"></script>';
	$return .= '<script type="text/javascript">$(document).ready(function() { $("#advcash_form").submit(); });</script>';
	$return .= '<div class="alert alert-info"><i class="fa fa-spin fa-spinner"></i> '.$lang[processing].'</div>';
	echo $return;
} elseif($row1['name'] == "OKPay") {
	$insert = $db->query("INSERT exchanges (c_send,c_receive,c_payee,a_send,a_receive,a_currency,a_rate,uid,ip,account,email,exchange_id,status,transaction_id,time,refid) VALUES ('$send','$receive','','$amount','$receive_amount','$currency','$exchange_rate','$uid','$ip','$account','$email','$exchange_id','1','','$time','$refid')");
	$getquery = $db->query("SELECT * FROM exchanges WHERE exchange_id='$exchange_id'");
	$get = $getquery->fetch_assoc();
	$return = '<form  method="post" id="okpay_form" action="https://checkout.okpay.com/">
				   <input type="hidden" name="ok_receiver" value="'.$row1[account].'"/>
				   <input type="hidden" name="ok_item_1_name" value="Exchange '.$amount.' '.$currency.'"/>
				   <input type="hidden" name="ok_item_1_price" value="'.$amount.'"/>
				   <input type="hidden" name="ok_item_1_id" value="'.$get[id].'"/>
				   <input type="hidden" name="ok_currency" value="'.$currency.'"/>
				   <input type="image" name="submit" alt="OKPAY Payment" src="https://www.okpay.com/img/buttons/x02.gif"/>
				</form>';
	$return .= '<script type="text/javascript" src="'.$settings[url].'assets/js/jquery-1.9.1.js"></script>';
	$return .= '<script type="text/javascript">$(document).ready(function() { $("#okpay_form").submit(); });</script>';
	$return .= '<div class="alert alert-info"><i class="fa fa-spin fa-spinner"></i> '.$lang[processing].'</div>';
	echo $return;
} else {
	echo error($lang['error_42']);
}
?>