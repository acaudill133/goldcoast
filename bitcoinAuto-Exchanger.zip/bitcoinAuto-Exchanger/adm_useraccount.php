<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function last_key( $t )
{
    if ( !$t )
    {
        return "d.email";
    }
    return "l.exchange";
}

function last_value( $t )
{
    global $line;
    if ( !$t )
    {
        return 0;
    }
    return $line[amt];
}

function choice_summary( $title )
{
    global $t;
    if ( !$t )
    {
        $t = 0;
    }
    return "<input type='radio' name='t' value='{$title}' class='nostyle' ".show_input_checked( $i, $t )." onclick=\"submit();\" ".( $_POST['t'] == $title ? "checked='checked'" : "" )." >".ucfirst( $title );
}

require( "public.inc.php" );
if ( !session_admin( ) )
{
    @header( "Location: ".$CONFIG['SITE_URL'] );
}
$show_main = true;
if ( $_GET['act'] == "status" && $_GET['uid'] && !$demo_mode )
{
    $status_old = db_get_id( "select status from {$_users} where uid='{$_GET['uid']}'" );
    if ( $status_old == $STATUS_ENUM_DISABLE )
    {
        $status_new = $STATUS_ENUM_ENABLE;
    }
    else if ( $status_old == $STATUS_ENUM_ENABLE )
    {
        $status_new = $STATUS_ENUM_LOCKED;
    }
    else if ( $status_old == $STATUS_ENUM_LOCKED )
    {
        $status_new = $STATUS_ENUM_DISABLE;
    }
    if ( db_exec( "update {$_users} set status='{$status_new}' where status='{$status_old}' and uid='{$_GET['uid']}'" ) )
    {
        $Success[] = "User status successfully changed to: ".convert_status( $status_new );
    }
}
if ( $_GET['act'] == "status" && $_GET['uid'] && $demo_mode )
{
    $Error_div[] = "Some features are not active in Demo Version.";
}
$t = $_REQUEST['t'];
$tables = "{$_users} u";
$key = $_GET['key'];
$order = $_GET['order'];
if ( !$order )
{
    $order = "ASC";
}
if ( !$key )
{
    $key = "d.reg_date";
}
$key = $key." ".$order;
if ( $order == "Desc" )
{
    $write_order = "Asc";
}
else
{
    $write_order = "Desc";
}
if ( $_POST['submit'] == "Update" && $_GET['uid'] )
{
    $count = 0;
    $total_fields = count( $_POST );
    foreach ( $_POST as $key => $value )
    {
        if ( $count < $total_fields - 2 )
        {
            $SQL .= "{$key}='{$value}' , ";
        }
        else if ( $key != "submit" && $key != "submit" )
        {
            $SQL .= "{$key}='{$value}' WHERE uid='{$_GET['uid']}'";
        }
        ++$count;
    }
    if ( db_exec( "UPDATE {$_users_details} SET {$SQL}" ) )
    {
        $Success[] = "Member (#) updated successfully.";
    }
    $show_main = false;
    $key = "d.reg_date";
}
if ( !$_GET['act'] && $_GET['uid'] )
{
    $show_main = false;
}
$query_fields = "u.uid,u.login,u.status,date_format(d.reg_date,'%Y-%m-%d') as day,u.ip,d.Country_short,d.fullname,d.click_counter";
$query_where = "d.uid=u.uid and u.permit='{$PMT_INFO_MEMBER}'";
if ( $_POST['fld_search'] )
{
    $query_where = "";
    $fld_search = $_POST['fld_search'];
    $query_where .= "(u.login LIKE '%{$fld_search}%' OR d.fullname LIKE '%{$fld_search}%' OR d.email LIKE '%{$fld_search}%' OR u.uid = '%{$fld_search}%' OR u.ip LIKE '%{$fld_search}%')";
    $Success[] = "Your search results for: '<u>".$_POST['fld_search']."</u>', between: fullnames, emails, user ids, login ids and ips";
}
if ( $_GET['uid'] && $_GET['act'] != "status" )
{
    $query_where = "";
    $uid = $_GET['uid'];
    $query_where .= "u.uid = '{$uid}'";
    $query_fields = "u.*, d.*";
}
if ( $t && $t != "list" )
{
    $tables .= ", {$_lines} l";
    $query_fields .= ",d.money_account , sum(l.exchange) as amt, d.cid";
    $query_where .= " and l.uid=u.uid and l.date<'now()'";
    if ( $t == "balance" )
    {
        $query_where .= " and l.pmt_type='{$TRANS_ENUM_BANK}' and l.status='{$STATUS_ENUM_ENABLE}'";
    }
    else if ( $t == "spend" )
    {
        $query_where .= " and l.pmt_type='{$TRANS_ENUM_SPEND}' and l.status='{$STATUS_ENUM_ENABLE}'";
    }
    else if ( $t == "earn" )
    {
        $query_where .= " and l.pmt_type='{$TRANS_ENUM_EARNBANK}' and l.status='{$STATUS_ENUM_ENABLE}' and l.amount<>'0'";
    }
    else if ( $t == "comission" )
    {
        $query_where .= " and l.pmt_type='{$TRANS_ENUM_COMMISSION}' and l.status='{$STATUS_ENUM_ENABLE}'";
    }
    else if ( $t == "bonus" )
    {
        $query_where .= " and l.pmt_type='{$TRANS_ENUM_BONUS}' and l.status='{$Var_6192}'";
    }
    else if ( $t == "pending" )
    {
        $query_where .= " and l.pmt_type='{$TRANS_ENUM_WITHDRAW}' and l.status='{$STATUS_ENUM_DISABLE}'";
    }
    else if ( $t == "withdraw" )
    {
        $query_where .= " and l.pmt_type='{$TRANS_ENUM_WITHDRAW}' and l.status='{$STATUS_ENUM_ENABLE}'";
    }
}
else
{
    $query_fields .= ", d.email";
}
$no = 0;
$sum = 0;
$query = "SELECT {$query_fields} FROM ({$tables}) INNER JOIN {$_users_details} d ON u.uid = d.uid WHERE {$query_where} GROUP BY u.uid ORDER BY {$key} ";
$page = $_GET['page'];
$total = mysql_num_rows( mysql_query( $query ) );
$perpage = $CONFIG['recordsnumperpage'];
$url_string = get_link( $cur_page.( $CONFIG['FRIENDLY_URL'] ? "" : "?" ).preg_replace( "/(&)page(\\/^|=)\\d+/", "", $_SERVER['QUERY_STRING'] ) );
$pager = new pager( $total, $perpage, $url_string, $CONFIG['FRIENDLY_URL'] );
if ( empty( $page ) )
{
    $page = 1;
}
$from = $pager->getPageFrom( $page );
$query = $query." limit {$from}, {$perpage}";
$result = db_query( $query, "&nbsp;" );
$arr_data_users = mysql_push_data( $result );
db_free_result( $result );
if ( !count( $arr_data_users ) )
{
    $Error[] = "There is not any Member in {$t} view";
}
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."adm_useraccount.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "adm_useraccount.html";
    $page->assign( "write_order", $write_order );
    $page->assign( "total", $total );
    $page->assign( "t", $t );
    if ( $perpage < $total )
    {
        $pg = $pager->page;
        $page_navigation .= $pager->getButPrev( $pg );
        $range = 20;
        $page_navigation .= $pager->getButList( $range );
        $page_navigation .= $pager->getButNext( $pg );
        $page_navigation .= "<br><br><br>";
        $page_navigation .= $pager->getRangeInfo( );
    }
    $page->assign( "page_navigation", $page_navigation );
    $page->assign( "choice_list", choice_summary( "list" ) );
    $page->assign( "choice_balance", choice_summary( "balance" ) );
    $page->assign( "choice_comission", choice_summary( "comission" ) );
    $multi_key = "&key=".( !$t || $t == "list" ? "d.email" : "l.exchange" );
    $multi_row = !$t || $t == "list" ? "Mail" : "Amount";
    $page->assign( "multi_row", $multi_row );
    $page->assign( "multi_key", $multi_key );
    foreach ( $arr_data_users as $key => $value )
    {
        if ( !$t || $t == "list" )
        {
            $amount = "<a href=".get_link( "adm_massemail.php?searchmem=".$arr_data_users[$key]['email'] ).">".$arr_data_users[$key]['email']."</a>";
        }
        else if ( $t == "balance" )
        {
            $amount = FormatPrice( $Var_11616[amt], 2 );
            $amount = "<a href=".get_link( "balance.php?id=".$arr_data_users[$key]['uid'] ).">{$amount}</a>";
        }
        else
        {
            $amount = FormatPrice( $arr_data_users[amt], 2 );
        }
        $arr_data_users[$key]['amount'] = $amount;
        $page_sum = $page_sum + $arr_data_users[$key]['exchange'];
        $arr_data_users[$key]['status'] = convert_status( $arr_data_users[$key]['status'] );
    }
    $page->assign( "arr_data_users", $arr_data_users );
    $page->assign( "show_main", $show_main );
    if ( !$show_main )
    {
        $query = "select countries_iso, countries_name from {$_countries}";
        $result = db_query( $query, "&nbsp;" );
        $arr_data_country = mysql_push_data( $result );
        db_free_result( $result );
        foreach ( $arr_data_country as $key => $value )
        {
            $arr_countries[$arr_data_country[$key]['countries_iso']] = $arr_data_country[$key]['countries_name'];
        }
        $page->assign( "arr_countries", $arr_countries );
        $page->assign( "arr_currencies_ALL", $Allcurrencies );
    }
    require( "include/engine_run.php" );
}
?>
