<?php
  				// read the post from PayPal system and add 'cmd'
				$req = 'cmd=_notify-validate';

				foreach ($_POST as $key => $value) {
				$value = urlencode(stripslashes($value));
				$req .= "&$key=$value";
				}

				// post back to PayPal system to validate
				$header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
				$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
				$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
				$fp = fsockopen ('ssl://www.paypal.com', 443, $errno, $errstr, 30);

				// assign posted variables to local variables
				$item_name = $_POST['item_name'];
				$item_number = $_POST['item_number'];
				$payment_status = $_POST['payment_status'];
				$payment_amount = $_POST['mc_gross'];
				$payment_currency = $_POST['mc_currency'];
				$txn_id = $_POST['txn_id'];
				$receiver_email = $_POST['receiver_email'];
				$payer_email = $_POST['payer_email'];
				$query = $db->query("SELECT * FROM exchanges WHERE id='$item_number'");
				if($query->num_rows==0) { header("Location: $settings[url]"); }
				$row = $query->fetch_assoc();
				$query1 = $db->query("SELECT * FROM companies_list WHERE id='$row[c_send]'");
				$row1 = $query1->fetch_assoc();
				$date = date("d/m/Y H:i:s");
				if(checkSession()) { $uid = $_SESSION['suid']; } else { $uid = 0; }
				$check_trans = $db->query("SELECT * FROM transactions WHERE tid='$txn_id' and date='$date' and uid='$uid'");
				if (!$fp) {
				// HTTP ERROR
				} else {
				fputs ($fp, $header . $req);
				while (!feof($fp)) {
				$res = fgets ($fp, 1024);
				if (strcmp ($res, "VERIFIED") == 0) {

					if ($payment_status == 'Completed') {


							if ($receiver_email==$row1['account']) {

								if ($payment_amount == $row['a_send'] && $payment_currency == $row['a_currency']) {
									if($check_trans->num_rows>0) {
										echo error($lang['error_15']);
									} else {
										$insert = $db->query("INSERT transactions (tid,from,uid,in,amount,currency,date) VALUES ('$txn_id','$payer_email','$uid','PayPal','$payment_amount','$payment_currency','$date')");
										$update = $db->query("UPDATE exchanges SET status='2' WHERE id='$row[id]'");
										echo success($lang['success_4']);
									}
								} else {
									echo error($lang['error_16']);
								}

							} else {
								echo error($lang['error_17']);
							}

					}

				}

				else if (strcmp ($res, "INVALID") == 0) {
					echo error($lang['error_20']);
				}
				}
				fclose ($fp);
				}  
?>