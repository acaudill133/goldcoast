<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

echo "\t\t<input type=\"hidden\" name=\"ATIP_STATUS_URL_METHOD\" value=\"POST\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_STATUS_URL\" value=\"";
echo $status_url;
echo "\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_BAGGAGE_FIELDS\" value=\"paymentid\">\r\n\t\t<input type=\"hidden\" name=\"paymentid\" value=\"";
echo $payment_id;
echo "\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_PAYMENT_UNIT\" value=\"";
echo $arr_PAYMENT['WORTH_VALUE'];
echo "\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_PAYMENT_METAL\" value=\"";
echo $arr_PAYMENT['METAL_VALUE'];
echo "\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_SUGGESTED_MEMO\" value=\"";
echo $suggested_memo;
echo "\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_FORCED_PAYER_ACCOUNT\" value=\"\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_PAYER_FEE_AMOUNT\" value=\"\">\r\n\t\t\r\n";
if ( $amount == "ask" )
{
    echo "    Amount you want to pay: <INPUT type='text' name=\"ATIP_PAYMENT_AMOUNT\">\r\n";
}
else
{
    echo "    <input type=\"hidden\" name=\"ATIP_PAYMENT_AMOUNT\" value=\"";
    echo $amount;
    echo "\">\r\n";
}
echo "\t\t<input type=\"hidden\" name=\"ATIP_PAYMENT_URL\" value=\"";
echo $response_ok;
echo "\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_PAYMENT_URL_METHOD\" value=\"POST\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_NOPAYMENT_URL\" value=\"";
echo $response_no;
echo "\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_NOPAYMENT_URL_METHOD\" value=\"POST\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_PAYMENT_FIXED\" value=\"1\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_PAYEE_ACCOUNT\" value=\"";
echo $payee_account;
echo "\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_PAYEE_NAME\" value=\"";
echo $user;
echo "\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_BUTTON\" value=\"0\">";
?>
