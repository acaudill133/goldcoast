<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

class QuickSkinDebugger
{

    public $filename = NULL;
    public $template = NULL;
    public $left_delimiter = "{";
    public $right_delimiter = "}";

    public function QuickSkinDebugger( $template_filename, $right_delimiter = "}", $left_delimiter = "{" )
    {
        $this->filename = $template_filename;
        if ( $hd = @fopen( $template_filename, "r" ) )
        {
            $this->template = fread( $hd, filesize( $template_filename ) );
            fclose( $hd );
        }
        else
        {
            $this->template = "QuickSkin Debugger Error: File not found: ".$template_filename;
        }
        $this->tab[0] = "";
        $i = 1;
        while ( $i < 10 )
        {
            $this->tab[$i] = str_repeat( "    ", $i );
            ++$i;
        }
        $this->right_delimiter = $right_delimiter;
        $this->left_delimiter = $left_delimiter;
    }

    public function start( $vars )
    {
        $page = $this->template;
        $page = preg_replace( "/(<!-- BEGIN [ a-zA-Z0-9_.]* -->)/", "\n\$1\n", $page );
        $page = preg_replace( "/(<!-- IF .+? -->)/", "\n\$1\n", $page );
        $page = preg_replace( "/(<!-- END.*? -->)/", "\n\$1\n", $page );
        $page = preg_replace( "/(<!-- ELSEIF .+? -->)/", "\n\$1\n", $page );
        $page = preg_replace( "/(<!-- ELSE [ a-zA-Z0-9_.]*-->)/", "\n\$1\n", $page );
        $page = $this->highlight_html( $page );
        $rows = explode( "\n", $page );
        $page_arr = array( );
        $level = 0;
        $blocklvl = 0;
        $rowcnt = 0;
        $spancnt = 0;
        $offset = 22;
        $lvl_block = array( );
        $lvl_row = array( );
        $lvl_typ = array( );
        foreach ( $rows as $row )
        {
            if ( $row = trim( $row ) )
            {
                $closespan = false;
                if ( substr( $row, $offset, 12 ) == "&lt;!-- END " )
                {
                    if ( $level < 1 )
                    {
                        ++$level;
                        $error[$rowcnt] = "END Without BEGIN";
                    }
                    else if ( $lvl_typ[$level] != "BEGIN" )
                    {
                        $error[$lvl_row[$level]] = "IF without ENDIF";
                        $error[$rowcnt] = "END Without BEGIN";
                    }
                    --$blocklvl;
                    --$level;
                    $closespan = true;
                }
                if ( substr( $row, $offset, 14 ) == "&lt;!-- ENDIF " )
                {
                    if ( $level < 1 )
                    {
                        ++$level;
                        $error[$rowcnt] = "ENDIF Without IF";
                    }
                    else if ( $lvl_typ[$level] != "IF" )
                    {
                        $error[$lvl_row[$level]] = "BEGIN without END";
                        $error[$rowcnt] = "ENDIF Without IF";
                    }
                    $closespan = true;
                    --$level;
                }
                if ( $closespan )
                {
                    $page_arr[$rowcnt - 1] .= "</span>";
                }
                $this_row = $this->tab[$level].$Var_3528;
                if ( substr( $row, $offset, 12 ) == "&lt;!-- ELSE" )
                {
                    if ( $level < 1 )
                    {
                        $error[$rowcnt] = "ELSE Without IF";
                    }
                    else if ( $lvl_typ[$level] != "IF" )
                    {
                        $error[$rowcnt] = "ELSE Without IF";
                    }
                    else
                    {
                        $this_row = $this->tab[$level - 1].$row;
                    }
                }
                if ( substr( $row, $offset, 14 ) == "&lt;!-- BEGIN " )
                {
                    if ( $blocklvl == 0 )
                    {
                        if ( ( $lp = strpos( $row, "--&gt;" ) ) && ( $blockname = trim( substr( $row, $offset + 14, $lp - $offset - 14 ) ) ) )
                        {
                            if ( $nr = count( $vars[$blockname] ) )
                            {
                                $this_row .= $this->toggleview( $nr." Entries" );
                            }
                            else
                            {
                                $this_row .= $this->toggleview( "Emtpy" );
                            }
                        }
                    }
                    else
                    {
                        $this_row .= $this->toggleview( "[" );
                    }
                    ++$blocklvl;
                    ++$level;
                    $lvl_row[$level] = $rowcnt;
                    $lvl_typ[$level] = "BEGIN";
                }
                else if ( substr( $row, $offset, 11 ) == "&lt;!-- IF " )
                {
                    ++$level;
                    $lvl_row[$level] = $rowcnt;
                    $lvl_typ[$level] = "IF";
                    $this_row .= $this->toggleview( );
                }
                $page_arr[] = $this_row;
                $lvl_block[$rowcnt] = $blocklvl;
                ++$rowcnt;
            }
        }
        if ( 0 < $level )
        {
            $error[$lvl_row[$level]] = "Block not closed";
        }
        $page = join( "\n", $page_arr );
        $rows = explode( "\n", $page );
        $cnt = count( $rows );
        $i = 0;
        while ( $i < $cnt )
        {
            if ( isset( $error ) && ( $err = $error[$i] ) )
            {
                $rows[$i] = "<b>".$rows[$i]."        ERROR: ".$err."!</b>";
            }
            $right_delimiter = preg_quote( $this->right_delimiter );
            $left_delimiter = preg_quote( $this->left_delimiter );
            if ( preg_match_all( "/{$left_delimiter}([a-zA-Z0-9_. &;]+){$right_delimiter}/", $rows[$i], $var ) )
            {
                foreach ( $var[1] as $tag )
                {
                    $fulltag = $tag;
                    if ( $delim = strpos( $tag, " &gt; " ) )
                    {
                        $tag = substr( $tag, 0, $delim );
                    }
                    if ( substr( $tag, 0, 4 ) == "top." )
                    {
                        $title = $this->tip( $vars[substr( $tag, 4 )] );
                    }
                    else if ( $lvl_block[$i] == 0 )
                    {
                        $title = $this->tip( $vars[$tag] );
                    }
                    else
                    {
                        $title = "[BLOCK?]";
                    }
                    $code = "<b title=\"".$title."\">".$left_delimiter.$fulltag.$right_delimiter."</b>";
                    $rows[$i] = str_replace( "{".$fulltag."}", $code, $rows[$i] );
                }
            }
            foreach ( $var[2] as $tmpcnt => $tag )
            {
                $fulltag = $tag;
                if ( $delim = strpos( $tag, " &gt; " ) )
                {
                    $tag = substr( $tag, 0, $delim );
                }
                if ( strpos( $tag, "," ) )
                {
                    list( $tag, $addparam ) = tag  ;              }
                $extension = $var[1][$tmpcnt];
                if ( substr( $tag, 0, 4 ) == "top." )
                {
                    $title = $this->tip( $vars[substr( $tag, 4 )] );
                }
                else if ( $lvl_block[$i] == 0 )
                {
                    $title = $this->tip( $vars[$tag] );
                }
                else
                {
                    $title = "[BLOCK?]";
                }
                $code = "<b title=\"".$title."\">".$this->left_delimiter.$extension.":".$fulltag.$this->right_delimiter."</b>";
                $rows[$i] = str_replace( $this->left_delimiter.$extension.":".$fulltag.$this->right_delimiter, $code, $rows[$i] );
            }
        }
        if ( preg_match_all( "/&lt;!-- IF ([a-zA-Z0-9_.]+) --&gt;/", $rows[$i], $var ) )
        {
            foreach ( $var[1] as $tag )
            {
                if ( substr( $tag, 0, 4 ) == "top." )
                {
                    $title = $this->tip( $vars[substr( $tag, 4 )] );
                }
                else if ( $lvl_block[$i] == 0 )
                {
                    $title = $this->tip( $vars[$tag] );
                }
                else
                {
                    $title = "[BLOCK?]";
                }
                $code = "<span title=\"".$title."\">&lt;!-- IF ".$tag." --&gt;</span>";
                $rows[$i] = str_replace( "&lt;!-- IF {$tag} --&gt;", $code, $rows[$i] );
                if ( $title == "[NULL]" )
                {
                    $rows[$i] = $Var_13272;
                    $rows[$i] = str_replace( "block", "none", $rows[$i] );
                }
            }
        }
        ++$i;
    #}
    $page = join( "<br>", $rows );
    echo "<html><head><script type=\"text/javascript\">\r\n        function toggleVisibility(el, src) {\r\n        var v = el.style.display == \"block\";\r\n        var str = src.innerHTML;\r\n        el.style.display = v ? \"none\" : \"block\";\r\n        src.innerHTML = v ? str.replace(/Hide/, \"Show\") : str.replace(/Show/, \"Hide\");}\r\n        </script></head><body>";
    echo "<font face=\"Arial\" Size=\"3\"><b>";
    echo "QuickSkin Debugger<br>";
    echo "<font size=\"2\"><li>PHP-Script: ".$_SERVER['SCRIPT_FILENAME']."</li><li>Template: ".$this->filename."</li></font><hr>";
    echo "<li><a href=\"#template_code\">Template</a></li>";
    echo "<li><a href=\"#compiled_code\">Compiled Template</a></li>";
    echo "<li><a href=\"#data_code\">Data</a></li>";
    echo "</b></font><hr>";
    echo "<a name=\"template_code\"><br><font face=\"Arial\" Size=\"3\"><b>Template:</b>&nbsp;[<a href=\"javascript:void('');\" onclick=\"toggleVisibility(document.getElementById('Template'), this); return false\">Hide Ouptut</a>]</font><br>";
    echo "<table border=\"0\" cellpadding=\"4\" cellspacing=\"1\" width=\"100%\" bgcolor=\"#C6D3EF\"><tr><td bgcolor=\"#F0F0F0\"><pre id=\"Template\" style=\"display:block\">";
    echo $page;
    echo "</pre></td></tr></table>";
    str_replace( $this->filename );
    $parser = new QuickSkinParser( );
    $compiled = $parser->compile( );
    echo "<a name=\"compiled_code\"><br><br><font face=\"Arial\" Size=\"3\"><b>Compiled Template:</b>&nbsp;[<a href=\"javascript:void('');\" onclick=\"toggleVisibility(document.getElementById('Compiled'), this); return false\">Hide Ouptut</a>]</font><br>";
    echo "<table border=\"0\" cellpadding=\"4\" cellspacing=\"1\" width=\"100%\" bgcolor=\"#C6D3EF\"><tr><td bgcolor=\"#F0F0F0\"><pre id=\"Compiled\" style=\"display:block\">";
    highlight_string( $compiled );
    echo "</pre></td></tr></table>";
    echo "<a name=\"data_code\"><br><br><font face=\"Arial\" Size=\"3\"><b>Data:</b>&nbsp;[<a href=\"javascript:void('');\" onclick=\"toggleVisibility(document.getElementById('Data'), this); return false\">Hide Ouptut</a>]</font><br>";
    echo "<table border=\"0\" cellpadding=\"4\" cellspacing=\"1\" width=\"100%\" bgcolor=\"#C6D3EF\"><tr><td bgcolor=\"#F0F0F0\"><pre id=\"Data\" style=\"display:block\">";
    echo $this->vardump( $vars );
    echo "</pre></td></tr></table></body></html>";
}

    public function toggleview( $suffix = "" )
    {
        global $spancnt;
        ++$spancnt;
        if ( $suffix )
        {
            $suffix .= ":";
        }
        $ret = "[".$suffix."<a href=\"javascript:void('');\" onclick=\"toggleVisibility(document.getElementById('Block".$spancnt."'), this); return false\">Hide Block</a>]<span id=\"Block".$spancnt."\" style=\"display:block\">";
        return $ret;
    }

    public function tip( $value )
    {
        if ( empty( $value ) )
        {
            return "[NULL]";
        }
        $ret = htmlentities( substr( $value, 0, 200 ) );
        return $ret;
    }

    public function vardump( $var, $depth = 0 )
    {
        if ( is_array( $var ) )
        {
            $result = "Array (".count( $var ).")<BR>";
            foreach ( array_keys( $var ) as $key )
            {
                $result .= $this->tab[$depth]."<B>{$key}</B>: ".$this->vardump( $var[$key], $depth + 1 );
            }
            return $result;
        }
        $ret = htmlentities( $var )."<BR>";
        return $ret;
    }

    public function var_name( $tag )
    {
        $parent_level = 0;
        while ( substr( $tag, 0, 7 ) == "parent." )
        {
            $tag = substr( $tag, 7 );
            ++$parent_level;
        }
        if ( substr( $tag, 0, 4 ) == "top." )
        {
            $ret = array(
                "_stack[0]",
                substr( $tag, 4 )
            );
            return $ret;
        }
        if ( $parent_level )
        {
            $ret = array(
                "_stack[\$_stack_cnt-".$parent_level."]",
                $tag
            );
            return $ret;
        }
        $ret = array(
            "_obj",
            $tag
        );
        return $ret;
    }

    public function highlight_html( $code )
    {
        $code = htmlentities( $code );
        $code = preg_replace( "/([a-zA-Z_]+)=/", "<font color=\"#FF0000\">\$1=</font>", $code );
        $code = preg_replace( "/(&lt;[\\/a-zA-Z0-9&;]+)/", "<font color=\"#0000FF\">\$1</font>", $code );
        $code = str_replace( "&lt;!--", "<font color=\"#008080\">&lt;!--", $code );
        $code = str_replace( "--&gt;", "--&gt;</font>", $code );
        $code = preg_replace( "/[\\r\\n]+/", "\n", $code );
        return $code;
    }

}

?>
