<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

include( "public.inc.php" );
$subject = stripslashes( htmlspecialchars( $_REQUEST['subject'] ) );
if ( $_POST['status'] == "send" )
{
    $department = $_POST['department'];
    $fullname = stripslashes( htmlspecialchars( $_POST['fullname'] ) );
    $uname = stripslashes( htmlspecialchars( $_POST['uname'] ) );
    $mail = trim( $_POST['mail'] );
    $msg = stripslashes( htmlspecialchars( $_POST['msg'] ) );
    $idcode = $_POST['turning'];
    if ( $CONFIG['SUPPORT_TURNING'] && strtolower( trim( $idcode ) ) != $_SESSION['UniqCode'] )
    {
        $Error[] = $LANG_msg['support_005'];
    }
    unset( $_SESSION['UniqCode'] );
    if ( !empty( $mail ) && !empty( $fullname ) && !empty( $msg ) && !empty( $subject ) && !$Error )
    {
        if ( preg_match( "/.+@.+\\..+/", $mail ) )
        {
            unset( $_SESSION['UniqCode'] );
            $message = "{$msg} \n\n";
            if ( !empty( $uname ) )
            {
                $message .= "username: {$uname} \n";
            }
            $message .= "E-mail: {$mail} \n";
            $message .= "Date: ".date( "F j, Y, g:i a" )."\n";
            $message .= "Department: ".$LANG_msg_department[$department]."\n";
            $message .= "IP Address: ".$_SERVER['REMOTE_ADDR']."\n";
            $country_detect = GetCountry_csv( $_SERVER['REMOTE_ADDR'] );
            if ( $country_detect )
            {
                $message .= "Country from ip: ".$country_detect."\n";
            }
            $headers .= "To: {$CONFIG['SITE_NAME']} <".$CONFIG['ADMIN_MAIL'].">\r\n";
            $headers .= "From: {$fullname} <".$CONFIG['REPORT_MAIL'].">\r\n";
            $headers .= "Reply-To: {$mail}\r\n";
            $mail = new siteMAIL( );
            $mail->AddAddress( $CONFIG['ADMIN_MAIL'], $CONFIG['SITE_NAME']." Administrator" );
            $mail->Subject = $subject;
            $mail->Body = $message;
            $mail->FromName = $fullname;
            $mail->AddReplyTo( $mail, $fullname );
            $mail->bakeMail( false );
            if ( $CONFIG['MAIL_TYPE'] == "smtp" )
            {
                if ( !$mail->Send( ) )
                {
                    $Error[] = "There was an error sending the message: ".$mail->ErrorInfo;
                }
            }
            else if ( !mail( $CONFIG['ADMIN_MAIL'], $mail->Subject, $mail->Body, $headers ) )
            {
                $Error[] = "There was an error sending the email by server php mail extension.";
            }
            if ( !$Error )
            {
                $message_body = "Dear: {$fullname},\nThank you for mailing, We received your message and\n";
                $message_body .= "our support staffs will replay your email in next few hours.\n\n";
                $message_body .= "*DO NOT REPLY TO THIS E-MAIL*\n";
                $message_body .= "This is an automated e-mail message sent from ".$CONFIG['SITE_NAME']." support system. Do not reply to this e-mail as we won't receive your reply!\n";
                $message_body .= "\nYours sincerely,\n";
                $message_body .= $CONFIG['SITE_NAME'].",\n{$CONFIG['SITE_URL']}\n";
                $headers = "To: {$fullname} <{$mail}>\r\n";
                $headers .= "From: {$CONFIG['SITE_NAME']} Do Not Reply<".$CONFIG['REPORT_MAIL'].">\r\n";
                $mail = new siteMAIL( );
                $mail->AddAddress( $mail, $fullname );
                $mail->Subject = $subject;
                $mail->Body = nl2br( $message_body );
                $mail->mail_title = "Support ticket";
                $mail->FromName = $CONFIG['SITE_NAME']." Do Not Reply";
                $mail->bakeMail( false );
                if ( $CONFIG['MAIL_TYPE'] == "smtp" )
                {
                    if ( !$mail->Send( ) )
                    {
                        $Error[] = "There was an error sending the message: ".$mail->ErrorInfo;
                    }
                }
                else if ( !mail( $arr_PAYMENT['EMAIL'], $mail->Subject, $mail->Body, $headers ) )
                {
                    $Error[] = "There was an error sending the email by server php mail extension.";
                }
                if ( !$Error )
                {
                    $Success[] = $LANG_msg['support_018'];
                    $mail_sent = true;
                }
                unset( $fullname );
                unset( $mail );
                unset( $msg );
                unset( $subject );
                unset( $uname );
                unset( $msg );
            }
            else
            {
                $Error[] = $LANG_msg['support_016']." ".$CONFIG['ADMIN_MAIL'];
            }
        }
        else
        {
            $Error[] = $LANG_msg['support_006'];
        }
    }
    else if ( !$Error )
    {
        $Error[] = $LANG_msg['support_007'];
    }
    else if ( session_active( ) )
    {
        $mail = db_get_id( "select email from {$_users_details} where uid={$uid}" );
    }
}
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."support.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "support.html";
    $page->assign( "Departments", $LANG_msg_department );
    $page->assign( "mail_sent", $mail_sent );
    require( "include/engine_run.php" );
}
echo "\r\n";
?>
