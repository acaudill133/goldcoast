<?php
$b = protect($_GET['b']);
$id = protect($_GET['id']);
?>
<ol class="breadcrumb">
	<li><a href="./">WebAdmin</a></li>
	<?php if($b == "preview") { ?>
	<li><a href="./?a=exchanges">Exchanges</a></li>
	<li class="active">Preview</li>
	<?php } else { ?>
	<li class="active">Exchanges</li>
	<?php } ?>
</ol>

<div class="row">
	<div class="col-lg-12">
			<?php
			if($b == "preview") {
			$query = $db->query("SELECT * FROM exchanges WHERE id='$id'");
			if($query->num_rows==0) { header("Location: ./?a=exchanges"); }
			$row = $query->fetch_assoc();
			$query1 = $db->query("SELECT * FROM companies_list WHERE id='$row[c_send]'");
									$row1 = $query1->fetch_assoc();
									$query2 = $db->query("SELECT * FROM companies_list_receive WHERE id='$row[c_receive]'");
									$row2 = $query2->fetch_assoc();
				?>
				<div class="panel panel-primary">
                  <div class="panel-heading"> 
						<i class="fa fa-search"></i> Preview exchange 
				  </div>
                  <div class="panel-body">
					<h3>Exchange id: <?php echo $row['exchange_id']; ?></h3>
					<table class="table">
						<thead>
							<tr>
								<td>User</td>
								<td>Send</td>
								<td>Receive</td>
								<td>Amount</td>
								<td>Status</td>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><?php if($row['uid']>0) { echo idinfo($row['uid'],"username"); } else { echo 'Anonymous ('.$row[ip].')'; } ?></td>
								<td><?php echo $row1['name']; ?></td>
								<td><?php echo $row2['name']; ?></td>
								<td>$<?php echo $row['a_send']; ?></td>
								<td><?php
										if($row['status'] == "1") { echo '<span class="label label-info">Awaiting payment</span>'; }
										elseif($row['status'] == "2") { echo '<span class="label label-info">Processing</span>'; }
										elseif($row['status'] == "3") { echo '<span class="label label-danger">Payment fail</span>'; }
										elseif($row['status'] == "4") { echo '<span class="label label-danger">Refused</span>'; }
										elseif($row['status'] == "5") { echo '<span class="label label-success">Processed</span>'; }
										elseif($row['status'] == "6") { echo '<span class="label label-danger">Timeout</span>'; }
										else {
											echo '<span class="label label-default">Unknown</span>';
										}
										?></td>
							</tr>
							<tr>
								<td colspan="5">&nbsp;</td>
							</tr>
						</tbody>
						<thead>
							<tr>
								<td>Payee</td>
								<td>Referral id</td>
								<td>Exchange rate</td>
								<td>Amount receive</td>
								<td>Requested on</td>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><?php echo $row1['account']; ?></td>
								<td><?php if($row['refid'] == "0") { echo 'None'; } else { echo idinfo($row['refid'],"username"); } ?></td>
								<td><?php echo $row['a_rate']; ?></td>
								<td>$<?php echo $row['a_receive']; ?></td>
								<td><?php echo date("d/m/Y H:i",$row['time']); ?></td>
							</tr>
							<tr>
								<td colspan="5">&nbsp;</td>
							</tr>
						</tbody>
						<thead>
							<tr>
								<td>Receiver account</td>
								<td>Receiver email</td>
								<td>Expiration</td>
								<td>Earned</td>
								<td>Action</td>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><?php echo $row['account']; ?></td>
								<td><?php echo $row['email']; ?></td>
								<td><?php echo date("d/m/Y H:i",$row['expiration']); ?></td>
								<td><?php if($row['status'] == "5") { echo '$'; echo number_format($row['a_send']-$row['a_receive'],2); } ?></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					
					<?php if($row['status'] == "2") { ?>
					<div id="take_action">
						<?php
						if(isset($_POST['btn_update'])) {
							$redirect = './?a=exchanges&b=preview&id='.$id;
							$status = protect($_POST['status']);
							if($status == "5") {
								$earnings = $row['a_send']-$row['a_receive'];
								$date = date("d/m/Y");
								$check_e = $db->query("SELECT * FROM earnings WHERE date='$date'");
								if($check_e->num_rows>0) {
									$update = $db->query("UPDATE settings SET earnings=earnings+$earnings");
									$update = $db->query("UPDATE earnings SET earnings=earnings+$earnings WHERE date='$date'");
								} else {
									$update = $db->query("UPDATE settings SET earnings=earnings+$earnings");
									$insert = $db->query("INSERT earnings (earnings,date) VALUES ('$earnings','$date')");
								}
								if($row['refid']>0) {
									$com = $row['a_send'] - $row['a_receive'];
									$com2 = ($com * 100) / 110; 
									$com = $com-$com2; 
									$comission = $com;
									$update = $db->query("UPDATE users SET earnings=earnings+$comission WHERE id='$row[refid]'");
								}
								$update = $db->query("UPDATE exchanges SET status='5' WHERE id='$row[id]'");
								header("Location: $redirect");
							} else {
								$update = $db->query("UPDATE exchanges SET status='$status' WHERE id='$row[id]'");
								header("Location: $redirect");
							}
						}
						?>
						<form action="" method="POST">
							<div class="form-group">
								<label>Status</label>
								<select name="status" class="form-control">
									<option value="1" <?php if($row['status'] == "1") { echo 'selected'; } ?>>Awaiting payment</option>
									<option value="2" <?php if($row['status'] == "2") { echo 'selected'; } ?>>Processing</option>
									<option value="3" <?php if($row['status'] == "3") { echo 'selected'; } ?>>Payment fail</option>
									<option value="4" <?php if($row['status'] == "4") { echo 'selected'; } ?>>Refused</option>
									<option value="5" <?php if($row['status'] == "5") { echo 'selected'; } ?>>Processed</option>
									<option value="6" <?php if($row['status'] == "6") { echo 'selected'; } ?>>Timeout</option>
								</select>
							</div>
							<button type="submit" class="btn btn-primary" name="btn_update"><i class="fa fa-check"></i> Update</button>
						</form>
					</div>
					<?php } ?>
				  </div>
				</div>
				<?php
			} else {
				?>
				<div class="panel panel-primary">
                  <div class="panel-heading"> 
						<i class="fa fa-refresh"></i> Exchanges 
				  </div>
                  <div class="panel-body">
					<table class="table table-hover">
						<thead>
							<tr>
								<td width="25%">User</td>
								<td width="20%">Send</td>
								<td width="20%">Receive</td>
								<td width="15%">Amount</td>
								<td width="15%">Status</td>
								<td width="5%">Action</td>
							</tr>
						</thead>
						<tbody>
							<?php
							$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
							$limit = 20;
							$startpoint = ($page * $limit) - $limit;
							if($page == 1) {
								$i = 1;
							} else {
								$i = $page * $limit;
							}
							$statement = "exchanges";
							$query = $db->query("SELECT * FROM {$statement} ORDER BY id LIMIT {$startpoint} , {$limit}");
							if($query->num_rows>0) {
								while($row = $query->fetch_assoc()) {
									$rows[] = $row;
								}
								foreach($rows as $row) {
								
									$query1 = $db->query("SELECT * FROM companies_list WHERE id='$row[c_send]'");
									$row1 = $query1->fetch_assoc();
									$query2 = $db->query("SELECT * FROM companies_list_receive WHERE id='$row[c_receive]'");
									$row2 = $query2->fetch_assoc();
									?>
									<tr>
										<td><?php if($row['uid'] == "0") { echo 'Anonymous'; } else { echo idinfo($row['uid'],"username"); } ?></td>
										<td><?php echo $row1['name']; ?></td>
										<td><?php echo $row2['name']; ?></td>
										<td>$<?php echo $row['a_send']; ?></td>
										<td>
										<?php
										if($row['status'] == "1") { echo '<span class="label label-info">Awaiting payment</span>'; }
										elseif($row['status'] == "2") { echo '<span class="label label-info">Processing</span>'; }
										elseif($row['status'] == "3") { echo '<span class="label label-danger">Payment fail</span>'; }
										elseif($row['status'] == "4") { echo '<span class="label label-danger">Refused</span>'; }
										elseif($row['status'] == "5") { echo '<span class="label label-success">Processed</span>'; }
										elseif($row['status'] == "6") { echo '<span class="label label-danger">Timeout</span>'; }
										else {
											echo '<span class="label label-default">Unknown</span>';
										}
										?>
										</td>
										<td>
											<a href="./?a=exchanges&b=preview&id=<?php echo $row['id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Preview"><i class="fa fa-search"></i></a> 
										</td>
									</tr>
									<?php
								}
							} else {
								echo '<tr><td colspan="6">No have recorded exchanges.</td></tr>';
							}
							?>
						</tbody>
					</table>
					<?php
					$ver = "./?a=exchanges";
					if(pagination($statement,$ver,$limit,$page)) {
						echo pagination($statement,$ver,$limit,$page);
					}
					?>
			      </div>
				</div>
				<?php
			}
			?>
	</div>
</div>