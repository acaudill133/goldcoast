<?php
/**
 * @package 	Plugin EXchange Rate Calculator for Joomla!
 * @version 	1.0.0
 * @author 		E-max
 * @copyright 	Copyright (C) 2013 - E-max
 * @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 **/

// No direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.plugin.plugin');

class PlgContentExchangeRateCalculator extends JPlugin {
	/**
	 * @since	1.6
	 */
	public function onContentBeforeDisplay($context, &$row, &$params, $page=0) {
		$app = JFactory::getApplication();
		$document = JFactory::getDocument();
		
		$lang = JFactory::getLanguage();
		$lang->load('plg_content_exchangeratecalculator', JPATH_ADMINISTRATOR);
		
		$view = $app->input->get('view');
		$print = $app->input->getBool('print');
		$regex_all		= '/{exchangeratecalculator\s*.*?}/si';
		$matches 		= array();
		$count_matches	= preg_match_all($regex_all,$row->text,$matches,PREG_OFFSET_CAPTURE | PREG_PATTERN_ORDER);
		$document->addCustomTag('<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.js"></script>');
		$document->addCustomTag('<link rel="stylesheet" type="text/css" href="'.JURI::base(true).'/plugins/content/exchangeratecalculator/assets/css/style.css">');
		
		if ($print) {
			return false;
		}

		if (($context == 'com_content.article') && $count_matches) {
			$html = '';
			$db = JFactory::getDbo();
			$user = JFactory::getUser();
			$lang = JFactory::getLanguage();
			$nullDate = $db->getNullDate();

			$date = JFactory::getDate();
			$now = $date->toSql();
			$token = "%jNtA7z?2Hy;?Qs+n+G{6jHi[7.w6L,M";
				$currencies = array(
					"USD" => "United States Dollars - USD" ,
					"EUR" => "Euro - EUR" ,
					"GBP" => "United Kingdom Pounds - GBP" ,
					"JPY" => "Japan Yen - JPY" ,
					"CNY" => "China Yuan Renminbi - CNY" ,
					"CNY" => "RMB (China Yuan Renminbi) - CNY" ,
					"RUB" => "Russia Rubles - RUB" ,
					"CAD" => "Canada Dollars - CAD" ,
					"AUD" => "Australia Dollars - AUD" ,
					"ARS" => "Argentina Pesos - ARS" ,
					"BHD" => "Bahrain Dinars - BHD" ,
					"BRL" => "Brazil Reais - BRL" ,
					"CHF" => "Switzerland Francs - CHF" ,
					"ZAR" => "South Africa Rand - ZAR" ,
					"DZD" => "Algeria Dinars - DZD" ,
					"NZD" => "New Zealand Dollars - NZD" ,
					"INR" => "India Rupees - INR" ,
					"CLP" => "Chile Pesos - CLP" ,
					"COP" => "Colombia Pesos - COP" ,
					"CRC" => "Costa Rica Colones - CRC" ,
					"HRK" => "Croatia Kuna - HRK" ,
					"CZK" => "Czech Republic Koruny - CZK" ,
					"DKK" => "Denmark Kroner - DKK" ,
					"DOP" => "Dominican Republic Pesos - DOP" ,
					"EGP" => "Egypt Pounds - EGP" ,
					"HKD" => "Hong Kong Dollars - HKD" ,
					"HUF" => "Hungary Forint - HUF" ,
					"ISK" => "Iceland Kronur - ISK" ,
					"INR" => "India Rupees - INR" ,
					"IDR" => "Indonesia Rupiahs - IDR" ,
					"ILS" => "Israel New Shekels - ILS" ,
					"IQD" => "Iraqi Dinar - IQD" ,
					"JMD" => "Jamaica Dollars - JMD" ,
					"JOD" => "Jordan Dinars - JOD" ,
					"KES" => "Kenya Shillings - KES" ,
					"KRW" => "Korea (South) Won - KRW" ,
					"KWD" => "Kuwait Dinars - KWD" ,
					"LBP" => "Lebanon Pounds - LBP" ,
					"MYR" => "Malaysia Ringgits - MYR" ,
					"MUR" => "Mauritius Rupees - MUR" ,
					"MXN" => "Mexico Pesos - MXN" ,
					"MAD" => "Morocco Dirhams - MAD" ,
					"NZD" => "New Zealand Dollars - NZD" ,
					"NOK" => "Norway Kroner - NOK" ,
					"OMR" => "Oman Rials - OMR" ,
					"PKR" => "Pakistan Rupees - PKR" ,
					"PEN" => "Peru Nuevos Soles - PEN" ,
					"PHP" => "Philippines Pesos - PHP" ,
					"PLN" => "Poland Zlotych - PLN" ,
					"QAR" => "Qatar Riyals - QAR" ,
					"RUB" => "Russia Rubles - RUB" ,
					"SAR" => "Saudi Arabia Riyals - SAR" ,
					"SGD" => "Singapore Dollars - SGD" ,
					"ZAR" => "South Africa Rand - ZAR" ,
					"KRW" => "South Korea Won - KRW" ,
					"LKR" => "Sri Lanka Rupees - LKR" ,
					"SEK" => "Sweden Kronor - SEK" ,
					"CHF" => "Switzerland Francs - CHF" ,
					"TWD" => "Taiwan New Dollars - TWD" ,
					"THB" => "Thailand Baht - THB" ,
					"TTD" => "Trinidad and Tobago Dollars - TTD" ,
					"TND" => "Tunisia Dinars - TND" ,
					"TRY" => "Turkey Lira - TRY" ,
					"AED" => "United Arab Emirates Dirhams - AED" ,
					"ZMK" => "Zambia Kwacha - ZMK"
					);
			$uid = $row->id;
			$option = 'com_content';
			$canPublish = $user->authorise('core.edit.state', $option . '.article.' . $row->id);

			$orderBy = 'a.ordering ASC';
			
			$xwhere = ' AND (a.state = 1 OR a.state = -1)' .
			' AND (publish_up = '.$db->quote($nullDate).' OR publish_up <= '.$db->quote($now).')' .
			' AND (publish_down = '.$db->quote($nullDate).' OR publish_down >= '.$db->quote($now).')';

			// Array of articles in same category correctly ordered.
			$query	= $db->getQuery(true);
			$query->select('a.id, a.title, '
					.'CASE WHEN CHAR_LENGTH(a.alias) THEN CONCAT_WS(":", a.id, a.alias) ELSE a.id END as slug, '
					.'CASE WHEN CHAR_LENGTH(cc.alias) THEN CONCAT_WS(":", cc.id, cc.alias) ELSE cc.id END as catslug');
			$query->from('#__content AS a');
			$query->leftJoin('#__categories AS cc ON cc.id = a.catid');
			$query->where('a.catid = '. (int)$row->catid .' AND a.state = '. (int)$row->state
						. ($canPublish ? '' : ' AND a.access = ' .(int)$row->access) . $xwhere);
			$query->order($orderBy);

			$db->setQuery($query);
				$html = '<!-- Exchange Rate Calculator | In collaborazione con <a href="http://e-max.it/posizionamento-siti-web/roi-highway" title="Migliorare il posizionamento siti web" target="_blank" rel="nofollow">Primo sui motori di ricerca con e-max.it</a> -->';
				$html .= '
					<div class="block_main rounded exchangeratecalculator"><table><tbody>
					<tr>
					<td>
						<label for="amount">'.JText::_('PLG_CONTENT_EXCHANGERATECALCULATOR_AMOUNT').'</label>
						</td>
						<td>
						<input class="amount" type="text" name="amount" id="amount" value="1" />
						</td>
						</tr>
						<tr>
						<td>
						<label for="from">'.JText::_('PLG_CONTENT_EXCHANGERATECALCULATOR_FROM').'</label></td>
						<td>
						<select name="from" id="from">';
				
							foreach ($currencies as $k => $v) {
							$html .= "<option value=\"$k\">$v</option>" ;
							}
				$html .= '</select></td>
						</tr>
						<tr>
						<td>
						<label for="to">'.JText::_('PLG_CONTENT_EXCHANGERATECALCULATOR_TO').'</label></td><td>
						<select name="to" id="to">';
							foreach ($currencies as $k => $v) {
							$html .= "<option value=\"$k\">$v</option>" ;
							}
				$html .= '</select></td>
						</tr>
						<tr>
						<td colspan="2">
						<div class="container_butt"><input type="button" name="submit" id="submit" value="'.JText::_('PLG_CONTENT_EXCHANGERATECALCULATOR_CONVERT').'" />';
					$html .= '<span><a href="http://e-max.it/posizionamento-siti-web/roi-highway" title="Migliorare il posizionamento siti web" target="_blank" rel="nofollow"><img src="'.JURI::base(true).'/plugins/content/exchangeratecalculator/assets/img/primo-sui-motori.png" alt="Migliorare il posizionamento siti web" width="12" height="12" style="vertical-align:middle;" /></a></span>';
				
				$html .= '</div></td></tr></tbody></table>
						<div id="converted_value"></div>
					</div>
				     <script type="text/javascript">
			 		jQuery(document).ready(function($) {
			 			$("#submit").click(function(){
			 			//Get the values
			 				var amount = $("#amount").val();
			 				var from  = $("#from").val();
			 				var to = $("#to").val();
							var string = "'.JText::_('PLG_CONTENT_EXCHANGERATECALCULATOR_STRING').'";
							
			 				var params = "amount=" + amount + "&from=" + from + "&to=" + to ;
			 		        $.getJSON("'.JURI::base(true).'/plugins/content/exchangeratecalculator/assets/currency.php", { amount: amount, from: from, to: to }, function (result) {
			 		        	$("#converted_value").html(amount + " " + from + " " + string + " " + result[0].v + " " + to);
			 		        });
			 			}) ;
			 		});
					 </script>	
					';
				$html .= '<!-- Exchange Rate Calculator | In collaborazione con <a href="http://e-max.it/posizionamento-siti-web/roi-highway" title="Migliorare il posizionamento siti web" target="_blank" rel="nofollow">Primo sui motori di ricerca con e-max.it</a> -->';
				$row->text = preg_replace($regex_all, $html, $row->text, 1);
		}
		return ;
	}
}