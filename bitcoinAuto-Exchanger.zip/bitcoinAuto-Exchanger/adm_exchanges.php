<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "public.inc.php" );
if ( !session_admin( ) )
{
    @header( "Location: ".$CONFIG['SITE_URL'] );
}
if ( $_GET['Action'] == "Mark_Received" && $_GET['reference'] )
{
    if ( db_if_exists( "SELECT * FROM {$_exchange_lines} WHERE exchange_refrence='{$_GET['reference']}' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}'" ) )
    {
        if ( db_exec( "UPDATE {$_exchange_lines} SET src_status='{$STATUS_ENUM_ENABLE}', exchange_note=CONCAT(exchange_note,' - Your payment manually marked received') WHERE exchange_refrence='' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}'" ) )
        {
            SEND_EXHCANGE_MAIL( $_GET['reference'], "receive" );
            $Success[] = "Order source Marked Received, an email has been sent.<br>You can see this order in Pending list now. #{$_GET['reference']}";
        }
    }
    else
    {
        $Error[] = "Error: You don't have exchange order with Open status as Source by this exchange: {$_GET['reference']} ";
    }
    $show_main = true;
}
if ( $_POST['submit'] == "Update" && $_GET['eid'] )
{
    $count = 0;
    $total_fields = count( $_POST );
    foreach ( $_POST as $key => $value )
    {
        if ( $count < $total_fields - 2 )
        {
            $SQL .= "{$key}='{$value}' , ";
        }
        else if ( $key != "submit" && $key != "submit" )
        {
            $SQL .= "{$key}='{$value}' WHERE eid='{$_GET['eid']}'";
        }
        ++$count;
    }
    if ( db_exec( "UPDATE {$_users_details} SET {$SQL}" ) )
    {
        $Success[] = "Exchange Order updated successfully.";
    }
    $show_main = false;
}
if ( $_GET['Action'] == "Delete" && $_GET['reference'] )
{
    if ( db_get_id( "SELECT eid FROM {$_exchange_lines} WHERE exchange_refrence='{$_GET['reference']}' AND src_status='{$STATUS_ENUM_DISABLE}'" ) )
    {
        if ( db_exec( "DELETE FROM {$_exchange_lines} WHERE exchange_refrence='{$_GET['reference']}' AND src_status='{$STATUS_ENUM_DISABLE}'" ) )
        {
            $Success[] = "Order :#{$_GET['reference']} Delete Successfully.";
        }
    }
    else
    {
        $Error[] = "Error: You don't have exchange order with Open status as Source by this exchange: {$_GET['reference']} ";
    }
    $show_main = true;
}
if ( $_GET['Action'] == "Edit" && $_GET['eid'] )
{
    $query = "SELECT * FROM {$_exchange_lines} WHERE eid='{$_GET['eid']}'";
    $result = db_query( $query, "&nbsp;" );
    $arr_data_admexchange2 = mysql_push_data( $result );
    db_free_result( $result );
    $show_main = false;
}
if ( $INVEST_SECTION )
{
    $section = "Invest_Static";
    include( "include/box_includes.php" );
}
$order = $_GET['order'];
if ( !$order )
{
    $order = "ASC";
}
$key = $_GET['key'];
if ( !$key )
{
    $key = "{$_exchange_lines}.src_date";
}
$key = $key." ".$order;
$write_order = "Asc";
if ( $order == "Asc" )
{
    $write_order = "Desc";
}
if ( !$_GET['Type'] )
{
    $SQL = "src_status='{$STATUS_ENUM_ENABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}'";
    $_GET['Type'] = "pending";
}
else if ( $_GET['Type'] == "complete" )
{
    $SQL = "src_status='{$STATUS_ENUM_ENABLE}' AND dst_status='{$Var_4920}'";
}
else if ( $_GET['Type'] == "not_received" )
{
    $SQL = "src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}'";
}
if ( $_GET['src_date'] == "today" )
{
    $SQL .= " AND to_days(src_date)=to_days(now())";
}
else if ( $_GET['src_date'] )
{
    $SQL .= " AND src_date='{$_GET['src_date']}'";
}
if ( $_GET['dst_date'] == "today" )
{
    $SQL .= " AND to_days(dst_date)=to_days(now())";
}
else if ( $_GET['dst_date'] )
{
    $SQL .= " AND src_date='{$_GET['dst_date']}'";
}
if ( !$SQL )
{
    $SQL = "eid>'1'";
}
$no = 0;
$sum = 0;
if ( !$_GET['Action'] || $show_main )
{
    $query = "SELECT {$_exchange_lines}.*, {$_currencies}.exchange_automatic FROM {$_exchange_lines} Left Join {$_currencies} ON {$_exchange_lines}.dst_cid = {$_currencies}.cid WHERE {$SQL} ORDER BY {$key} ";
    $page = $_GET['page'];
    $total = mysql_num_rows( mysql_query( $query ) );
    $perpage = $CONFIG['recordsnumperpage'];
    $url_string = $cur_page.( $_GET['Type'] ? "&Type=" : "" );
    $url_string = get_link( $Var_6864 );
    $pager = new pager( $total, $perpage, $url_string, $CONFIG['FRIENDLY_URL'] );
    if ( empty( $page ) )
    {
        $page = 1;
    }
    $from = $pager->getPageFrom( $page );
    $query = $query." limit {$from}, {$perpage}";
    $result = db_query( $query, "&nbsp;" );
    $arr_data_admexchange = mysql_push_data( $result );
    db_free_result( $result );
    $show_main = true;
    $page_title2 = str_replace( "_", " ", $Var_7920 )." ".$_GET['src_date']." ".$_GET['dst_date']." ";
    if ( !count( $arr_data_admexchange ) )
    {
        $Error[] = "There is not any ".ucfirst( $page_title2 )." Order";
    }
}
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."adm_exchanges.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "adm_exchanges.html";
    if ( $show_main )
    {
        if ( $perpage < $total )
        {
            $pg = $pager->page;
            $page_navigation .= $pager->getButPrev(  );
            $range = 20;
            $page_navigation .= $pager->getButList( $range );
            $page_navigation .= $pager->getButNext( $pg );
            $page_navigation .= "<br><br><br>";
            $page_navigation .= $pager->getRangeInfo( );
        }
        $page->assign( "page_navigation", $page_navigation );
        $page->assign( "total", $total );
        $result = db_query( "select cid, currency_name, currency_worth_name from {$_currencies}", "&nbsp;" );
        while ( $line = db_fetch_array( $result ) )
        {
            $All_currencies_name[$line['cid']] = $line['currency_name'];
            $All_currencies_worth[$line['cid']] = $line['currency_worth_name'];
        }
        db_free_result( $result );
        foreach ( $arr_data_admexchange as $key => $value )
        {
            $arr_data_admexchange[$key]['dst_status_name'] = $STATUS_EXCHANGE[$arr_data_admexchange[$key]['dst_status']];
            $arr_data_admexchange[$key]['src_status_name'] = $STATUS_EXCHANGE[$arr_data_admexchange[$key]['src_status']];
            $Var_11064['src_worth'] = $All_currencies_worth[$arr_data_admexchange[$key]['src_cid']];
            $arr_data_admexchange[$key]['dst_worth'] = $All_currencies_worth[$arr_data_admexchange[$key]['dst_cid']];
            $arr_data_admexchange[$key]['dst_emoney'] = $All_currencies_name[$arr_data_admexchange[$key]['dst_cid']];
            $arr_data_admexchange[$key]['src_emoney'] = $All_currencies_name[$arr_data_admexchange[$key]['src_cid']];
            $arr_data_admexchange[$key]['amount'] = FormatPrice( $arr_data_admexchange[$key]['exchange'], 2 );
        }
        $page->assign( "arr_data_admexchange", $arr_data_admexchange );
    }
    else
    {
        $page->assign( "arr_data_admexchange2", $arr_data_admexchange2 );
        $page->assign( "STATUS_EXCHANGE", $STATUS_EXCHANGE );
        $page->assign( "Get", array(
            "Action" => $_GET['Action'],
            "eid" => $_GET['eid']
        ) );
        $page->assign( "arr_currencies_ALL", $Allcurrencies );
    }
    $page->assign( "page_title2", $page_title2 );
    $page->assign( "show_main", $show_main );
    $page->assign( "Type", $_GET['Type'] );
    $page->assign( "write_order", $write_order );
    require( "include/engine_run.php" );
}
?>
