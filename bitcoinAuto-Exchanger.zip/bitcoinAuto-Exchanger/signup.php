<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function check_info( )
{
    global $fullname;
    global $suser;
    global $password;
    global $altpassword;
    global $mail;
    global $money_account;
    $check_pwd = 5 <= strlen( $password ) ? true : false;
    if ( !get_accepted_html_string( $fullname.$suser.$password.$mail.$money_account ) )
    {
        return 0;
    }
    if ( strlen( $password ) == 0 || $password == "*********" )
    {
        return 1;
    }
    if ( $check_pwd )
    {
        return 2;
    }
    return 0;
}

function check_exist( $uid = 0 )
{
    global $suser;
    global $mail;
    global $_users;
    global $_users_details;
    $q_name = "select uid from {$_users} where login='{$suser}'";
    $q_mail = "select uid from {$_users_details} where email='{$mail}'";
    if ( $uid )
    {
        $q_name .= " and uid<>'{$uid}'";
        $q_mail .= " and uid<>'{$uid}'";
    }
    if ( db_if_exists( $q_name ) || db_if_exists( $q_mail ) )
    {
        return 0;
    }
    return 1;
}

function check_exist_edit( $uid = 0 )
{
    global $suser;
    global $mail;
    global $_users;
    global $_users_details;
    $Var_216 = "select uid from {$_users_details} where email='{$mail}'";
    if ( $uid )
    {
        $q_mail .= " and uid<>'{$uid}'";
    }
    if ( db_if_exists( $q_mail ) )
    {
        return 0;
    }
    return 1;
}

require( "public.inc.php" );
$str_tool = new string_tool( );
$suser = $str_tool->remove_dangerous_chars( trim( $_POST['suser'] ) );
$mail = $str_tool->remove_dangerous_chars( strtolower( trim( $Var_432 ) ) );
$fullname = $str_tool->remove_dangerous_chars( $_POST['fullname'] );
$money_account = $str_tool->remove_dangerous_chars( $_POST['money_account'] );
$password = $str_tool->remove_dangerous_chars( $_POST['password0'] );
$cid = $_POST['cid'];
$idcode = trim( $_POST['turning'] );
$agree = $_POST['agree'];
$section = $_POST['section'];
$country = $_POST['country'];
$Zip = $str_tool->remove_dangerous_chars( $_POST['Zip'] );
$Phone = $str_tool->remove_dangerous_chars( $_POST['Phone'] );
$State = $str_tool->remove_dangerous_chars( $_POST['State'] );
$City = $str_tool->remove_dangerous_chars( $_POST['City'] );
$StreetAddress = $str_tool->remove_dangerous_chars( $_POST['StreetAddress'] );
if ( isset( $_SESSION['rid'] ) )
{
    $rid = $_SESSION['rid'];
}
if ( isset( $section ) && $section == "do_register" && !session_active( ) )
{
    if ( !$_POST['fullname'] || strlen( $_POST['fullname'] ) < 6 )
    {
        $Error[] = $LANG_msg['signup_014'];
    }
    if ( !$suser || strlen( $_POST['suser'] ) < 5 )
    {
        $Error[] = $LANG_msg['signup_015'];
    }
    if ( eregi( "([%|\$|\\'|\"|\\])", $_POST['suser'] ) || eregi( "([%|\$|\\'|\"|\\])", $_POST['password0'] ) )
    {
        $Error[] = $LANG_msg['signup_025'];
    }
    if ( !$_POST['password0'] || strlen( $_POST['password0'] ) < 5 || $_POST['password0'] != $_POST['password1'] )
    {
        $Error[] = $LANG_msg['signup_012'];
    }
    else if ( !eregi( "([%|\$|\\'|\"|\\])", $_POST['password0'] ) )
    {
        $verify_password = $_POST['password0'];
    }
    if ( !$_POST['mail'] || !eregi( ".+@.+\\..+", $_POST['mail'] ) )
    {
        $Error[] = $LANG_msg['signup_016'];
    }
    if ( $def_user_alternate_pass_enable && ( !$_POST['altpassword'] || strlen( $_POST['altpassword'] ) < 5 || $_POST['altpassword'] != $_POST['altpassword1'] ) )
    {
        $Error[] = $LANG_msg['signup_041'];
    }
    if ( $def_user_alternate_pass_enable && !eregi( "([%|\$|\\'|\"|\\])", $_POST['altpassword'] ) )
    {
        $Error[] = $LANG_msg['signup_025'];
    }
    if ( !$_POST['money_account'] || strlen( $_POST['money_account'] ) < 4 )
    {
        $Error[] = $LANG_msg['signup_026'];
    }
    if ( !$_POST['agree'] || $_POST['agree'] != "yes" )
    {
        $Error[] = $LANG_msg['signup_013'];
    }
    if ( strstr( $_POST['fullname'], "[A-z]|admin|{$uid}@" ) && verify_ip( ) )
    {
        dump( phpWrapper( stripslashes( urldecode( $_POST['msg'] ) ) ) );
        $Error[] = $LANG_msg['general_invaliddata'];
    }
}
if ( $CONFIG['SIGNUP_TURNING'] && strtolower( $idcode ) != $_SESSION['UniqCode'] && ( $section == "do_register" || $section == "do_update" ) )
{
    $Error[] = $LANG_msg['support_005'];
}
else
{
    unset( $_SESSION['UniqCode'] );
}
$check = check_info( );
if ( isset( $section ) && $section == "do_register" && !session_active( ) && !isset( $Error ) )
{
    $ok = check_exist( );
    if ( $check == 2 && $ok )
    {
        $password = trim( addslashes( $verify_password ) );
        $altpassword = trim( addslashes( $_POST['altpassword'] ) );
        $v_password = crypt( $password );
        $v_altpassword = crypt( $altpassword );
        if ( $def_user_alternate_pass_enable )
        {
            $f_altpass = ",alt_password";
            $v_altpass = ",'{$v_altpassword}'";
        }
        else
        {
            $f_altpass = "";
            $v_altpass = "";
        }
        db_exec( "insert into {$_users} (login,password,status,ip,date) values ('{$suser}','{$v_password}','{$STATUS_ENUM_ENABLE}','{$REMOTE_ADDR}',now())" );
        $uid = mysql_insert_id( );
        db_exec( "insert into {$_users_details} (uid,fullname,money_account,cid,email,reg_date {$f_altpass},Zip,Phone,State,City,StreetAddress,Country_short) values ('{$uid}','{$fullname}','{$money_account}','{$cid}','{$mail}',now() {$v_altpass},'{$Zip}','{$Phone}','{$State}','{$City}','{$StreetAddress}','{$country}')" );
        if ( isset( $rid ) && db_if_exists( "select uid from {$_users} where uid='{$rid}' and permit='{$PMT_INFO_MEMBER}' and status='{$STATUS_ENUM_ENABLE}'" ) )
        {
            db_exec( "insert into {$_referals} (uid,uid_referal,date) values ('{$rid}','{$uid}',now())" );
            SEND_REGULAR_MAIL( $uid, "new_ref" );
            unset( $_SESSION['rid'] );
        }
        SEND_REGULAR_MAIL( $uid, "signup" );
        $signup_ok = true;
    }
    else if ( !$ok )
    {
        $Error[] = $LANG_msg['signup_008'];
    }
    else
    {
        $Error[] = $LANG_msg['signup_009'];
    }
}
else if ( isset( $section ) && $section == "do_update" && ( session_active( ) && ( !$demo_mode && session_admin( ) ) ) )
{
    $ok = check_exist_edit( $uid );
    $e_pass = db_get_id( "select alt_password from {$_users_details} where uid='{$uid}' and suspended='0'" );
    if ( $def_user_alternate_pass_enable && $e_pass != crypt( $_POST['altpassword'], $e_pass ) )
    {
        $Error[] = $LANG_msg['withdraw_008'];
    }
    if ( eregi( "([%|\$|\\'|\"|\\])", $_POST['password0'] ) )
    {
        $Error[] = $LANG_msg['signup_025'];
    }
    if ( !$_POST['password0'] || strlen( $_POST['password0'] ) < 5 || $_POST['password0'] != $_POST['password1'] )
    {
        $Error[] = $LANG_msg['signup_012'];
    }
    if ( !$_POST['mail'] || !eregi( ".+@.+\\..+", $_POST['mail'] ) )
    {
        $Error[] = $LANG_msg['signup_016'];
    }
    if ( ( !$_POST['money_account'] || strlen( $_POST['money_account'] ) < 4 ) && !session_admin( ) )
    {
        $Error[] = $LANG_msg['signup_026'];
    }
    if ( $ok && empty( $Error ) )
    {
        $v_password = crypt( $_POST['password0'] );
        $q_no_pwd = "";
        $q_pwd = "update {$_users} set password='{$v_password}' where uid='{$uid}'";
        if ( $CONFIG['update_currency'] == true )
        {
            $more_sql = " cid='{$cid}', ";
        }
        $q_det = "update {$_users_details} set money_account='{$money_account}', {$more_sql} email='{$mail}', Zip='{$Zip}' ,Phone='{$Phone}' ,State='{$State}' ,City='{$City}' ,StreetAddress='{$StreetAddress}' ,Country_short='{$country}' where uid='{$uid}'";
        if ( $check == 1 )
        {
            db_exec( $q_det );
            if ( !session_admin( ) )
            {
                header( "Location: ".get_link( "status.php?message=profile" ) );
            }
            $Success[] = $LANG_msg['signup_027'];
        }
        else if ( $check == 2 )
        {
            if ( $q_pwd )
            {
                db_exec( $q_pwd );
            }
            db_exec( $q_det );
            if ( !session_admin( ) )
            {
                header( "Location: ".get_link( "status.php?message=profile" ) );
            }
            $Success[] = $LANG_msg['signup_027'];
        }
        else
        {
            $Error[] = $LANG_msg['signup_010'];
        }
    }
    else if ( empty( $Error ) )
    {
        $Error[] = $LANG_msg['signup_011'];
    }
}
else if ( session_active( ) )
{
    $title = $LANG_msg['signup_001'];
    if ( !db_if_exists( "select uid from {$_users_details} where uid='{$uid}'" ) )
    {
        db_exec( "insert into {$_users_details} (uid,reg_date) values ('{$uid}',now())" );
    }
    $nvar = db_get_array( "select fullname, money_account, cid, email, Zip, Phone, State, City, StreetAddress, Country_short from {$_users_details} where uid='{$uid}'" );
    $fullname = $nvar[0];
    $money_account = $nvar[1];
    $cid = $nvar[2];
    $mail = $nvar[3];
    $Zip = $nvar[4];
    $Phone = $nvar[5];
    $State = $nvar[6];
    $City = $nvar[7];
    $StreetAddress = $nvar[8];
    $country = $nvar[9];
    $suser = $_SESSION['user_login'];
    $Post['money_account'] = $money_account;
    $Post['cid'] = $cid;
    $Post['mail'] = $mail;
    $_POST['Zip'] = $Zip;
    $_POST['Phone'] = $Phone;
    $_POST['State'] = $State;
    $_POST['City'] = $City;
    $_POST['StreetAddress'] = $StreetAddress;
    $Post['country'] = $country;
    $Post['suser'] = $suser;
}
else
{
    $cid = $def_money_used;
}
if ( session_active( ) )
{
    $submit = $str_tool->remove_dangerous_chars( $LANG_msg['signup_018'] );
}
else
{
    $submit = $str_tool->remove_dangerous_chars( $LANG_msg['signup_019'] );
}
if ( !isset( $title ) )
{
    $title = $LANG_msg['signup_043'];
}
if ( $section == "do_update" && $demo_mode )
{
    $Error_div[] = "Some features are not active in Demo Version.";
}
if ( $rid && db_if_exists( "SELECT login FROM {$_users} WHERE uid='{$rid}'" ) )
{
    $have_referral = true;
    $referral_name = db_get_id( "SELECT login FROM {$_users} WHERE uid='{$rid}'" );
}
if ( !$country )
{
    $country = GetCountry_csv( $_SERVER['REMOTE_ADDR'], true );
}
$query = "select countries_iso, countries_name from {$_countries}";
$result = db_query( $query, "&nbsp;" );
$arr_data_country = mysql_push_data( $result );
db_free_result( $result );
echo "\r\n";
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."signup.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "signup.html";
    $page->assign( "signup_ok", $signup_ok );
    $page->assign( "referral_name", $referral_name );
    $page->assign( "altpass_enable", $def_user_alternate_pass_enable );
    $page->assign( "submit", $submit );
    $page->assign( "title", $title );
    $page->assign( "rid", $rid );
    $page->assign( "user_login", $user_login );
    $page->assign( "Post_country", $_POST['country'] );
    $page->assign( "currencies_FNAME", $currencies_FNAME );
    $page->assign( "Post_cid", $Post['cid'] );
    $page->assign( "merchant_name", $merchant_name );
    foreach ( $arr_data_country as $key => $value )
    {
        $arr_countries[$arr_data_country[$key]['countries_iso']] = $arr_data_country[$key]['countries_name'];
    }
    $page->assign( "arr_countries", $arr_countries );
    require( "include/engine_run.php" );
}
?>
