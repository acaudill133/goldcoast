<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_stringwordcut( $sText, $iMaxLength = 50, $sMessage = "..." )
{
    if ( $iMaxLength < strlen( $sText ) )
    {
        $sString = wordwrap(  );
        $asExplodedString = explode( "[cut]", $sString );
        echo $sCutText = $asExplodedString[0];
        $sReturn = $sCutText.$sMessage;
    }
    else
    {
        $sReturn = $sText;
    }
    return $sReturn;
}

?>
