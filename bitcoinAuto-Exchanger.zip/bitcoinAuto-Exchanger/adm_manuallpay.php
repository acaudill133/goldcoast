<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function form_header( $url )
{
    global $id;
    global $demo_mode;
    echo "<form name=\"pay\" action=\"{$url}\" method=\"post\">\n";
    echo "<input type=\"hidden\" value=\"{$id}\" name=\"id\">\n";
}

function form_footer( $caption )
{
    global $merchant_name;
    global $demo_mode;
    if ( $demo_mode )
    {
        $Error_div[] = "Some features are not active in Demo Version.";
        $disabled = "disabled";
        echo "<span class=ErrorMessage>Some features are not active in Demo Version.</span><br>";
    }
    echo "<input type=\"submit\" class=\"btn\" value=\"Pay by {$merchant_name}\" {$disabled} >\n";
    echo "</form>\n";
}

require( "public.inc.php" );
if ( !session_admin( ) )
{
    @header( "Location: ".$CONFIG['SITE_URL'] );
}
$subject = $LANG_msg['pay_013'];
$user = $_GET['user'];
$act = $_GET['act'];
$id = $_GET['id'];
$amount = $_GET['amount'];
$payee_account = $_GET['account'];
$cid = $_GET['cid'];
$process = $_GET['process'];
$bulk = $_POST['bulk'];
$type = $_GET['Type'];
echo "<link rel=\"stylesheet\" href=\"";
echo $CONFIG['SKIN_CSS'];
echo "/style.php?URL=";
echo $CONFIG['SKIN_IMAGES'];
echo "\" media=\"screen\">\t\t\r\n<link rel=\"stylesheet\" href=\"";
echo $CONFIG['SKIN_CSS'];
echo "/admin.css\" media=\"screen\">\r\n<DIV class=\"BoxStyle1\">\r\n";
if ( isset( $act ) && $act == "accept" && $id )
{
    do
    {
        do
        {
            $merchant_name = convert_emoney( $cid );
            if ( $type == "withdraw" )
            {
                db_exec( "update {$_lines} set status='{$STATUS_ENUM_ENABLE}', pmt_note=CONCAT(pmt_note,' - Withdraw {$LANG_msg['note_exchange4']}'), amount=-abs(amount), exchange=-abs(exchange) where id='{$id}' and pmt_type='{$TRANS_ENUM_WITHDRAW}' and status='{$STATUS_ENUM_DISABLE}'" );
            }
            else if ( $type == "exchange" )
            {
                db_exec( "update {$_exchange_lines} set dst_status='{$STATUS_ENUM_ENABLE}', exchange_note=CONCAT(exchange_note, ' - Exchange {$LANG_msg['note_exchange4']}'), dst_date=now() WHERE eid='{$id}' AND dst_status='{$STATUS_ENUM_DISABLE}'" );
            }
            else if ( $type == "buysell" )
            {
                db_exec( "update {$_orders} set dst_status='{$STATUS_ENUM_ENABLE}', order_note=CONCAT(order_note, ' - Order {$LANG_msg['note_exchange4']}'), dst_date=now() WHERE oid='{$id}' AND dst_status='{$STATUS_ENUM_DISABLE}'" );
            }
            echo "<center>\r\n\t<div id=page_title><center><h1>Manuall payout</h1></center></div>";
            if ( $amount == "ask" )
            {
                echo "Please wnter amount you want pay for (#{$id}) in below field: <b><br><img src='".$CONFIG['SKIN_IMAGES']."/bank_images/".$merchant_name."_4.gif'></b><br><br>";
            }
            else
            {
                echo "You are paying <b>\${$amount}</b> (#{$id}) Via: <b><br><img src='".$CONFIG['SKIN_IMAGES']."/bank_images/".$merchant_name."_4.gif'></b><br><br>";
            }
            echo "<span class=ErrorMessage>Note: You have marked this payment as paid.</span><br><br>\n";
            echo "<br /><span class=SuccessMessage><a href='{$_SERVER['PHP_SELF']}?Type={$_GET['Type']}&process=no&id={$id}' style='font-size:14px'>".$LANG_msg['general_click']."</a>\n";
            echo "to cancel manual payment and mark it as pending again</span><br><br />";
            echo "<br /><b>OR start manual payout</b><br />";
            $nvar = db_get_array( "SELECT currency_name, currency_worth_value, currency_worth_name, currency_metal_value, currency_metal_name, currency_merchant_url FROM {$_currencies} WHERE cid=''" );
            $merchant_name = $nvar[0];
            $arr_PAYMENT['WORTH_VALUE'] = $nvar[1];
            $arr_PAYMENT['WORTH_NAME'] = $nvar[2];
            $arr_PAYMENT['METAL_VALUE'] = $nvar[3];
            $arr_PAYMENT['METAL_NAME'] = $nvar[4];
            $MERCHANT_URL = $nvar[5];
            $suggested_memo = "Pay to [{$user}] by {$Var_3864['SITE_NAME']}";
            $response_ok = "{$CONFIG['SITE_URL_SECURE']}/adm_manuallpay.php?Type={$type}&id={$id}&process=yes&";
            $response_no = "{$CONFIG['SITE_URL_SECURE']}/adm_manuallpay.php?Type={$type}&id={$id}&process=no&";
            $status_url = "{$CONFIG['SITE_URL_SECURE']}/adm_manuallpay.php";
            $payment_id = $id;
            switch ( $merchant_name )
            {
            case "e-gold" :
                require( "hsh_bnk/atp_egold.php" );
                break;
            case "e-bullion" :
                require( "hsh_bnk/atp_ebullion.php" );
                break;
            case "pecunix" :
                require( "hsh_bnk/atp_pecunix.php" );
                break;
            case "moneybookers" :
                require( "hsh_bnk/atp_moneybookers.php" );
                break;
            case "libertyreserve" :
                require( "hsh_bnk/atp_liberty.php" );
                break;
            case "alertpay" :
                require( "hsh_bnk/atp_alert.php" );
                break;
            case "v-money" :
                require( "hsh_bnk/atp_vmoney.php" );
                break;
            case "webmoney" :
                require( "hsh_bnk/atp_webmoney.php" );
                break;
            case "perfectmoney" :
                require( "hsh_bnk/atp_perfectmoney.php" );
                break;
            case "altergold" :
                require( "hsh_bnk/atp_altergold.php" );
                break;
            case "c-gold" :
                require( "hsh_bnk/atp_cgold.php" );
                break;
            case "paypal" :
                require( "hsh_bnk/atp_paypal.php" );
                break;
            case "debit card" :
                $Error[] = "Debit and Credit cards have not Shopping card system!, This Order marked as paid.";
                break;
            default :
                $Error[] = "INCORRECT CURRENCY ID";
            }
            if ( !$Error && $MERCHANT_URL )
            {
                form_header( $MERCHANT_URL );
            }
            if ( !$Error && $MERCHANT_URL )
            {
                form_footer( $LANG_msg['pay_005'] );
            }
        }
        else
        {
            if ( $process == "yes" )
            {
                $id = $_REQUEST['id'];
                $arr_PAYMENT['BATCH'] = $_REQUEST['PAYMENT_BATCH_NUM'].$_REQUEST['lr_transfer'].$_POST['ATIP_TRANSACTION_ID'].$_POST['PAYMENT_REC_ID'].$_POST['LMI_SYS_TRANS_NO'].$_POST['PMT_BATCH_NUM'];
                db_exec( "UPDATE {$_lines} SET pmt_note=CONCAT(pmt_note,' - Withdraw {$LANG_msg['note_exchange5']} #{$arr_PAYMENT['BATCH']}, {$accept_date}') WHERE id='{$id}' and pmt_type='{$TRANS_ENUM_WITHDRAW}' and status='{$STATUS_ENUM_ENABLE}'" );
                SEND_WITHDRAW_MAIL( $id );
                if ( $type == "exchange" && $id )
                {
                    db_exec( "UPDATE {$_exchange_lines} SET exchange_note=CONCAT(exchange_note, ' - Exchange {$LANG_msg['note_exchange5']} - {$accept_date}') , dst_batch='{$arr_PAYMENT['BATCH']}', dst_date=now() WHERE eid='{$id}' AND dst_status='{$STATUS_ENUM_ENABLE}'" );
                    SEND_EXHCANGE_MAIL( $id, "complete" );
                    break;
                }
                else if ( !( $type == "buysell" ) )
                {
                    break;
                }
                else
                {
                    db_exec( "UPDATE {$_orders} SET order_note=CONCAT(order_note, ' - Order {$LANG_msg['note_exchange5']} - {$accept_date} #{$arr_PAYMENT['BATCH']}'), dst_date=now() WHERE oid='{$id}' AND dst_status='{$Var_6816}'" );
                    SEND_ORDER_MAIL( $id, "complete" );
                }
            }
            if ( !( $process == "no" ) )
            {
                break;
            }
            if ( $id )
            {
                if ( $type == "withdraw" )
                {
                    db_exec( "update {$_lines} set status='{$STATUS_ENUM_DISABLE}', pmt_note=CONCAT(pmt_note,' - Withdraw {$LANG_msg['note_exchange5']}({$accept_date})') where id='{$id}' and pmt_type='{$TRANS_ENUM_WITHDRAW}' and status='{$STATUS_ENUM_ENABLE}'" );
                }
                else if ( $type == "exchange" )
                {
                    db_exec( "update {$_exchange_lines} set dst_status='{$STATUS_ENUM_DISABLE}', exchange_note=CONCAT(exchange_note,  - Exchange {$LANG_msg['note_exchange5']}({$accept_date})'), dst_date='' WHERE eid='{$id}' AND dst_status='{$STATUS_ENUM_ENABLE}'" );
                }
                else if ( $type == "buysell" )
                {
                    db_exec( "UPDATE {$_orders} SET dst_status='{$STATUS_ENUM_DISABLE}', order_note=CONCAT(order_note, ' - Order {$LANG_msg['note_exchange5']}({$accept_date})'), dst_date='' WHERE oid='{$id}' AND dst_status='{$STATUS_ENUM_ENABLE}'" );
                }
            }
            echo "<h2>Money did not send to member account and request marked as not paid.</h2><br>";
            echo "<a href='javascript:window.close();'>Click here</a> to close window.";
        } while ( 0 );
    } while ( 0 );
}
echo "\r\n";
echo show_page_messages( );
echo "</DIV>\r\n";
db_close( $dbconn );
?>
