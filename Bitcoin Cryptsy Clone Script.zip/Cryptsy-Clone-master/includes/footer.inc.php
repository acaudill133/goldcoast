    <footer>
      <div class="container">
        <div class="row">
          <div class="col-xs-6 copyrights">
            <p>&copy; 2014 Crypto Maniac Inc  -  All Rights Reserved</p>
          </div>
          <div class="col-xs-6 nav">
            <ul class="nav nav-pills pull-right"> 
              <li><a href="/legal/terms.php" title="Terms">Terms</a></li>
              <li><a href="/legal/privacy-policy.php" title="Privacy Policy">Privacy Policy</a></li>
              <li><a href="/api/api.php?pair=DOGE-LTC&range=month" title="API">Public API</a></li>
              <li><a href="/legal/security.php" title="About">About our Security</a></li>
              <li><a href="/info/about" title="About">About</a></li>
            </ul>
          </div>
        </div>
      </div>
    </footer> 