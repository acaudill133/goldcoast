<?php
ob_start();
session_start();
error_reporting(0);
include("../includes/config.php");
$db = new mysqli($CONF['host'], $CONF['user'], $CONF['pass'], $CONF['name']);
if ($db->connect_errno) {
    echo "Failed to connect to MySQL: (" . $db->connect_errno . ") " . $db->connect_error;
}
$db->set_charset("utf8");
$settingsQuery = $db->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
$settings = $settingsQuery->fetch_assoc();
include("../includes/functions.php");
include(getLanguage($settings['url'],null,2));
$send = protect($_POST['send']);
$receive = protect($_POST['receive']);
$amount = protect($_POST['amount']);
$currency = protect($_POST['currency']);

if(empty($send) or empty($receive) or empty($amount) or empty($currency)) { echo error("Please complete form."); }
elseif(!is_numeric($amount)) { echo error("Please enter valid amount. Eg: 100 or 99.99"); }
elseif($settings['exchminamount'] > $amount) { echo error("Minimal amount is $settings[exchminamount] $currency."); }
else {
	$c1sql = $db->query("SELECT * FROM companies_list_receive WHERE id='$receive' and cid='$send'");
	$c1 = $c1sql->fetch_assoc();
	$receive_amount = $amount * $c1['exchange_rate'];
	?>
	<form action="" method="POST" id="become_exchange_form">
		<div class="form-group">
			<label><?php echo $lang['receive_amount']; ?> <small><?php echo $lang['exchange_rate']; ?>: 1 <?php echo $currency; ?> = <?php echo $c1['exchange_rate']." ".$currency; ?></small></label>
			<input type="text" class="form-control input-lg" name="receive_amount" id="receive_amount" value="<?php echo $receive_amount; ?>" disabled>
		</div>
		<div class="form-group">
			<label><?php echo $lang['f_your']; ?> <?php echo $c1['name']; ?> <?php echo $lang['f_account']; ?></label>
			<input type="text" class="form-control input-lg" name="account" id="account">
		</div>
		<div class="form-group">
			<label><?php echo $lang['your_email']; ?></label>
			<input type="text" class="form-control input-lg" name="email" id="email" value="<?php if(checkSession()) { echo idinfo($_SESSION['suid'],"email"); } ?>">
		</div>
		<input type="hidden" name="send" value="<?php echo $send; ?>">
		<input type="hidden" name="receive" value="<?php echo $receive; ?>">
		<input type="hidden" name="amount" value="<?php echo $amount; ?>">
		<input type="hidden" name="currency" value="<?php echo $currency; ?>">
		<button type="button" class="btn btn-primary btn-lg btn-block" onclick="validateForm();"><i class="fa fa-mail-forward"></i> <?php echo $lang['btn_9']; ?></button>
	</form>
	<?php
}
?>