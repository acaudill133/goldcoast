<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "public.inc.php" );
if ( !session_admin( ) )
{
    @header( "Location: ".$CONFIG['SITE_URL'] );
}
$ramz = new RamzNegar( );
if ( $_POST['Action'] == "Save" && $demo_mode )
{
    $Error_div[] = "You can not change some settings in Demo Version.";
}
$demo_mode_allowfields = array( "FULL_REGISTRATION", "LOGIN_TURNING", "SUPPORT_TURNING", "SIGNUP_TURNING", "EXCHANGE_REF_COMISSION", "MIN_EXCHANGE_FEE", "gpg_path", "FRIENDLY_URL", "SITE_TEMPLATE", "MAIL_FORMAT", "adminemailnotification", "NEWS_NUMBER", "recordsnumperpage" );
#}
if ( $_POST['Action'] == "Save" && $_POST['submit'] )
{
    foreach ( $_POST as $key => $value )
    {
        if ( $key != "submit" && $key != "Action" && $key != "selectedtab" && !empty( $key ) )
        {
            if ( $key == "MAIL_SMTP_PASS" )
            {
                $value = $ramz->encrypt( ramzkey( "number1" ), $value );
            }
            if ( $key == "SITE_TEMPLATE" && $value != $CONFIG['SITE_TEMPLATE'] && !$recache )
            {
                $recache = true;
            }
            $SQL = "UPDATE ".$_settings." SET value='".$value."' WHERE setting='".$key."'";
            if ( !$demo_mode )
            {
                db_exec( $SQL );
            }
            else if ( $demo_mode && in_array( $key, $demo_mode_allowfields ) )
            {
                db_exec( $SQL );
            }
        }
        $$fieldname = trim( $value );
    }
    $Success[] = "Site settings updated successfully.";
    if ( $recache )
    {
        @header( "Location: ".@get_link( $cur_page."?recache=true" ) );
    }
    else
    {
        empty_cache_folder( );
    }
}
$query = "SELECT * FROM {$_settings}";
$result = db_query( $query, "&nbsp;" );
while ( $line = db_fetch_array( $result ) )
{
    $key = $line['setting'];
    $value = $line['value'];
    $$key = "".$value;
}
db_free_result( $result );
$templates = list_dirs( $Template_folder );
foreach ( $templates as $key => $value )
{
    if ( $value != "uploads" )
    {
        if ( file_exists( $Template_folder."/".$value."/tplimgs/"."_preview.jpg" ) )
        {
            $Template_rows .= "<div style=\"float:left; text-align:center; padding:15px;\"><img src=\"".$CONFIG['SITE_URL']."/".$Template_folder."/".$value."/tplimgs/_preview.jpg\" width=\"160\" height=\"124\" alt=\"".ucfirst( $value )."\" /><br>";
        }
        else
        {
            $Template_rows .= "<div style=\"float:left; text-align:center; padding:15px;\"><img src=\"".$CONFIG['SKIN_IMAGES']."/ico/no_image.gif\" width=\"160\" height=\"124\" alt=\"".ucfirst( $value )."\" /><br>";
        }
        $Template_rows .= "<input name=\"SITE_TEMPLATE\" type=\"radio\" value=\"".$value."\"   class=\"nostyle\" ".( $CONFIG['SITE_TEMPLATE'] == $value ? "checked=\"checked\"" : "" )."/>".ucfirst( $value )."</div>";
    }
}
echo "\r\n";
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."adm_settings.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "adm_settings.html";
    $page->assign( "arr_MailFormat", array( "text" => "Text", "html" => "Html" ) );
    $page->assign(  );
    $page->assign( "arr_CHOOSE", array( "1" => "Yes", "0" => "No" ) );
    $query = "SELECT * FROM {$_settings}";
    $result = db_query( $query, "&nbsp;" );
    while ( $line = db_fetch_array( $result ) )
    {
        if ( $line['setting'] == "MAIL_SMTP_PASS" )
        {
            $line['value'] = $ramz->decrypt( ramzkey( "number1" ), $line['value'] );
        }
        $setting = $line['setting'];
        $page->assign( $setting, $line['value'] );
    }
    db_free_result( $result );
    $page->assign( "Template_rows", $Template_rows );
    $page->assign( "Post_selectedtab", $_POST['selectedtab'] );
    $page->assign( "arr_lang_box", $lang );
    require( "include/engine_run.php" );
}
?>
