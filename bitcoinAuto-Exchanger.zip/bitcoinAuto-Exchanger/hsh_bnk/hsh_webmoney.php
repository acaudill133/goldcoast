<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

chdir( "../" );
include( "include/config.inc.php" );
$LMI_MODE = $_POST['LMI_MODE'];
$LMI_PAYMENT_AMOUNT = $_POST['LMI_PAYMENT_AMOUNT'];
$LMI_PAYEE_PURSE = $_POST['LMI_PAYEE_PURSE'];
$LMI_PAYER_WM = $_POST['LMI_PAYER_WM'];
$LMI_PAYER_PURSE = $_POST['LMI_PAYER_PURSE'];
$LMI_SYS_INVS_NO = $_POST['LMI_SYS_INVS_NO'];
$LMI_SYS_TRANS_NO = $_POST['LMI_SYS_TRANS_NO'];
$LMI_SYS_TRANS_DATE = $_POST['LMI_SYS_TRANS_DATE'];
$LMI_HASH = $_POST['LMI_HASH'];
$PAYMENT_ID = $_POST['LMI_PAYMENT_NO'];
if ( $_POST['LMI_PAYMENT_AMOUNT'] )
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    $arr_WEBMONEY = get_currency_data( "", "webmoney", "", "", $LMI_PAYEE_PURSE );
    $ramz = new RamzNegar( );
    $arr_WEBMONEY['ALT_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_WEBMONEY['ALT_PASSWORD'] );
}
$v2_array = array(
    $_POST['LMI_PAYEE_PURSE'],
    $_POST['LMI_PAYMENT_AMOUNT'],
    $_POST['LMI_PAYMENT_NO'],
    $_POST['LMI_MODE'],
    $_POST['LMI_SYS_INVS_NO'],
    $_POST['LMI_SYS_TRANS_NO'],
    $_POST['LMI_SYS_TRANS_DATE'],
    $arr_WEBMONEY['ALT_PASSWORD'],
    $_POST['LMI_PAYER_PURSE'],
    $_POST['LMI_PAYER_WM']
);
$v2_hash = strtoupper( md5( implode( "", $v2_array ) ) );
if ( $LMI_MODE == 1 )
{
    $Message_log[] = "Test Transfer Mode, Turn it off from your webmoney panel first, {$v2_hash} == {$_POST['LMI_HASH']}";
}
if ( $v2_hash == $_POST['LMI_HASH'] )
{
    $Message_log[] = "WEBMONEY hash accepted";
}
if ( $v2_hash == $_POST['LMI_HASH'] && $LMI_MODE == 0 )
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    if ( Refrence2eid( $PAYMENT_ID ) )
    {
        $Message_log[] = "WEBMONEY EXCHANGE MODE";
        if ( $_POST['LMI_PAYEE_PURSE'] == $arr_WEBMONEY['ACCOUNT'] && db_if_exists( "SELECT eid FROM {$_exchange_lines} WHERE exchange_refrence='{$PAYMENT_ID}' AND src_amount='{$LMI_PAYMENT_AMOUNT}' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}'" ) )
        {
            SEND_EXHCANGE_MAIL( $PAYMENT_ID, "receive" );
            commit_exchange( $PAYMENT_ID, $LMI_SYS_TRANS_NO, $LMI_PAYER_PURSE );
            $Message_log[] = "WEBMONEY ADD TO DATABSE EXCHANGE";
        }
    }
    else
    {
        $Message_log[] = "INVEST MODE";
        if ( $_POST['LMI_PAYEE_PURSE'] == $arr_WEBMONEY['ACCOUNT'] && db_if_exists( "SELECT * FROM {$_lines} WHERE id='{$PAYMENT_ID}' AND amount='{$LMI_PAYMENT_AMOUNT}' AND status='{$STATUS_ENUM_DISABLE}' AND pmt_type='{$TRANS_ENUM_SPEND}'" ) )
        {
            SEND_INVEST_RECEIVE_MAIL( $PAYMENT_ID, $LMI_PAYER_PURSE );
            commit_transaction( $PAYMENT_ID, $LMI_SYS_TRANS_NO );
            $Message_log[] = "WEBMONEY ADD TO DATABSE INVEST";
        }
    }
    $Message_log[] = "WEBMONEY  HASH ACCEPTED";
    db_close( $dbconn );
}
Write_File( );
unset( $arr_WEBMONEY );
exit( );
?>
