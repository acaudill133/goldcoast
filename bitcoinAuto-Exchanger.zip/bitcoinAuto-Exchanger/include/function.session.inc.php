<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function login_check( $c_user, $c_pass, $db_opened = true )
{
    global $REMOTE_ADDR;
    global $_users;
    global $sid;
    global $language;
    global $_users_details;
    global $_logs;
    global $def_monitor_logins;
    if ( !$db_opened )
    {
        $dbconn = db_open( );
    }
    $nvar = db_get_array( "Select uid, login, password, permit, status, language\tFrom {$_users} Where login = '{$c_user}'" );
    $uid = $nvar[0];
    $login = $nvar[1];
    $password = $nvar[2];
    $permit = $nvar[3];
    $status = $nvar[4];
    $language = $nvar[5];
    if ( $Var_1296 == $password )
    {
        $nvar[6] = db_get_id( "Select fullname FROM {$_users_details} WHERE uid='{$uid}'" );
        $fullname = $nvar[6];
        $ret = array(
            "uid" => $uid,
            "permit" => $permit,
            "status" => $status,
            "language" => $language,
            "fullname" => $fullname,
            "user_login" => $c_user
        );
        db_exec( "UPDATE {$_users} SET ip='{$REMOTE_ADDR}',date=NOW(), session_id='{$sid}' WHERE uid='{$uid}'" );
        db_exec( "INSERT into {$_logs} (uid, ip, login_date, login_attempts, session_id) VALUES ('{$uid}', '{$REMOTE_ADDR}',now(), '1', '{$sid}')" );
    }
    else
    {
        $ret = false;
    }
    if ( !$db_opened )
    {
    }
    return $ret;
}

function login_refresh( )
{
    global $user_status;
    global $permit;
    global $uid;
    global $_users;
    global $sid;
    global $PMT_INFO_ADMIN;
    global $STATUS_ENUM_ENABLE;
    if ( isset( $_SESSION['uid'] ) )
    {
        if ( $uid == 1 )
        {
            $user_status = $STATUS_ENUM_ENABLE;
            $permit = $PMT_INFO_ADMIN;
        }
        else
        {
            $nvar = db_get_array( "select status,permit from {$_users} where uid='{$uid}' AND session_id='{$sid}" );
            $user_status = $nvar[0];
            $permit = $nvar[1];
        }
    }
    else
    {
        $user_status = "";
        $permit = "";
    }
}

function session_active( )
{
    global $site_identifier;
    global $CONFIG;
    global $_users;
    global $sid;
    global $db_opened;
    global $Error_div;
    global $demo_mode;
    if ( !$db_opened )
    {
        $dbconn = db_open( );
    }
    $nvar = db_get_id( "select permit from {$_users} where session_id='{$sid}' AND uid='".$_SESSION['uid']."'" );
    if ( $nvar )
    {
        return isset( $_SESSION['uid'], $_SESSION['permit'] ) && $_SESSION['site_identifier'] == $CONFIG['SITE_NAME'];
    }
    if ( $_SESSION['uid'] && !$nvar )
    {
        if ( count( $Error_div ) < 1 )
        {
            $Error_div[] = "Someone logged in to admin panel, or session time expired, if you are not sure log in again and change your passwords immediatly";
        }
        return false;
    }
}

function session_admin( )
{
    global $permit;
    return session_active( ) && $permit == $PMT_INFO_ADMIN;
}

function session_member( )
{
    global $permit;
    global $PMT_INFO_MEMBER;
    return session_active( ) && $permit == $PMT_INFO_MEMBER;
}

function make_session_register( )
{
    global $site_identifier;
    global $CONFIG;
    global $user_login;
    global $uid;
    global $permit;
    global $user_status;
    global $fullname;
    $_SESSION['site_identifier'] = $CONFIG['SITE_NAME'];
    $_SESSION['user_login'] = $user_login;
    $_SESSION['uid'] = $uid;
    $_SESSION['permit'] = $permit;
    $_SESSION['user_status'] = $user_status;
    $_SESSION['fullname'] = $fullname;
}

function make_session_unregister( )
{
    global $_logs;
    global $uid;
    global $def_monitor_logins;
    global $sid;
    unset( $_SESSION['site_identifier'] );
    unset( $_SESSION['user_login'] );
    unset( $_SESSION['uid'] );
    unset( $_SESSION['permit'] );
    unset( $_SESSION['user_status'] );
    unset( $_SESSION['fullname'] );
}

if ( isset( $_SESSION['uid'] ) )
{
    $site_identifier = $_SESSION['site_identifier'];
    $user_login = $_SESSION['user_login'];
    $uid = $_SESSION['uid'];
    $permit = $_SESSION['permit'];
    $user_status = $_SESSION['user_status'];
    $fullname = $_SESSION['fullname'];
}
?>
