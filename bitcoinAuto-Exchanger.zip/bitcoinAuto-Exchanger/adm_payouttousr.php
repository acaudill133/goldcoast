<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function auto_payout_status( $cid )
{
    global $_currencies;
    return db_get_id( "SELECT payout_automatic FROM {$_currencies} WHERE cid='{$cid}'" );
}

require( "public.inc.php" );
if ( !session_admin( ) )
{
    @header( "Location: ".$CONFIG['SITE_URL'] );
}
if ( $_GET['money_sent'] == true )
{
    if ( db_if_exists( "SELECT id FROM {$_lines} WHERE id='{$_GET['id']}' AND pmt_type='{$TRANS_ENUM_WITHDRAW}' AND status='{$STATUS_ENUM_DISABLE}'" ) )
    {
        if ( db_exec( "UPDATE {$_lines} SET status='{$STATUS_ENUM_ENABLE}', pmt_note=CONCAT(pmt_note,' - {$LANG_msg['note_exchange4']}'), amount=-abs(amount), exchange=-abs(exchange) WHERE id='{$_GET['id']}' AND pmt_type='{$TRANS_ENUM_WITHDRAW}' AND status='{$STATUS_ENUM_DISABLE}'" ) )
        {
            SEND_WITHDRAW_MAIL( $_GET['id'] );
            $Success[] = "Withdraw request mark as paid and mail has been sent.";
        }
    }
    else
    {
        $Error[] = "You don't have any not paid withdraw request with this id: {$_GET['id']} ";
    }
}
$key = $_GET['key'];
$order = $_GET['order'];
if ( !$order )
{
    $order = "ASC";
}
if ( !$key )
{
    $key = "l.date";
}
$key = $key." ".$order;
if ( $order == "Asc" )
{
    $write_order = "Desc";
}
else
{
    $write_order = "Asc";
}
if ( $INVEST_SECTION )
{
    $section = "Invest_Static";
    include( "include/box_includes.php" );
}
$count = $n;
$no = 0;
$sum = 0;
$query = "select u.uid,u.login,u.status,l.id, date_format(l.date,'%Y-%m-%d') as day, d.money_account, d.cid, d.fullname, l.pmt_note, l.exchange, l.cid from {$_users} u, {$_users_details} d, {$_lines} l\r\nwhere u.permit='{$PMT_INFO_MEMBER}' and l.uid=u.uid and d.uid=u.uid and l.date<now() and l.pmt_type='{$TRANS_ENUM_WITHDRAW}' and l.status='{$STATUS_ENUM_DISABLE}' order by {$key} ";
$page = $_GET['page'];
$total = mysql_num_rows( mysql_query( $query ) );
$perpage = $CONFIG['recordsnumperpage'];
$url_string = get_link( $cur_page.( $CONFIG['FRIENDLY_URL'] ? "" : "?" ).preg_replace( "/(&)page(\\/^|=)\\d+/", "", $_SERVER['QUERY_STRING'] ) );
$pager = new pager( $total, $perpage, $url_string, $CONFIG['FRIENDLY_URL'] );
if ( empty( $page ) )
{
    $page = 1;
}
$from = $pager->getPageFrom( $page );
$query = $query." limit {$from}, {$perpage}";
$result = db_query( $query, "&nbsp;" );
$arr_data_payusers = mysql_push_data( $result );
db_free_result( $result );
if ( !count(  ) )
{
    $Error[] = "There is pending comission to payout";
}
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."adm_payouttousr.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "adm_payouttousr.html";
    $page->assign( "write_order", $write_order );
    $result = db_query( "select cid, currency_name, currency_worth_name from {$_currencies}", "&nbsp;" );
    while ( $line = db_fetch_array( $result ) )
    {
        $All_currencies_name[$line['cid']] = $line['currency_name'];
        $All_currencies_worth[$Var_4488] = $line['currency_worth_name'];
    }
    db_free_result( $result );
    foreach ( $arr_data_payusers as $key => $value )
    {
        $arr_data_payusers[$key]['auto_payout_status'] = auto_payout_status( $arr_data_payusers[$key]['cid'] );
        $arr_data_payusers[$key]['exchange'] = 0 - $arr_data_payusers[$key]['exchange'];
        $arr_data_payusers[$key]['amount'] = FormatPrice( $arr_data_payusers[$key]['exchange'], 2 );
        $arr_data_payusers[$key]['dst_worth'] = $All_currencies_worth[$arr_data_payusers[$key]['cid']];
        $arr_data_payusers[$key]['status'] = convert_status( $arr_data_payusers[$key]['status'] );
        $arr_data_payusers[$key]['emoney'] = ucfirst( $All_currencies_name[$arr_data_payusers[$key]['cid']] );
        $page_sum = $page_sum + $arr_data_payusers[$key]['exchange'];
    }
    $page->assign( "arr_data_payusers", $arr_data_payusers );
    $page->assign( "t", $t );
    $page->assign( "page_sum", set_money_color( FormatPrice( $page_sum, 1 ) ) );
    $page->assign( "total", $total );
    if ( $perpage < $total )
    {
        $pg = $pager->page;
        $page_navigation .= $Var_7200->getButPrev( $pg );
        $range = 20;
        $page_navigation .= $pager->getButList( $range );
        $page_navigation .= $pager->getButNext( $pg );
        $page_navigation .= "<br><br><br>";
        $page_navigation .= $pager->getRangeInfo( );
    }
    $page->assign( "page_navigation", $page_navigation );
    $page->assign( "Rate_Row", $Rate_Row );
    require( "include/engine_run.php" );
}
?>
