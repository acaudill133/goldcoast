<?php
$c = protect($_GET['c']);
if($c == "result") {
	require_once 'includes/webmoney.inc.php';

	  $wm_prerequest = new WM_Prerequest();
	  if ($wm_prerequest->GetForm() == WM_RES_OK)
	  {
		 $orderid = $wm_prerequest->payment_no;
		   $merchant = $wm_prerequest->payee_purse;
		   $amount = $wm_prerequest->payment_amount;
		   $trans_id = $wm_prerequest->sys_trans_no;
		   $date = $wm_prerequest->sys_trans_date;
		   $payer = $wm_prerequest->payer_wm;
		   $query = $db->query("SELECT * FROM exchanges WHERE id='$orderid'");
		if($query->num_rows==0) { header("Location: $settings[url]"); }
		$row = $query->fetch_assoc();
		$query1 = $db->query("SELECT * FROM companies_list WHERE id='$row[c_send]'");
		$row1 = $query1->fetch_assoc();
		if(checkSession()) { $uid = $_SESSION['suid']; } else { $uid = 0; }
		$check_trans = $db->query("SELECT * FROM transactions WHERE tid='$trans_id' and date='$date' and uid='$uid'");
		if (
		  $wm_prerequest->payment_no == $row['id'] &&
		  $wm_prerequest->payee_purse == $row1['account'] &&
		  $wm_prerequest->payment_amount == $row['a_send']
		)
		{
			if($check_trans->num_rows>0) {
				echo error($lang['error_15']);
			} else {
				$insert = $db->query("INSERT transactions (tid,from,uid,in,amount,currency,date) VALUES ('$trans_id','$payer','$uid','WebMoney','$amount','','$date')");
				$update = $db->query("UPDATE exchanges SET status='2' WHERE id='$row[id]'");
				echo success($lang['success_4']);
			}
		}
		else
		{
		  echo error($lang['error_22']);
		}
	  }
} elseif($c == "success") {
require_once 'includes/webmoney.inc.php';

	  $wm_prerequest = new WM_Prerequest();
	  if ($wm_prerequest->GetForm() == WM_RES_OK)
	  {
		 $orderid = $wm_prerequest->payment_no;
		   $merchant = $wm_prerequest->payee_purse;
		   $amount = $wm_prerequest->payment_amount;
		   $trans_id = $wm_prerequest->sys_trans_no;
		   $date = $wm_prerequest->sys_trans_date;
		   $payer = $wm_prerequest->payer_wm;
		   $query = $db->query("SELECT * FROM exchanges WHERE id='$orderid'");
		if($query->num_rows==0) { header("Location: $settings[url]"); }
		$row = $query->fetch_assoc();
		$query1 = $db->query("SELECT * FROM companies_list WHERE id='$row[c_send]'");
		$row1 = $query1->fetch_assoc();
		if(checkSession()) { $uid = $_SESSION['suid']; } else { $uid = 0; }
		$check_trans = $db->query("SELECT * FROM transactions WHERE tid='$trans_id' and date='$date' and uid='$uid'");
		if (
		  $wm_prerequest->payment_no == $row['id'] &&
		  $wm_prerequest->payee_purse == $row1['account'] &&
		  $wm_prerequest->payment_amount == $row['a_send']
		)
		{
			if($check_trans->num_rows>0) {
				echo error($lang['error_15']);
			} else {
				$insert = $db->query("INSERT transactions (tid,from,uid,in,amount,currency,date) VALUES ('$trans_id','$payer','$uid','WebMoney','$amount','','$date')");
				$update = $db->query("UPDATE exchanges SET status='2' WHERE id='$row[id]'");
				echo success($lang['success_4']);
			}
		}
		else
		{
		  echo error($lang['error_22']);
		}
	  }
} elseif($c == "fail") {
require_once 'includes/webmoney.inc.php';
	  $wm_result = new WM_Result();
	  $wm_result->method = WM_POST;
	   $orderid = $wm_result->payment_no;
	  if ($wm_result->GetForm() == WM_RES_OK)
	  {	
		$update = $db->query("UPDATE exchanges SET status='3' WHERE id='$orderid'");
	echo error($lang['error_18']);
		}
} else {
	echo error($lang['error_2']);
}
?>