<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_regex( $param, $pattern, $replace )
{
    return preg_replace( $pattern, $replace, $param );
}

?>
