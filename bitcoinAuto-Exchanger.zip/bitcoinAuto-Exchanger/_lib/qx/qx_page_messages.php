<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_page_messages( $Error = "", $Success = "" )
{
    if ( is_array( $Error[0] ) && $Error[0]['Error'] != "" )
    {
        $i = 0 - 1;
        $result .= "<div class='ErrorMessage'>";
        while ( $i++ <= count( $Error ) )
        {
            if ( $Error[$i]['Error'] )
            {
                $result .= $Error[$i]['Error']."<br>";
            }
        }
        $result .= "</div>";
    }
    if ( is_array( $Success[0] ) && $Success[0]['Success'] )
    {
        $i = 0 - 1;
        $result .= "<div class='SuccessMessage'>";
        while ( $i++ <= count( $Success ) )
        {
            if ( $Success[$i]['Success'] )
            {
                $result .= $Success[$i]['Success']."<br>";
            }
        }
        $result .= "</div>";
    }
    return $result;
}

?>
