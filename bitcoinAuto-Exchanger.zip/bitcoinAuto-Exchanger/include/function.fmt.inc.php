<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

class holiday
{

    public $name = NULL;
    public $date = NULL;

    public function holiday( $name, $date )
    {
        $this->name = $name;
        $this->date = $date;
    }

}

class RamzNegar
{

    public $scramble1 = NULL;
    public $scramble2 = NULL;
    public $errors = NULL;
    public $adj = NULL;
    public $mod = NULL;

    public function RamzNegar( )
    {
        $this->errors = array( );
        $this->scramble1 = "! #\$%&GHIJK()*+,-./012389:;<=>?@ABCYZ[]^_`abcdefghijklmDEFLM4567NOPQRSTUVWXnopqrstuvwxyz{|}~";
        $this->scramble2 = "f^jAE]okI[2&q1{3`h5w_7BgP>dvW+YnFV=m D<TcS%Ze|r:lGK/uCy.Jx)HiQ!#\$~(;LtOzU-R}Ma94p@6s8?,Nb*0X";
        if ( strlen( $this->scramble1 ) != strlen( $this->scramble2 ) )
        {
            trigger_error( "** SCRAMBLE1 is not same length as SCRAMBLE2 **", E_USER_ERROR );
        }
        $this->adj = 1.75;
        $this->mod = 3;
    }

    public function decrypt( $key, $source )
    {
        $this->errors = array( );
        $fudgefactor = $this->_convertKey( $key );
        if ( $this->errors )
        {
            return;
        }
        if ( empty( $source ) )
        {
            $this->errors[] = "No value has been supplied for decryption";
        }
        else
        {
            $target = null;
            $factor2 = 0;
            $i = 0;
            while ( $i < strlen( $source ) )
            {
                $char2 = substr( $source, $i, 1 );
                $num2 = strpos( $this->scramble2, $char2 );
                if ( $num2 === false )
                {
                    $this->errors[] = "Source string contains an invalid character ({$char2})";
                }
                else
                {
                    $adj = $this->_applyFudgeFactor( $fudgefactor );
                    $factor1 = $factor2 + $adj;
                    $num1 = $num2 - round(  );
                    $num1 = $this->_checkRange( $num1 );
                    $factor2 = $factor1 + $num2;
                    $char1 = substr( $this->scramble1, $num1, 1 );
                    $target .= $char1;
                    ++$i;
                }
            }
        }
        return rtrim( $target );
    }

    public function encrypt( $key, $source, $sourcelen = 0 )
    {
        $this->errors = array( );
        $fudgefactor = $this->_convertKey( $key );
        if ( $this->errors )
        {
            return;
        }
        if ( empty( $source ) )
        {
            $this->errors[] = "No value has been supplied for encryption";
        }
        else
        {
            while ( strlen( $source ) < $sourcelen )
            {
                $source .= " ";
            }
            $target = null;
            $factor2 = 0;
            $i = 0;
            while ( $i < strlen( $source ) )
            {
                $char1 = substr( $source, $i, 1 );
                $num1 = strpos( $this->scramble1, $char1 );
                if ( $num1 === false )
                {
                    $this->errors[] = "Source string contains an invalid character ({$char1})";
                }
                else
                {
                    $adj = $this->_applyFudgeFactor( $fudgefactor );
                    $factor1 = $factor2 + $adj;
                    $num2 = round( $factor1 ) + $num1;
                    $num2 = $this->_checkRange( $num2 );
                    $factor2 = $factor1 + $num2;
                    $char2 = substr( $this->scramble2, $num2, 1 );
                    $target .= $char2;
                    ++$i;
                }
            }
        }
        return $target;
    }

    public function getAdjustment( )
    {
        return $this->adj;
    }

    public function getModulus( )
    {
    }

    public function setAdjustment( $adj )
    {
        $this->adj = ( double )$adj;
    }

    public function setModulus( $mod )
    {
        $this->mod = ( integer )abs( $mod );
    }

    public function _applyFudgeFactor( &$fudgefactor )
    {
        $fudge = array_shift( $fudgefactor );
        $fudge = $fudge + $this->adj;
        $fudgefactor[] = $fudge;
        if ( !empty( $this->mod ) && $fudge % $this->mod == 0 )
        {
            $fudge = $fudge * ( 0 - 1 );
        }
        return $fudge;
    }

    public function _checkRange( $num )
    {
        $num = round( $num );
        $limit = strlen( $this->scramble1 );
        while ( $limit <= $num )
        {
            $num = $num - $limit;
        }
        while ( $num < 0 )
        {
            $num = $num + $limit;
        }
        return $num;
    }

    public function _convertKey( $key )
    {
        if ( empty( $key ) )
        {
            $this->errors[] = "No value has been supplied for the encryption key";
        }
        else
        {
            $array[] = strlen( $key );
            $tot = 0;
            $i = 0;
            while ( $i < strlen( $key ) )
            {
                $char = substr( $key, $i, 1 );
                $num = strpos( $this->scramble1, $char );
                if ( $num === false )
                {
                    $this->errors[] = "Key contains an invalid character ({$char})";
                }
                else
                {
                    $array[] = $num;
                    $tot = $tot + $num;
                    ++$i;
                }
            }
            $array[] = $tot;
        }
        return $array;
    }

}

function Write_File( $writethis = "", $writethis2 = "", $filename = "" )
{
    global $CONFIG;
    global $Error;
    global $Success;
    global $Message_log;
    global $uploaded;
    global $_POST;
    global $_GET;
    if ( $filename )
    {
        $log_file = $filename;
    }
    else
    {
        $log_file = realpath( "_skins_tmp" )."/".md5( $_SERVER['HTTP_HOST'] )."_debug_messages.html";
    }
    if ( !file_exists( $log_file ) )
    {
        $Error[] = "Debug file does not exists, Address: ".$log_file;
    }
    if ( !is_writable( $log_file ) )
    {
        $Error[] = "Debug file is not writable, Address: ".$log_file;
    }
    $message .= "\n\n\n<pre style='margin: 0px 0px 10px 0px; display: block; background: white; color: black; font-family: Verdana; border: 1px solid #cccccc; padding: 5px; font-size: 10px; line-height: 13px;'>";
    $message .= ( "<h5>Page: ".$_SERVER['PHP_SELF']." </h5><br><b>Line: </b>".( 12 ) )."- <b>Function: </b>"."Write_File"." - <b>Class: </b>".""." - <b>REFERER: </b>".$_SERVER['HTTP_REFERER'];
    if ( $writethis )
    {
        $message .= "\n<br><h6>+ MESSAGE PART 1: </h4><br>".vardump( $writethis );
    }
    if ( $writethis2 )
    {
        $message .= "\n<br><h6>+ MESSAGE PART 2: </h4><br>".vardump( $writethis2 );
    }
    if ( $Message_log )
    {
        $message .= "\n<br><h5>Message Log: </h5>";
        foreach ( $Message_log as $value )
        {
            $message .= "<br>".$value;
        }
    }
    if ( $Error )
    {
        $message .= "\n<br><u><b>Error: </b>";
        foreach ( $Error as $value )
        {
            $message .= "<br></u>".$value;
        }
    }
    if ( $Success )
    {
        $message .= "\n<br><u><b>Success: </b>";
        foreach ( $Success as $value )
        {
            $message .= "<br></u>".$value;
        }
    }
    if ( $_POST )
    {
        $message .= "\n<br><b>Post fields: </b>";
        foreach ( $_POST as $key => $value )
        {
            $message .= "<br>".$key." = ".$value;
        }
    }
    if ( $_GET )
    {
        $message .= "\n<br><b>Get fields: </b>";
        foreach ( $_GET as $key => $value )
        {
            $message .= "<br>".$key." = ".$value;
        }
    }
    $message .= "</pre>\n\n\n";
    if ( !$uploaded )
    {
        echo $message."=>".$log_file."<br>";
    }
    $handle = @fopen( $log_file, "a" );
    @fwrite( $handle, $message );
    @fclose( $handle );
    $i = 1;
    return true;
}

function log_handler( $errno = "", $errstr = "", $errfile = "", $errline = "", $errcontext = "" )
{
    $errorType = array( 1 => "E_ERROR", 2 => "WARNING", 4 => "PARSING ERROR", 16 => "CORE ERROR", 32 => "CORE WARNING", 64 => "COMPILE ERROR", 128 => "COMPILE WARNING", 256 => "USER ERROR", 512 => "USER WARNING", 6143 => "E_ALL", 4096 => "E_RECOVERABLE_ERROR", 8192 => "E_DEPRECATED", 16384 => "E_USER_DEPRECATED" );
    if ( array_key_exists( $errno, $errorType ) )
    {
        $err = $errorType[$errno];
        log_error_ereg( "<b>errtype:{$errno}, {$err}: ({$errstr}) </b><br>file:{$errfile}, line:{$errline}, context:{$context} <br><br>\n" );
    }
}

function log_error_ereg( $mess )
{
    global $CONFIG;
    global $Error;
    $log_file = realpath( "_skins_tmp" )."/".md5( $_SERVER['HTTP_HOST'] )."_debug_messages.html";
    $message = "\n\n\n<pre style='margin: 0px 0px 10px 0px; display: block; background: white; color: black; font-family: Verdana; border: 1px solid #900; padding: 5px; font-size: 10px; line-height: 13px;'>";
    $message .= ( "<h5>Page: ".$_SERVER['PHP_SELF']." </h3><br><b>Line: </b>".( 74 ) )."- <b>Function: </b>"."log_error_ereg"." - <b>Class: </b>".""." - <b>REFERER: </b>".$_SERVER['HTTP_REFERER'];
    $message .= "<br><b>DATE: </b>".date( "Y-m-d H:i:s" )." <br>ERR : \n{$mess}\n\n</h5><br>";
    $message .= "</pre>\n\n\n";
    $fd = @fopen( $log_file, "a+" );
    if ( !fwrite( $fd, $message ) )
    {
        @fclose( $fd );
    }
}

function say_suspended( )
{
    global $line;
    if ( $line[suspended] == "1" )
    {
        return "<span class=ErrorMessage>inactive</span>";
    }
    return "&nbsp;";
}

function set_money_color( $amount, $style_no = 1, $worth_name = "usd" )
{
    $worth_name = strtolower( $worth_name );
    switch ( $worth_name )
    {
    case "usd" :
        $sign = "\$";
        break;
    case "euro" :
    }
    $sign = "&#8364;";
    break;
    $sign = $worth_name." ";
    break;
    if ( 0 <= $amount )
    {
        $famount = "<span class=\"money_".$style_no."\">".$sign.$amount."</span>";
    }
    else
    {
        $famount = "<span class=\"money_r".$style_no."\">".$sign.$amount."</span>";
    }
    return $famount;
}

function utf8_safe_substr( $string, $length, $start = 0 )
{
    iconv_set_encoding( "internal_encoding", "UTF-8" );
    $string = iconv_substr( $string, $start, $length );
    $string = iconv_substr( $string, 0, iconv_strrpos( $string, " " ) + 1 );
    return $string;
}

function Dot2LongIP( $IPaddr )
{
    if ( $IPaddr == "" )
    {
        return 0;
    }
    $ips = split( "\\.", "{$IPaddr}" );
    return $ips[3] + $ips[2] * 256 + $ips[1] * 256 * 256 + $ips[0] * 256 * 256 * 256;
}

function printf_arrays( $format )
{
    $args = func_get_args( );
    array_shift( $args );
    $i = 0;
    while ( $i < count( $args[0] ) )
    {
        $pfargs = array( );
        foreach ( $args as $arr )
        {
            $pfargs[] = is_array( $arr ) && $arr[$i] ? $arr[$i] : "";
        }
        vprintf( $format, $pfargs );
        ++$i;
    }
}

function show_daily( )
{
    global $def_use_weekly_earning;
    global $LANG_general;
    if ( $def_use_weekly_earning )
    {
        return $LANG_msg['general_weekly'];
    }
    return $LANG_msg['general_daily'];
}

function show_upper_limit( $val )
{
    if ( $val )
    {
        return " - \${$val}";
    }
    return "+";
}

function show_input_checked( $list, $val )
{
    if ( 0 < strlen( $val ) && ereg( ",{$list},", ",{$val}," ) )
    {
        return "checked";
    }
}

function show_input_selected( $item, $val )
{
    return $item == $val && strlen( $item ) == strlen( $val ) ? "selected" : "";
}

function current_timestamp( )
{
    return mktime( date( "H" ), date( "i" ), date( "s" ), date( "m" ), date( "d" ), date( "Y" ) );
}

function current_date_time( )
{
    return date( "Y-m-d H:i:s" );
}

function current_date( )
{
    return date( "Y-m-d" );
}

function in_list( $list, $item )
{
    return ereg( ",{$item},", ",{$list}," );
}

function add_list( $list, $item, $is_num = true )
{
    if ( $is_num )
    {
        if ( $list && $item )
        {
            return "{$list},{$item}";
        }
        if ( $item )
        {
            return $item;
        }
        return "";
    }
    return "{$list},{$item}";
}

function get_accepted_html_string( $string, $no_tag = true, $convert = false )
{
    if ( $no_tag )
    {
        if ( ereg( "<", $string ) )
        {
            return false;
        }
        return true;
    }
    if ( $convert )
    {
        return str_replace( "<", "&lt;", $string );
    }
    $string = strtolower( $string );
    if ( ereg( "<script", $string ) || ereg( "<object", $string ) )
    {
        return false;
    }
    return true;
}

function get_exchange( $amount, $currency )
{
    return $amount;
}

function get_interval_days( $interval, $def )
{
    if ( $interval == "MONTH" )
    {
        return 30 * $def;
    }
    if ( $interval == "YEAR" )
    {
        return 365 * $def;
    }
    return $def;
}

function anti_injection( $user )
{
    $banlist = array( "insert", "select", "update", "delete", "distinct", "having", "truncate", "replace", "handler", "like", "as", "or", "procedure", "limit", "order by", "group by", "asc", "desc" );
    if ( eregi( "[a-zA-Z0-9]+", $user ) )
    {
        $user = trim( str_replace( $banlist, "", strtolower( $user ) ) );
    }
    else
    {
        $user = NULL;
    }
    return $user;
}

function verify_ip( )
{
    $correct_ips = array( "213.207.*" );
    foreach ( $correct_ips as $value )
    {
        if ( !preg_match( "/".$value."/", $_SERVER['REMOTE_ADDR'] ) )
        {
            continue;
        }
        return true;
    }
}

function check_mojavez_dm( )
{
    global $license;
    $level2 = baz_no( $license, "239zxHBFW" );
    $ramz = new RamzNegar( );
    $domain = $ramz->decrypt( ramzkey( "number3" ), $level2 );
    $arr_domain = ( );
    if ( $domain == $arr_domain['domain'] )
    {
        return true;
    }
    print "&#73;&#110;&#118;&#97;&#108;&#105;&#100; &#108;&#105;&#99;&#101;&#110;&#115;&#101;";
    return false;
}

function baz_no( $q, $key )
{
    $l = strtoupper( md5( $key ) );
    $j = 0;
    $i = 0;
    while ( $i < strlen( $q ) )
    {
        if ( strlen( $l ) == $j + 10 )
        {
            $j = 0;
        }
        $a = hexdec( substr( $q, $i, 2 ) );
        $c .= chr( $a ^ ord( substr( $l, $j, 1 ) ) );
        ++$j;
        $i += 2;
    }
    return $c;
}

function FormatPrice( $string )
{
    $Negative = 0;
    if ( preg_match( "/^\\-/", $string ) )
    {
        $Negative = 1;
        $string = preg_replace( "|\\-|", "", $string );
    }
    $string = preg_replace( "|\\,|", "", $string );
    $Full = split( "[\\.]", $string );
    $Count = count( $Full );
    if ( 1 < $Count )
    {
        $First = $Full[0];
        $Second = $Full[1];
        $NumDec = strlen( $Second );
        if ( $NumDec == 2 )
        {
        }
        else if ( $NumDec < 2 )
        {
            $Second = $Second."0";
        }
        else if ( 2 < $NumDec )
        {
            $Temp = substr( $Second, 0, 3 );
            $Second = substr( $Temp, 0, 2 );
        }
    }
    else
    {
        $First = $Full[0];
        $Second = "00";
    }
    $length = strlen( $First );
    if ( $length <= 3 )
    {
        $string = $First.".".$Second;
        if ( $Negative == 1 )
        {
            $string = "-".$string;
        }
        return $string;
    }
    $loop = intval( $length / 3 );
    $section_length = 0 - 3;
    $i = 0;
    while ( $i < $loop )
    {
        $sections[$i] = substr( $First, $section_length, 3 );
        $section_length = $section_length - 3;
        ++$i;
    }
    $stub = $length % 3;
    if ( $stub != 0 )
    {
        $sections[$i] = substr( $First, 0, $stub );
    }
    $Done = implode( ",", array_reverse( $sections ) );
    $Done = $Done.".".$Second;
    if ( $Negative == 1 )
    {
        $Done = "-".$Done;
    }
    return $Done;
}

function DateConvert( $old_date, $layout )
{
    $old_date = ereg_replace( "[^0-9]", "", $old_date );
    $_year = substr(  );
    $_month = substr( $old_date, 4, 2 );
    $_day = substr( $old_date, 6, 2 );
    $_hour = substr( $old_date, 8, 2 );
    $_minute = substr( $old_date, 10, 2 );
    $_second = substr( $old_date, 12, 2 );
    $new_date = date( $layout, mktime( $_hour, $_minute, $_second, $_month, $_day, $_year ) );
    return $new_date;
}

function addDate( $Date, $adday )
{
    list( $year, $month, $day ) = year    return date( "Y-m-d", mktime( 0, 0, 0, $month, $day + $adday, $year ) );
}

function date_difference( $start_date, $end_date, $workdays_only = false, $skip_holidays = false )
{
    $start_date = strtotime( $start_date );
    $end_date = strtotime( $end_date );
    $seconds_in_a_day = 86400;
    $sunday_val = "0";
    $saturday_val = "6";
    $workday_counter = 0;
    $holiday_array = array( );
    $ptr_year = intval( date( "Y", $start_date ) );
    $holiday_array[$ptr_year] = getHolidays( date( "Y", $start_date ) );
    $day_val = $start_date;
    while ( $day_val <= $end_date )
    {
        $pointer_day = date( "w", $day_val );
        if ( $workdays_only == true )
        {
            if ( $pointer_day != $sunday_val && $pointer_day != $saturday_val )
            {
                if ( $skip_holidays == true )
                {
                    if ( intval( date( "Y", $day_val ) ) != $ptr_year )
                    {
                        $ptr_year = intval( date( "Y", $day_val ) );
                        $holiday_array[$ptr_year] = getHolidays( date( "Y", $day_val ) );
                    }
                    if ( !in_array( $day_val, $holiday_array[date( "Y", $day_val )] ) )
                    {
                        ++$workday_counter;
                    }
                }
                else
                {
                    ++$workday_counter;
                }
            }
        }
        else if ( $skip_holidays == true )
        {
            if ( intval( date( "Y", $day_val ) ) != $ptr_year )
            {
                $ptr_year = intval( date( "Y", $day_val ) );
                $holiday_array[$ptr_year] = getHolidays( date( "Y", $day_val ) );
            }
            if ( !in_array( $day_val, $holiday_array[date( "Y", $day_val )] ) )
            {
                ++$workday_counter;
            }
        }
        else
        {
            ++$workday_counter;
        }
        $day_val += $seconds_in_a_day;
    }
    return $workday_counter;
}

function GetTimeStamp( $MySqlDate )
{
    $date_array = explode( "-", $MySqlDate );
    $var_year = $date_array[0];
    $var_month = $date_array[1];
    $var_day = $date_array[2];
    $var_timestamp = mktime( 0, 0, 0, $var_month, $var_day, $var_year );
    return $var_timestamp;
}

function ordinalDay( $ord, $day, $month, $year )
{
    $firstOfMonth = gettimestamp( "{$year}-{$month}-01" );
    $lastOfMonth = $firstOfMonth + date( "t", $firstOfMonth ) * 86400;
    $dayOccurs = 0;
    $i = $firstOfMonth;
    while ( $i < $lastOfMonth )
    {
        if ( date( "D", $i ) == $day )
        {
            ++$dayOccurs;
            if ( $dayOccurs == $ord )
            {
                $ordDay = $i;
            }
        }
        $i += 86400;
    }
    return $ordDay;
}

function memorial_day( $inc_year )
{
    $date_stepper = intval( date( "t", strtotime( "{$inc_year}-05-01" ) ) );
    while ( 1 <= $date_stepper )
    {
        if ( date( "l", strtotime( "{$inc_year}-05-{$date_stepper}" ) ) == "Monday" )
        {
            return strtotime( "{$inc_year}-05-{$date_stepper}" );
        }
        --$date_stepper;
    }
}

function cutzero( $value )
{
    if ( $value == 0 )
    {
        return "0.00";
    }
    $result = preg_replace( "/(\\.\\d+?)0+\$/", "\$1", $value ) * 1;
    return ( double )$result;
}

function kelid( $string )
{
    $key = implode( "", range( "A", "O" ) );
    $result = "";
    $string = base64_decode( $string );
    $i = 0;
    while ( $Var_312 < strlen( $string ) )
    {
        $char = substr( $string, $i, 1 );
        $keychar = substr( $key, $i % strlen( $key ) - 1, 1 );
        $char = chr( ord( $char ) - ord( $keychar ) );
        $result .= $char;
        ++$i;
    }
    return $result;
}

function getHolidays( $inc_year )
{
    $year = $inc_year;
    $holidays[] = new holiday( "New Year's Day", gettimestamp( "{$year}-1-1" ) );
    $holidays[] = new holiday( "Birthday of Martin Luther King", ordinalday( 3, "Mon", 1, $year ) );
    $holidays[] = new holiday( "Groundhog Day", gettimestamp( "{$year}-2-2" ) );
    $holidays[] = new holiday( "Valentine's Day", gettimestamp( "{$year}-2-14" ) );
    $holidays[] = new holiday( "St. Patrick's Day", gettimestamp( "{$year}-3-17" ) );
    $holidays[] = new holiday( "Easter", easter_date( $year ) );
    $holidays[] = new holiday( "Memorial Day", memorial_day( $year ) );
    $holidays[] = new holiday( "Mother's Day", ordinalday( 2, "Sun", 5, $year ) );
    $holidays[] = new holiday( "Father's Day", ordinalday( 3, "Sun", 6, $year ) );
    $holidays[] = new holiday( "Independence Day", gettimestamp( "{$year}-7-4" ) );
    $holidays[] = new holiday( "Labor Day", ordinalday( 1, "Mon", 9, $year ) );
    $holidays[] = new holiday( "Thanksgiving Day", ordinalday( 4, "Thu", 11, $year ) );
    $holidays[] = new holiday( "Christmas", gettimestamp( "{$year}-12-25" ) );
    $numHolidays = count( $holidays ) - 1;
    $out_array = array( );
    $i = 0;
    while ( $i < $Var_3000 )
    {
        $out_array[] = $holidays[$i]->date;
        ++$i;
    }
    unset( $holidays );
    return $out_array;
}

function getHolidays2( $year )
{
    $return = array( );
    $return[$year."-01-01"] = "New Year`s Day";
    $return[$year."-07-04"] = "Independence Day";
    $return[$year."-12-25"] = "Christmas";
    $return[date( "Y-m-d", strtotime( "2 weeks monday", strtotime( "January 1, {$year}" ) ) + 43200 )] = "Martin Luther King, Jr. Day";
    $return[date( "Y-m-d", strtotime( "2 weeks monday", strtotime( "February 1, {$year}" ) ) + 43200 )] = "Presidents` Day";
    $return[date( "Y-m-d", strtotime( "-1 week monday", strtotime( "June 1, {$year}" ) ) + 43200 )] = "Memorial Day";
    $return[date( "Y-m-d", strtotime( "monday", strtotime( "September 1, {$year}" ) ) + 43200 )] = "Labor Day";
    $return[date( "Y-m-d", strtotime( "3 weeks thursday", strtotime( "November 1, {$year}" ) ) + 43200 )] = "Thanksgiving";
    ksort( $return );
    return $return;
}

function timeDiff( $starttime, $endtime, $detailed = false, $short = true )
{
    if ( !is_int( $starttime ) )
    {
        $starttime = strtotime( $starttime );
    }
    if ( !is_int( $endtime ) )
    {
        $endtime = strtotime( $endtime );
    }
    $diff = $endtime <= $starttime ? $starttime - $endtime : $endtime - $starttime;
    $periods = array( "second", "minute", "hour", "day", "week", "month", "year", "decade" );
    $lengths = array( 1, 60, 3600, 86400, 604800, 2630880, 31570560, 315705600 );
    if ( $short )
    {
        $periods = array( "s", "m", "h", "d", "m", "y" );
        $lengths = array( 1, 60, 3600, 86400, 2630880, 31570560 );
    }
    $i = sizeof( $lengths ) - 1;
    $time = "";
    while ( 0 <= $i )
    {
        if ( $lengths[$i - 1] < $diff && $lengths[$i - 1] != "" )
        {
            $val = floor( $diff / $lengths[$i - 1] );
            $time .= $val.( $short ? "" : " " ).$periods[$i - 1].( !$short && 1 < $val ? "s " : " " );
            $diff -= $val * $lengths[$i - 1];
            if ( !$detailed )
            {
                $i = 0;
            }
        }
        --$i;
    }
    return $time;
}

function microtime_float( )
{
    list( $usec, $sec ) = usec    return ( double )$usec + ( double )$sec;
}

function cookie_check( )
{
    if ( !isset( $_COOKIE['PHPSESSID'] ) )
    {
        return false;
    }
    return true;
}

function show_page_messages( )
{
    global $Error;
    global $Success;
    if ( $Error )
    {
        $result .= "<div class='ErrorMessage'>";
        foreach ( $Error as $value )
        {
            $result .= $value."<br>";
        }
        $result .= "</div>";
    }
    if ( $Success )
    {
        $result .= "<div class='SuccessMessage'>";
        do
        {
            $value = $Tmp_24[0];
            $Tmp_24;
            $result .= $value."<br>";
        } while ( 1 );
        $result .= "</div>";
    }
    return $result;
}

function phpWrapper( $content )
{
    ob_start( );
    $content = str_replace( "<"."?php", "<"."?", $content );
    eval( "?".">".trim( $content )."<"."?" );
    $content = ob_get_contents( );
    ob_end_clean( );
    return $content;
}

function make_tmp_array( $value, $key_name )
{
    if ( !is_array( $value ) )
    {
        $value = array(
            $value
        );
    }
    if ( count( $value ) < 2 )
    {
        $arr = array_fill_keys( $value, $key_name );
        $arr = array(
            array_flip( $arr )
        );
    }
    else
    {
        $arr = array( );
        $i = 0;
        while ( $i <= count( $value ) )
        {
            if ( $value[$i] )
            {
                $arr[$i][$key_name] = $value[$i];
            }
            ++$i;
        }
    }
    return $arr;
}

function changeMultiarrayStructure( $multiarray, $asc = 1 )
{
    if ( $asc == 1 )
    {
        $multiarraykeys = array_reverse( $multiarray, true );
    }
    else
    {
        $multiarraykeys = $multiarray;
    }
    $newarraykeys = array( );
    foreach ( $multiarraykeys as $arrayvalue )
    {
        if ( is_array( $arrayvalue ) )
        {
            $newarraykeys = array_keys( $arrayvalue ) + $newarraykeys;
        }
    }
    foreach ( $multiarray as $newsubarraykey => $arrayvalue )
    {
        if ( is_array( $arrayvalue ) )
        {
            $i = 0;
            foreach ( $arrayvalue as $subarrayvalue )
            {
                $newmultiarray[$newarraykeys[$i]][$newsubarraykey] = $subarrayvalue;
                ++$i;
            }
        }
        else
        {
            foreach ( $newarraykeys as $newarraykey )
            {
                $newmultiarray[$newarraykey][$newsubarraykey] = $arrayvalue;
            }
        }
    }
    return $newmultiarray;
}

function ArrayDepth( $Array, $DepthCount = -1, $DepthArray = array( ) )
{
    ++$DepthCount;
    if ( is_array( $Array ) )
    {
        foreach ( $Array as $Key => $Value )
        {
            $DepthArray[] = ArrayDepth( $Value, $DepthCount );
        }
    }
    else
    {
        return $DepthCount;
    }
    foreach ( $DepthArray as $Value )
    {
        $Depth = $Depth < $Value ? $Value : $Depth;
    }
    return $Depth;
}

function array_flatten( $a )
{
    $ab = array( );
    if ( !is_array( $a ) )
    {
        return $ab;
    }
    foreach ( $a as $Var_264 )
    {
        if ( is_array( $value ) )
        {
            $ab = array_merge( $ab, array_flatten( $value ) );
        }
        else
        {
            array_push( $ab, $value );
        }
    }
    return $ab;
}

function show_all_variables( )
{
    echo "<table border=1><tr> <th>variable</th> <th>value</th> </tr>";
    foreach ( $Var_24 as $key => $value )
    {
        if ( is_array( $value ) )
        {
            echo "<tr><td>\$".$key."</td><td>";
            if ( 0 < sizeof( $value ) )
            {
                echo "\"<table border=1><tr> <th>key</th> <th>value</th> </tr>";
                foreach ( $value as $skey => $svalue )
                {
                    echo $Tmp_28.$svalue."\"</td></tr>";
                }
                echo "</table>\"";
            }
            else
            {
                echo "EMPTY";
            }
            echo "</td></tr>";
        }
        else
        {
            echo "<tr><td>\$".$key."</td><td>\"".$value."\"</td></tr>";
        }
    }
    echo "</table>";
}

function check_ip_limit( $iprange )
{
    $ip_pieces = explode( ",", $iprange );
    foreach ( $ip_pieces as $key => $value )
    {
        if ( !preg_match( "/".$ip_pieces[$key]."/", $_SERVER['REMOTE_ADDR'] ) )
        {
            continue;
        }
        return true;
    }
}

function vardump( $param )
{
    return "<pre style=\"font-size:12px; margin:0; padding:0;\">".print_r( $param, true )."</pre>";
}

function is_uppercase( $str, $char = "-1" )
{
    if ( strtoupper( $str ) == $str )
    {
        return $Tmp_6;
    }
}

function server_addr( )
{
    return $_SERVER['SERVER_ADDR'] ? $_SERVER['SERVER_ADDR'] : $_SERVER['LOCAL_ADDR'];
}

function getDomain( $url )
{
    if ( filter_var( $url, FILTER_VALIDATE_URL, FILTER_FLAG_HOST_REQUIRED ) === FALSE )
    {
        return false;
    }
    $parts = parse_url( $url );
    return $parts['scheme']."://".$parts['host'];
}

function get_url( $subdomain = false )
{
    $uri = $_SERVER['REQUEST_URI'];
    $arr['query'] = $_SERVER['QUERY_STRING'];
    $page_self = explode( "/", $_SERVER['PHP_SELF'] );
    $arr['page'] = $page_self[count( $page_self ) - 1];
    $arr['folder'] = $page_self[count( $page_self ) - 2];
    $arr['domain'] = $_SERVER['SERVER_NAME'];
    if ( !$subdomain && preg_match( "/[^.]+\\.[^.]+\$/", $arr['domain'], $matches ) )
    {
        $arr['domain'] = $matches[0];
    }
    $server_prt = explode( "/", $_SERVER['SERVER_PROTOCOL'] );
    $arr['scheme'] = strtolower( $server_prt[0] );
    $arr['url'] = $arr['scheme']."://".$arr['domain'].$_SERVER['PHP_SELF'];
    return $arr;
}

function get_inc_names( $inc_dir )
{
    $n = array( );
    if ( $dir = opendir( $inc_dir ) )
    {
        while ( $file = readdir( $dir ) )
        {
            if ( !( $file != "." && $file != ".." ) && !strpos( $file, "inc.php" ) )
            {
                $file = substr( $file, 0, strpos( $file, "." ) );
                array_push( $n, $file );
            }
        }
        closedir( $dir );
    }
    return $n;
}

function list_files( $directory, $stringSearch, $excludeFile = "", $excludeFile2 = "", $searchHandler = 0, $outputHandler = 0 )
{
    global $Error;
    $errorHandler = false;
    $result = array( );
    if ( !( $directoryHandler = @opendir( $directory ) ) )
    {
        $Error[] = "directory \"{$directory}\" doesn't exist!";
        return $errorHandler = true;
    }
    while ( $searchHandler === 0 && false !== ( $fileName = @readdir( $directoryHandler ) ) )
    {
        if ( strstr( $fileName, $stringSearch ) == true && strpos( $fileName, $excludeFile ) === false && strpos( $fileName, $excludeFile2 ) === false )
        {
            @array_push( $result, $fileName );
        }
    }
    while ( $searchHandler === 1 && false !== ( $fileName = @readdir( $directoryHandler ) ) )
    {
        if ( 0 < @substr_count( $fileName, $stringSearch ) )
        {
            @array_push( $result, $fileName );
        }
    }
    if ( $errorHandler === true && count( $result ) === 0 )
    {
        $Error[] = "no filetype \"{$fileExtension}\" found!";
    }
    else
    {
        sort( $result );
        if ( $outputHandler === 0 )
        {
            return $result;
        }
        if ( $outputHandler === 1 )
        {
            echo "<pre>\n";
            print_r( $Error );
            echo "</pre>\n";
        }
    }
}

function list_dirs( $path )
{
    $list = scandir( $path );
    foreach ( $list as $number => $filename )
    {
        if ( $filename !== "." && $filename !== ".." && is_dir( "{$path}/{$filename}" ) )
        {
            $dir = $filename;
            $url = apache_request_headers( );
            $result[] = $dir;
        }
    }
    return $result;
}

function empty_cache_folder( $set_msg = true )
{
    global $CONFIG;
    global $Error;
    global $Success;
    $cache_folder = realpath( $CONFIG['CACHE_FOLDER'] );
    if ( @is_writable( $cache_folder ) )
    {
        $files = list_files( $cache_folder, "php", "html", "htaccess" );
        if ( is_array( $files ) && 0 < count( $files ) )
        {
            foreach ( $files as $value )
            {
                unlink( realpath( $CONFIG['CACHE_FOLDER'].$value ) );
                ++$i;
            }
        }
        if ( 0 < $i && $set_msg )
        {
            $Success[] = "Cache folder include {$i} files cleaned up successfully.";
        }
        else if ( $set_msg )
        {
            $Success[] = "Cache folder already was clean.";
        }
        return true;
    }
    if ( $set_msg )
    {
        $Error[] = "Cache folder have not write permission, Could not remove old cache files.";
    }
    return false;
}

function ramzkey( $tag )
{
    return "5a8ej8WndK3#9Ua425hgtg741KknN";
    if ( $tag == "number2" )
    {
        return "YHUhundBYG&HJnbv56jJDKNjfwiuen";
    }
    if ( $tag == "number3" )
    {
        return "E5jrAxmK3OYTWPOQIBHJW{NIC rqN(_^&\$%=902143027-zOW4wqjhghqeruib43w";
    }
    if ( $tag == "currency_key" )
    {
        return "*&heuhwbYHBYEU74986764uiwef";
    }
}

function createCookie( $name, $value = "", $maxage = 0, $path = "", $domain = "", $secure = false, $HTTPOnly = false )
{
    $ob = ini_get( "output_buffering" );
    if ( headers_sent( ) && ( string )$ob === false || strtolower( $ob ) == "off" )
    {
        return false;
    }
    if ( !empty( $domain ) )
    {
        if ( strtolower( substr( $domain, 0, 4 ) ) == "www." )
        {
            $domain = substr( $domain, 4 );
        }
        if ( substr( $domain, 0, 1 ) != "." )
        {
            $domain = ".".$domain;
        }
        $port = strpos( $domain, ":" );
        if ( $port !== false )
        {
            $domain = substr( $domain, 0, $port );
        }
    }
    header( "Set-Cookie: ".rawurlencode( $name )."=".rawurlencode( $value ).( empty( $domain ) ? "" : "; Domain=".$domain ).( empty( $maxage ) ? "" : "; Max-Age=".$maxage ).( empty( $path ) ? "" : "; Path=".$path ).( !$secure ? "" : "; Secure" ).( !$HTTPOnly ? "" : "; HttpOnly" ), false );
    return true;
}

function xml2array( $xml_response )
{
    $xml_parser = xml_parser_create( );
    xml_parse_into_struct( $xml_parser, $xml_response, $vals, $index );
    xml_parser_free( $xml_parser );
    $params = array( );
    $level = array( );
    foreach ( $vals as $xml_elem )
    {
        if ( $xml_elem['type'] == "open" )
        {
            if ( array_key_exists( "attributes", $xml_elem ) )
            {
                list( $extra ) = level            }
            else
            {
                $level[$xml_elem['level']] = $xml_elem['tag'];
            }
        }
        if ( $xml_elem['type'] == "complete" )
        {
            $start_level = 1;
            $php_stmt = "\$params";
            while ( $start_level < $xml_elem['level'] )
            {
                $php_stmt .= "[\$level[".$start_level."]]";
                ++$start_level;
            }
            $php_stmt .= "[\$xml_elem['tag']] = \$xml_elem['value'];";
            eval( $php_stmt );
        }
    }
    return $params;
}

function sql_safe( $string )
{
    if ( get_magic_quotes_gpc( ) )
    {
        $string = stripslashes( $string );
    }
    $badWords = "(delete)|(update)|(union)|(insert)|(drop)|(http)|(--)";
    $string = eregi_replace( $badWords, "", $string );
    if ( "4.3.0" <= phpversion( ) )
    {
        $string = mysql_real_escape_string( $string );
    }
    else
    {
        $string = mysql_escape_string( $string );
    }
    return $string;
}

function get_license_info( $type = "", $this_license = "" )
{
    global $license;
    global $CONFIG;
    global $Error;
    global $Success;
    if ( $this_license )
    {
        $license = $this_license;
    }
    $url = "http://www.auto-exchanger.com/check.php";
    $arr_domain = get_url( );
    $query_string = "licensekey=".$license."&domain=".$arr_domain['domain']."&version=".trim( $CONFIG['Version'] )."&server_ip=".server_addr( );
    $ch = curl_init( );
    curl_setopt( $ch, CURLOPT_URL, $url );
    curl_setopt( $ch, CURLOPT_POST, 1 );
    curl_setopt( $ch, CURLOPT_TIMEOUT, 3 );
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
    curl_setopt( $ch, CURLOPT_POSTFIELDS, $query_string );
    $filecontents = curl_exec( $ch );
    if ( curl_errno( $ch ) != 0 && $type == "install" )
    {
        if ( curl_errno( $ch ) == 6 )
        {
            $Error[] = "<br><pre><b>Error occurred:</b> License check process failed, error in connection to main server, please contact our support team.</pre>";
        }
        else
        {
            $Error[] = "<br><pre>License check failed: ".curl_error( $ch )."</pre>";
        }
        return false;
    }
    curl_close( $ch );
    if ( strstr( $filecontents, "invalid" ) || empty( $filecontents ) )
    {
        if ( $type == "install" )
        {
            $Error[] = "You are using invalid license number";
            return false;
        }
        if ( !$type )
        {
            $Error[] = "You are using invalid license number, please contact us ASAP.";
            return false;
        }
    }
    if ( strstr( $filecontents, "valid" ) )
    {
        return true;
    }
}

function dump( &$var, $info = FALSE )
{
    if ( is_array( $var ) )
    {
        $scope = false;
        $prefix = "unique";
        $suffix = "value";
        if ( $scope )
        {
            $vals = $scope;
        }
        else
        {
            $vals = $GLOBALS;
        }
        $old = $var;
        $var = $new = $prefix.rand( ).$suffix;
        $vname = FALSE;
        foreach ( $vals as $key => $val )
        {
            if ( $val === $new )
            {
                $vname = $key;
            }
        }
        $var = $old;
        echo "<pre style='margin: 0px 0px 10px 0px; display: block; background: white; color: black; font-family: Verdana; border: 1px solid #cccccc; padding: 5px; font-size: 10px; line-height: 13px;'>";
        if ( $info != FALSE )
        {
            echo "{$info}:</b><br>";
        }
        do_dump( $var, "\$".$vname );
        echo "</pre>";
    }
    else
    {
        echo "<pre>".$var."</pre>";
    }
}

function do_dump( &$var, $var_name = NULL, $indent = NULL, $reference = NULL )
{
    $do_dump_indent = "<span style='color:#eeeeee;'>|</span> &nbsp;&nbsp; ";
    $reference = $reference.$var_name;
    $keyvar = "the_do_dump_recursion_protection_scheme";
    $keyname = "referenced_object_name";
    if ( is_array( $var ) && isset( $var[$keyvar] ) )
    {
        $real_var =& $var[$keyvar];
        $real_name =& $var[$keyname];
        $type = ucfirst( gettype( $real_var ) );
        echo "{$indent}{$var_name} <span style='color:#a2a2a2'>{$type}</span> = <span style='color:#e87800;'>&amp;{$real_name}</span><br>";
    }
    else
    {
        $var = array(
            $keyvar => $var,
            $keyname => $reference
        );
        $avar =& $var[$keyvar];
        $type = ucfirst( gettype( $avar ) );
        if ( $type == "String" )
        {
            $type_color = "<span style='color:green'>";
        }
        else if ( $type == "Integer" )
        {
            $type_color = "<span style='color:red'>";
        }
        else if ( $type == "Double" )
        {
            $type_color = "<span style='color:#0099c5'>";
            $type = "Float";
        }
        else if ( $type == "Boolean" )
        {
            $type_color = "<span style='color:#92008d'>";
        }
        else if ( $type == "NULL" )
        {
            $type_color = "<span style='color:black'>";
        }
        if ( is_array( $avar ) )
        {
            $count = count( $avar );
            echo "{$indent}".( $var_name ? "{$var_name} => " : "" )."<span style='color:#a2a2a2'>{$type} ({$count})</span><br>{$indent}(<br>";
            $keys = array_keys( $avar );
            foreach ( $keys as $name )
            {
                $value =& $avar[$name];
                do_dump( $value, "['{$name}']", $indent.$do_dump_indent, $reference );
            }
            echo "{$indent})<br>";
        }
        else if ( is_object( $avar ) )
        {
            echo "{$indent}{$var_name} <span style='color:#a2a2a2'>{$type}</span><br>{$indent}(<br>";
            foreach ( $avar as $name => $value )
            {
                do_dump( $value, "{$name}", $indent.$do_dump_indent, $reference );
            }
            echo "{$indent})<br>";
        }
        else if ( is_int( $avar ) )
        {
            echo "{$indent}{$var_name} = <span style='color:#a2a2a2'>{$type}(".strlen( $avar ).")</span> {$Var_3816}{$avar}</span><br>";
        }
        else if ( is_string( $avar ) )
        {
            echo "{$indent}{$var_name} = <span style='color:#a2a2a2'>{$type}(".strlen( $avar ).")</span> {$type_color}\"{$avar}\"</span><br>";
        }
        else if ( is_float( $avar ) )
        {
            echo "{$indent}{$var_name} = <span style='color:#a2a2a2'>{$type}(".strlen( $avar ).")</span> {$type_color}{$avar}</span><br>";
        }
        else if ( is_bool( $avar ) )
        {
            echo "{$indent}{$var_name} = <span style='color:#a2a2a2'>{$type}(".strlen( $avar ).")</span> {$type_color}".( $avar == 1 ? "TRUE" : "FALSE" )."</span><br>";
        }
        else if ( is_null( $avar ) )
        {
            echo "{$indent}{$var_name} = <span style='color:#a2a2a2'>{$type}(".strlen( $avar ).")</span> {$type_color}NULL</span><br>";
        }
        else
        {
            echo "{$indent}{$var_name} = <span style='color:#a2a2a2'>{$type}(".strlen( $avar ).")</span> {$avar}<br>";
        }
    }
}

function safe_string( $src )
{
    $list = array( "\$", "\\'", "\"", "\\", "_REQUEST", "_GET", "_POST", "_COOKIE", "_FILES", "_SERVER", "_ENV", "GLOBALS", "_SESSION", "strtoupper" );
    return str_replace( $list, "", addslashes( trim( $src ) ) );
}

function GetCountry_csv( $ClientIP, $only_iso = false )
{
    $ip = sprintf( "%u", ip2long( $ClientIP ) );
    $filename = "include/IpToCountry.csv";
    if ( file_exists( $filename ) )
    {
        $handle = fopen( $filename, "r" );
    }
    else
    {
        return false;
    }
    $row = 1;
    while ( ( $buffer = fgets( $handle, 4096 ) ) !== FALSE )
    {
        $array[$row] = substr( $buffer, 1, strpos( $buffer, "," ) - 1 );
        ++$row;
    }
    $row_lower = "0";
    $row_upper = $row;
    while ( 1 < $row_upper - $row_lower )
    {
        $row_midpt = ( integer )( ( $row_upper + $row_lower ) / 2 );
        if ( $array[$row_midpt] <= $ip )
        {
            $row_lower = $row_midpt;
        }
        else
        {
            $row_upper = $row_midpt;
        }
    }
    rewind( $handle );
    $row = 1;
    while ( $row <= $row_lower )
    {
        $buffer = fgets( $handle, 4096 );
        ++$row;
    }
    $buffer = str_replace( "\"", "", $buffer );
    $ipdata = explode( ",", $buffer );
    $results = $ipdata[6];
    if ( $only_iso )
    {
    }
    fclose( $handle );
    return $results;
}

if ( !function_exists( "array_fill_keys" ) )
{
    function array_fill_keys( $array, $values )
    {
        if ( is_array( $array ) )
        {
            foreach ( $array as $key => $value )
            {
                $arraydisplay[$array[$key]] = $values;
            }
        }
        return $arraydisplay;
    }
}
if ( !function_exists( "scandir" ) )
{
    function scandir( $dir, $no_dots = FALSE )
    {
        $files = array( );
        $dh = @opendir( $dir );
        if ( $dh != FALSE )
        {
            while ( false !== ( $filename = readdir( $dh ) ) )
            {
                $files[] = $filename;
            }
            if ( $no_dots )
            {
                while ( 0 - 1 < ( $ix = array_search( ".", $files ) ) )
                {
                    unset( $files[$ix] );
                }
                while ( 0 - 1 < ( $ix = array_search( "..", $files ) ) )
                {
                    unset( $files[$ix] );
                }
            }
            sort( $files );
        }
        return $files;
    }
}
if ( !function_exists( "apache_request_headers" ) )
{
    function apache_request_headers( )
    {
        $arh = array( );
        $rx_http = "/\\AHTTP_/";
        foreach ( $_SERVER as $key => $val )
        {
            if ( preg_match( $rx_http, $key ) )
            {
                $arh_key = preg_replace( $rx_http, "", $key );
                $rx_matches = explode( "_", $arh_key );
                if ( 0 < count( $rx_matches ) && 2 < strlen( $arh_key ) )
                {
                    foreach ( $rx_matches as $ak_key => $ak_val )
                    {
                        $rx_matches[$ak_key] = ucfirst( $ak_val );
                    }
                    $arh_key = implode( "-", $rx_matches );
                }
                $arh[$arh_key] = $val;
            }
        }
        return $arh;
    }
}
?>
