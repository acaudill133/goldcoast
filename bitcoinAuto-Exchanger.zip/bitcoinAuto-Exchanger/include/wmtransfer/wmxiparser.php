<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

class WMXIParser
{

    public $parser_encoding = "UTF-8";
    public $parser = NULL;
    public $error_code = NULL;
    public $error_string = NULL;
    public $current_line = NULL;
    public $current_column = NULL;
    public $datas = array( );
    public $data = array( );

    public function _tagOpen( $parser, $tag, $attribs )
    {
        $node = array(
            "name" => strtolower( $tag ),
            "data" => ""
        );
        if ( 0 < count( $attribs ) )
        {
            $node['@'] = $attribs;
        }
        $this->data['node'][] = $node;
        $this->datas[] =& $this->data;
        $this->data =& $this->data['node'][count( $this->data['node'] ) - 1];
    }

    public function _tagClose( $parser, $tag )
    {
        $this->data =& $this->datas[count( $this->datas ) - 1];
        array_pop( $this->datas );
    }

    public function _tagData( $parser, $cdata )
    {
        $this->data['data'] .= $cdata;
    }

    public function _change_encoding( $data, $encoding )
    {
        $result = array( );
        foreach ( $data as $k => $v )
        {
            $value = is_array( $v ) ? $this->_change_encoding( $v, $encoding ) : mb_convert_encoding( $v, $encoding, $this->parser_encoding );
            $result[$k] = $value;
        }
        return $result;
    }

    public function Parse( $data, $encoding = "UTF-8" )
    {
        if ( !( $this->parser = xml_parser_create( $this->parser_encoding ) ) )
        {
            $this->parser = xml_parser_create( );
        }
        xml_set_object( $this->parser, $this );
        xml_parser_set_option( $this->parser, XML_OPTION_SKIP_WHITE, 1 );
        xml_set_element_handler( $this->parser, "_tagOpen", "_tagClose" );
        xml_set_character_data_handler( $this->parser, "_tagData" );
        if ( !xml_parse( $this->parser, $data ) )
        {
            $this->data = array( );
            $this->error_code = xml_get_error_code( $this->parser );
            $this->error_string = xml_error_string( $this->error_code );
            $this->current_line = xml_get_current_line_number( $this->parser );
            $this->current_column = xml_get_current_column_number( $this->parser );
        }
        else
        {
            $this->data = $this->data['node'];
        }
        xml_parser_free( $this->parser );
        $this->data = $this->_change_encoding( $this->data, $encoding );
        return $this->data;
    }

    public function Reindex( $data, $skip_attr = FALSE )
    {
        $result = array( );
        foreach ( $data as $k => $v )
        {
            $name = $v['name'];
            if ( $skip_attr )
            {
                $result[$name] = isset( $v['node'] ) ? $this->Reindex( $v['node'], $skip_attr ) : $v['data'];
            }
            else
            {
                if ( isset( $v['@'] ) && !$skip_attr )
                {
                    $result[$name]['@'] = $v['@'];
                }
                $result[$name]['data'] = isset( $v['node'] ) ? $this->Reindex( $v['node'], $skip_attr ) : $v['data'];
            }
        }
        return $result;
    }

}

?>
