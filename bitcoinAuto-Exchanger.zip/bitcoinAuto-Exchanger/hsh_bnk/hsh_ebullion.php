<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

chdir( "../" );
include( "include/config.inc.php" );
$REFERER = $_SERVER['HTTP_REFERER'];
$REMOTE_ADDRESS = $_SERVER['REMOTE_ADDR'];
$ATIP_TIMESTAMP = $_POST['ATIP_TIMESTAMP'];
$ATIP_EXCHANGE_RATE = $_POST['ATIP_EXCHANGE_RATE'];
$ATIP_TRANSACTION_ID = $_POST['ATIP_TRANSACTION_ID'];
$ATIP_VERIFICATION = $_POST['ATIP_VERIFICATION'];
$PAYMENT_ID = $_POST['paymentid'];
$SECURE_CODE = $_POST['securecode'];
$Message_log[] = "PAYMENT_ID2 ------->".$PAYMENT_ID2;
if ( empty( $REFERER ) && !empty( $ATIP_TIMESTAMP ) && !empty( $ATIP_TRANSACTION_ID ) )
{
    $dbconn = db_open( );
}
$arr_EBULLION = get_currency_data( "", "e-bullion" );
$ramz = new RamzNegar( );
$arr_EBULLION['ALT_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_EBULLION['ALT_PASSWORD'] );
if ( strlen( $arr_EBULLION['ALT_PASSWORD'] ) < 6 )
{
    $arr_EBULLION['ALT_PASSWORD'] = ramzkey( "currency_key" );
}
if ( Refrence2eid( $PAYMENT_ID ) )
{
    $PAYMENT_AMOUNT = db_get_id( "SELECT src_amount From {$_exchange_lines} WHERE exchange_refrence='{$PAYMENT_ID}' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}'" );
}
else
{
    $PAYMENT_AMOUNT = db_get_id( "SELECT amount FROM {$_lines} WHERE id='{$PAYMENT_ID}' AND status='{$STATUS_ENUM_DISABLE}'" );
}
$Ebullion_array = array(
    $arr_EBULLION['ACCOUNT'],
    $PAYMENT_ID,
    strtoupper( $arr_EBULLION['ALT_PASSWORD'] ),
    $PAYMENT_AMOUNT
);
$Ebullion_hash = strtoupper( md5( implode( ":", $Ebullion_array ) ) );
if ( $Ebullion_hash == $SECURE_CODE )
{
    if ( Refrence2eid( $PAYMENT_ID ) )
    {
        if ( db_if_exists( "SELECT eid From {$_exchange_lines} WHERE exchange_refrence='{$PAYMENT_ID}' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND src_amount='{$PAYMENT_AMOUNT}'" ) )
        {
            SEND_EXHCANGE_MAIL( $PAYMENT_ID, "receive" );
            commit_exchange( $PAYMENT_ID, $ATIP_TRANSACTION_ID );
            $Message_log[] = "E-BULLION ADD TO DATABASE";
        }
    }
    else if ( db_if_exists( "SELECT * FROM {$_lines} WHERE id='{$PAYMENT_ID}' AND status='{$STATUS_ENUM_DISABLE}' AND amount='{$PAYMENT_AMOUNT}'" ) )
    {
        SEND_INVEST_RECEIVE_MAIL( $PAYMENT_ID, $PAYER_ACCOUNT );
        commit_transaction( $PAYMENT_ID, $ATIP_TRANSACTION_ID );
        $Message_log[] = "E-BULLION ADD TO DATABASE";
    }
    db_close( $dbconn );
}
$Message_log[] = "E-BULLION ACCEPTED";
#}
#else
{
    $Message_log[] = "E-BULLION IF FAILED ****";
}
Write_File( );
?>
