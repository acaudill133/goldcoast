<?php
$c = protect($_GET['c']);
$ac_src_wallet = $_GET['ac_src_wallet'];
$ac_dest_wallet = $_GET['ac_dest_wallet'];
$ac_amount = $_GET['ac_amount'];
$ac_merchant_currency = $_GET['ac_merchant_currency'];
$ac_transfer = $_GET['ac_transfer'];
$ac_start_date = $_GET['ac_start_date'];
$ac_order_id = $_GET['ac_order_id'];
$query = $db->query("SELECT * FROM exchanges WHERE id='$ac_order_id'");
if($query->num_rows==0) { header("Location: $settings[url]"); }
$row = $query->fetch_assoc();
$query1 = $db->query("SELECT * FROM companies_list WHERE id='$row[c_send]'");
$row1 = $query1->fetch_assoc();
if(checkSession()) { $uid = $_SESSION['suid']; } else { $uid = 0; }
$check_trans = $db->query("SELECT * FROM transactions WHERE tid='$ac_transfer' and date='$ac_start_date' and uid='$uid'");
if($c == "success") {
	if($ac_dest_wallet == $row1['account']) {
		if($ac_amount == $row['a_send'] or $ac_merchant_currency == $row['a_currency']) {
			if($check_trans->num_rows>0) {
				echo error($lang['error_15']);
			} else {
				$insert = $db->query("INSERT transactions (tid,from,uid,in,amount,currency,date) VALUES ('$ac_transfer','$ac_src_wallet','$uid','AdvCash','$ac_amount','$ac_merchant_currency','$ac_start_date')");
				$update = $db->query("UPDATE exchanges SET status='2' WHERE id='$row[id]'");
				echo success($lang['success_4']);
			}
		} else {
			echo error($lang['error_16']);
		}
	} else { 
		echo error($lang['error_17']);
	}
} elseif($c == "status") {
	if($ac_dest_wallet == $row1['account']) {
		if($ac_amount == $row['a_send'] or $ac_merchant_currency == $row['a_currency']) {
			if($check_trans->num_rows>0) {
				echo error($lang['error_15']);
			} else {
				$insert = $db->query("INSERT transactions (tid,from,uid,in,amount,currency,date) VALUES ('$ac_transfer','$ac_src_wallet','$uid','AdvCash','$ac_amount','$ac_merchant_currency','$ac_start_date')");
				$update = $db->query("UPDATE exchanges SET status='2' WHERE id='$row[id]'");
				echo success($lang['success_4']);
			}
		} else {
			echo error($lang['error_16']);
		}
	} else { 
		echo error($lang['error_17']);
	}
} elseif($c == "fail") {
	$update = $db->query("UPDATE exchanges SET status='3' WHERE id='$row[id]'");
	echo error($lang['error_18']);
} else {
	echo error($lang['error_2']);
}
?>