<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function check_rows( $uid_pct, $plid, $payment_id = "" )
{
    if ( !empty( $_SESSION['uid'] ) )
    {
        check_bank_row( $uid_pct, $plid, $payment_id );
        check_earn_bank( $uid_pct, $plid, $payment_id );
        check_compund_row( $uid_pct, $plid );
    }
}

function commit_transaction( $pmt_id, $pmt_transaction )
{
    global $_lines;
    global $_exchange_rate;
    global $_currencies;
    global $CONFIG;
    global $TRANS_ENUM_SPEND;
    global $TRANS_ENUM_EARNING;
    global $TRANS_ENUM_BANK;
    global $TRANS_ENUM_COMMISSION;
    global $TRANS_ENUM_EARNBANK;
    global $STATUS_ENUM_ENABLE;
    global $STATUS_ENUM_DISABLE;
    global $STATUS_ENUM_LOCKED;
    global $TRANS_ENUM_COMPOUND;
    $nvar = db_get_array( "SELECT amount, exchange, uid, plan_type, cid FROM {$_lines} WHERE id='{$pmt_id}' AND status='{$STATUS_ENUM_DISABLE}' AND pmt_type = '{$TRANS_ENUM_SPEND}'" );
    $amount_spend = $nvar[0];
    $amount_exchange = $nvar[1];
    $uid = $nvar[2];
    $plid = $nvar[3];
    $SRC_ID = $nvar[4];
    if ( get_worth_name( $SRC_ID ) == "euro" )
    {
        $amount_spend = calculate_DST_amount( $SRC_ID, 50, $amount_spend );
        $amount_exchange = calculate_DST_amount( $SRC_ID, 50, $amount_exchange );
    }
    if ( isset( $amount_spend, $uid ) )
    {
        db_exec( "update {$_lines} set amount=(amount + {$amount_spend}), exchange=(exchange + {$amount_exchange}), date=now() WHERE pmt_type = '{$TRANS_ENUM_BANK}' AND status='{$STATUS_ENUM_ENABLE}' AND plan_type='{$plid}' AND uid='{$uid}'" );
        db_exec( "update {$_lines} set pmt_id='0', date=now() WHERE pmt_type='{$TRANS_ENUM_EARNBANK}' AND status='{$STATUS_ENUM_ENABLE}' AND plan_type='{$plid}' AND uid='{$uid}' AND amount<='0'" );
        $nvar = db_get_array( "SELECT id, amount, exchange, uid FROM {$_lines} WHERE pmt_id='{$pmt_id}' AND status='{$STATUS_ENUM_DISABLE}' AND pmt_type = '{$TRANS_ENUM_COMMISSION}'" );
        $referer_line_id = $nvar[0];
        $referer_amount = $nvar[1];
        $referer_exchange = $nvar[2];
        $referer_uid = $nvar[3];
        if ( $referer_amount && $referer_uid )
        {
            db_exec( "update {$_lines} set amount=(amount + {$referer_amount}), exchange=(exchange + {$referer_exchange}) WHERE pmt_type = '{$TRANS_ENUM_EARNBANK}' AND status='{$STATUS_ENUM_ENABLE}' AND uid='{$referer_uid}'" );
        }
        $src_trans_name = db_get_id( "SELECT transaction_name FROM {$_currencies} WHERE cid='{$SRC_ID}'" );
        db_exec( "update {$_lines} set \r\n\t\tpmt_note=\r\n\t\tcase pmt_type\r\n\t\twhen '{$TRANS_ENUM_SPEND}' then '{$src_trans_name}: #{$pmt_transaction}'\r\n\t\telse pmt_note\r\n\t\tend,\r\n\t\tstatus= \r\n\t\tcase pmt_type\r\n\t\twhen '{$TRANS_ENUM_COMMISSION}' then '{$STATUS_ENUM_ENABLE}'\r\n\t\telse '{$STATUS_ENUM_ENABLE}'\r\n\t\tend\r\n\t\tWHERE pmt_id='{$pmt_id}' and status='{$STATUS_ENUM_DISABLE}'" );
        update_reserved( $SRC_ID, $amount_spend );
    }
    else
    {
        Write_File( "<b>TRANSACTION not Confirmed!!!</b> payment id:".$pmt_id );
    }
}

function check_bank_row( $uid, $plan_type = 1, $payment_id = "" )
{
    global $STATUS_ENUM_ENABLE;
    global $TRANS_ENUM_BANK;
    global $PLAN_ID_UNKNOWN;
    global $_lines;
    global $LANG_note;
    $check_row = db_if_exists( "SELECT id FROM {$_lines} WHERE uid='{$uid}' AND pmt_type='{$TRANS_ENUM_BANK}' AND plan_type='{$plan_type}' AND status='{$STATUS_ENUM_ENABLE}'" );
    if ( !$check_row )
    {
        db_exec( "insert into {$_lines} (uid,plan_type,pmt_type,amount,exchange,cid,status,pmt_note,pmt_id,date) values ('{$uid}','{$plan_type}','{$TRANS_ENUM_BANK}','0','0','0','{$STATUS_ENUM_ENABLE}','{$LANG_note['b_spend']}','{$payment_id}',NOW())" );
    }
}

function check_earn_bank( $uid, $plan_type = 1, $payment_id = "" )
{
    global $STATUS_ENUM_ENABLE;
    global $TRANS_ENUM_EARNBANK;
    global $PLAN_ID_UNKNOWN;
    global $_lines;
    global $LANG_note;
    $check_row = db_if_exists( "SELECT id FROM {$_lines} WHERE uid='{$uid}' AND pmt_type='{$TRANS_ENUM_EARNBANK}' AND plan_type='{$plan_type}' AND status='{$STATUS_ENUM_ENABLE}'" );
    if ( !$check_row )
    {
        db_exec( "insert into {$_lines} (uid,plan_type,pmt_type,amount,exchange,cid,status,pmt_note,pmt_id,date) values ('{$uid}','{$plan_type}','{$TRANS_ENUM_EARNBANK}','0','0','0','{$STATUS_ENUM_ENABLE}','{$LANG_note['earning_bank']}','{$payment_id}',NOW())" );
    }
}

function check_compund_row( $uid, $plan_type = 1, $payment_id = "" )
{
    global $STATUS_ENUM_ENABLE;
    global $TRANS_ENUM_BONUS;
    global $TRANS_ENUM_BANK;
    global $INTERNAL_CID;
    global $TRANS_ENUM_COMPBANK;
    global $PLAN_ID_UNKNOWN;
    global $SIGNUP_BONUS;
    global $_lines;
    global $LANG_note;
    $check_row = db_if_exists( "SELECT id FROM {$_lines} WHERE uid='{$uid}' AND pmt_type='{$TRANS_ENUM_COMPBANK}' AND plan_type='{$plan_type}' AND status='{$STATUS_ENUM_ENABLE}'" );
    if ( !$check_row )
    {
        db_exec( "insert into {$_lines} (uid,plan_type,pmt_type,amount,exchange,cid,status,pmt_note,pmt_id,date) values ('{$uid}','{$plan_type}','{$TRANS_ENUM_COMPBANK}','0','0','0','{$STATUS_ENUM_ENABLE}','{$LANG_note['b_compound']}','{$payment_id}',NOW())" );
        if ( $SIGNUP_BONUS && db_if_exists( "SELECT id FROM {$_lines} WHERE uid='{$uid}' AND pmt_type='{$TRANS_ENUM_BANK}' AND status='{$STATUS_ENUM_ENABLE}' AND amount='0'" ) )
        {
            db_exec( "insert into {$_lines}\r\n\t\t\t(uid,pmt_type,amount,exchange,cid,status,pmt_note,date) values\r\n\t\t\t('{$uid}','{$TRANS_ENUM_BONUS}','{$SIGNUP_BONUS}','{$SIGNUP_BONUS}','{$INTERNAL_CID}','{$STATUS_ENUM_ENABLE}','Sign up Bonus',now())" );
            db_exec( "update {$_lines} set amount=(amount + {$SIGNUP_BONUS}), exchange=(exchange + {$SIGNUP_BONUS}) WHERE pmt_type = '{$TRANS_ENUM_BANK}' AND status='{$STATUS_ENUM_ENABLE}' AND uid='{$uid}'" );
        }
    }
}

function update_history( $uid )
{
    global $STATUS_ENUM_ENABLE;
    global $STATUS_ENUM_LOCKED;
    global $TRANS_ENUM_EARNING;
    global $TRANS_ENUM_WITHDRAW;
    global $STATUS_ENUM_DISABLE;
    global $TRANS_ENUM_COMPOUND;
    global $TRANS_ENUM_BANK;
    global $TRANS_ENUM_EARNBANK;
    global $TRANS_ENUM_COMPBANK;
    global $TRANS_ENUM_SPEND;
    global $PLAN_ID_DAILY;
    global $PLAN_ID_PERIOD;
    global $PLAN_ID_SPC_DAILY;
    global $PLAN_ID_SPC_WEEKLY;
    global $PLAN_ID_SPC_BIWEEKLY;
    global $PLAN_ID_SPC_MONTHLY;
    global $PLAN_ID_SPC_YEARLY;
    global $LANG_note;
    global $def_use_special_plans;
    global $def_use_weekly_earning;
    global $def_principal_full_withdraw;
    global $STATUS_ENUM_CLEAR;
    global $def_compound_full_withdraw;
    global $def_compound_infect_principal;
    global $THIS_SITE_PLAN_ID;
    global $_users;
    global $_lines;
    global $_daily_plans;
    global $_period_plans;
    global $_special_plans;
    global $def_days_stop_payment;
    global $COMPOUND_ENABLE;
    global $WEEKLY_PAYOUT_DAY;
    global $RANDOM_RATES;
    global $_payout_table;
    $user = "and uid='{$uid}'";
    $plid = $THIS_SITE_PLAN_ID;
    check_rows( $uid, $plid, $payment_id );
    $root_compound_percent = db_get_id( "SELECT compound FROM {$_users} WHERE uid={$uid}" );
    $query = "SELECT id,uid,amount,exchange,cid,date,to_days(date) as datecount,plan_type,status from {$_lines} WHERE pmt_type='{$TRANS_ENUM_BANK}' and status='{$STATUS_ENUM_ENABLE}' and date<now() and amount>0 {$user}";
    $result = db_query( $query );
    while ( $line = db_fetch_array( $result ) )
    {
        $plid = $line[plan_type];
        $root_id = $line[id];
        $root_datecount = $line[datecount];
        $root_amount = $line[amount];
        $root_exchange = $line[exchange];
        $root_status = $line[status];
        $nvar = db_get_array( "SELECT date, to_days(date) from {$_lines} WHERE pmt_type='{$TRANS_ENUM_EARNBANK}' and status='{$STATUS_ENUM_ENABLE}' and plan_type ='{$plid}' and date<now() {$user}" );
        $last_date = $nvar[0];
        $last_datecount = $nvar[1];
        if ( $last_datecount )
        {
            if ( $plid == $PLAN_ID_DAILY )
            {
                $nvar = db_get_array( "SELECT pct_daily_rate, random_rate_part, plan_period from {$_daily_plans} WHERE suspended='0' and amount_min <= {$root_amount} and (amount_max >= {$root_amount} or amount_max='0')" );
                $percent = $nvar[0];
                $random_part = $nvar[1];
                $plan_period = $nvar[2];
                $step = 1;
                $INTERVAL = "DAY";
            }
            else if ( $plid == $PLAN_ID_PERIOD )
            {
                $nvar = db_get_array( "SELECT pct_period_rate, period_days from {$_period_plans} WHERE suspended='0' and amount_min<='{$root_exchange}' and (amount_max>='{$root_exchange}' or amount_max='0')" );
                $percent = $nvar[0];
                $step = $nvar[1];
                $INTERVAL = "DAY";
            }
            else if ( get_special_plid( $plid ) )
            {
                $percent = db_get_id( "SELECT pct_special_rate from {$_special_plans} WHERE suspended='0' and special_type='{$plid}'" );
                $nvar = get_special_interval( $plid );
                $step = 1;
                $INTERVAL = $nvar[1];
            }
            if ( $percent && $step && $INTERVAL )
            {
                $now_datecount = db_get_id( "SELECT to_days(now())" );
                do
                {
                    if ( $last_datecount < $now_datecount )
                    {
                        if ( $RANDOM_RATES )
                        {
                            $check_date = date( "Y-m-d", strtotime( $last_date ) + 60 * 60 * 24 )." 12:00:00";
                            $nvar = db_get_array( "SELECT {$_payout_table}.{$plid}, rate_reason FROM {$_payout_table} WHERE rate_date='{$check_date}'" );
                            $full_random_rate = explode( ":", $nvar[0] );
                            $percent = $full_random_rate[$random_part];
                            $reason = htmlspecialchars( $nvar[1] );
                        }
                        if ( $plid == $PLAN_ID_DAILY && !$reason )
                        {
                            if ( date( "D", strtotime( $last_date ) + 60 * 60 * 24 ) == "Sat" || date( "D", strtotime( $last_date ) + 60 * 60 * 24 ) == "Sun" )
                            {
                                $reason = "(Weekend)";
                            }
                            $US_HOLIDAYS = getHolidays2( date( "Y", strtotime( $last_date ) ) );
                            $check_date = date( "Y-m-d", strtotime( $last_date ) + 60 * 60 * 24 );
                            if ( array_key_exists( $check_date, $US_HOLIDAYS ) )
                            {
                                $reason = "(".htmlspecialchars( $US_HOLIDAYS[$check_date] ).")";
                            }
                        }
                        if ( !$reason )
                        {
                            $nvar = db_get_array( "SELECT amount, exchange from {$_lines} WHERE pmt_type='{$TRANS_ENUM_COMPBANK}' AND status='{$STATUS_ENUM_ENABLE}' AND plan_type='{$plid}' {$user}" );
                            $compunded_amount = $nvar[0];
                            $compunded_exchange = $nvar[1];
                            $amount = ( $root_amount + $compunded_amount ) * $percent / 100;
                            $exchange = ( $root_exchange + $compunded_exchange ) * $percent / 100;
                        }
                        else
                        {
                            $Var_8256 = 0;
                            $amount = 0;
                            $exchange = 0;
                        }
                        if ( 0 < $root_compound_percent && $COMPOUND_ENABLE && !$reason )
                        {
                            $compound_amount = $amount * $root_compound_percent / 100;
                            $compound_exchange = get_exchange( $compound_amount, $INTERNAL_CID, "compound" );
                            db_exec( "insert into {$_lines} (uid,plan_type,pmt_type,amount,exchange,status,pmt_note,pmt_id,date) values ('{$line['uid']}','{$plid}','{$TRANS_ENUM_COMPOUND}','{$compound_amount}', '{$compound_exchange}', '{$STATUS_ENUM_ENABLE}', ".$LANG_msg['note_compound']."' {$reason}', '{$root_id}',DATE_ADD('{$last_date}',INTERVAL {$step} {$INTERVAL}))" );
                            db_exec( "update {$_lines} set amount=(amount+{$compound_amount}), exchange=(exchange+{$compound_exchange}), date=DATE_ADD('{$last_date}',INTERVAL {$step} {$INTERVAL}) WHERE pmt_type='{$TRANS_ENUM_COMPBANK}' and status='{$STATUS_ENUM_ENABLE}' and plan_type='{$plid}' {$user}" );
                            if ( $def_compound_infect_principal )
                            {
                                db_exec( "update {$_lines} set date=DATE_ADD('{$last_date}',INTERVAL {$step} {$INTERVAL}) WHERE pmt_type = '{$TRANS_ENUM_BANK}' AND plan_type='{$plid}' {$user}" );
                                ++$root_datecount;
                            }
                            $amount = $amount - $compound_amount;
                            $exchange = $exchange - $compound_exchange;
                        }
                        if ( $plid == $PLAN_ID_DAILY )
                        {
                            db_exec( "insert into {$_lines} (uid,plan_type,pmt_type,amount,exchange,cid,status,pmt_note,pmt_id,date) values ('{$line['uid']}','{$plid}','{$TRANS_ENUM_EARNING}','{$amount}','{$exchange}','{$line['cid']}','{$STATUS_ENUM_ENABLE}', ".$LANG_msg['note_earning']." ' {$reason}','',DATE_ADD('{$last_date}',INTERVAL {$step} {$INTERVAL}))" );
                            $new_id = mysql_insert_id( );
                            db_exec( "update {$_lines} set amount=(amount+{$amount}), exchange=(exchange+{$exchange}), date=DATE_ADD('{$last_date}',INTERVAL {$step} {$INTERVAL}), user_note='Daily intrest {$uid}' WHERE pmt_type='{$TRANS_ENUM_EARNBANK}' and status='{$STATUS_ENUM_ENABLE}' and plan_type='{$plid}' {$user}" );
                            $last_date = $nvar[0];
                            $last_datecount = $nvar[1];
                        }
                        if ( $plid == $PLAN_ID_SPC_WEEKLY )
                        {
                            $new_id = mysql_insert_id( );
                            db_exec( "update {$_lines} set date=DATE_ADD('{$last_date}',INTERVAL {$step} {$INTERVAL}) WHERE pmt_type='{$TRANS_ENUM_EARNBANK}' and status='{$STATUS_ENUM_ENABLE}' and plan_type='{$plid}' {$user}" );
                            $nvar = db_get_array( "SELECT date, to_days(date) from {$_lines} WHERE id='{$new_id}' AND pmt_type='{$TRANS_ENUM_EARNING}' AND status='{$STATUS_ENUM_DISABLE}'" );
                            $last_date = $nvar[0];
                            $last_datecount = $nvar[1];
                            $next_payday = date( "Y-m-d", strtotime( "Next ".$WEEKLY_PAYOUT_DAY, strtotime( $last_date ) ) );
                            $date_differnce = date_difference( $last_date, $next_payday );
                            $last_date_name = date( "l", strtotime( $last_date ) );
                            if ( $last_date_name == $WEEKLY_PAYOUT_DAY )
                            {
                                $reason = "Weekly earning untill ".$next_payday;
                                $hidden_profit = db_get_id( "SELECT SUM(amount) from {$_lines} WHERE pmt_type='{$TRANS_ENUM_EARNING}' AND status='{$STATUS_ENUM_DISABLE}' AND plan_type='{$plid}' {$user}" );
                                db_exec( "update {$_lines} set amount=(amount+{$hidden_profit}), exchange=(exchange+{$hidden_profit}), user_note='Weekly profit {$uid}' WHERE pmt_type='{$TRANS_ENUM_EARNBANK}' and status='{$STATUS_ENUM_ENABLE}' and plan_type='{$plid}' {$user}" );
                                db_exec( "update {$_lines} set status='{$STATUS_ENUM_CLEAR}', user_note='Weekly Profit' WHERE pmt_type='{$TRANS_ENUM_EARNING}' and status='{$STATUS_ENUM_DISABLE}' and plan_type='{$plid}' {$user}" );
                                $exchange = $hidden_profit;
                                db_exec( "insert into {$_lines} (uid,plan_type,pmt_type,amount,exchange,cid,status,pmt_note,pmt_id,date) values ('{$line['uid']}','{$plid}','{$TRANS_ENUM_EARNING}','{$hidden_profit}','{$exchange}','{$line['cid']}','{$STATUS_ENUM_ENABLE}','{$reason}','',DATE_ADD('{$last_date}',INTERVAL {$step} {$INTERVAL}))" );
                            }
                        }
                        unset( $reason );
                    }
                } while ( 1 );
                if ( $def_principal_full_withdraw )
                {
                    db_exec( "update {$_lines} set status='{$STATUS_ENUM_LOCKED}' Where pmt_type = '{$TRANS_ENUM_BANK}' AND plan_type = '{$plid}' {$user}" );
                }
                else
                {
                    db_exec( "update {$_lines} set status='{$STATUS_ENUM_CLEAR}' Where pmt_type = '{$TRANS_ENUM_BANK}' AND plan_type = '{$plid}' {$user}" );
                }
                if ( $def_compound_full_withdraw )
                {
                    db_exec( "update {$_lines} set status='{$STATUS_ENUM_LOCKED}' Where pmt_type = '{$TRANS_ENUM_COMPBANK}' AND plan_type = '{$plid}' {$user}" );
                }
                break;
            }
        }
    }
    db_free_result( $result );
}

?>
