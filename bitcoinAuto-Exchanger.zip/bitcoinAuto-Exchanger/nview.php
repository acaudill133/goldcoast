<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function replaceBadLinks( $str )
{
    global $CONFIG;
    $str = str_replace( "http:///", "", $str );
    preg_match_all( "#(href|src)=\"([^:\"]*)#", $str, $matches, PREG_SET_ORDER );
    foreach ( $matches as $val )
    {
        if ( !strstr( strtolower( $val[0] ), "http" ) )
        {
            if ( $CONFIG['FRIENDLY_URL'] )
            {
                $str_changed = preg_replace( "#(href|src)=\"([^:\"]*)#", "\$1=\"".get_link( "\$2" )."\"", $val[0] );
            }
            else
            {
                $str_changed = preg_replace( "#(href|src)=\"([^:\"]*)#", "\$1=\"".$CONFIG['SITE_URL']."/\$2\"", $val[0] );
            }
        }
        else
        {
            $str_changed = "";
        }
        if ( $str_changed )
        {
        }
    }
    $str = str_replace( $str, ".gif/", $str );
    $str = str_replace( ".jpg/", ".jpg", $str );
    $str = str_replace( ".png/", ".png", $str );
    $str = str_replace( ":&quot;", ":\"", $str );
    $str = str_replace( "&quot;}", "\"}", $str );
    return $str;
}

require( "public.inc.php" );
$str_tool = new string_tool( );
$id = $str_tool->remove_dangerous_chars( trim( $_GET['id'] ) );
$title = trim( urldecode( $_GET['title'] ) );
if ( is_numeric( $id ) )
{
    $doc_type = db_get_id( "SELECT type FROM {$_news} WHERE fld_language='{$language}' AND related_id='{$id}' AND status='1'" );
    if ( $doc_type )
    {
        $query = "SELECT * FROM {$_news} WHERE status='1' AND related_id='{$id}' AND  fld_language='{$language}' ";
    }
    else
    {
        $doc_type = db_get_id( "SELECT type FROM {$_news} WHERE status='1' AND related_id='{$id}' AND  fld_language='{$CONFIG['DEF_LANGUAGE']}'" );
        $query = "SELECT * FROM {$_news} WHERE status='1' AND related_id='{$id}' AND  fld_language='{$CONFIG['DEF_LANGUAGE']}' ";
    }
}
else if ( $title )
{
    $nvar = db_get_array( "SELECT id, type FROM {$_news} WHERE fld_language='{$language}' AND fld_title LIKE '{$title}%' AND status='1'" );
    $id = $nvar[0];
    $doc_type = $nvar[1];
    if ( $doc_type )
    {
        $query = "SELECT * FROM {$_news} WHERE status='1' AND id='{$id}' AND  fld_language='{$language}'";
    }
    else
    {
        $nvar = db_get_array( "SELECT id, type FROM {$_news} WHERE fld_language='{$CONFIG['DEF_LANGUAGE']}' AND fld_title LIKE '{$title}%' AND status='1'" );
        $id = $nvar[0];
        $doc_type = $nvar[1];
        $query = "SELECT * FROM {$_news} WHERE status='1' AND fld_language='{$CONFIG['DEF_LANGUAGE']}' AND fld_title LIKE '{$title}%' AND status='1'";
    }
}
if ( !$query )
{
    $query = "SELECT * FROM {$_news} WHERE status = '1' AND type='1' AND fld_language='{$language}' ORDER BY fld_date desc";
}
$page = $_GET['page'];
$total = db_num_rows( db_query( $query ) );
$perpage = 10;
$url_string = get_link( $cur_page.( $CONFIG['FRIENDLY_URL'] ? "" : "?" ).preg_replace( "/(&)page(\\/^|=)\\d+/", "", $_SERVER['QUERY_STRING'] ) );
$pager = new pager( $total, $perpage, $url_string, $CONFIG['FRIENDLY_URL'] );
if ( empty( $page ) )
{
    $page = 1;
}
$from = $pager->getPageFrom( $page );
$query = $query." limit {$from}, {$perpage}";
if ( !$total )
{
    $Error[] = $LANG_msg['news_005'];
}
$result = db_query( $query, "&nbsp;" );
$arr_data_news = mysql_push_data( $result );
db_free_result( $result );
switch ( $doc_type )
{
case 1 :
    $page_title = $CONFIG['SITE_NAME']." ".$LANG_msg['menu_017'];
    $NEWS = true;
    break;
case 2 :
    $page_title = $arr_data_news[0]['fld_title'];
    break;
case 3 :
}
$page_title = $CONFIG['SITE_NAME']." ".$LANG_msg['menu_022'];
break;
$page_title = $CONFIG['SITE_NAME']." ".$LANG_msg['news_007'];
$NEWS = true;
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."nview.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "nview.html";
    if ( $perpage < $total )
    {
        $pg = $pager->page;
        $page_navigation .= $pager->getButPrev( $pg );
        $range = 20;
        $page_navigation .= $pager->getButList( $range );
        $page_navigation .= $pager->getButNext( $pg );
        $page_navigation .= "<br><br><br>";
        $page_navigation .= $pager->getRangeInfo( );
    }
    $page->assign( "page_navigation", $page_navigation );
    foreach ( $arr_data_news as $key => $value )
    {
        $arr_data_news[$key]['fld_body_2'] = replacebadlinks( $arr_data_news[$key]['fld_body'] );
        $arr_data_news[$key]['fld_body_2'] = str_replace( "[SITE_NAME]", $CONFIG['SITE_NAME'], $arr_data_news[$key]['fld_body_2'] );
        $arr_data_news[$key]['fld_body_2'] = str_replace( "[SITE_URL]", $CONFIG['SITE_URL'], $arr_data_news[$key]['fld_body_2'] );
        $arr_data_news[$key]['fld_body_2'] = str_replace( "[SITE_URL_SECURE]", $CONFIG['SITE_URL_SECURE'], $arr_data_news[$key]['fld_body_2'] );
    }
    $page->assign( "arr_data_news", $arr_data_news );
    $page->assign( "NEWS", $NEWS );
    $page->assign( "page_title", $page_title );
    require( "include/engine_run.php" );
}
?>
