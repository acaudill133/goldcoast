<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "public.inc.php" );
if ( !session_admin( ) )
{
    @header( "Location: ".$CONFIG['SITE_URL'] );
}
$tinymce_one_filed = true;
if ( $CONFIG['tinymce_editor'] )
{
    if ( strstr( $_SERVER['HTTP_ACCEPT_ENCODING'], "gzip" ) )
    {
        $tiny_config_file = "jscripts/tiny_mce/tinymce_config_gzip.inc.js";
    }
    else
    {
        $tiny_config_file = "jscripts/tiny_mce/tinymce_config.inc.js";
    }
    $tiny_js = file_get_contents( $tiny_config_file );
    $tiny_js = str_replace( "[SITE_URL]", $CONFIG['SITE_URL'], $tiny_js );
    $tiny_js = str_replace( "[SKIN_CSS]", $CONFIG['SKIN_CSS'], $tiny_js );
    if ( $tinymce_one_filed )
    {
        $tiny_js = str_replace( "//[OPTIONAL],", "editor_selector : \"mceEditor\",", $tiny_js );
    }
}
if ( $NoTemp && $CONFIG['tinymce_editor'] )
{
    echo $tiny_js;
}
set_time_limit( 120 );
$mail_list = $_REQUEST['mail_list'];
$mail_subject = $_REQUEST['mail_subject'];
$mail_content = $_REQUEST['mail_content'];
if ( $_POST['task'] != "mail_sender" )
{
    $member_type = $_POST['member_type'];
    $search_mem = $_POST['searchmem'];
    if ( !$_POST['searchmem'] )
    {
        $search_mem = $_GET['searchmem'];
    }
    if ( $search_mem != "" )
    {
        $Query = "SELECT {$_users_details}.uid, {$_users}.login, {$_users_details}.fullname, {$_users_details}.email\r\n\t\t\t\t\t\tFROM {$_users_details} LEFT Join {$_users} ON {$_users_details}.uid = {$_users}.uid\r\n\t\t\t\t\t\tWHERE {$_users}.login = '%{$search_mem}%' OR {$_users_details}.fullname Like '%{$search_mem}%' OR {$_users_details}.email Like '%{$search_mem}%'";
    }
    else if ( !$member_type )
    {
        $Query = "SELECT {$_users_details}.uid, {$_users_details}.fullname, {$_users_details}.email\r\n\t\t\t\t\tFROM {$_users_details} WHERE {$_users_details}.suspended = '0' GROUP BY {$Var_2520}.uid";
    }
    else if ( $member_type == 1 )
    {
        $Query = "SELECT .fullname, {$_users_details}.uid, {$_users_details}.email\r\n\t\t\t\t\tFROM {$_users_details} Left Join {$_lines} ON {$_users_details}.uid = {$_lines}.uid\r\n\t\t\t\t\tWHERE {$_lines}.pmt_type='{$TRANS_ENUM_BANK}' AND {$_lines}.amount >= '5' AND {$_users_details}.suspended = '0' GROUP BY {$_users_details}.uid";
    }
    else if ( $member_type == 2 )
    {
        $Query = "SELECT {$_users_details}.uid, {$_users_details}.fullname, {$_users_details}.email\r\n\t\t\t\t\t  FROM {$_users_details} Left Join {$_lines} ON {$_lines}.uid = {$_users_details}.uid\r\n\t\t\t\t\t  WHERE {$_lines}.pmt_type='{$TRANS_ENUM_BANK}' AND {$_lines}.amount = '0' AND {$_users_details}.suspended = '0' GROUP BY {$_users_details}.uid";
    }
    if ( !$_GET['sendmailto'] )
    {
        if ( !( $query_id = mysql_query( $Query ) ) )
        {
            exit( mysql_error( "Bad Sql Command" ) );
        }
        if ( !$query_id )
        {
            echo "No Results";
        }
        $email_list = "";
        $i = 0;
        while ( $i < mysql_num_rows( $query_id ) )
        {
            $row = mysql_fetch_assoc( $query_id );
            if ( eregi( ".+@.+\\..+", $row['email'] ) )
            {
                $email_list .= $row['fullname'].":".$row['email'].":".$row['uid']."\n";
            }
            ++$i;
        }
    }
}
else if ( $_REQUEST['mail_list'] != "" && $_REQUEST['task'] == "mail_sender" && $_REQUEST['mail_subject'] && !$demo_mode )
{
    $str_tool = new string_tool( );
    $content = "";
    $mail_headers = "MIME-Version: 1.0\r\n";
    $mail_headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
    if ( strpos( $mail_subject, "Statistics" ) )
    {
        $mail_headers .= "From: dontreply@".$CONFIG['SITE_NAME']." <".$CONFIG['REPORT_MAIL'].">\r\n";
        $mail_title = "Statistics";
    }
    else if ( strpos( $mail_subject, "Newsletter" ) )
    {
        $mail_headers .= "From: ".$CONFIG['SITE_NAME']." customers support <".$CONFIG['REPORT_MAIL'].">\r\n";
        $mail_title = "Support Message";
    }
    else
    {
        $mail_headers .= "From: ".$CONFIG['REPORT_MAIL_NAME']." <".$CONFIG['REPORT_MAIL'].">\r\n";
        $mail_title = "Support Message";
    }
    $mail_headers .= "Reply-to: ".$CONFIG['ADMIN_MAIL']."\r\n";
    $mail_list = explode(  );
    $i = 0;
    while ( $i < count( $mail_list ) )
    {
        list( $fullname, $email, $uid ) = fullname  ;      if ( 0 < strlen( $email ) )
        {
            $arr_Replacer = array(
                "fullname" => $fullname,
                "email" => $email,
                "balance" => $balance_str,
                "date" => $accept_date
            );
            $mail = new siteMAIL( );
            $mail->AddAddress( $email, $fullname );
            $mail->Subject = $mail_subject;
            $mail->Body = nl2br( $mail_content );
            $mail->mail_title = $mail_title;
            $mail->arrReplacer = $arr_Replacer;
            $mail->bakeMail( );
            if ( $CONFIG['MAIL_TYPE'] == "smtp" && count( $Error ) < 5 )
            {
                if ( !$mail->Send( ) )
                {
                    $Error[] = "There was an error sending mails: ".$mail->ErrorInfo;
                }
            }
            else if ( count( $Error ) < 5 )
            {
                if ( !mail( $email, $mail->Subject, $mail->Body, $mail_headers ) )
                {
                    $Error[] = "There was an error sending the email by server php mail extension.";
                }
                if ( $CONFIG['adminemailnotification'] )
                {
                    mail( $CONFIG['ADMIN_MAIL'], $mail->Subject, $mail->Body, $mail_headers );
                }
            }
        }
        ++$i;
    }
    if ( !$Error )
    {
        $Success[] = "<div style='font-weight:normal'>Your mail(s) has been sent for {$i} Person!";
        $Success[] = $subject;
        $Success[] = $mail->Body."</div>";
    }
}
else
{
    $Error[] = "Check subject and mailing list";
}
if ( $_REQUEST['mail_list'] != "" && $_REQUEST['task'] == "mail_sender" && $_REQUEST['mail_subject'] && $demo_mode )
{
    $Error_div[] = "Some features are not active in Demo Version.";
}
echo "\r\n\r\n\r\n\r\n";
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."adm_massemail.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "adm_massemail.html";
    $page->assign( "mail_list", $_POST['mail_list'] ? $_POST['mail_list'] : $email_list );
    $page->assign( "mail_subject", $mail_subject );
    if ( !$mail_content )
    {
        $mail_content = "Hello dear <b>[fullname]</b>,<br><br>";
    }
    $page->assign( "mail_content", $mail_content );
    $page->assign( "total_selected", $i );
    $page->assign( "search_mem", $search_mem );
    $page->assign( "member_types", array( 0 => "All", 1 => "Paid Members", 2 => "NotPaid Members" ) );
    $page->assign( "tiny_js", $tiny_js );
    require( "include/engine_run.php" );
}
?>
