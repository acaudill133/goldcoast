<h3><?php echo $lang['about']; ?></h3>

<?php echo $settings['p_about']; ?>