<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function set_check( $var )
{
    return "checked";
}
#}

require( "public.inc.php" );
include( "include/user_ids_include.php" );
if ( !$uid && !session_admin( ) )
{
    header( "Location: ".$CONFIG['SITE_URL'] );
}
$s = $_POST['s'];
$w = $_POST['w'];
$c = $_POST['c'];
$b = $_POST['b'];
$p = $_POST['p'];
$e = $_POST['e'];
$t = $_POST['t'];
$year = $_POST['year'];
$month = $_POST['month'];
if ( !$year )
{
    $year = date( Y );
}
if ( !$month )
{
    $month = date( m );
}
if ( !$s && !$w && !$c && !$b && !$p && !$e )
{
    $c = 1;
    $b = 1;
    $p = 1;
    $e = 1;
}
if ( $s && $w && $c && $b && $p && $e )
{
    $add = "'{$TRANS_ENUM_INTERNAL}','{$TRANS_ENUM_TRANSFER}'";
}
else
{
    $add = "''";
}
$types = "";
if ( $s )
{
    $types .= "'{$TRANS_ENUM_SPEND}',";
}
if ( $w )
{
    $types .= "'{$TRANS_ENUM_WITHDRAW}',";
}
if ( $c )
{
    $types .= "'{$TRANS_ENUM_COMMISSION}',";
}
if ( $b )
{
    $types .= "'{$TRANS_ENUM_BONUS}',";
}
if ( $p )
{
    $types .= "'{$TRANS_ENUM_PENALTY}',";
}
if ( $e )
{
    $types .= "'{$TRANS_ENUM_EARNING}',";
}
if ( $t )
{
    $types .= "'{$TRANS_ENUM_TRANSFER}',";
}
$types .= "'{$TRANS_ENUM_PENALTY}','{$TRANS_ENUM_BONUS}',";
$types .= $add;
$types = "'{$TRANS_ENUM_TRANSFER}', '{$TRANS_ENUM_INTERNAL}', '{$TRANS_ENUM_COMMISSION}', '{$TRANS_ENUM_BONUS}', '{$TRANS_ENUM_PENALTY}', '{$TRANS_ENUM_EARNING}', '{$TRANS_ENUM_COMPOUND}'";
$count = 0;
$no = 0;
$query = "SELECT *, DATE(src_date) as src_date FROM {$_exchange_lines} WHERE uid='{$uid}' and src_status='1' ORDER BY src_date ";
$page = $_GET['page'];
$total = mysql_num_rows( mysql_query( $query ) );
$perpage = $CONFIG['recordsnumperpage'];
$url_string = get_link( $cur_page.( $CONFIG['FRIENDLY_URL'] ? "" : "?" ).preg_replace( "/(&)page(\\/^|=)\\d+/", "", $_SERVER['QUERY_STRING'] ) );
$pager = new pager( $total, $perpage, $url_string, $CONFIG['FRIENDLY_URL'] );
if ( empty( $page ) )
{
    $page = 1;
}
$from = $pager->getPageFrom( $page );
$query = $query." limit {$from}, {$Var_4896}";
$result = db_query( $query, "&nbsp;" );
$arr_data_exchange_history = mysql_push_data( $result );
db_free_result( $result );
echo "\r\n\r\n";
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."exchange_history.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "exchange_history.html";
    if ( $perpage < $total )
    {
        $pg = $pager->page;
        $page_navigation .= $pager->getButPrev( $pg );
        $range = 20;
        $page_navigation .= $pager->getButList( $range );
        $page_navigation .= $pager->getButNext( $pg );
        $page_navigation .= "<br><br><br>";
        $page_navigation .= $pager->getRangeInfo( );
    }
    $page->assign( "page_navigation", $page_navigation );
    $result = db_query( "select cid, currency_name, currency_worth_name from {$_currencies}", "&nbsp;" );
    while ( $line = db_fetch_array( $result ) )
    {
        $All_currencies_name[$line['cid']] = $line['currency_name'];
        $All_currencies_worth[$line['cid']] = $line['currency_worth_name'];
    }
    db_free_result( $result );
    $i = 1;
    foreach ( $arr_data_exchange_history as $key => $value )
    {
        $arr_data_exchange_history[$key]['NO'] = $i++;
        $arr_data_exchange_history[$key]['src_merchant_name'] = $All_currencies_name[$arr_data_exchange_history[$key][src_cid]];
        $arr_data_exchange_history[$key]['dst_merchant_name'] = $All_currencies_name[$arr_data_exchange_history[$key][dst_cid]];
        $arr_data_exchange_history[$key]['src_famount'] = set_money_color( FormatPrice( $arr_data_exchange_history[$key][src_amount] ), 1, $All_currencies_worth[$arr_data_exchange_history[$key][src_cid]] );
        $arr_data_exchange_history[$key]['dst_famount'] = set_money_color( FormatPrice( $arr_data_exchange_history[$key][dst_amount] ), 1, $All_currencies_worth[$arr_data_exchange_history[$key][dst_cid]] );
    }
    $page->assign( "src_worth", $src_worth );
    $page->assign( "dst_worth", $dst_worth );
    $page->assign( "arr_exchange_history", $arr_data_exchange_history );
    require( "include/engine_run.php" );
}
?>
