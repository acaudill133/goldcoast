<?php
/**
 * @package		 Google+ Page Badge Plugins
 * @subpackage	 Badge
 * @author		 E-max
 * @copyright    Copyright (C) 2008 - 2013 - E-max. All rights reserved.
 * @license      http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

jimport('joomla.plugin.plugin');

/**
 * Google+ Page Badge Plugins
 *
 * @package		Google+ Page Badge Plugins
 * @subpackage	Badge
 * @since 		1.6
 */
class plgContentGooglePageBadge extends JPlugin {
       
    /**
     * Constructor
     **/
    public function __construct(&$subject, $config = array()) {
        parent::__construct($subject, $config);
              
    }
    
    public function onContentPrepare($context, &$article, &$params, $limitstart) {

        $app = JFactory::getApplication();

        if($app->isAdmin()) {
            return;
        }
        
        $doc     = JFactory::getDocument();
        $docType = $doc->getType();
        
        // Check document type
        if(strcmp("html", $docType) != 0){
            return;
        }
        
        $ok = strstr ($article->text, '{googlepagebadge}');
            
        // Generate content
		$content      = $this->getContent($article, $params);

        if ($ok) {
			$article->text = str_replace('{googlepagebadge}', $content, $article->text);
		}
        return;
    }
    
    /**
     * Generate content
     * @param   object      The article object.  Note $article->text is also available
     * @param   object      The article params
     * @return  string      Returns html code or empty string.
     */
    private function getContent(&$article, &$params){
        
        $doc   = JFactory::getDocument();
            
        $doc->addStyleSheet(JURI::root() . "plugins/content/googlepagebadge/assets/css/style.css");

        $url = JURI::getInstance();
        $root= $url->getScheme() ."://" . $url->getHost();
        
        $url = JRoute::_(ContentHelperRoute::getArticleRoute($article->slug, $article->catslug), false);
        $url = $root.$url;
        $title= htmlentities($article->title, ENT_QUOTES, "UTF-8");
        
        $html = '<!-- Google+ Page Badge | Powered by <a href="http://e-max.it/creazione-siti-web/web-base" title="e-max.it: realizzazione siti internet" target="_blank" rel="nofollow">e-max.it: creare un sito web aziendale</a> -->
        <div class="google_page_badge">';
        $html .= $this->getGooglePageBadge($this->params, $url, $title);
        $html .= '
        </div>
        <div style="clear:both;"></div>
        ';

    	$credits = $this->params->get('GooglePageBadgecredits');
			if ($credits) {
				$html .= '<div class="google_page_badge_credits"><a href="http://e-max.it/posizionamento-siti-web/kickstart" title="e-max.it: ottimizzazione siti web" target="_blank" rel="nofollow"><img src="'.JURI::base(true).'/plugins/content/googlepagebadge/assets/img/parole_chiave_giuste.png" alt="Calibra il tuo SEO sulle parole chiave giuste" width="12" height="12" style="vertical-align:middle;" /></a></div>';
			}
			else {
				$html .= '<div class="google_page_badge_credits" style="display:none;"><a href="http://e-max.it/posizionamento-siti-web/kickstart" title="e-max.it: ottimizzazione siti web" target="_blank" rel="nofollow"><img src="'.JURI::base(true).'/plugins/content/googlepagebadge/assets/img/parole_chiave_giuste.png" alt="Calibra il tuo SEO sulle parole chiave giuste" width="12" height="12" style="vertical-align:middle;" /></a></div>';
			}
		$html .= '<!-- Google+ Page Badge | Powered by <a href="http://e-max.it/agenzia-web" title="creazione siti internet aziendali" target="_blank" rel="nofollow">e-max.it: le soluzioni web innovative</a> -->';
		
        return $html;
    }
          
    private function getGooglePageBadge($params, $url, $title){
		
		$doc = JFactory::getDocument();
		$lang='';
		$html = "";
		$link='';
		
		if ($params->get("GooglePageBadgeWidth") < "170") { $GooglePageBadgeHeight="131"; }
		else {
			if($params->get("GooglePageBadgeType")=="badge") { $GooglePageBadgeHeight="131"; }
			else { $GooglePageBadgeHeight="69"; }
		}
		$GooglePageBadgeWidth=$params->get("GooglePageBadgeWidth");
		if ($params->get("GooglePageBadgeWidth") < "100") { $GooglePageBadgeWidth="100"; }
		else if ($params->get("GooglePageBadgeWidth") > "1024") { $GooglePageBadgeWidth="1024"; }
		
		$lang='{lang: \'' . $params->get("GooglePageBadgeLang") . '\'}';
				
		if($params->get("GooglePageBadgeType")=="badge" || $params->get("GooglePageBadgeType")=="smallbadge") {
			if($params->get("GooglePageBadgeParse")=="explicit" || $params->get("GooglePageBadgeAsync")== "0") {
				$link.='<script type="text/javascript" src="https://apis.google.com/js/plusone.js">' . $lang . '</script>';
			}
			else {
				$link.='<script type="text/javascript">'."\n"
				.'window.___gcfg = ' . $lang . ';' ."\n"
				.'(function()'."\n"
				.'{var po = document.createElement("script");'."\n"
				.'po.type = "text/javascript"; po.async = true;po.src = "https://apis.google.com/js/plusone.js";'."\n"
				.'var s = document.getElementsByTagName("script")[0];'."\n"
				.'s.parentNode.insertBefore(po, s);'."\n"
				.'})();</script>';
			}
			if($params->get("GooglePageBadgeHtml5")) {
				$html = '<div class="g-plus" data-href="https://plus.google.com/' . $params->get("GooglePageBadgeId") . '?rel=publisher" data-width="' . $GooglePageBadgeWidth . '" data-height="' . $GooglePageBadgeHeight . '" data-theme="' . $params->get("GooglePageBadgeTheme") . '"></div>';
			}
			else {
				$html = '<g:plus href="https://plus.google.com/' . $params->get("GooglePageBadgeId") . '" rel="publisher" width="' . $GooglePageBadgeWidth . '" height="' . $GooglePageBadgeHeight . '" theme="' . $params->get("GooglePageBadgeTheme") . '"></g:plus>';
			}
			if($params->get("GooglePageBadgeParse")=="explicit") {
				$html.='<script type="text/javascript">gapi.plus.go();</script>';				
			}
		}
		else {
			$html='<a href="https://plus.google.com/' . $params->get("GooglePageBadgeId") . '?prsrc=3" rel="publisher" style="text-decoration:none;';
			if($params->get("GooglePageBadgeName")=="") { $html.='">'; }
			else {
				/*if($params->get("GooglePageBadgeType")!="largeicon") { $html.='cursor:pointer;'; }*/
				$html.='display:inline-block;color:#333;text-align:center;font:13px/16px arial,sans-serif;white-space:nowrap;';
				/*if($params->get("GooglePageBadgeType")=="largeicon") { $html.='text-align:center;white-space:nowrap;'; }*/
				if($params->get("GooglePageBadgeType")!="largeicon") { 
					$html.='"><span style="display:inline-block;font-weight:bold;vertical-align:top;margin-right:5px;';
					if($params->get("GooglePageBadgeType")=="mediumicon") { $html.='margin-top:8px;'; }
					else if($params->get("GooglePageBadgeType")=="smallicon") { $html.='margin-top:0px;'; }
					$html.='">' . $params->get("GooglePageBadgeName") . '</span><span style="display:inline-block;vertical-align:top;margin-right:';
					if($params->get("GooglePageBadgeType")=="smallicon") { $html.='13px;margin-top:0px;'; }
					else { $html.='15px;margin-top:8px;'; }
					$html.='">on</span>';
				}
				else { $html.='">';}
			}
			if($params->get("GooglePageBadgeType")=="smallicon") {$html.='<img src="https://ssl.gstatic.com/images/icons/gplus-16.png" alt="" style="border:0;width:16px;height:16px;"/></a>';}
			else if($params->get("GooglePageBadgeType")=="mediumicon") {
				$html.='<img src="https://ssl.gstatic.com/images/icons/gplus-32.png" alt="" style="border:0;width:32px;height:32px;"/></a>';
			}
			else {
				$html.='<img src="https://ssl.gstatic.com/images/icons/gplus-64.png" alt="" style="border:0;width:64px;height:64px;';
				if($params->get("GooglePageBadgeName")=="") { $html.='"/></a>'; }
				else {
					$html.='margin-bottom:7px;"><br/><span style="font-weight:bold;">' . $params->get("GooglePageBadgeName") . '</span><br/><span> on Google+ </span></a>';
				}
			}
		}
		$doc->addCustomTag($link);
        
        return $html;
    }
        
}