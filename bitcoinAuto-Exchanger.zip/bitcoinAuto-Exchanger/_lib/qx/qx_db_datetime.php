<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_db_datetime( $param )
{
    global $configuration;
    if ( preg_match( "/\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}/", $param ) )
    {
        return date( $configuration['datetime_format'], strtotime( $param ) );
    }
    return "Invalid date format!";
}

?>
