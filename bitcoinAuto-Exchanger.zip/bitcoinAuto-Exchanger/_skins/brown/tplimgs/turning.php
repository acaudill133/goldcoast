<?php
/**
*
* @ This file is created by Decodeby.US
* @ deZender Public (PHP5 Decompiler)
*
* @	Version			:	1.0.0.2
* @	Author			:	Ps2Gamer & Cyko
* @	Release on		:	25.07.2011
* @	Official site	:	http://decodeby.us
*
*/

function gerString( $char_num )
{
    rand( 0, time( ) );
    $possible = "1234567890";
    while ( strlen( $str ) < $char_num )
    {
        $str .= substr( $possible, rand( ) % strlen( $possible ), 1 );
    }
    $txt = $str;
    return $txt;
}

session_start( );
srand( ( double )microtime( ) * 10000000 );
$charwidth = 12;
$charheight = 17;
$char_num = 5;
$imgpath = "turning";
$bgNum = rand( 1, 4 );
$img = imagecreatefromjpeg( $imgpath."/"."background{$bgNum}.jpg" );
$UniqCode = gerString( $char_num );
$i = 0;
for ( ; $i < $char_num; $i++ )
{
    $char = substr( $UniqCode, $i, 1 );
    $litera = imagecreatefrompng( $imgpath."/".$char.".png" );
    imagecopyresampled( $img, $litera, $n, 0, 0, 0, $charwidth, $charheight, $charwidth, $charheight );
    $n += $charwidth;
}
$_SESSION['UniqCode'] = $UniqCode;
header( "Content-type: image/png" );
imagepng( $img );
?>
