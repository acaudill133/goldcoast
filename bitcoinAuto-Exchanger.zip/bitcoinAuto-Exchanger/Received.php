<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "include/config.inc.php" );
Write_File( );
$REFERER = $_SERVER['HTTP_REFERER'];
if ( isset( $_POST['PAYMENT_BATCH_NUM'] ) )
{
    $PAYMENT_ID = $_POST['PAYMENT_ID'];
    $payment_amount = $_POST['PAYMENT_AMOUNT'];
    $payer_acc = $_POST['PAYER_ACCOUNT'];
    $payment_batch = $_POST['PAYMENT_BATCH_NUM'];
    $payment_type = "E-gold/PerfectMoney";
}
else if ( isset( $_POST['ATIP_TRANSACTION_ID'] ) )
{
    $PAYMENT_ID = $_POST['paymentid'];
    $payment_amount = $_POST['ATIP_PAYMENT_AMOUNT'];
    $worth_of = $_POST['ATIP_PAYMENT_METAL'];
    $payment_batch = $_POST['ATIP_TRANSACTION_ID'];
    $payment_type = "E-bullion";
}
else if ( isset( $_POST['PAYMENT_REC_ID'] ) )
{
    $PAYMENT_ID = $_POST['PAYMENT_ID'];
    $payment_amount = $_POST['PAYMENT_AMOUNT'];
    $worth_of = $_POST['PAYMENT_UNITS'];
    $payment_batch = $_POST['PAYMENT_REC_ID'];
    $payer_acc = $_POST['PAYER_ACCOUNT'];
    $payment_type = "Pecunix";
}
else if ( isset( $_POST['lr_transfer'] ) )
{
    $PAYMENT_ID = $_POST['order_id'];
    $payment_amount = $_POST['lr_amnt'];
    $worth_of = $_POST['lr_currency'];
    $payment_batch = $_POST['lr_transfer'];
    $payment_type = "Liberty Reserve";
}
else if ( isset( $_POST['PMT_PAYMENT_ID'] ) )
{
    $PAYMENT_ID = $_POST['PMT_PAYMENT_ID'];
    $payment_amount = $_POST['PMT_AMOUNT'];
    $payment_batch = $_POST['PMT_BATCH_NUM'];
    $payment_type = "V-money";
}
else if ( isset( $_POST['LMI_PAYMENT_NO'] ) )
{
    $PAYMENT_ID = $_POST['LMI_PAYMENT_NO'];
    $payment_batch = $_POST['LMI_SYS_TRANS_NO'];
    $payment_type = "Webmoney";
}
else if ( isset( $_POST['sigil3_str'] ) )
{
    $PAYMENT_ID = preg_replace( "/[A-z+ :#]/", "", $_POST['memo'] );
    if ( !is_numeric( $PAYMENT_ID ) )
    {
        $PAYMENT_ID = preg_replace(  );
    }
    $payment_amount = $_POST['payment_amount'];
    $payee_acc = $_POST['payee_account'];
    $payment_type = "C-gold";
}
else if ( eregi( "https://www.alertpay.com", $REFERER ) )
{
    $batch_name = $arr_ALERTPAY['TRANSACTION_NAME'];
    $payment_type = "Alertpay";
    $PAYMENT_ID = true;
}
if ( $PAYMENT_ID )
{
    $x_status = "Successfull";
}
if ( $Received_no )
{
    $x_status = "Failed";
}
echo "<html>\r\n<head>\r\n<link href=\"";
echo $CONFIG['SKIN_CSS'];
echo "/style.php\" rel=\"stylesheet\" type=\"text/css\">\r\n</head>\r\n<body onLoad=\"document.form.submit();\">\r\n<form method=\"POST\" action=\"";
echo get_link( "exchange_status.php" );
echo "\" name=\"form\">\r\n";
if ( eregi( "https://", $_SERVER['HTTP_REFERER'] ) || $_SERVER['HTTP_REFERER'] == "" )
{
    echo "\t<input TYPE=\"HIDDEN\" name=\"x_status\" id=\"x_status\" VALUE=\"";
    echo $x_status;
    echo "\">\r\n\t<input TYPE=\"HIDDEN\" name=\"referenceid\" id=\"referenceid\" VALUE=\"";
    echo $PAYMENT_ID;
    echo "\">\r\n";
}
echo "</form>\r\n</body>\r\n</html>";
?>
