<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "public.inc.php" );
if ( !session_admin( ) )
{
    @header( "Location: ".$CONFIG['SITE_URL'] );
}
$query = "Select cid From {$_currencies} Where ({$_currencies}.exchange_status = '1'  OR {$_currencies}.cid='50') Order By cid Asc";
$arr_currency_ID = array( );
$result = db_query( $query, "&nbsp;" );
$TOTAL_EX_CURRENCIES = mysql_num_rows( $result );
while ( $line = db_fetch_array( $result ) )
{
    $x = $line[cid];
    $arr_currency_ID[$x] = $line[cid];
    $coloumns .= $coloumns.", ";
}
db_free_result( $result );
$Oid = $_GET['id'];
$last = 1;
if ( $_POST['Action'] == "Save" && !$demo_mode )
{
    foreach ( $_POST as $key => $value )
    {
        list( $fieldname, $fld_Good_id ) = fieldname   ;     if ( !empty( $fieldname ) && ( $fieldname != "Action" && $fieldname != "Submit" ) )
        {
            if ( !$value )
            {
                $value = "0:0";
            }
            if ( !eregi( "[0-9.]:[0-9.]", $value ) && $value != "-" )
            {
                $Error[] = "Incorrect exchange rate value, all rates must seperated by ':'";
                $value = "0:0";
            }
            else if ( $value == "-" )
            {
                $value = "";
            }
            else if ( $value == "-" )
            {
                $value = "";
            }
            if ( $last == $TOTAL_EX_CURRENCIES )
            {
                $update_query .= "{$_exchange_rate}.{$fld_Good_id}='{$value}' WHERE cid='{$fieldname}'";
                $Query = "UPDATE {$_exchange_rate} SET {$update_query};";
                $result = db_query( $Query, "&nbsp;" );
                $update_query = "";
                $last = 1;
            }
            else
            {
                $update_query .= "{$_exchange_rate}.{$fld_Good_id}='{$value}', ";
                ++$last;
            }
            $Query = "UPDATE {$_exchange_rate} SET {$_exchange_rate}.{$fld_Good_id}='{$value}{$fieldname}';";
            $result = db_query( $Query, "&nbsp;" );
        }
    }
    $Success[] = "Exchange rates update sucessfully.";
}
if ( $_POST['Action'] == "Save" && $demo_mode )
{
    $Error_div[] = "Some features are not active in Demo Version.";
}
$query = "Select {$_exchange_rate}.*, {$_currencies}.currency_name, {$_currencies}.currency_metal_name, {$_currencies}.currency_worth_name From {$_exchange_rate} Inner Join {$_currencies} ON {$_exchange_rate}.cid = {$_currencies}.cid\r\n\t\tWhere ({$_currencies}.exchange_status = '1'  OR {$_currencies}.cid='50')Order By {$_currencies}.cid Asc;";
$result = db_query( $query, "&nbsp;" );
$arr_data_exrate = mysql_push_data( $result );
db_free_result( $result );
if ( $INVEST_SECTION )
{
    $section = "Invest_Static";
    include( "include/box_includes.php" );
}
echo "\r\n";
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."adm_exchange_rate.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "adm_exchange_rate.html";
    foreach ( $arr_data_exrate as $line )
    {
        fmod( $count, 2 ) == 1 ? ( $color = "#F8FAF9" ) : ( $color = "#F3F3F3" );
        ++$count;
        if ( !$_GET['enable_guide'] )
        {
            $Rate_Row .= "<tr style='background-color: {$color};'>";
        }
        else
        {
            $Rate_Row .= "<tr>";
        }
        $Rate_Row .= "<td  class='tablefirstrow' style='font-size:11px; text-align:center;'>".ucfirst( $line[currency_name] )." ".ucfirst( $line[currency_metal_name] )."</td>";
        foreach ( $arr_currency_ID as $key => $x )
        {
            if ( !$line[$x] )
            {
                $Rate_Row .= "<td><input type='hidden' name='".$line[cid]."|".$x."' value='-' />x</td>";
            }
            else
            {
                $Rate_Row .= "<td>"."<input type='text' size='8' name='".$line[cid]."|".$x."' value='".$line[$x]."' /></td>";
            }
        }
        $Rate_Row .= "</TR>\n";
    }
    $page->assign( "arr_currency_ID", $arr_currency_ID );
    $page->assign(  );
    $page->assign( "arr_exchange_rate", $arr_data_exrate );
    $page->assign( "Rate_Row", $Rate_Row );
    $page->assign( "get_enable_guide", $_GET['enable_guide'] );
    require( "include/engine_run.php" );
}
echo "\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n";
?>
