<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function paypalpaymentspro_activate( )
{
    definegatewayfield(  );
    definegatewayfield( "paypalpaymentspro", "text", "apipassword", "", "API Password", 30, "" );
    definegatewayfield( "paypalpaymentspro", "text", "apisignature", "", "API Signature", 30, "" );
    definegatewayfield( "paypalpaymentspro", "yesno", "sandbox", "", "Sandbox", "", "" );
}

function paypalpaymentspro_link( $params )
{
    $code = "<form method=\"post\" action=\"".$params['systemurl']."/creditcard.php\" name=\"paymentfrm\">\r\n\t\t<input type=\"hidden\" name=\"invoiceid\" value=\"".$params['invoiceid']."\">\r\n\t\t<input type=\"submit\" value=\"".$params['langpaynow']."\">\r\n\t\t</form>";
    return $code;
}

function paypalpaymentspro_capture( $params )
{
    if ( $params['sandbox'] )
    {
        $url = "https://api-3t.sandbox.paypal.com/nvp";
    }
    else
    {
        $url = "https://api-3t.paypal.com/nvp";
    }
    if ( $params['clientdetails']['country'] == "UK" )
    {
        $params['clientdetails']['country'] = "GB";
    }
    $cardtype = $params['cardtype'];
    if ( $cardtype == "American Express" )
    {
        $cardtype = "Amex";
    }
    $paymentvars['METHOD'] = "doDirectPayment";
    $paymentvars['VERSION'] = "3.0";
    $paymentvars['PWD'] = $params['apipassword'];
    $paymentvars['USER'] = $params['apiusername'];
    $paymentvars['SIGNATURE'] = $params['apisignature'];
    $paymentvars['PAYMENTACTION'] = "Sale";
    $paymentvars['AMT'] = $params['amount'];
    $paymentvars['CREDITCARDTYPE'] = $cardtype;
    $paymentvars['ACCT'] = $params['cardnum'];
    $paymentvars['EXPDATE'] = substr( $params['cardexp'], 0, 2 )."20".substr( $params['cardexp'], 2, 2 );
    $paymentvars['CVV2'] = $params['cccvv'];
    $paymentvars['FIRSTNAME'] = $params['clientdetails']['firstname'];
    $paymentvars['LASTNAME'] = $params['clientdetails']['lastname'];
    $paymentvars['STREET'] = $params['clientdetails']['address1'];
    $paymentvars['CITY'] = $params['clientdetails']['city'];
    $paymentvars['STATE'] = $params['clientdetails']['state'];
    $paymentvars['ZIP'] = $params['clientdetails']['postcode'];
    $paymentvars['COUNTRYCODE'] = $params['clientdetails']['country'];
    $paymentvars['CURRENCYCODE'] = $params['currency'];
    $paymentvars['INVNUM'] = $params['invoiceid'];
    $fieldstring = "";
    foreach ( $paymentvars as $key => $value )
    {
        $fieldstring .= "".$key."=".urlencode( $value )."&";
    }
    $ch = curl_init( );
    curl_setopt( $ch, CURLOPT_URL, $url );
    curl_setopt( $ch, CURLOPT_VERBOSE, 1 );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0 );
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
    curl_setopt( $ch, CURLOPT_POST, 1 );
    curl_setopt( $ch, CURLOPT_POSTFIELDS, $fieldstring );
    $response = curl_exec( $ch );
    if ( curl_errno( $ch ) )
    {
        $resArray['Curl Error Number'] = curl_errno( $ch );
        $resArray['Curl Error Description'] = curl_error( $ch );
    }
    else
    {
        $resArray = paypalpaymentspro_deformatnvp( $response );
    }
    curl_close( $ch );
    $debugreport = "";
    foreach ( $resArray as $key => $value )
    {
        $debugreport .= "".$key." => ".$value."\r\n";
    }
    $ack = strtoupper( $resArray['ACK'] );
    if ( $ack == "SUCCESS" || $ack == "SUCCESSWITHWARNING" )
    {
        addinvoicepayment( $params['invoiceid'], $$resArray['PPREF'], "", "", "paypalpro", "on" );
        logtransaction( "PayPal Payments Pro", $debugreport, "Successful" );
        sendmessage( "Credit Card Payment Confirmation", $params['invoiceid'] );
        $result = "success";
    }
    else
    {
        logtransaction( "PayPal Payments Pro", $debugreport, "Error" );
        sendmessage( "Credit Card Payment Failed", $params['invoiceid'] );
        $result = "error";
    }
    return $result;
}

function paypalpaymentspro_deformatnvp( $nvpstr )
{
    $intial = 0;
    $nvpArray = array( );
    while ( strlen( $nvpstr ) )
    {
        $keypos = strpos( $nvpstr, "=" );
        $valuepos = strpos( $nvpstr, "&" ) ? strpos( $nvpstr, "&" ) : strlen( $nvpstr );
        $keyval = substr( $nvpstr, $intial, $keypos );
        $valval = substr( $nvpstr, $Var_696 + 1, $valuepos - $keypos - 1 );
        $nvpArray[urldecode( $keyval )] = urldecode( $valval );
        $nvpstr = substr( $nvpstr, $valuepos + 1, strlen( $nvpstr ) );
    }
    return $nvpArray;
}

$GATEWAYMODULE['paypalpaymentsproname'] = "paypalpaymentspro";
$GATEWAYMODULE['paypalpaymentsprovisiblename'] = "PayPal Website Payments Pro";
$GATEWAYMODULE['paypalpaymentsprotype'] = "CC";
?>
