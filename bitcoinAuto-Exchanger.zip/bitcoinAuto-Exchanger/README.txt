=====================================================================================================
Auto-Exchanger - E-currency exchanger, Buy , Sell & Content Management

 Release Version: 3.1.0 Stable
    Release Date: 2th May 2009
   Download Type: Full Package

PLEASE READ ALL THE ENCLOSED INSTRUCTIONS

       Support: http://www.auto-exchanger.com/support/
   Client Area: http://www.auto-exchanger.com/login/

=====================================================================================================
[ SERVER REQUIREMENTS ]
=====================================================================================================

1. PHP Version 4.4.x or later 
2. MySQL Version 4.0.3 or later
3. Curl Support 
4. GD Image Library
5. ionCube extension

=====================================================================================================
[ NEW INSTALLATION INSTRUCTIONS ]
=====================================================================================================

The following steps will guide you through the process of setting up Auto Exchanger on your server.

1. Unzip the contents of the zip file to a folder on your computer

2. Upload the entire Auto Exchanger folder to your website in binary mode

4. Rename configuration.php_rename in root to configuration.php

5. CHMOD the following folders & files:

     /configuration.php      777
     /_skins_tmp             777
	 /_skins/uploads		 777		(Only if you want upload image directly from admin panel)
		 
6. Run the installation script at
   http://www.yourdomain.com/install/index.php
   

7. This will guide you through the rest of the setup process.  On the
   last step.
   
8. Once complete, delete the install folder from your web server and
   CHMOD the configuration.php file back to 644.
=====================================================================================================


Your database has been setup. Use the following values:

Database:	moneytrans_ex
Host:	localhost
Username:	moneytrans_ex
Password:	a112233

==================================================================================
  --------------------
  Unlimited Hosting, Space, Bandwidth 
  --------------------
  http://goo.gl/AMeKl1
  
  --------------------
  Visit us
  --------------------
  Pro.ZPDMA is a system that will help you increase your social presence for FREE. 
  We allow you to pick and choose who you want to exchange with and skip those 
  who you're not interested in.

  http://goo.gl/CcdB21