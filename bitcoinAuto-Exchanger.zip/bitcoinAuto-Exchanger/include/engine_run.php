<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

if ( $EXTRA_ENGINE )
{
    include( $EXTRA_ENGINE );
}
if ( $PAGE_TEMPLATE )
{
    $page->addtpl( "PAGE_CONTENT", $Template_folder."/".$CONFIG['SITE_TEMPLATE']."/".$PAGE_TEMPLATE );
}
$page->assign( "cpt", "<span style=display:none;>Powered by: <a href=\"http://www.auto-exchanger.com\">Auto-Exchanger.com</a></span>" );
$page->output( );
if ( $dbconn )
{
    db_close( $dbconn );
}
if ( session_admin( ) )
{
    $time_end = microtime_float( );
    $time = substr( $time_end - $time_start, 0, 7 );
    echo "<div id='timer' style='padding:4px;background-color:#fff; text-align:center; font-size:11px; width:80%; margin:auto'>Page execution time: <u>{$time} seconds</u> - Caching status: ".( !$CONFIG['caching_status'] ? "<span class=\"ErrorMessage\">Off</span>" : "<span class=\"SuccessMessage\">ON</span>" )." - Auto-Exchanger v".$CONFIG['Version']."</div>";
}
if ( $Error_div )
{
    echo "\r\n\t<script language=\"JavaScript\">\r\n\tfunction setVisibility(id, visibility) { document.getElementById(id).style.display = visibility;}\r\n\t</script>";
    echo "\r\n\t<style type=\"text/css\">\r\n\t#floater{\r\n\t\tBORDER: #ccc7bc 2px solid;\r\n\t\tbackground-color:#f3f2f1;\r\n\t\tcolor:#4b3d35;\twidth:100%;\r\n\t\tposition:fixed!important;\r\n\t\tposition:absolute;\r\n\t\tleft:0; top:0;\r\n\t\tfont-size:13px;\r\n\t\tz-index: 999;\r\n\t\tpadding:10px;\r\n\t}\r\n\t</style>";
    echo "<DIV id=\"floater\">";
    foreach ( $Error_div as $key => $value )
    {
        echo "<img src=\"".$CONFIG['SKIN_IMAGES']."/ico/fasle2.gif\" hspace=1 border=0 onclick=\"setVisibility('floater', 'none');\" style=\"cursor:hand\" >";
        echo "<span class=ErrorMessage>".$value."</span><br />";
    }
    echo "</div>";
}
?>
