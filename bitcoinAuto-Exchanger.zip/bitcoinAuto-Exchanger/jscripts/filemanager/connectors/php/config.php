<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function get_url_tiny( )
{
    $arr = array( );
    $uri = $_SERVER['REQUEST_URI'];
    $arr['query'] = $_SERVER['QUERY_STRING'];
    $page_self = explode( "/", $_SERVER['PHP_SELF'] );
    $arr['page'] = $page_self[count( $page_self ) - 1];
    $arr['folder'] = $page_self[count( $page_self ) - 2];
    $arr['domain'] = $_SERVER['SERVER_NAME'];
    $server_prt = explode( "/", $_SERVER['SERVER_PROTOCOL'] );
    $arr['scheme'] = strtolower( $server_prt[0] );
    $arr['url'] = $arr['scheme']."://".$arr['domain'].$_SERVER['PHP_SELF'];
    return $arr;
}

$get_url = get_url_tiny( );
$str_absPath = str_replace( "\\", "/", dirname( __FILE__ ) );
$str_absPath = str_replace( "/jscripts/filemanager/connectors/php", "/_skins/uploads", $str_absPath )."/";
$url_absPath = str_replace( "/jscripts/filemanager/connectors/php/connector.php", "/_skins/uploads", $get_url['url'] );
global $Config;
$Config['Enabled'] = TRUE;
$Config['UserFilesPath'] = $url_absPath;
$Config['UserFilesAbsolutePath'] = $str_absPath;
$Config['AllowedExtensions']['File'] = array( );
$Config['DeniedExtensions']['File'] = array( "php", "php3", "php5", "phtml", "asp", "aspx", "ascx", "jsp", "cfm", "cfc", "pl", "bat", "exe", "dll", "reg", "cgi" );
$Config['AllowedExtensions']['Image'] = array( "jpg", "gif", "jpeg", "png" );
$Config['DeniedExtensions']['Image'] = array( );
$Config['AllowedExtensions']['Flash'] = array( "swf", "fla" );
$Config['DeniedExtensions']['Flash'] = array( );
$Config['AllowedExtensions']['Media'] = array( "swf", "fla", "jpg", "gif", "jpeg", "png", "avi", "mpg", "mpeg" );
$Config['DeniedExtensions']['Media'] = array( );
?>
