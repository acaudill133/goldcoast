<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_make_title( $url )
{
    $list = array( "%", "\$", "\\'", "\"", "\\", "_", "-" );
    $url = str_replace( $list, " ", $url );
    $pieces = array( "/", $url );
    return strtoupper( end( $pieces ) );
}

?>
