<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function get_special_plid( $plid )
{
    global $PLAN_ID_SPC_DAILY;
    global $PLAN_ID_SPC_WEEKLY;
    global $PLAN_ID_SPC_BIWEEKLY;
    global $PLAN_ID_SPC_MONTHLY;
    global $PLAN_ID_SPC_YEARLY;
    return $plid == $PLAN_ID_SPC_DAILY || $plid == $PLAN_ID_SPC_WEEKLY || $plid == $PLAN_ID_SPC_BIWEEKLY || $plid == $PLAN_ID_SPC_MONTHLY || $plid == $PLAN_ID_SPC_YEARLY ? true : false;
}

function get_exist_daily_plan( )
{
    global $_daily_plans;
    return db_if_exists( "select id from {$_daily_plans} where amount_min>'0' and (amount_max>amount_min or amount_max='0') and pct_daily_rate>'0' and suspended='0'" );
}

function get_exist_period_plan( )
{
    global $_period_plans;
    return db_if_exists( "select id from {$_period_plans} where amount_min>0 and (amount_max>amount_min or amount_max='0') and pct_period_rate>'0' and suspended='0'" );
}

function get_exist_special_plan( $plid = "" )
{
    global $_special_plans;
    $query = "select id from {$_special_plans} where amount_min>'0' and pct_special_rate>'0' and suspended='0'";
    if ( $plid )
    {
        $query .= " and special_type='{$plid}'";
    }
    return db_if_exists( $query );
}

function get_exist_plid( $plid )
{
    global $PLAN_ID_DAILY;
    global $PLAN_ID_PERIOD;
    global $_daily_plans;
    global $_period_plans;
    global $_special_plans;
    if ( $plid == $PLAN_ID_DAILY && get_exist_daily_plan( ) )
    {
        return true;
    }
    if ( $plid == $PLAN_ID_PERIOD && get_exist_period_plan( ) )
    {
        return true;
    }
    if ( get_special_plid( $plid ) && get_exist_special_plan( $plid ) )
    {
        return true;
    }
    return false;
}

function get_exist_referal( )
{
    global $_referal_plans;
    return db_if_exists( "select id from {$_referal_plans} where number_min>'0' and (number_max>number_min or number_max='0') and pct_rate>'0' and suspended='0'" );
}

function get_special_interval( $plid )
{
    global $PLAN_ID_SPC_DAILY;
    global $PLAN_ID_SPC_WEEKLY;
    global $PLAN_ID_SPC_BIWEEKLY;
    global $PLAN_ID_SPC_MONTHLY;
    global $PLAN_ID_SPC_YEARLY;
    $n = array( );
    if ( $plid == $PLAN_ID_SPC_DAILY )
    {
        $n[0] = 1;
        $n[1] = "DAY";
    }
    else if ( $plid == $PLAN_ID_SPC_WEEKLY )
    {
        $n[0] = 7;
        $n[1] = "DAY";
    }
    else if ( $plid == $PLAN_ID_SPC_BIWEEKLY )
    {
        $n[0] = 14;
        $n[1] = "DAY";
    }
    else
    {
        $n[0] = 1;
        $n[1] = "MONTH";
        if ( $plid == $PLAN_ID_SPC_YEARLY )
        {
            $n[0] = 1;
            $n[1] = "YEAR";
        }
        else
        {
            $n[0] = 0;
            $n[1] = "";
        }
    }
    return $n;
}

function convert_term( $term )
{
    global $LANG_general;
    global $PLAN_ID_DAILY;
    global $PLAN_ID_PERIOD;
    global $PLAN_ID_SPC_DAILY;
    global $PLAN_ID_SPC_WEEKLY;
    global $PLAN_ID_SPC_BIWEEKLY;
    global $PLAN_ID_SPC_MONTHLY;
    global $PLAN_ID_SPC_YEARLY;
    if ( $term == $PLAN_ID_DAILY )
    {
        return $LANG_msg['general_daily'];
    }
    if ( $term == $PLAN_ID_PERIOD )
    {
        return $LANG_msg['general_long'];
    }
    if ( $term == $PLAN_ID_SPC_DAILY )
    {
        return $LANG_msg['general_daily'];
    }
    if ( $term == $PLAN_ID_SPC_WEEKLY )
    {
        return $LANG_msg['general_weekly'];
    }
    if ( $term == $PLAN_ID_SPC_BIWEEKLY )
    {
        return $LANG_msg['general_biweekly'];
    }
    if ( $term == $PLAN_ID_SPC_MONTHLY )
    {
        return $LANG_msg['general_monthly'];
    }
    if ( $term == $PLAN_ID_SPC_YEARLY )
    {
        return $LANG_msg['general_yearly'];
    }
    return "&nbsp;";
}

function convert_trans_type( $type )
{
    global $TRANS_ENUM_SPEND;
    global $TRANS_ENUM_WITHDRAW;
    global $TRANS_ENUM_TRANSFER;
    global $TRANS_ENUM_INTERNAL;
    global $TRANS_ENUM_COMMISSION;
    global $TRANS_ENUM_BONUS;
    global $TRANS_ENUM_PENALTY;
    global $TRANS_ENUM_EARNING;
    global $LANG_note;
    if ( $type == $TRANS_ENUM_SPEND )
    {
        return $LANG_msg['note_dmoney'];
    }
    if ( $type == $TRANS_ENUM_WITHDRAW )
    {
        return $LANG_msg['note_with_money'];
    }
    if ( $type == $TRANS_ENUM_TRANSFER )
    {
        return $LANG_msg['note_tmoney'];
    }
    if ( $type == $TRANS_ENUM_INTERNAL )
    {
        return $LANG_msg['note_tinternal'];
    }
    if ( $type == $TRANS_ENUM_COMMISSION )
    {
        return $LANG_msg['note_referral'];
    }
    if ( $type == $TRANS_ENUM_BONUS )
    {
        return $LANG_msg['note_bonus'];
    }
    if ( $type == $TRANS_ENUM_PENALTY )
    {
        return $LANG_msg['note_penalty'];
    }
    if ( $type == $TRANS_ENUM_EARNING )
    {
        return $LANG_msg['note_rearning'];
    }
}

function convert_status( $status )
{
    global $STATUS_ENUM_DISABLE;
    global $STATUS_ENUM_ENABLE;
    global $STATUS_ENUM_LOCKED;
    global $LANG_msg;
    if ( $status == $STATUS_ENUM_DISABLE )
    {
        return "Disable";
    }
    if ( $status == $STATUS_ENUM_ENABLE )
    {
        return "Active";
    }
    if ( $status == $STATUS_ENUM_LOCKED )
    {
        return "Locked";
    }
    return "-";
}

function get_sum( $clause = "", $status = "", $pmt_type = "", $negative = false )
{
    global $_lines;
    global $uid;
    $query = "select sum(exchange) from {$_lines} where uid={$uid}";
    if ( $clause )
    {
        $query .= " and {$clause}";
    }
    else
    {
        $query .= " and status='{$status}' and pmt_type='{$pmt_type}'";
    }
    $n = db_get_id( $query );
    if ( !$n )
    {
        $n = 0;
    }
    else if ( $negative )
    {
        $n = 0 - $n;
    }
    return $n;
}

?>
