<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "public.inc.php" );
if ( !session_admin( ) )
{
    @header( "Location: ".$CONFIG['SITE_URL'] );
}
$tinymce_one_filed = false;
if ( ( $_REQUEST['Action'] == "Edit" || $_REQUEST['Action'] == "Add" ) && $CONFIG['tinymce_editor'] )
{
    if ( strstr( $_SERVER['HTTP_ACCEPT_ENCODING'], "gzip" ) )
    {
        $tiny_config_file = "jscripts/tiny_mce/tinymce_config_gzip.inc.js";
    }
    else
    {
        $tiny_config_file = "jscripts/tiny_mce/tinymce_config.inc.js";
    }
    $tiny_js = file_get_contents( $tiny_config_file );
    $tiny_js = str_replace( "[SITE_URL]", $CONFIG['SITE_URL'], $tiny_js );
    $tiny_js = str_replace( "[SKIN_CSS]", $CONFIG['SKIN_CSS'], $tiny_js );
    if ( $tinymce_one_filed )
    {
        $tiny_js = str_replace( "//[OPTIONAL],", "editor_selector : \"mceEditor\",", $tiny_js );
    }
}
if ( $NoTemp && $CONFIG['tinymce_editor'] )
{
    echo $tiny_js;
}
$Oid = $_GET['id'];
$fld_date = $_POST['fld_date'];
$fld_type = $_POST['type'];
$status = $_POST['status'];
$type = $_GET['type'];
if ( !is_numeric( $_GET['type'] ) && $_GET['type'] )
{
    $DEF_DOCS_TYPE_VALUES = array_flip( $DEF_DOCS_TYPE );
    $type = $DEF_DOCS_TYPE_VALUES[$_GET['type']];
}
$show_lang = $_GET['show_lang'];
if ( $_POST['submit'] )
{
    foreach ( $_POST as $key => $value )
    {
        list( $fld_name, $language ) = fld_name  ;      if ( !empty( $language ) )
        {
            $arr_values[$language][] = preg_replace( "/\"{(make_link:|dynamic_link:)\"(.*?)\"}(.*?)\"/", "'{\$1\"\$2\"}\$3'", htmlspecialchars_decode( stripslashes( $value ) ), $value );
        }
    }
    if ( $_POST['Action'] == "Edit" && !$demo_mode )
    {
        $Oid = $_POST['id'];
        foreach ( $lang as $lang_name )
        {
            $fld_title = addslashes( $arr_values[$lang_name][0] );
            $fld_body = addslashes( $arr_values[$lang_name][1] );
            if ( $fld_title )
            {
                if ( db_if_exists( "SELECT id FROM {$_news} WHERE related_id='{$Oid}' AND fld_language='{$lang_name}'" ) )
                {
                    $query = "UPDATE {$_news} SET fld_date = '{$fld_date}',  fld_title= '{$fld_title}', fld_body = '{$fld_body}', type = '{$fld_type}', pdfurl = '{$pdfurl}', status = '{$status}' WHERE related_id='{$Oid}' AND fld_language = '{$lang_name}'";
                }
                else
                {
                    $query = "INSERT INTO {$_news} (fld_date ,  fld_title , fld_body, type, pdfurl, status, fld_language, related_id)\r\n\t\t\t\t\tVALUES('{$fld_date}', '{$fld_title}', '{$fld_body}', '{$fld_type}', '{$pdf_url}', '{$status}', '{$lang_name}', '{$Oid}')";
                }
                $result = db_query( $query, "&nbsp;" );
                if ( $result )
                {
                    $Success[] = $fld_title." (".$DEF_DOCS_TYPE[$fld_type]." ".$lang_name.") update Successfully";
                }
                else
                {
                    $Error[] = "Sorry an error occurred.";
                }
            }
            else
            {
                $Error[] = ucfirst( $lang_name )." title was empty, this document doesn't save.";
            }
        }
    }
    else if ( $_POST['Action'] == "Add" )
    {
        $next_id = db_get_last_id( $_news ) + 1;
        foreach ( $lang as $lang_name )
        {
            $fld_title = addslashes( $arr_values[$lang_name][0] );
            $fld_body = addslashes( $arr_values[$lang_name][1] );
            if ( $fld_title )
            {
                if ( !db_if_exists( "SELECT id FROM {$_news} WHERE fld_title='{$fld_title}' AND fld_language='{$lang_name}' AND type='{$fld_type}'" ) )
                {
                    $query = "INSERT INTO {$_news} (fld_date ,  fld_title , fld_body, type, pdfurl, status, fld_language, related_id)\r\n\t\t\t\t\t\tVALUES('{$fld_date}', '{$fld_title}', '{$fld_body}', '{$fld_type}', '{$pdf_url}', '{$status}', '{$lang_name}', '{$next_id}')";
                    $result = db_query( $query, "&nbsp;" );
                    $Success[] = $fld_title." (".$DEF_DOCS_TYPE[$fld_type]." ".$lang_name.") Add Successfully";
                    $show_main = true;
                }
                else
                {
                    $Error[] = "This title already exist for ".ucfirst( $lang_name )." language.";
                }
            }
            else
            {
                $Error[] = ucfirst( $lang_name )." title was empty, this document doesn't save.";
            }
        }
    }
}
if ( ( $_POST['Action'] == "Edit" && $_POST['submit'] || $_GET['Action'] == "Delete" ) && $demo_mode )
{
    $Error_div[] = "Some features are not active, in Demo Version you can not edit or delete pages";
}
if ( $_GET['Action'] == "enable" )
{
    if ( db_exec( "UPDATE {$_news} SET status='1' WHERE related_id='{$Oid}'" ) )
    {
        $Success[] = $DEF_DOCS_TYPE[$type]." Enable Successfully";
    }
    $show_main = true;
}
else if ( $_GET['Action'] == "disable" )
{
    if ( db_exec( "UPDATE {$_news} SET status='0' WHERE related_id='{$Oid}'" ) )
    {
        $Success[] = $DEF_DOCS_TYPE[$type]." Disable Successfully";
    }
    $show_main = true;
}
else if ( $_GET['Action'] == "Delete" && !$demo_mode )
{
    if ( db_exec( "DELETE FROM {$_news} WHERE related_id='{$Oid}'" ) )
    {
        $Success[] = $DEF_DOCS_TYPE[$type]." Delete Successfully";
    }
    $show_main = true;
}
if ( $show_lang )
{
    $clause = "WHERE fld_language='{$show_lang}'";
}
else
{
    $clause = "WHERE fld_language='{$CONFIG['DEF_LANGUAGE']}'";
}
if ( $type )
{
    $clause .= " AND type='{$type}'";
}
if ( !$_GET['Action'] || $show_main )
{
    $query = "SELECT * FROM {$_news} {$clause} ORDER BY fld_date DESC";
    $page = $_GET['page'];
    $total = mysql_num_rows( mysql_query( $query ) );
    $perpage = $CONFIG['recordsnumperpage'];
    $url_string = get_link( $cur_page.( $CONFIG['FRIENDLY_URL'] ? "" : "?" ).preg_replace( "/(&)page(\\/^|=)\\d+/", "", $_SERVER['QUERY_STRING'] ) );
    $pager = new pager( $total, $perpage, $url_string, $CONFIG['FRIENDLY_URL'] );
    if ( empty( $page ) )
    {
        $page = 1;
    }
    $from = $pager->getPageFrom( $page );
    $query = $query." limit {$from}, {$perpage}";
    $result = db_query( $query, "&nbsp;" );
    $arr_adm_pages = mysql_push_data( $result );
    db_free_result( $result );
}
else
{
    $query2 = "SELECT * FROM {$_news} WHERE related_id='{$Oid}'";
    $result = db_query( $query2, "&nbsp;" );
    $arr_adm_pages2 = db_fetch_array( $result );
    db_free_result( $result );
}
if ( $_GET['Action'] == "Add" )
{
    $form_Action = get_link( $cur_page."?Action=".$_GET['Action'] );
}
else
{
    $form_Action = get_link( $cur_page."?Action=".$_GET['Action']."&id=".$_GET['id'] );
}
echo "\r\n";
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."adm_newsmain.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "adm_newsmain.html";
    if ( !$_GET['Action'] || $show_main )
    {
        foreach ( $arr_adm_pages as $key => $value )
        {
            $arr_adm_pages[$key]['doc_type'] = $DEF_DOCS_TYPE[$Var_12120[$key]['type']];
        }
        $page->assign( "arr_adm_pages", $arr_adm_pages );
        $page->assign( "no_results", count( $arr_adm_pages ) );
    }
    else
    {
        if ( $_GET['Action'] == "Edit" && $arr_adm_pages2['type'] == 2 )
        {
            $Rows = "<br><br><span style=font-size:11px>Ready link code to use in template files: <u>&lt;a href='&#123;dynamic_link:&quot;".$arr_adm_pages2['fld_title']."&quot;&#125;'&gt;".$arr_adm_pages2['fld_title']."&lt;/a&gt;</u></span>";
        }
        foreach ( $lang as $key => $lang_name )
        {
            $nvar = db_get_array( "select fld_body, fld_title from {$_news} where (related_id='{$Oid}' or id='{$Oid}') AND fld_language='{$lang_name}'" );
            $body = $nvar[0];
            $title = $nvar[1];
            $Rows .= "<fieldset style=\"border:1px solid #b1b5b9;\">\r\n\t\t\t\t\t  <legend style=\"color:#006699\"> Language: ".ucfirst( $lang_name )."</legend>\r\n\t\t\t\t\t <label><span style=\"width:50px;\">Title:</span>\r\n\t\t\t\t\t <input name=\"title_".$lang_name."\" type=\"text\" class=\"textbox\" id=\"title_".$lang_name."\" value=\"".$title."\" size=\"60\" />\r\n\t\t\t\t\t </label>\r\n\t\t\t\t\t <div style=\"text-align:left\">\r\n\t\t\t\t\t <a href=\"javascript:toggleEditor('body_".$lang_name."');\">Add/Remove editor</a><br />\r\n\t\t\t\t\t <textarea name=\"body_".$lang_name."\" rows=\"6\" id=\"body_".$lang_name."\"  style=\"width:98%;height:400px;\" class=\"mceEditor\" >".htmlspecialchars( $body )."</textarea>\r\n\t\t\t\t\t </div>\r\n\t\t\t\t\t </fieldset> ";
        }
        $page->assign( "Rows", $Rows );
        if ( $arr_adm_pages2 )
        {
            foreach ( $arr_adm_pages2 as $key => $value )
            {
                $arr_adm_pages2['status'] = $arr_adm_pages2['status'] ? "checked=checked" : "";
            }
        }
        if ( $_GET['Action'] == "Add" )
        {
            $arr_adm_pages2['status'] = "checked=checked";
        }
        $page->assign( "type", $arr_adm_pages2['type'] );
        $page->assign( "arr_adm_pages2", $arr_adm_pages2 );
    }
    $page->assign( "Action", $_GET['Action'] );
    if ( !$_GET['Action'] || $show_main )
    {
        $page->assign( "show_main", true );
    }
    $page->assign( "form_Action", $form_Action );
    $page->assign( "tiny_js", $tiny_js );
    if ( $perpage < $total )
    {
        $pg = $pager->page;
        $page_navigation .= $pager->getButPrev( $pg );
        $range = 20;
        $page_navigation .= $pager->getButList( $range );
        $page_navigation .= $pager->getButNext( $pg );
        $page_navigation .= "<br><br><br>";
        $page_navigation .= $pager->getRangeInfo( );
    }
    $page->assign( "page_navigation", $page_navigation );
    $page->assign( "arr_DOCUMENT_TYPES", make_tmp_array( $DEF_DOCS_TYPE, "doc_type" ) );
    $page->assign( "DOCUMENT_TYPES", $DEF_DOCS_TYPE );
    require( "include/engine_run.php" );
}
?>
