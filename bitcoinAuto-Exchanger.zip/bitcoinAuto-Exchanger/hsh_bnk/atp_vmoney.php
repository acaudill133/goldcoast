<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

echo "<input type=hidden name=\"PMT_MERCHANT_ACCOUNT\" value=\"";
echo $payee_account;
echo "\">\r\n<input type=hidden name=\"PMT_PAYMENT_URL_METHOD\" value=\"POST\">\r\n<input type=hidden name=\"PMT_NOPAYMENT_URL_METHOD\" value=\"POST\">\r\n<input type=hidden name=\"PMT_PAYMENT_URL\" value=\"";
echo $response_ok;
echo "\">\r\n<input type=hidden name=\"PMT_NOPAYMENT_URL\" value=\"";
echo $response_no;
echo "\">\r\n<input type=hidden name=\"PMT_NOTIFY_URL\" value=\"";
echo $status_url;
echo "\">\r\n\r\n";
if ( $amount == "ask" )
{
    echo "    Amount you want to pay: <INPUT type='text' name=\"PMT_AMOUNT\">\r\n";
}
else
{
    echo "    <input type=hidden name=\"PMT_AMOUNT\" value=\"";
    echo $amount;
    echo "\">\r\n";
}
echo "<input type=hidden name=\"PMT_PAYMENT_ID\" value=\"";
echo $payment_id;
echo "\">\r\n<input type=hidden name=\"CUSTOM_bookname\" value=\"";
echo $suggested_memo;
echo "\">\r\n";
?>
