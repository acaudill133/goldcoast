<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "public.inc.php" );
$str_tool = new string_tool( );
$SRC_ID = $str_tool->remove_dangerous_chars( $_POST['srcID'] );
$SRC_AMOUNT = $str_tool->remove_dangerous_chars( $_POST['SRC_AMOUNT'] );
$DST_ID = $str_tool->remove_dangerous_chars( $_POST['dstID'] );
$DST_AMOUNT = $str_tool->remove_dangerous_chars( $_POST['DST_AMOUNT'] );
$DST_ACCOUNT = $str_tool->remove_dangerous_chars( trim( $_POST['DST_ACCOUNT'] ) );
$STEP = $str_tool->remove_dangerous_chars( $_POST['STEP'] );
$EMAIL = $str_tool->remove_dangerous_chars( $_POST['EMAIL'] );
$AGREE = $str_tool->remove_dangerous_chars( $_POST['agree'] );
$idcode = $str_tool->remove_dangerous_chars( $_POST['exchange_turning'] );
$DST_ACCOUNT_NAME = $str_tool->remove_dangerous_chars( $_POST['DST_ACCOUNT_getname'] );
if ( !$EMAIL && session_member( ) )
{
    $EMAIL = db_get_id( "select email from {$_users_details} where uid='{$uid}' and suspended='0'" );
}
if ( !isset( $SRC_AMOUNT ) && !isset( $DST_AMOUNT ) && $_POST['submit_exchange'] )
{
    $Error[] = $LANG_msg['exchange_077'];
}
if ( !$STEP && $SRC_AMOUNT )
{
    if ( !db_if_exists( "SELECT cid FROM {$_currencies} WHERE exchange_status='{$STATUS_ENUM_ENABLE}' AND cid='{$SRC_ID}' AND cid<>'50'" ) )
    {
        $Error[] = $LANG_msg['exchange_078'];
    }
    if ( !db_if_exists( "SELECT cid FROM {$_currencies} WHERE exchange_status='{$STATUS_ENUM_ENABLE}' AND cid='{$DST_ID}' AND cid<>'50'" ) )
    {
        $Error[] = $LANG_msg['exchange_079'];
    }
    if ( !$SRC_AMOUNT )
    {
        $Error[] = $LANG_msg['exchange_075'];
    }
    if ( !$DST_AMOUNT )
    {
        $Error[] = $LANG_msg['exchange_076'];
    }
    if ( !$EMAIL || !eregi( ".+@.+\\..+", $EMAIL ) )
    {
        $Error[] = $LANG_msg['signup_016'];
    }
    if ( !$DST_ACCOUNT )
    {
        $Error[] = $LANG_msg['exchange_042'];
    }
    else
    {
        $merchant_name = convert_emoney( $DST_ID );
        $arr_DST['AUTO_EXCHANGE'] = db_get_id( "SELECT exchange_automatic FROM {$_currencies} WHERE cid='{$DST_ID}'" );
        switch ( $merchant_name )
        {
        case "e-gold" :
            do
            {
                if ( isValid_egold_AccountNumber( $DST_ACCOUNT ) )
                {
                    break;
                }
                else
                {
                    $Error[] = $LANG_msg['exchange_043']." ".ucfirst( $merchant_name )." ".$LANG_msg['exchange_044'];
                }
            } while ( 0 );
            if ( $arr_DST['AUTO_EXCHANGE'] == 1 )
            {
                fetch_egold_AccountName( $DST_ACCOUNT );
                if ( $arr_ACCOUNT_DATA['ERROR'] )
                {
                    $Error[] = $arr_ACCOUNT_DATA['ERROR'];
                }
            }
            break;
        case "e-bullion" :
            if ( !isValid_ebullion_AccountNumber( $DST_ACCOUNT ) )
            {
                $Error[] = $LANG_msg['exchange_043']." ".ucfirst( $merchant_name )." ".$LANG_msg['exchange_044'];
            }
            break;
        case "pecunix" :
            do
            {
                if ( eregi( ".+@.+\\..+", $DST_ACCOUNT ) )
                {
                    break;
                }
                else
                {
                    $Error[] = $LANG_msg['exchange_043']." ".ucfirst( $merchant_name )." ".$LANG_msg['exchange_044'];
                }
            } while ( 0 );
            if ( $arr_DST['AUTO_EXCHANGE'] == 1 )
            {
                fetch_pecunix_AccountName( $DST_ACCOUNT );
                if ( $arr_ACCOUNT_DATA['ERROR'] )
                {
                    $Error[] = $arr_ACCOUNT_DATA['ERROR'];
                }
            }
            break;
        case "moneybookers" :
            if ( !eregi( ".+@.+\\..+", $DST_ACCOUNT ) )
            {
                $Error[] = "Incorrect ".ucfirst( $merchant_name )." account id.";
            }
            break;
        case "libertyreserve" :
            do
            {
                if ( isValid_liberty_AccountNumber( $DST_ACCOUNT ) )
                {
                    break;
                }
                else
                {
                    $Error[] = $LANG_msg['exchange_043']." ".ucfirst( $merchant_name )." ".$LANG_msg['exchange_044'];
                }
            } while ( 0 );
            if ( $arr_DST['AUTO_EXCHANGE'] == 1 )
            {
                fetch_liberty_AccountName( $DST_ACCOUNT );
                if ( $arr_ACCOUNT_DATA['ERROR'] )
                {
                    $Error[] = $arr_ACCOUNT_DATA['ERROR'];
                }
            }
            break;
        case "alertpay" :
            if ( !eregi( ".+@.+\\..+", $DST_ACCOUNT ) )
            {
                $Error[] = $LANG_msg['exchange_043']." ".ucfirst( $merchant_name )." ".$LANG_msg['exchange_044'];
            }
            break;
        case "v-money" :
            do
            {
                if ( isValid_vmoney_AccountNumber( $DST_ACCOUNT ) )
                {
                    break;
                }
                else
                {
                    $Error[] = $LANG_msg['exchange_043']." ".ucfirst( $merchant_name )." ".$LANG_msg['exchange_044'];
                }
            } while ( 0 );
            if ( $arr_DST['AUTO_EXCHANGE'] == 1 )
            {
                fetch_vmoney_AccountName( $DST_ACCOUNT );
                if ( $arr_ACCOUNT_DATA['ERROR'] )
                {
                    $Error[] = $arr_ACCOUNT_DATA['ERROR'];
                }
            }
            break;
        case "webmoney" :
            if ( !isValid_webmoney_AccountNumber( $DST_ACCOUNT ) )
            {
                $Error[] = $LANG_msg['exchange_043']." ".ucfirst( $merchant_name )." ".$LANG_msg['exchange_044'];
            }
            break;
        case "perfectmoney" :
            if ( !isValid_perfectmoney_AccountNumber( $DST_ACCOUNT ) )
            {
                $Error[] = $LANG_msg['exchange_043']." ".ucfirst( $merchant_name )." ".$LANG_msg['exchange_044'];
            }
            break;
        case "altergold" :
            if ( !isValid_altergold_AccountNumber( $DST_ACCOUNT ) )
            {
                $Error[] = $LANG_msg['exchange_043']." ".ucfirst( $merchant_name )." ".$LANG_msg['exchange_044'];
            }
            break;
        case "c-gold" :
            if ( !isValid_cgold_AccountNumber( $DST_ACCOUNT ) )
            {
                $Error[] = $LANG_msg['exchange_043']." ".ucfirst( $merchant_name )." ".$LANG_msg['exchange_044'];
            }
            break;
        case "paypal" :
            if ( !eregi( ".+@.+\\..+", $DST_ACCOUNT ) )
            {
                $Error[] = "Incorrect ".ucfirst( $merchant_name )." account id.";
            }
            break;
        case "paypal" :
            if ( !eregi( ".+@.+\\..+", $DST_ACCOUNT ) )
            {
                $Error[] = "Incorrect ".ucfirst( $merchant_name )." account id.";
            }
            break;
        case "debit card" :
            if ( strlen( $DST_ACCOUNT ) != 16 )
            {
                $Error[] = "Invalid debit number, your card number need to have 16 number without any other characters.";
            }
            break;
        default :
            $Error[] = $LANG_msg['exchange_045'];
        }
    }
    if ( !$Error )
    {
        $STEP = "check";
    }
}
else if ( !$Error && $STEP == "check" )
{
    if ( !$AGREE )
    {
        $Error[] = $LANG_msg['exchange_046'];
    }
    if ( strtolower( $idcode ) != $_SESSION['UniqCode'] )
    {
        $Error[] = $LANG_msg['login_007'];
        unset( $_SESSION['UniqCode'] );
    }
    if ( $_POST['addtional']['required'] && ( $_POST['addtional']['fullname'] == "" || $_POST['addtional']['address'] == "" ) )
    {
        $Error[] = $LANG_msg['exchange_089'];
    }
    if ( !is_array( $Error ) )
    {
        $STEP = "goTopaY";
    }
}
if ( $STEP )
{
    $DST_AMOUNT = calculate_DST_amount( $SRC_ID, $DST_ID, $SRC_AMOUNT );
    if ( !$DST_AMOUNT || $DST_AMOUNT < 0 )
    {
        $Error[] = $LANG_msg['exchange_047'];
    }
    $arr_SRC = array( );
    $nvar = db_get_array( "SELECT currency_name, currency_worth_name, currency_metal_name, exchange_min, exchange_accept_limit, show_as_source FROM {$_currencies} WHERE exchange_status='{$STATUS_ENUM_ENABLE}' AND cid='{$SRC_ID}'" );
    $arr_SRC['NAME'] = $nvar[0];
    $arr_SRC['WORTH_NAME'] = $Var_11952;
    $arr_SRC['METAL_NAME'] = $nvar[2];
    $arr_SRC['EXCHANGE_MIN'] = $nvar[3];
    $arr_SRC['FULL_NAME'] = ucfirst( $arr_SRC['NAME'] )." ".$arr_SRC['METAL_NAME'];
    $arr_SRC['ACCEPT_LIMIT'] = $nvar[4];
    $arr_SRC['show_as_source'] = $nvar[5];
    $arr_DST = array( );
    $nvar = db_get_array( "SELECT currency_name, currency_worth_name, currency_metal_name, exchange_min, exchange_max, reserve_amount, exchange_automatic, show_as_destination FROM {$_currencies} WHERE exchange_status='{$STATUS_ENUM_ENABLE}' AND cid='{$DST_ID}'" );
    $arr_DST['NAME'] = $nvar[0];
    $arr_DST['WORTH_NAME'] = $nvar[1];
    $arr_DST['METAL_NAME'] = $nvar[2];
    $arr_DST['EXCHANGE_MIN'] = $nvar[3];
    $arr_DST['EXCHANGE_MAX'] = $nvar[4];
    $arr_DST['RESERVE_AMOUNT'] = $nvar[5];
    $arr_DST['EXCHANGE_AUTO'] = $nvar[6];
    $arr_DST['show_as_destination'] = $nvar[7];
    $arr_DST['FULL_NAME'] = ucfirst( $arr_DST['NAME'] )." ".$arr_DST['METAL_NAME'];
    if ( $arr_DST['EXCHANGE_MAX'] < $DST_AMOUNT )
    {
        $Error[] = $LANG_msg['exchange_048']." ".$arr_DST['FULL_NAME']." ".$LANG_msg['exchange_049']." ".$arr_DST['EXCHANGE_MIN']." ".$arr_DST['WORTH_NAME']." , ".$LANG_msg['exchange_050'];
        $STEP = "";
    }
    if ( $SRC_AMOUNT < $arr_SRC['EXCHANGE_MIN'] )
    {
        $Error[] = $LANG_msg['exchange_051']." ".$arr_SRC['FULL_NAME']." ".$LANG_msg['exchange_049']." ".$arr_SRC['EXCHANGE_MIN']." ".$arr_SRC['WORTH_NAME']." , ".$LANG_msg['exchange_052'];
        $STEP = "";
    }
    if ( $arr_SRC['ACCEPT_LIMIT'] != "" )
    {
        $MAX_DST_LIMIT = calculate_DST_amount( $SRC_ID, $DST_ID, $arr_SRC['ACCEPT_LIMIT'] );
        if ( $MAX_DST_LIMIT < $DST_AMOUNT )
        {
            $Error[] = $LANG_msg['exchange_081'];
            $STEP = "";
        }
    }
    if ( $SRC_AMOUNT <= $CONFIG['MIN_EXCHANGE_FEE'] )
    {
        $Var_16224[] = $LANG_msg['exchange_016']." ".FormatPrice( $CONFIG['MIN_EXCHANGE_FEE'] );
        $STEP = "";
    }
    if ( $arr_DST['RESERVE_AMOUNT'] < $DST_AMOUNT || $arr_DST['RESERVE_AMOUNT'] == 0 )
    {
        $Error[] = $LANG_msg['exchange_054']." ".$arr_DST['NAME']." ".$LANG_msg['exchange_055'];
        $STEP = "";
    }
    if ( !$arr_SRC['show_as_source'] || !$arr_DST['show_as_destination'] )
    {
        $Error[] = "Currently we are not accepting your selected currency.";
        $STEP = "";
    }
    if ( !$arr_DST['EXCHANGE_AUTO'] || $arr_DST['EXCHANGE_AUTO'] == $STATUS_ENUM_LOCKED )
    {
        $arr_DST['CAUTION'] = "<u>".$LANG_msg['exchange_053']."</u> (".$LANG_msg['exchange_056']." ".$arr_DST['NAME']." ".$LANG_msg['exchange_057'].")";
    }
    if ( $arr_DST['EXCHANGE_AUTO'] == $STATUS_ENUM_ENABLE )
    {
        $arr_DST['TIME'] = $LANG_msg['exchange_058'];
    }
}
if ( !$Error && $STEP == "goTopaY" )
{
    while ( !$Exchange_Refrence_exist )
    {
        $Exchange_Refrence = rand( 1000000000, 1e+010 );
        if ( !db_if_exists( "SELECT eid FROM {$_exchange_lines} WHERE exchange_refrence='{$Exchange_Refrence}'" ) )
        {
            $Exchange_Refrence_exist = true;
        }
    }
    $DST_AMOUNT = calculate_DST_amount( $SRC_ID, $DST_ID, $SRC_AMOUNT );
    if ( isset( $rid ) && db_if_exists( "SELECT uid from {$_users} where uid='{$rid}' and permit='{$PMT_INFO_MEMBER}' and status='{$STATUS_ENUM_ENABLE}'" ) )
    {
        $Exchange_referral = $rid;
    }
    if ( !isset( $Exchange_referral ) && $uid && db_if_exists( "select r.uid from {$_referals} r, {$_users} u where r.uid_referal='{$uid}' and r.uid<'{$Var_19104}' and r.uid=u.uid and u.status='{$STATUS_ENUM_ENABLE}'" ) )
    {
        $Exchange_referral = db_get_id( "select r.uid from {$_referals} r, {$_users} u where r.uid_referal='{$uid}' and r.uid<'{$uid}' and r.uid=u.uid and u.status='{$STATUS_ENUM_ENABLE}" );
    }
    if ( is_array( $_POST['addtional'] ) )
    {
        foreach ( $_POST['addtional'] as $key => $value )
        {
            $note .= ucfirst( $key )." : ".$value."\n";
        }
    }
    db_exec( "insert into {$_exchange_lines} (uid, src_cid, src_amount, src_date, src_status, dst_cid, dst_amount, dst_account, dst_status, exchange_email_address, exchange_note, exchange_refrence, ref_uid, dst_account_name) \r\n\tvalues ('{$uid}', '{$SRC_ID}', '{$SRC_AMOUNT}', now(), '{$STATUS_ENUM_DISABLE}', '{$DST_ID}', '{$Var_20064}', '{$DST_ACCOUNT}', '{$STATUS_ENUM_DISABLE}', '{$EMAIL}', '{$note}', '{$Exchange_Refrence}', '{$Exchange_referral}', '{$DST_ACCOUNT_NAME}')" );
    $payment_id = $Exchange_Refrence;
    $arr_CURRENCY_SRC = get_currency_data( $SRC_ID );
    $merchant_name = $arr_CURRENCY_SRC['currency_name'];
    $merchant_account = $arr_CURRENCY_SRC['ACCOUNT'];
    if ( $arr_CURRENCY_SRC['no_interface_message'] )
    {
        $NO_INTERFACE_MESSAGE = str_replace( "[payment_id]", $payment_id, $arr_CURRENCY_SRC['no_interface_message'] );
    }
    $REDIRECT_PAYMENT = $arr_CURRENCY_SRC['redirect_payment'];
    $MEMO = "Reference number:";
    $PAYEE_NAME = $CONFIG['SITE_NAME'];
    $RESPONSE_OK = $CONFIG['SITE_URL_SECURE']."/Received.php";
    $RESPONSE_NO = $CONFIG['SITE_URL_SECURE']."/Received_no.php?type=exchange";
    $next_page = $arr_CURRENCY_SRC['currency_merchant_url'];
    $cid = $SRC_ID;
    $amount = $SRC_AMOUNT;
    switch ( $merchant_name )
    {
    case "e-gold" :
        $merchant_form = egold_form_inc_php( );
        break;
    case "e-bullion" :
        $baggage_fields = "paymentid";
        $merchant_form = bullion_form_inc_php( );
        break;
    case "pecunix" :
        $merchant_form = pecunix_form_inc_php( );
        break;
    case "moneybookers" :
        $merchant_form = moneybookers_form_inc_php( );
        break;
    case "libertyreserve" :
        $merchant_form = liberty_form_inc_php( );
        break;
    case "alertpay" :
        $merchant_form = alertpay_form_inc_php( );
        break;
    case "webmoney" :
        $merchant_form = webmoney_form_inc_php( );
        break;
    case "v-money" :
        $merchant_form = vmoney_form_inc_php( );
        break;
    case "perfectmoney" :
        $merchant_form = perfectmoney_form_inc_php( );
        break;
    case "altergold" :
        $merchant_form = altergold_form_inc_php( );
        break;
    case "c-gold" :
        $merchant_form = cgold_form_inc_php( );
        break;
    case "paypal" :
        $merchant_form = paypal_form_inc_php( );
        break;
    default :
        echo "ERROR: NOT FOUND CURRENCY";
    }
}
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."exchange_step.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "exchange_step.html";
    $EXTRA_ENGINE = "exchange_box.php";
    $Post['EMAIL'] = $EMAIL;
    $arr_DST['AMOUNT'] = $DST_AMOUNT;
    $arr_SRC['AMOUNT'] = $SRC_AMOUNT;
    $page->assign( "STEP", $STEP );
    $page->assign( "dst_worth", $arr_DST['WORTH_NAME'] );
    $page->assign( "src_worth", $arr_SRC['WORTH_NAME'] );
    $page->assign( "arr_SRC", $arr_SRC );
    $page->assign( "arr_DST", $arr_DST );
    $page->assign( "next_page", $next_page );
    $page->assign( "merchant_form", $merchant_form );
    $page->assign( "merchant_name", $merchant_name );
    if ( !$merchant_name )
    {
        $page->assign( "merchant_name", $arr_DST['NAME'] );
    }
    $page->assign( "merchant_account", $merchant_account );
    $page->assign( "no_interface_message", $NO_INTERFACE_MESSAGE );
    $page->assign( "payment_id", $payment_id );
    if ( $_POST['DST_ACCOUNT_getname'] )
    {
        $arr_ACCOUNT_DATA['NAME'] = $_POST['DST_ACCOUNT_getname'];
    }
    $page->assign( "arr_ACCOUNT_DATA", $arr_ACCOUNT_DATA );
    if ( is_array( $_POST['addtional'] ) )
    {
        foreach ( $_POST['addtional'] as $key => $value )
        {
            $page->assign( "addtional_".$key, $value );
        }
    }
    require( "include/engine_run.php" );
}
?>
