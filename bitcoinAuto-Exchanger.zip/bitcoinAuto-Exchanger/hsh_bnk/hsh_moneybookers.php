<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

chdir( "../" );
include( "include/config.inc.php" );
$PAYMENT_ID = $_POST['transaction_id'];
$PAYMENT_BATCH_NUM = $_POST['rec_payment_id'];
$PAYMENT_AMOUNT = $_POST['amount'];
$PAYEE_ACCOUNT = $_POST['pay_to_email'];
$PAYMENT_CURRENCY = $_POST['currency'];
$status = $_POST['status'];
$PAYER_ACCOUNT = $_POST['pay_from_email'];
$PAID_WORTH_VALUE = $_POST['mb_currency'];
if ( $_POST['transaction_id'] )
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    $arr_Moneybookers = get_currency_data( "", "moneybookers", $PAYMENT_CURRENCY );
    $ramz = new RamzNegar( );
    $arr_Moneybookers['ALT_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_Moneybookers['ALT_PASSWORD'] );
}
$Moneybookers_array = array(
    $_POST['merchant_id'],
    $_POST['transaction_id'],
    md5( strtoupper( $arr_Moneybookers['ALT_PASSWORD'] ) ),
    $_POST['mb_amount'],
    $_POST['mb_currency'],
    $_POST['status']
);
$Moneybookers_hash = md5( implode( "", $Moneybookers_array ) );
if ( $Moneybookers_hash == $_POST['md5sig'] )
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    if ( Refrence2eid( $PAYMENT_ID ) )
    {
        if ( db_if_exists( "SELECT eid From {$_exchange_lines} WHERE exchange_refrence='{$PAYMENT_ID}' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND src_amount='{$PAYMENT_AMOUNT}'" ) )
        {
            SEND_EXHCANGE_MAIL( $PAYMENT_ID, "receive" );
            commit_exchange( $PAYMENT_ID, $PAYMENT_BATCH_NUM, $PAYER_ACCOUNT, $PAID_WORTH_VALUE );
            $Message_log[] = "MONEYBOOKERS ADD TO DATABSE";
        }
    }
    else if ( db_if_exists( "SELECT * FROM {$_lines} WHERE id='{$PAYMENT_ID}' AND amount='{$PAYMENT_AMOUNT}' AND status='{$STATUS_ENUM_DISABLE}' AND pmt_type='{$TRANS_ENUM_SPEND}'" ) )
    {
        SEND_INVEST_RECEIVE_MAIL( $PAYMENT_ID, $PAYER_ACCOUNT );
        commit_transaction( $PAYMENT_ID, $PAYMENT_BATCH_NUM );
        $Message_log[] = "MONEYBOOKERS ADD TO DATABSE";
    }
    $Message_log[] = "MONEYBOOKERS ACCEPTED";
    db_close( $dbconn );
}
Write_File( );
?>
