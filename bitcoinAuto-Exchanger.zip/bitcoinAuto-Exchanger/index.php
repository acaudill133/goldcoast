<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

include( "public.inc.php" );
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."index.php" );
}
else
{
    require( "include/engine_settings.php" );
    $EXTRA_ENGINE = "exchange_box.php";
    $PAGE_TEMPLATE = "index.html";
    if ( ( $CONFIG['temporary_close'] || $CONFIG['secretadminlogin'] ) && $_GET['_login'] == $CONFIG['secretadminlogin'] && !session_active( ) )
    {
        $PAGE_TEMPLATE = "login_page.html";
        $page->assign( "do_login", $_GET['_login'] );
        $LANG_msg['login_013'] = $LANG_msg['admin_023'];
        $page->assign( "LANG", $LANG_msg );
    }
    if ( $_GET['_page'] )
    {
        $PAGE_TEMPLATE = $_GET['_page'].".html";
    }
    require( "include/engine_run.php" );
}
?>
