$(document).ready(function() {
	$("#exchange_button").hover(
		function() {
			$(this).find("i").addClass("fa-spin");
		},
		function() {
			$(this).find("i").removeClass("fa-spin");
		}
	);
});

function get_receive(id) {
	var url = $("#url").val();
	var data_url = url + "requests/get-receive.php?id="+id;
	$.ajax({
		type: "GET",
		url: data_url,
		dataType: "html",
		success: function (data) {
			$("#receive_list").html(data);
		}
	});
}

function get_currencies(id) {
	var url = $("#url").val();
	var data_url = url + "requests/get-currencies.php?id="+id;
	$.ajax({
		type: "GET",
		url: data_url,
		dataType: "html",
		success: function (data) {
			$("#currency").html(data);
		}
	});
}

function generateForm() {
	var url = $("#url").val();
	var data_url = url + "requests/generate-form.php";
	$.ajax({
		type: "POST",
		url: data_url,
		dataType: "html",
		data: $("#exchange_form").serialize(),
		success: function (data) {
			$("#exchange_status").html(data);
		}
	});
}

function validateForm() {
	$("#loader").modal("show");
	var url = $("#url").val();
	var receive = $("#receive_list").val();
	var data_url = url + "requests/validate-form.php?receive="+receive;
	$.ajax({
		type: "POST",
		url: data_url,
		dataType: "json",
		data: $("#become_exchange_form").serialize(),
		success: function (data) {
			$("#loader").modal("hide");
			if(data['status'] == "111") {
				makePayment();
			} else {
				$("#loader").modal("hide");
				$("#exchange_results").html(data['msg']);
			}
		}
	});
}

function makePayment() {
	var url = $("#url").val();
	var send = $("#send_list").val();
	var receive = $("#receive_list").val();
	var amount = $("#amount").val();
	var currency = $("#currency").val();
	var receive_amount = $("#receive_amount").val();
	var account = $("#account").val();
	var email = $("#email").val();
	var data_url = url + "requests/make-payment.php?send="+send+"&receive="+receive+"&amount="+amount+"&currency="+currency+"&receive_amount="+receive_amount+"&account="+account+"&email="+email;
	$.ajax({
		type: "GET",
		url: data_url,
		dataType: "html",
		success: function (data) {
			$("#exchange_results").html(data);
		}
	});
}