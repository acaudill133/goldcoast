<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

if ( !$CONFIG )
{
    require( "include/config.inc.php" );
}
if ( !$dbconn )
{
    $dbconn = db_open( );
}
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."inc.head.php" );
    require_once( $CONFIG['SKIN_FOLDER']."inc.menu.top.php" );
}
if ( $_GET['Action'] == "logout" )
{
    db_exec( "UPDATE {$_users} SET session_id='', language='{$_SESSION['language']}' WHERE session_id='{$sid}' and uid='{$_SESSION['uid']}'" );
    make_session_unregister( );
    header( "Location: ".$CONFIG['SITE_URL'] );
}
if ( $_POST['submit_login'] && !session_active( ) )
{
    include( "include/user_login_check.php" );
}
if ( isset( $_GET['inccur'] ) )
{
    $str_tool = new string_tool( );
    $inccur = $str_tool->remove_dangerous_chars( trim( $_GET['inccur'] ) );
    $arr_INCLUDE_CURRENCIES = explode( ",", $inccur );
    $i = 0;
    foreach ( $arr_INCLUDE_CURRENCIES as $key => $value )
    {
        if ( db_get_id( "SELECT cid FROM {$_currencies} WHERE {$_currencies}.currency_name='{$value}'" ) )
        {
            $currencies_names .= "'{$value}', ";
            $currencies_names_title .= ucfirst( $value ).", ";
        }
    }
    if ( $currencies_names )
    {
        $currencies_names = substr( $currencies_names, 0, strlen( $currencies_names ) - 2 );
        $LANG_msg['exchange_004'] .= " (".substr( $currencies_names_title, 0, strlen( $currencies_names_title ) - 2 ).")";
        $currencies_clause = " AND currency_name in (".$currencies_names.") ";
    }
}
else if ( $CONFIG['EXCLUDE_CURRENCIES'] )
{
    $arr_EXCLUDE_CURRENCIES = explode( ",", $CONFIG['EXCLUDE_CURRENCIES'] );
    foreach ( $arr_EXCLUDE_CURRENCIES as $key => $value )
    {
        $currencies_clause .= " AND {$_currencies}.currency_name<>'{$value}' ";
    }
}
$arr_currency = array( );
$query_currency = "Select {$_exchange_rate}.cid, currency_name, reserve_amount, currency_worth_name, currency_metal_name, ACCOUNT From {$_exchange_rate} Inner Join {$_currencies} ON {$_exchange_rate}.cid = {$_currencies}.cid\r\n\t\t\tWhere {$_currencies}.exchange_status = '1' {$currencies_clause} Order By {$_currencies}.cid Asc";
$result = db_query( $query_currency, "&nbsp;" );
$arr_Reserve = mysql_push_data( $result );
db_free_result( $result );
foreach ( $arr_Reserve as $key => $value )
{
    $currencies_FNAME[$arr_Reserve[$key]['cid']] = ucfirst( $arr_Reserve[$key]['currency_name'] )." ".ucfirst( $arr_Reserve[$key]['currency_metal_name'] );
}
$query_currencies = "Select cid, currency_name, currency_worth_name, currency_metal_name From {$_currencies} Order By {$_currencies}.cid Asc";
$result = db_query( $query_currencies, "&nbsp;" );
$arr_result = mysql_push_data( $result );
foreach ( $arr_result as $key => $value )
{
    $Allcurrencies[$arr_result[$key]['cid']] = ucfirst( $arr_result[$key]['currency_name'] )." ".ucfirst( $arr_result[$key]['currency_metal_name'] );
}
db_free_result( $result );
unset( $arr_result );
if ( $CONFIG['NEWS_NUMBER'] )
{
    if ( !$CONFIG )
    {
        require( "include/config.inc.php" );
    }
    $nclause = "fld_language='{$CONFIG['DEF_LANGUAGE']}'";
    if ( db_get_id( "SELECT id FROM {$_news} WHERE type='1' AND status='1' AND fld_language='{$language}' AND fld_title<>''" ) )
    {
        $nclause = "fld_language='{$language}'";
    }
    $query_news = "SELECT id, fld_title, fld_body, fld_date FROM {$_news} WHERE type = '1' AND status = '1' AND {$nclause} ORDER BY fld_date DESC LIMIT 0, {$CONFIG['NEWS_NUMBER']}";
    $result = db_query( $query_news, "&nbsp;" );
    $arr_data_news_list = mysql_push_data( $result );
    db_free_result( $result );
    foreach ( $arr_data_news_list as $key => $value )
    {
        $arr_data_news_list[$key]['body_lenght'] = strlen( $arr_data_news_list[$key]['fld_body'] );
    }
}
?>
