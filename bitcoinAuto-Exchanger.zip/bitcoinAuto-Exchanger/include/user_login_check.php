<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

if ( !$CONFIG )
{
    require( "include/config.inc.php" );
}
if ( !$dbconn )
{
    $dbconn = db_open( );
}
if ( isset( $_POST['user'] ) && ( $_POST['password'] && !session_active( ) ) )
{
    if ( !cookie_check( ) )
    {
        header( "Location: ".get_link( $cur_page, "?Error=cookie" ) );
    }
    $str_tool = new string_tool( );
    $password = $str_tool->remove_dangerous_chars( stripslashes( trim( $_POST['password'] ) ) );
    $user = $str_tool->remove_dangerous_chars( stripslashes( trim( $_POST['user'] ) ) );
    $idcode = $_POST['turing'];
    if ( $CONFIG['LOGIN_TURNING'] && strtolower( trim( $idcode ) ) != $_SESSION['UniqCode'] )
    {
        $_SESSION['loginerror'] = $LANG_msg['login_007'];
        make_session_unregister( );
        echo "<meta http-equiv='Refresh' content='0; url=".get_link( $cur_page )."'>";
        unset( $_SESSION['UniqCode'] );
        exit( );
    }
    $login_check = login_check( $user, $password );
    if ( $login_check[permit] == $PMT_INFO_ADMIN && $CONFIG['secretadminlogin'] && $_POST['do_login'] != $CONFIG['secretadminlogin'] )
    {
        $Ad_error = ", or account is limited!";
    }
    if ( $login_check[permit] == $PMT_INFO_ADMIN && $CONFIG['adminloginlimitip'] && !check_ip_limit( $CONFIG['adminloginlimitip'] ) )
    {
        $Ad_error = ", or account is limited!";
    }
    if ( $login_check[uid] && !$Ad_error )
    {
        $user_login = $login_check[user_login];
        $uid = $login_check[uid];
        $permit = $login_check[permit];
        $user_status = $login_check[status];
        $fullname = $login_check[fullname];
        $user_lang = lang_selected( $login_check[language] );
        make_session_register( );
        if ( $permit != $PMT_INFO_ADMIN )
        {
            createCookie( "user", $user_login, 3600 * 48 );
        }
        if ( $user_status == $STATUS_ENUM_LOCKED )
        {
            $_SESSION['loginerror'] = $LANG_msg['login_011'];
            echo "<meta http-equiv='Refresh' content='0; url={$CONFIG['SITE_URL']}'>";
            exit( );
        }
        else if ( $user_status == $STATUS_ENUM_DISABLE )
        {
            $_SESSION['loginerror'] = $LANG_msg['login_012'];
            make_session_unregister( );
            echo "<meta http-equiv='Refresh' content='0; url=".( $cur_page )."'>";
            exit( );
        }
    }
    else
    {
        $_SESSION['loginerror'] = $LANG_msg['login_008'].$Ad_error;
        make_session_unregister( );
        echo "<meta http-equiv='Refresh' content='0; url=".get_link( $cur_page )."'>";
        exit( );
    }
    if ( session_member( ) )
    {
        header( "Location: ".get_link( "status.php", "", "", "", $user_lang ) );
    }
   # else if ( ( ) )
    {
        header( "Location: ".get_link( "adm_status.php" ) );
    }
    #else
    {
        header( "Location: ".get_link( $cur_page ) );
    }
}
?>
