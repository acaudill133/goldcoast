<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_entity_decode( $param )
{
    $param = strtr( $param, array_flip( get_html_translation_table( HTML_ENTITIES ) ) );
    $param = preg_replace( "/&#([0-9]+);/me", "chr('\\1')", $param );
    return $param;
}

?>
