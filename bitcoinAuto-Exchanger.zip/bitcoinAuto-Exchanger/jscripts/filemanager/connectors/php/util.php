<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function RemoveFromStart( $sourceString, $charToRemove )
{
    $sPattern = "|^".$charToRemove."+|";
    return preg_replace( $sPattern, "", $sourceString );
}

function RemoveFromEnd( $sourceString, $charToRemove )
{
    $sPattern = "|".$charToRemove."+\$|";
    return preg_replace( $sPattern, "", $sourceString );
}

function ConvertToXmlAttribute( $value )
{
    return utf8_encode( htmlspecialchars( $value ) );
}

?>
