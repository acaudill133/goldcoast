<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

chdir( "../" );
include( "include/config.inc.php" );
if ( $_POST['lr_transfer'] )
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    $arr_LIBERTYRESERVE = get_currency_data( "", "libertyreserve", $_POST['lr_currency'] );
    $ramz = new RamzNegar( );
}
$PAYMENT_ID = $_POST['order_id'];
$PAYEE_ACCOUNT = $_POST['lr_paidto'];
$PAYMENT_AMOUNT = $_POST['lr_amnt'];
$PAYMENT_BATCH_NUM = $_POST['lr_transfer'];
$PAYER_ACCOUNT = $_POST['lr_paidby'];
$PAID_WORTH_VALUE = $_POST['lr_currency'];
$Liberty_array = array(
    $_POST['lr_paidto'],
    $_POST['lr_paidby'],
    $_POST['lr_store'],
    $_POST['lr_amnt'],
    $_POST['lr_transfer'],
    $_POST['lr_currency'],
    $arr_LIBERTYRESERVE['ALT_PASSWORD']
);
$Liberty_array_value = implode( ":", $Liberty_array );
$Message_log[] = "Hash results: ".$Liberty_hash." = ".$_POST['lr_encrypted'];
$ver = explode( ".", phpversion( ) );
if ( $ver[0] == 4 )
{
    $Liberty_hash = bin2hex( mhash( MHASH_SHA256, $Liberty_array_value ) );
}
else
{
    $Liberty_hash = hash( "sha256", $Liberty_array_value );
}
if ( strtoupper( $Liberty_hash ) != $_POST['lr_encrypted'] )
{
    $Message_log[] = " LIBERT FAILED!!!!!!!!!!!<br> {$Liberty_hash} != {$_POST['lr_encrypted']}";
}
else
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    if ( $PAYMENT_ID && db_if_exists( "SELECT eid From {$_exchange_lines} WHERE exchange_refrence='{$PAYMENT_ID}' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND src_amount='{$PAYMENT_AMOUNT}'" ) && liberty_autocheck( $PAYMENT_BATCH_NUM, $PAYMENT_ID ) )
    {
        SEND_EXHCANGE_MAIL( $PAYMENT_ID, "receive" );
        commit_exchange( $PAYMENT_ID, $PAYMENT_BATCH_NUM, $PAYER_ACCOUNT, $PAID_WORTH_VALUE );
        $Message_log[] = "Liberty ADD TO DATABSE EXCHANGE";
    }
    db_close( $dbconn );
    $Message_log[] = "Liberty ACCEPTED";
}
Write_File( );
unset( $arr_LIBERTYRESERVE );
?>
