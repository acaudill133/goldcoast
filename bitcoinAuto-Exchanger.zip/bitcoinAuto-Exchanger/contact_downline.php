<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function referral_profit( $referral_id )
{
    global $_lines;
    global $TRANS_ENUM_EARNING;
    global $STATUS_ENUM_ENABLE;
    global $TRANS_ENUM_COMPOUND;
    global $TRANS_ENUM_COMMISSION;
    db_get_id( "select sum(exchange) from {$_lines} where uid='{$referral_id}' and date<=now() and status='{$STATUS_ENUM_ENABLE}' and (pmt_type='{$TRANS_ENUM_EARNING}' OR pmt_type='{$TRANS_ENUM_COMPOUND}' OR pmt_type='{$TRANS_ENUM_COMMISSION}')" );
}

require( "public.inc.php" );
include( "include/user_ids_include.php" );
if ( $_POST['Action'] == "Send" )
{
    $fld_message = $_POST['fld_message'];
    $fld_subject = $_POST['fld_subject'];
    if ( !$fld_subject || strlen( $fld_subject ) < 5 )
    {
        $Error[] = $LANG_msg['refstats_009']."<br>";
    }
    if ( !$fld_message || strlen( $fld_message ) < 10 )
    {
        $Error[] = $LANG_msg['refstats_010']."<br>";
    }
    if ( !$_POST['contact_id'] )
    {
        $Error[] = $LANG_msg['refstats_011']."<br>";
    }
    if ( !$Error )
    {
        $uids = implode( ",", $_POST['contact_id'] );
        $query = "select fullname, email from {$Var_1272} where uid='{$uid}'";
        $result = db_query( $query, "&nbsp;" );
        $line = db_fetch_array( $result );
        $from = $line[email];
        $from_name = $line[fullname];
        db_free_result( $result );
        $query = "Select {$_users_details}.fullname, {$_users_details}.email\r\n\t\tFrom {$_users_details} Inner Join {$_referals} ON {$_users_details}.uid = {$_referals}.uid_referal\r\n\t\tWhere {$_referals}.uid = '{$uid}' AND {$_referals}.uid_referal in ({$uids})";
        $result = db_query( $query );
        while ( $line = db_fetch_array( $result ) )
        {
            $to = $line[email];
            $to_name = $line[fullname];
            $to_all .= $to."\\n";
            $message = "Message from ".$CONFIG['SITE_NAME']." <b>User:</b> ".$from_name.",<br><br>".$fld_message."\r\n\t\t\t<br><br><br><br>If you found this email as spam please report it to ".$CONFIG['ADMIN_MAIL'].".";
            $headers = "MIME-Version: 1.0\r\n";
            $headers .= "Content-type: text/html; charset=utf-8\r\n";
            $headers .= "To: ".$to_name." <".$to.">\r\n";
            $headers .= "From: ".$from_name." <".$CONFIG['REPORT_MAIL'].">\r\n";
            $headers .= "Reply-to: ".$from."\r\n";
            $mail = new siteMAIL( );
            $mail->AddAddress( $to, $to_name );
            $mail->Subject = $fld_subject;
            $mail->Body = nl2br( $message );
            $mail->FromName = $from_name;
            $mail->AddReplyTo( $from, $from_name );
            $mail->bakeMail( );
            if ( $CONFIG['MAIL_TYPE'] == "smtp" )
            {
                if ( !$mail->Send( ) )
                {
                    $Error[] = $Tmp_192;
                }
            }
            else
            {
                if ( !mail( $CONFIG['ADMIN_MAIL'], $mail->Subject, $mail->Body, $headers ) )
                {
                    $Error[] = "There was an error sending the email by server php mail extension.";
                }
                if ( $CONFIG['adminemailnotification'] )
                {
                    mail( $CONFIG['ADMIN_MAIL'], "New Mail from contact downline page: ".$mail->Subject, "From:".$from_name."(".$from.")<br> TO: ".$to_all."<br>".$mail->Body, $headers );
                }
            }
        }
        if ( !$Error )
        {
            $sent = true;
        }
    }
}
if ( $sent )
{
    empty( $fld_message );
    empty( $fld_subject );
    empty( $Action );
    $Success[] = $LANG_msg['refstats_012'];
}
$date_field = "r.date";
$counter = 1;
$count = 0;
$query = "select date_format({$date_field},'%Y-%m-%d') as day, d.fullname, d.email, d.uid, u.ip from {$_referals} r, {$_users} u, {$_users_details} d\r\n\t\twhere r.uid='{$uid}{$STATUS_ENUM_ENABLE}' order by {$date_field} desc";
$result = db_query( $query, "&nbsp;" );
$arr_data_referral = mysql_push_data( $result );
db_free_result( $result );
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."contact_downline.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "contact_downline.html";
    $page->assign( "referral_link", make_ref_link( $uid ) );
    $Var_6720->assign( "total_refferals", $total_refferals );
    $page->assign( "referral_profit", $Var_6864 );
    $i = 1;
    foreach ( $arr_data_referral as $key => $value )
    {
        $arr_data_referral[$key]['NO'] = $i++;
        $arr_data_referral[$key]['NO'] = $i++;
    }
    $page->assign( "referral_no", count( $arr_data_referral ) );
    $page->assign( "arr_data_referral", $arr_data_referral );
    $page->assign( "Rate_Row", $Rate_Row );
    require( "include/engine_run.php" );
}
?>
