<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "public.inc.php" );
include( "include/user_ids_include.php" );
$query = "SELECT * FROM {$_logs} WHERE uid='{$uid}' AND session_id<>'{$sid}' ORDER BY login_date DESC ";
$page = $_GET['page'];
$total = mysql_num_rows( mysql_query( $query ) );
$perpage = $CONFIG['recordsnumperpage'];
$url_string = get_link( $cur_page.( $CONFIG['FRIENDLY_URL'] ? "" : "?" ).preg_replace( "/(&)page(\\/^|=)\\d+/", "", $_SERVER['QUERY_STRING'] ) );
$pager = new pager( $total, $perpage, $url_string, $CONFIG['FRIENDLY_URL'] );
if ( empty( $page ) )
{
    $page = 1;
}
$from = $pager->getPageFrom( $page );
$query = $query." limit {$from}, {$perpage}";
$result = db_query( $query, "&nbsp;" );
$arr_data_history = mysql_push_data( $result );
db_free_result( $result );
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."login_history.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "login_history.html";
    if ( $perpage < $total )
    {
        $pg = $pager->page;
        $page_navigation .= $pager->getButPrev( $pg );
        $range = 20;
        $page_navigation .= $pager->getButList( $range );
        $page_navigation .= $pager->getButNext( $pg );
        $page_navigation .= "<br><br><br>";
        $page_navigation .= $pager->getRangeInfo( );
    }
    $page->assign( "page_navigation", $page_navigation );
    $i = 1;
    foreach ( $arr_data_history as $key => $value )
    {
        $arr_data_history[$key]['NO'] = $i++;
    }
    foreach ( $arr_data_history as $key => $value )
    {
        if ( !is_null( $arr_data_history[$key]['logout_date'] ) )
        {
            $arr_data_history[$key]['Time_Diff'] = timeDiff( $arr_data_history[$key]['login_date'], $arr_data_history[$key]['logout_date'], true, true );
        }
    }
    $page->assign( "arr_data_history", $arr_data_history );
    require( "include/engine_run.php" );
}
?>
