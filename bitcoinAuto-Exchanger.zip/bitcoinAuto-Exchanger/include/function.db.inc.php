<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function mysql_error_report( $subject = "", $gen_error = "" )
{
    global $Error;
    Write_File( "MySql Error:", $subject );
    if ( $uploaded )
    {
        echo "Sorry, an error occurred while inderting new values into database please contact {$CONFIG['SITE_NAME']} about this error.";
    }
    else
    {
        echo $subject;
    }
}

function db_open( )
{
    global $hostname;
    global $db_login;
    global $db_pass;
    global $database;
    if ( !( $dbconn = mysql_connect( $hostname, $db_login, $db_pass ) ) )
    {
        exit( mysql_error_report( mysql_error( ), 1 ) );
    }
    mysql_select_db( $Var_408 );
    return $dbconn;
}

function db_country_open( )
{
    global $hostname;
    global $db_login_country;
    global $databaseCountry;
    global $db_pass_country;
    if ( !( $dbconn_country = mysql_connect( $hostname, $db_login_country, $db_pass_country ) ) )
    {
        exit( "Can not connect to country database" );
    }
    if ( !mysql_select_db( $databaseCountry ) )
    {
        exit( mysql_error( ) );
    }
    return $dbconn_country;
}

function db_close( $dbconn )
{
    if ( $dbconn )
    {
        mysql_close( $dbconn );
    }
}

function db_exec( $query )
{
    if ( !( $result = mysql_query( $query ) ) )
    {
        mysql_error( mysql_error_report( "<b>ERROR IN MySql db_exec:</b><br> <b>query:</b>".$query."<br><b>MySql error:</b>".mysql_error( ), 1 ) );
    }
    return $result;
}

function db_get_result( $result )
{
    return mysql_fetch_array( $result );
}

function db_if_exists( $query )
{
    $result = mysql_query( $query );
    $no = mysql_num_rows( $result );
    mysql_free_result( $result );
    return $no;
}

function db_get_id( $query )
{
    if ( !( $result = mysql_query( $query ) ) )
    {
        exit( mysql_error_report( "<b>ERROR IN MySql db_get_id:</b> <br>".mysql_error( )."<br><b>Query:</b> <br>".$query ) );
    }
    $line = mysql_fetch_array( $result );
    mysql_free_result( $result );
    return $line[0];
}

function db_get_array( $query )
{
    if ( !( $result = mysql_query( $query ) ) )
    {
        exit( mysql_error_report( "<b>ERROR IN MySql db_get_id:</b> <br>".mysql_error( )."<br><b>Query:</b> <br>".$query ) );
    }
    $line = mysql_fetch_array( $result );
    mysql_free_result( $result );
    $n = array( );
    $i = 0;
    while ( $i < sizeof( $line ) )
    {
        array_push( $n, $line[$i] );
        ++$i;
    }
    return $n;
}

function db_get_name_by_id( $table, $namefield, $idfield, $val )
{
    $query = "SELECT {$namefield} FROM {$table} WHERE {$idfield}={$val}";
    $result = mysql_query( $query );
    $line = mysql_fetch_array( $result );
    mysql_free_result( $result );
    return $line[0];
}

function db_get_position( $query, $id )
{
    $position = 0;
    $result = mysql_query( $query );
    while ( $line = mysql_fetch_array( $result ) )
    {
        ++$position;
        if ( !( $line[0] == $id ) )
        {
            continue;
        }
        break;
        break;
    }
    mysql_free_result( $result );
    return $position;
}

function db_count_records( $table, $more_clause )
{
    if ( $more_clause )
    {
        $more_clause = "WHERE {$more_clause}";
    }
    $query = "SELECT COUNT(*) FROM {$table} {$more_clause}";
    $result = mysql_query( $query );
    $line = mysql_fetch_array( $result );
    mysql_free_result( $result );
    return $line[0];
}

function db_get_last_id( $table, $autonumid = "id" )
{
    return db_get_id( "select max({$autonumid}) from {$table}" );
}

function db_query( $query, $die = "" )
{
    if ( $die )
    {
        if ( !( $result = mysql_query( $query ) ) )
        {
            exit( mysql_error( ) );
        }
        return $result;
    }
    return mysql_query( $query );
}

function db_fetch_array( $result )
{
    return mysql_fetch_array( $result );
}

function mysql_push_data( $result, $numass = MYSQL_BOTH )
{
    $got = array( );
    while ( $row = mysql_fetch_array( $result, $numass ) )
    {
        array_push( $Var_240, $row );
    }
    return $got;
}

function db_result( $result, $row = 0, $field = "" )
{
    return mysql_result( $result, $row, $field );
}

function db_num_rows( $result )
{
    return mysql_num_rows( $result );
}

function db_free_result( $result )
{
    mysql_free_result( $result );
}

function parse_mysql_dump( $url, $ignoreerrors = false )
{
    $file_content = file( $url );
    $query = "";
    foreach ( $file_content as $sql_line )
    {
        $tsl = trim( $sql_line );
        if ( $sql_line != "" && substr( $tsl, 0, 2 ) != "--" && substr( $tsl, 0, 1 ) != "#" )
        {
            $query .= $sql_line;
            if ( preg_match( "/;\\s*\$/", $sql_line ) )
            {
                ++$querycount;
                $query = str_replace( ";", "", "{$query}" );
                $result = mysql_query( $query );
                if ( !$result )
                {
                    $queryerrors .= ""."Line ".$querycount." - ".mysql_error( )."<br>";
                    continue;
                }
                $query = "";
            }
        }
    }
    if ( $queryerrors )
    {
        mysql_error_report( "Please open a ticket with the debug information below for support<br><br>File: ".$filename."<br>".$queryerrors, 1 );
    }
    else
    {
    }
    return true;
}

?>
