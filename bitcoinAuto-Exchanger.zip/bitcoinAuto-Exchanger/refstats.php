<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function referral_profit( $referral_id )
{
    global $_lines;
    global $TRANS_ENUM_EARNING;
    global $STATUS_ENUM_ENABLE;
    global $TRANS_ENUM_COMPOUND;
    global $TRANS_ENUM_COMMISSION;
    db_get_id( "select sum(exchange) from {$_lines} where uid='{$referral_id}' and date<=now() and status='{$STATUS_ENUM_ENABLE}' and (pmt_type='{$TRANS_ENUM_EARNING}' OR pmt_type='{$TRANS_ENUM_COMPOUND}' OR pmt_type='{$TRANS_ENUM_COMMISSION}')" );
}

require( "public.inc.php" );
require( "include/user_ids_include.php" );
$nvar = db_get_array( "select fullname,email from {$_users_details} where uid='{$uid}' and suspended='0'" );
$e_name = $nvar[0];
$e_email = $nvar[1];
$commission = FormatPrice( get_sum( "", $STATUS_ENUM_ENABLE, $TRANS_ENUM_COMMISSION ), 2 );
$earn = FormatPrice( get_sum( "", $STATUS_ENUM_ENABLE, $TRANS_ENUM_EARNING ), 2 );
$total_refferals = db_count_records( $_referals, "uid='{$uid}'" );
$date_field = "r.date";
$count = 1;
$query = "select date_format({$date_field},'%Y-%m-%d') as day, d.fullname, d.email, d.uid, u.ip from {$_referals} r, {$_users} u, {$_users_details} d\r\n\twhere r.uid='{$uid}' and u.uid=r.uid_referal and d.uid=r.uid_referal and u.status='{$STATUS_ENUM_ENABLE}' order by {$date_field} desc";
$result = db_query( $query, "&nbsp;" );
$arr_data_referral = mysql_push_data( $result );
db_free_result( $result );
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."refstats.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "refstats.html";
    $page->assign( "referral_link", make_ref_link( $uid ) );
    $page->assign( "total_refferals", $total_refferals );
    $page->assign( "commission", $commission );
    $page->assign( "admin_view", $admin_view );
    $i = 1;
    foreach ( $arr_data_referral as $key => $value )
    {
        $arr_data_referral[$key]['NO'] = $i++;
    }
    foreach ( $arr_data_referral as $key => $value )
    {
        $arr_data_referral[$key]['email'] = explode( "@", $arr_data_referral[email] );
    }
    $page->assign( "arr_data_referral", $arr_data_referral );
    require( "include/engine_run.php" );
}
?>
