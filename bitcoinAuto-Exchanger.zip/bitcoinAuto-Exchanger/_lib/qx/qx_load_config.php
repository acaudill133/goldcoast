<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_load_config( $filename, $name = "config" )
{
    global $_top;
    $section = null;
    if ( is_file( $filename ) )
    {
        if ( is_array( $cfgfile ) )
        {
            foreach ( $cfgfile as $line )
            {
                if ( substr( $line, 0, 1 ) != "#" )
                {
                    if ( substr( $line, 0, 1 ) == "[" && ( $rbr = strpos( $line, "]" ) ) )
                    {
                        $section = substr( $line, 1, $rbr - 1 );
                    }
                    if ( $tr = strpos( $line, "=" ) )
                    {
                        $k = trim( substr( $line, 0, $tr ) );
                        $v = trim( substr( $line, $tr + 1 ) );
                        if ( isset( $section ) )
                        {
                            $_top[$name][$section][$k] = $v;
                        }
                        else
                        {
                            $_top[$name][$k] = $v;
                        }
                    }
                }
            }
        }
    }
}

?>
