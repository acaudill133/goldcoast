<?php
  $transaction_id = $_POST['transaction_id'];
	$merchant_id = $_POST['pay_to_email'];
	$item_number = $_POST['detail1_text'];
	$item_name = $_POST['detail1_description'];
	$amount = $_POST['mb_amount'];
	$currency = $_POST['mb_currency'];
	$date = date("d/m/Y H:i:s");
	$query = $db->query("SELECT * FROM exchanges WHERE id='$item_number'");
	if($query->num_rows==0) { header("Location: $settings[url]"); }

$row = $query->fetch_assoc();
$query1 = $db->query("SELECT * FROM companies_list WHERE id='$row[c_send]'");
$row1 = $query1->fetch_assoc();
if(checkSession()) { $uid = $_SESSION['suid']; } else { $uid = 0; }
$check_trans = $db->query("SELECT * FROM transactions WHERE tid='$transaction_id' and date='$date' and uid='$uid'");
  $concatFields = $_POST['merchant_id']
					.$_POST['transaction_id']
					.strtoupper(md5($row1['a_field_1']))
					.$_POST['mb_amount']
					.$_POST['mb_currency']
					.$_POST['status'];

				$MBEmail = $row1['account'];

				// Ensure the signature is valid, the status code == 2,
				// and that the money is going to you
				if (strtoupper(md5($concatFields)) == $_POST['md5sig']
					&& $_POST['status'] == 2
					&& $_POST['pay_to_email'] == $MBEmail)
				{
					// payment successfully...
					if($merchant_id == $row1['account']) {
							if($amount == $row['a_send'] or $currency == $row['a_currency']) {
								if($check_trans->num_rows>0) {
									echo error($lang['error_15']);
								} else {
									$insert = $db->query("INSERT transactions (tid,from,uid,in,amount,currency,date) VALUES ('$transaction_id','$ac_src_wallet','$uid','Skrill','$amount','$currency','$date')");
									$update = $db->query("UPDATE exchanges SET status='2' WHERE id='$row[id]'");
									echo success($lang['success_4']);
								}
							} else {
								echo error($lang['error_16']);
							}
						} else { 
							echo error($lang['error_17']);
						}
				}
				else
				{
					echo error($lang['error_20']);
				}
?>