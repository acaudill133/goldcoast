<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_current_datetime( )
{
    global $_CONFIG;
    if ( empty( $_CONFIG['datetime_format'] ) )
    {
        $_CONFIG['datetime_format'] = "F j, Y H:i:s";
    }
    return date( $_CONFIG['datetime_format'] );
}

?>
