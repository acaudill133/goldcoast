<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

class pager
{

    public $per_page = NULL;
    public $page = NULL;
    public $page_identifier = NULL;
    public $but_next = "<a href=\"{query_string}&page={page}\">>></a>";
    public $but_next1 = "<a href=\"{query_string}page/{page}/\">>></a>";
    public $but_prev = "<a href=\"{query_string}&page={page}\"><<</a>";
    public $but_prev1 = "<a href=\"{query_string}page/{page}/\"><<</a>";
    public $but_page = "<a href=\"{query_string}&page={page}\">{page}</a>";
    public $but_page1 = "<a href=\"{query_string}page/{page}/\">{page}</a>";
    public $but_page_this = "<span class=current>{page}</span>";
    public $range_display = "<span class=info_line>Show Results: {from} to {to} from {total}</span>";
    public $num_results = NULL;
    public $page_list_size = NULL;
    public $query_string = NULL;

    public function pager( $num_results, $per_page = 10, $query_string = "", $friendly_url = "", $page_id = "page" )
    {
        $this->page = $_REQUEST[$page_id] ? $_REQUEST[$page_id] : 1;
        $this->page_identifier = $page_id;
        $this->per_page = $per_page;
        $this->num_results = $num_results;
        $this->query_string = $query_string;
        $this->page_list_size = ceil( $num_results / $per_page );
        $this->friendly_url = $friendly_url;
    }

    public function getPageFrom( $page )
    {
        if ( $page <= 0 )
        {
            return 0;
        }
        if ( $this->page_list_size < $page )
        {
            return 0;
        }
        $result = ( $page - 1 ) * $this->per_page;
        $result = $this->num_results <= $result ? $this->num_results - 1 : $result;
        return $result;
    }

    public function getPageTo( $page )
    {
        if ( $page <= 0 )
        {
            return 0;
        }
        if ( $this->page_list_size < $page )
        {
            return 0;
        }
        $result = ( $page - 1 ) * $this->per_page + $this->per_page;
        $result = $this->num_results <= $result ? $this->num_results : $result;
        return $result;
    }

    public function getButNext( $page )
    {
        ++$page;
        if ( $this->page_list_size < $page )
        {
            return "";
        }
        if ( $page < 1 )
        {
            return "";
        }
        if ( $this->friendly_url )
        {
            $temp = ereg_replace( "{query_string}", $this->query_string, $this->but_next1 );
        }
        else
        {
            $temp = ereg_replace( "{query_string}", $this->query_string, $this->but_next );
        }
        $result = ereg_replace( "{page}", ( boolean )$page, $temp );
        return $result;
    }

    public function getButPrev( $page )
    {
        --$page;
        if ( $page < 1 )
        {
            return "";
        }
        if ( $this->page_list_size < $page )
        {
            return "";
        }
        if ( $this->friendly_url )
        {
            $temp = ereg_replace( "{query_string}", $this->query_string, $this->but_prev1 );
        }
        else
        {
            $temp = ereg_replace( "{query_string}", $this->query_string, $this->but_prev );
        }
        $result = ereg_replace( "{page}", ( boolean )$page, $temp );
        return $result;
    }

    public function getButPage( $page )
    {
        if ( $page < 1 )
        {
            return "";
        }
        if ( $this->page_list_size < $page )
        {
            return "";
        }
        if ( $this->friendly_url )
        {
            $source = $page == $this->page ? $this->but_page_this : $this->but_page1;
        }
        else
        {
            $source = $page == $this->page ? $this->but_page_this : $this->but_page;
        }
        $temp = ereg_replace( "{query_string}", $this->query_string, $source );
        $result = ereg_replace( "{page}", ( boolean )$page, $temp );
        return $result;
    }

    public function getButList( $range = 9 )
    {
        ++$range;
        unset( $result );
        $i = $this->page - $range;
        while ( $i <= $this->page + $range )
        {
            if ( $this->page < $range )
            {
                do
                {
                    $result .= $this->getButPage( $i );
                    if ( !( $i == $range ) )
                    {
                        break;
                    }
                    else
                    {
                        break;
                    }
                }
                $result .= $this->getButPage( $i );
            } while ( 0 );
            if ( $this->getButPage( $i + 1 ) && $result && $Tmp_42 )
            {
                $result .= $this->separator;
            }
            ++$i;
        }
        return $result;
    }

    public function getRangeInfo( )
    {
        $from = $this->getPageFrom( $this->page ) + 1;
        $to = $this->getPageTo( $this->page );
        $temp = ereg_replace( "{from}", ( boolean )$from, $this->range_display );
        $temp = ereg_replace( "{to}", ( boolean )$to, $temp );
        $result = ereg_replace( "{total}", ( boolean )$this->num_results, $temp );
        return $result;
    }

}

?>
