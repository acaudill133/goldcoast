	<input type="hidden" id="url" value="<?php echo $settings['url']; ?>">
	<div class="footer_container">
		<div class="container">
			<div class="row" style="padding:30px;">
				<div class="col-sm-12 col-md-12 col-lg-12">
					<center>
						<img src="<?php echo $settings['url']; ?>assets/imgs/paypal.png" width="100px"> 
						<img src="<?php echo $settings['url']; ?>assets/imgs/skrill.png" width="100px"> 
						<img src="<?php echo $settings['url']; ?>assets/imgs/payeer.png" width="100px"> 
						<img src="<?php echo $settings['url']; ?>assets/imgs/perfectmoney.png" width="100px"> 
						<img src="<?php echo $settings['url']; ?>assets/imgs/advcash.jpg" width="100px"> 
						<img src="<?php echo $settings['url']; ?>assets/imgs/webmoney.png" width="100px"> 
						<img src="<?php echo $settings['url']; ?>assets/imgs/okpay.png" width="100px"> 
						<br>
						<a href="<?php echo $settings['url']; ?>page/privacy-policy"><?php echo $lang['privacy_policy']; ?></a> - 
						<a href="<?php echo $settings['url']; ?>page/terms-of-service"><?php echo $lang['terms_of_service']; ?></a> -
						<a href="<?php echo $settings['url']; ?>page/about"><?php echo $lang['about']; ?></a> - 
						<a href="<?php echo $settings['url']; ?>page/contact"><?php echo $lang['contact']; ?></a> - 
						<?php echo $lang['language']; ?>: <?php echo getLanguage($settings['url'],null,1); ?>
						<br>
						Copyright &copy; 2015 by <a href="http://me4onkof.info">me4onkof</a>
					</center>
				</div>
			</div>
		</div>	
	</div>
	
	<div class="modal fade" id="loader" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"  data-backdrop="static" data-keyboard="false">
	  <div class="modal-dialog" role="document">
		<div style="padding:100px;">
			<center>
				<img src="<?php echo $settings['url']; ?>assets/imgs/loader.GIF">
			</center>
		</div>
	  </div>
	</div>
</body>
</html>