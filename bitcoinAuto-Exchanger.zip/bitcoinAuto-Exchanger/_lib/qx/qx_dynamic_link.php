<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_dynamic_link( $title )
{
    global $language;
    global $CONFIG;
    global $cur_page;
    if ( !$CONFIG['FRIENDLY_URL'] )
    {
        return $CONFIG['SITE_URL']."/nview.php?title=".$title;
    }
    $title = urlencode( $title );
    $final_link = qx_make_link( "nview.php?title=".$title );
    return htmlspecialchars( $final_link );
}

?>
