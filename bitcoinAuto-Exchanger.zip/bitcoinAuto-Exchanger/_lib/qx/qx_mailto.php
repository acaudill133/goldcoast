<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_mailto( $param, $name = "", $encode = false )
{
    if ( $encode === false )
    {
        if ( $name != "" )
        {
            return "<a href=\"mailto:".$param."\">".$name."</a>";
        }
        return "<a href=\"mailto:".$param."\">".$param."</a>";
    }
    $obfuscatedMailTo = "";
    $mailto = "mailto:";
    $length = strlen( $mailto );
    $i = 0;
    while ( $i < $length )
    {
        $obfuscatedMailTo .= "&#".ord( $mailto[$i] );
        ++$i;
    }
    $mailto = $param;
    $length = strlen( $mailto );
    $param = "";
    $i = 0;
    while ( $i < $length )
    {
        $param .= "&#".ord( $mailto[$i] );
        ++$i;
    }
    if ( $name != "" )
    {
        $mailto = $name;
        $length = strlen( $mailto );
        $name = "";
        $i = 0;
        while ( $i < $length )
        {
            $name .= "&#".ord( $mailto[$i] );
            ++$i;
        }
        return "<a href=\"".$obfuscatedMailTo.":".$param."\">".$name."</a>";
    }
    return "<a href=\"".$obfuscatedMailTo.":".$param."\">".$param."</a>";
}

?>
