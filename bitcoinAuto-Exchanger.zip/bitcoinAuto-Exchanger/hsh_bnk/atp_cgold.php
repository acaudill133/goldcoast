<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

echo "\r\n\r\n  <input type='hidden' name='payee_account' value='";
echo $payee_account;
echo "'>\r\n  <input type='hidden' name='payee_name' value=\"";
echo $user;
echo "\">\r\n";
if ( $amount == "ask" )
{
    echo "    Amount you want to pay: <INPUT type='text' name=\"payment_amount\">\r\n";
}
else
{
    echo "  <input type='hidden' name='payment_amount' value='";
    echo $amount;
    echo "'>\r\n";
}
echo "  <input type='hidden' name='payment_units' value='";
echo $arr_PAYMENT['WORTH_VALUE'];
echo " worth'>\r\n  <input type='hidden' name='status_url' value='";
echo $status_url;
echo "'>\r\n  <input type='hidden' name='payment_url' value='";
echo $response_ok;
echo "'>\r\n  <input type='hidden' name='payment_url_method' value='post'>\r\n  <input type='hidden' name='nopayment_url' value='";
echo $response_no;
echo "'>\r\n  <input type='hidden' name='nopayment_url_method' value='post'>\r\n  <input type='hidden' name='suggested_memo' value='";
echo $suggested_memo;
echo "'>\r\n  <input type='hidden' name='forced_payer_account' value='";
echo $def_payee_account;
echo "'>\r\n  <INPUT type=hidden value=\"";
echo $payment_id;
echo "\" name=PAYMENT_ID>\r\n";
?>
