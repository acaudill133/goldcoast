	<div class="fullpagecover">
		<div class="container">
			<div class="row" style="padding-top:50px;padding-bottom:50px;">
				<div class="col-sm-12 col-md-12 col-lg-12" id="exchange_results"></div>
				<div class="col-sm-5 col-md-5 col-lg-5">
					<div class="panel">
						<div class="panel-body">
							<form action="" method="POST" id="exchange_form">
								<div class="form-group">
									<label><?php echo $lang['send_from']; ?></label>
									<select class="form-control input-lg" name="send" id="send_list" onChange="get_receive(this.value);">
										<option value=""></option>
										<?php
										$send_list = $db->query("SELECT * FROM companies_list WHERE allow_send='1' ORDER BY id");
										if($send_list->num_rows>0) {
											while($send = $send_list->fetch_assoc()) {
												echo '<option value="'.$send[id].'">'.$send[name].'</option>';
											}
										}
										?>
									</select>
								</div>
								<div class="form-group">
									<label><?php echo $lang['receive_to']; ?></label>
									<select class="form-control input-lg" name="receive" id="receive_list" onChange="get_currencies(this.value);">
									</select>
								</div>
								<div class="form-group">
									<label><?php echo $lang['amount']; ?></label>
									<div class="input-group">
									  <input type="text" class="form-control input-lg" name="amount" id="amount" placeholder="Eg: 100">
									  <span class="input-group-btn">
										<select class="form-control input-lg" style="min-width:100px;" name="currency" id="currency">
											<option value="">USD</option>
											<option value="">EUR</option>
										</select>
									  </span>
									</div>
								</div>
								<button type="button" id="exchange_button" onclick="generateForm();" class="btn btn-primary btn-block btn-lg"><i class="fa fa-refresh"></i> <?php echo $lang['btn_10']; ?></button>
							</form>
						</div>
					</div>
				</div>	
				<div class="col-sm-2 col-md-2 col-lg-2"></div>
				<div class="col-sm-5 col-md-5 col-lg-5">
					<div class="panel">
						<div class="panel-body" id="exchange_status">
							<center>
								<?php echo $lang['select_exchange']; ?>
							</center>
						</div>
					</div>
				</div>
			</div>	
		</div>
	</div>
	
	<div class="container">
		<div class="row" style="padding-top:20px;padding-bottom:20px;">
			<div class="col-sm-6 col-md-6 col-lg-6">
				<h3><?php echo $lang['why']; ?> <?php echo $settings['sitename']; ?>?</h3>
				<div class="media">
				  <div class="media-left">
					<i class="fa fa-support fa-3x"></i>
				  </div>
				  <div class="media-body">
					<h4 class="media-heading"><?php echo $lang['why_ans_1']; ?></h4>
				  </div>
				</div>
				<br>
				<div class="media">
				  <div class="media-left">
					<i class="fa fa-line-chart fa-3x"></i>
				  </div>
				  <div class="media-body">
					<h4 class="media-heading"><?php echo $lang['why_ans_2']; ?></h4>
				  </div>
				</div>
				<br>
				<div class="media">
				  <div class="media-left">
					<i class="fa fa-clock-o fa-3x"></i>
				  </div>
				  <div class="media-body">
					<h4 class="media-heading"><?php echo $lang['why_ans_3']; ?></h4>
				  </div>
				</div>
				<br>
				<div class="media">
				  <div class="media-left">
					<i class="fa fa-money fa-3x"></i>
				  </div>
				  <div class="media-body">
					<h4 class="media-heading"><?php echo $lang['why_ans_4']; ?></h4>
				  </div>
				</div>
			</div>
			<div class="col-sm-6 col-md-6 col-lg-6">
				<h3><?php echo $lang['clients_testimonials']; ?></h3>
					<div class="row">
						<div class="col-md-12">
							<div class="quote"><i class="fa fa-quote-left fa-4x"></i></div>
							<div class="carousel slide" id="fade-quote-carousel" data-ride="carousel" data-interval="5000">
							  <!-- Carousel indicators -->
							  <ol class="carousel-indicators">
								<?php
								$i=1;
								$get_tests = $db->query("SELECT * FROM testimonials WHERE status='1' ORDER BY RAND() LIMIT 5");
								if($get_tests->num_rows>0) {
									while($get = $get_tests->fetch_assoc()) {
										$gets[] = $get;
									}
									foreach($gets as $get) {
										?><li data-target="#fade-quote-carousel" data-slide-to="<?php echo $i; ?>" class="<?php if($i == "1") { echo 'active'; } ?>"></li><?php
										$i++;
									}
								}
								?>
							  </ol>
							  <!-- Carousel items -->
							  <div class="carousel-inner">
								<?php
								$t=1;
								if($get_tests->num_rows>0) {
									foreach($gets as $get) {
										?>
										<div class="<?php if($t == "1") { echo 'active'; } ?> item">
											<blockquote>
												<p><?php echo $get['content']; ?><br/><i class="text-muted">- <?php echo $lang['from']; ?> <?php echo idinfo($get['uid'],"name"); ?></i></p>
											</blockquote>
											<div class="profile-circle" style="background-color: rgba(0,0,0,.2);"></div>
										</div>
										<?php
										$t++;
									}
								}
								?>
							  </div>
							</div>
						</div>							
					</div>
			</div>
		</div>
	</div>