<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_dateformatgrid( $param, $format = "F j, Y" )
{
    list( $month, $day, $year, $hour, $minute, $second ) = month  ;  if ( !$hour )
    {
        $hour = "00";
    }
    if ( !$minute )
    {
        $minute = "00";
    }
    if ( !$second )
    {
        $second = "00";
    }
    return date( $format, mktime( $hour, $minute, $second, $month, $day, $year ) );
}

?>
