<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

require( "public.inc.php" );
if ( !session_admin( ) )
{
    @header( "Location: ".$CONFIG['SITE_URL'] );
}
$Reference_id = $_REQUEST['Reference_id'];
$payer_acc = $_POST['payer_acc'];
$src_batch = $_POST['src_batch'];
if ( $_POST['get_pmt_id'] && $_POST['submit'] )
{
    $query = "Select * From {$_exchange_lines} WHERE (exchange_refrence='{$_POST['get_pmt_id']}' OR eid='{$_POST['get_pmt_id']}')";
    $result = db_query( $query, "&nbsp;" );
    $line = db_fetch_array( $result );
    $page_result = "[ <a href=".get_link( "adm_exchanges.php?eid=".$line['eid']."&Action=Edit" ).">Edit this order</a> ]<br>";
    foreach ( $line as $key => $value )
    {
        if ( !is_int( $key ) && $value )
        {
            $page_result .= "<b>".str_replace( "_", " ", ucfirst( $key ) )."</b>: ".$value."<br>";
        }
    }
    if ( $line['src_status'] == $STATUS_ENUM_DISABLE )
    {
        $Error[] = "Source amount NOT marked as Receive, you can confirm and pay it here.";
    }
    if ( $line['src_status'] == $STATUS_ENUM_ENABLE )
    {
        $Success[] = "Source already marked as Receive, if you want to pay use pending exchange orders page.";
    }
    db_free_result( $result );
}
if ( $Reference_id && Refrence2eid( $Reference_id ) )
{
    if ( $PAYMENT_ID = db_if_exists( "SELECT eid FROM {$_exchange_lines} WHERE exchange_refrence='{$Reference_id}' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}'" ) )
    {
        if ( db_exec( "update {$_exchange_lines} SET src_status='{$STATUS_ENUM_ENABLE}', src_account='{$payer_acc}', src_batch='#{$src_batch}', exchange_note=CONCAT(exchange_note,' - Your payment manually marked received'), src_date=now() WHERE eid='{$PAYMENT_ID}'" ) )
        {
            SEND_EXHCANGE_MAIL( $Reference_id, "receive" );
            $Success[] = "Order source Marked Received, an email has been sent.<br>You can see this order in Pending list now.";
        }
    }
    else
    {
        $Error[] = "This Refrence id doesn't exist or already marked as receive.";
    }
}
else if ( db_get_id( "SELECT oid FROM {$_orders} WHERE oid='{$Reference_id}'" ) )
{
    if ( $PAYMENT_ID = db_if_exists( "SELECT oid FROM {$_orders} WHERE oid='{$Reference_id}' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}'" ) )
    {
        if ( db_exec( "update {$_orders} SET src_status='{$STATUS_ENUM_ENABLE}', currency_account=CONCAT(currency_account,' {$payer_acc}'), order_note=CONCAT(order_note,' - Your order manually marked received'), currency_account=CONCAT(currency_account,' #{$src_batch}'), src_date=now() WHERE oid='{$PAYMENT_ID}'" ) )
        {
            SEND_ORDER_MAIL( $PAYMENT_ID, "receive" );
            $Success[] = "Order Marked Complete, email has been sent.";
        }
    }
    else
    {
        $Error[] = "This Order id doesn't exist or already marked as receive.";
    }
}
else
{
    $Error[] = "You must enter Valid reference id to proccess.";
}
if ( $NoTemp )
{
    require_once( $CONFIG['SKIN_FOLDER']."adm_manualconfirm_exchange.php" );
}
else
{
    require( "include/engine_settings.php" );
    $PAGE_TEMPLATE = "adm_manualconfirm_exchange.html";
    $page->assign( "page_result", $page_result );
    $page->assign( "pmt_id", $Reference_id );
    require( "include/engine_run.php" );
}
?>
