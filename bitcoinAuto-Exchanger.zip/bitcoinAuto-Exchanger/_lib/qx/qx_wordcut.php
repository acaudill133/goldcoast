<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_wordcut( $sText, $iMaxLength = "150", $sMessage = "..." )
{
    if ( $iMaxLength < strlen( $sText ) )
    {
        $sString = wordwrap( $sText, $iMaxLength - strlen( $sMessage ), "[cut]", 1 );
        $asExplodedString = explode( "[cut]", $sString );
        $sCutText = $asExplodedString[0];
        $sReturn = strip_tags( $sCutText.$sMessage );
    }
    else
    {
        $sReturn = strip_tags( $sText );
    }
    return $sReturn;
}

?>
