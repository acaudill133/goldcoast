<h3><?php echo $lang['terms_of_service']; ?></h3>

<?php echo $settings['p_terms']; ?>