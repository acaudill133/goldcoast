<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

chdir( "../" );
include( "include/config.inc.php" );
if ( !$dbconn )
{
    $dbconn = db_open( );
}
$arr_PERFECT = get_currency_data( "", "perfectmoney", strtoupper( $_POST['PAYMENT_UNITS'] ) );
$ramz = new RamzNegar( );
$arr_PERFECT['ALT_PASSWORD'] = $ramz->decrypt( ramzkey( "number1" ), $arr_PERFECT['ALT_PASSWORD'] );
$Perfect_array = array(
    $_POST['PAYMENT_ID'],
    $_POST['PAYEE_ACCOUNT'],
    $_POST['PAYMENT_AMOUNT'],
    strtoupper( $_POST['PAYMENT_UNITS'] ),
    $_POST['PAYMENT_BATCH_NUM'],
    strtoupper( $_POST['PAYER_ACCOUNT'] ),
    strtoupper( md5( $arr_PERFECT['ALT_PASSWORD'] ) ),
    $_POST['TIMESTAMPGMT']
);
$Perfect_hash = strtoupper( md5( implode( ":", $Perfect_array ) ) );
$PAYEE_ACCOUNT = $_POST['PAYEE_ACCOUNT'];
$PAYMENT_ID = $_POST['PAYMENT_ID'];
$PAYMENT_AMOUNT = $_POST['PAYMENT_AMOUNT'];
$PAYMENT_BATCH_NUM = $_POST['PAYMENT_BATCH_NUM'];
$PAYER_ACCOUNT = $_POST['PAYER_ACCOUNT'];
if ( $Perfect_hash != $_POST['V2_HASH'] )
{
    $Message_log[] = "PerfectMoney FAILED!!!!!!!!!!!\n {$Perfect_hash} = {$_POST['V2_HASH']}";
}
else
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    if ( db_if_exists( "SELECT eid From {$_exchange_lines} WHERE exchange_refrence='{$PAYMENT_ID}' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND src_amount='{$PAYMENT_AMOUNT}'" ) )
    {
        SEND_EXHCANGE_MAIL( $PAYMENT_ID, "receive" );
        commit_exchange( $PAYMENT_ID, $PAYMENT_BATCH_NUM, $PAYER_ACCOUNT );
        $Message_log[] = "PerfectMoney ADD TO DATABSE";
    }
    db_close( $dbconn );
}
Write_File( );
unset( $arr_PERFECT );
?>
