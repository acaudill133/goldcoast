<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function fncSecurityCheck( )
{
    $arr_anywhere = array( "query", "shutdown", "process ", "union", "revoke ", "select ", "insert ", "update ", "create ", "delete ", "rename ", "reload ", "alter ", "grant ", "drop ", "script ", "cookie ", "<", ">", "--" );
    $arr_keywords = array( "admin", "password" );
    $hackstring = "<div align=\"center\"><br><br><br><b><font face=\"Arial\" size=\"5\" color=\"#FF0000\">";
    $hackstring .= "STOP! Hack attempt detected ... cannot proceed past this point!";
    $hackstring .= "</font></b><br></div>";
    if ( 0 < strlen( $_SERVER['QUERY_STRING'] ) )
    {
        $_SERVER['QUERY_STRING'] = str_replace( "%00", "", $_SERVER['QUERY_STRING'] );
        $_SERVER['QUERY_STRING'] = str_replace( "../", "", $_SERVER['QUERY_STRING'] );
        $_SERVER['QUERY_STRING'] = str_replace( "./", "", $_SERVER['QUERY_STRING'] );
        $str = urldecode( $_SERVER['QUERY_STRING'] );
        $arr = split( "[;&]", $str );
        while ( list( $key, $value ) = key )
        {
            $pos = strpos( $str, strtolower( $value ) );
            if ( $pos !== false )
            {
                exit( $hackstring );
            }
        }
        while ( list( $key, $val ) = key )
        {
            $arr2 = split( "=", $val );
            while ( list( $key2, $val2 ) = key2 )
            {
                if ( !( $key2 == 0 ) && !in_array( strtolower( $val2 ), $arr_keywords ) )
                {
                    exit( $hackstring );
                }
            }
        }
    }
}

if ( get_magic_quotes_gpc( ) && $cur_page != "adm_currencies_accounts.php" )
{
    if ( isset( $_POST ) )
    {
        while ( list( $variable, $value ) = variable )
        {
            $_POST["".safe_string( $variable ).""] = safe_string( $value );
        }
    }
    if ( isset( $_GET ) )
    {
        while ( list( $variable, $value ) = variable )
        {
            $_GET["".safe_string( $variable ).""] = safe_string( $value );
        }
    }
    if ( isset( $_COOKIE ) )
    {
        while ( list( $variable, $value ) = variable )
        {
            $_COOKIE["".safe_string( $variable ).""] = safe_string( $value );
        }
    }
}
?>
