<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

include( "public.inc.php" );
$Action = $_GET['Action'];
if ( session_active( ) && !$_POST['order_type'] )
{
    $nvar = db_get_array( "select fullname, money_account, cid, email, Zip, Phone, State, City, StreetAddress, Country_short from {$_users_details} where uid='{$uid}'" );
    $full_name = $nvar[0];
    $currency_account = $nvar[1];
    $cid = $nvar[2];
    $currency_name = convert_emoney( $nvar[2] );
    $email_address = $nvar[3];
    $zip_code = $nvar[4];
    $phone_number = $nvar[5];
    $state = $nvar[6];
    $city = $nvar[7];
    $address = $nvar[8];
    $country = $nvar[9];
    $Post['full_name'] = $full_name;
    $Post['currency_account'] = $currency_account;
    $Post['cid'] = $cid;
    $Post['email_address'] = $email_address;
    $Post['zip_code'] = $zip_code;
    $Post['phone_number'] = $phone_number;
    $Post['state'] = $state;
    $Post['address'] = $address;
    $Post['country'] = $country;
}
$db_fields = array( "order_type", "cid", "order_amount", "currency_account", "payment_method", "email_address", "account_name", "full_name", "phone_number", "country" );
$form_action = get_link( $cur_page."?Action=".$Action );
if ( $_POST['order_type'] )
{
    if ( $_POST['order_amount|req'] && !is_numeric( $_POST['order_amount|req'] ) )
    {
        $Error[] = $LANG_msg['buy_028'];
    }
    if ( !$_POST['email_address|req'] || !eregi( ".+@.+\\..+", $Var_2976['email_address|req'] ) )
    {
        $Error[] = $LANG_msg['signup_016'];
    }
    foreach ( $_POST as $key => $value )
    {
        list( $fieldname, $require ) = fieldname     ;   $filed_parts = explode( "_", $fieldname );
        do
        {
            $fvalue = $Tmp_156[0];
            $Tmp_156;
            $field_fullname .= ucfirst( $fvalue )." ";
        } while ( 1 );
        $err_message = $LANG_msg['buy_022'];
        if ( $require && !$value )
        {
            if ( $fieldname == "payment_method" || $fieldname == "country" || $fieldname == "cid" )
            {
                $err_message = $LANG_msg['buy_023'];
            }
            $Error[] = $err_message." ".$field_fullname;
        }
        else
        {
            if ( $fieldname == "cid" )
            {
                $mail_message .= $field_fullname.": ".$currencies_FNAME[$value]."\n";
            }
            if ( in_array( $fieldname, $db_fields ) )
            {
                $updateSQL_FLD .= $fieldname.", ";
                $updateSQL .= "'".$value."', ";
            }
        }
        $$fieldname = trim( $value );
        unset( $field_fullname );
    }
    if ( $fieldname != "licence_agreement" )
    {
        $Error[] = $LANG_msg['buy_024'];
    }
    if ( !$Error )
    {
        $updateSQL .= " '".$uid."', '0', '0', '".$mail_message."', now()";
        $SQL = "INSERT INTO ".$_orders." (".$updateSQL_FLD." uid, dst_status, src_status, order_detail, order_date)"." VALUES (".$updateSQL."); ";
        $result = db_query( $SQL, "&nbsp;" );
        $order_id = mysql_affected_rows( );
        if ( !$order_id )
        {
            $Error[] = $LANG_msg['withdraw_006'];
        }
        else
        {
            $Success[] = $LANG_msg['sell_019'];
            $mail_headers = "MIME-Version: 1.0\r\n";
            $mail_headers .= "Content-type: text/html; charset=utf-8\r\n";
            $mail_headers .= "From: ".$CONFIG['SITE_NAME']." ".$full_name." <".$CONFIG['REPORT_MAIL'].">\r\n";
            $mail_headers .= "Reply-to: ".$email_address."\r\n";
            $country_detect = GetCountry_csv( $_SERVER['REMOTE_ADDR'] );
            if ( $country_detect )
            {
                $mail_message .= "Country from ip: ".$country_detect."\n";
            }
            $mail = new siteMAIL( );
            $mail->AddAddress( $CONFIG['ADMIN_MAIL'], $CONFIG['SITE_NAME']." Administrator" );
            $mail->Subject = ucfirst( $_POST['order_type'] )." Order";
            $mail->Body = nl2br( $mail_message );
            $mail->FromName = $full_name;
            $mail->AddReplyTo( $email_address, $full_name );
            $mail->bakeMail( false );
            if ( $CONFIG['MAIL_TYPE'] == "smtp" )
            {
                if ( !$mail->Send( ) )
                {
                    $Error[] = "There was an error sending the message: ".$mail->ErrorInfo;
                }
            }
            else if ( !mail( $CONFIG['ADMIN_MAIL'], $mail->Subject, $mail->Body, $mail_headers ) )
            {
                $Error[] = "There was an error sending the email by server php mail extension.";
            }
            if ( !$Error )
            {
                $order_accept = true;
            }
            else
            {
                $Error[] = $Tmp_372;
            }
        }
    }
}
if ( !$_POST['country|req'] )
{
    $_POST['country|req'] = GetCountry_csv( $_SERVER['REMOTE_ADDR'], true );
}
$query = "select countries_iso, countries_name from {$_countries}";
$result = db_query( $query, "&nbsp;" );
$arr_data_country = mysql_push_data( $result );
db_free_result( $result );
if ( $NoTemp )
{
    if ( $Action == "currency_sell" )
    {
        require_once( $CONFIG['SKIN_FOLDER']."currency_sell.php" );
    }
    else
    {
        require_once( $CONFIG['SKIN_FOLDER']."currency_buy.php" );
    }
}
else
{
    require( "include/engine_settings.php" );
    if ( $Action == "currency_sell" )
    {
        $PAGE_TEMPLATE = "currency_sell.html";
    }
    else
    {
        $PAGE_TEMPLATE = "currency_buy.html";
    }
    $page->assign( "form_action", $form_action );
    $page->assign( "order_accept", $order_accept );
    $page->assign( "order_amount", $_POST['order_amount|req'] );
    $page->assign( "currencies_FNAME", $currencies_FNAME );
    $page->assign( "currency_FNAME", $currencies_FNAME[$_POST['cid|req']] );
    $page->assign( "currency_ACCOUNT", db_get_id( "SELECT ACCOUNT FROM ".$_currencies." WHERE cid='".$_POST['cid|req']."'" ) );
    $page->assign( "Post_cid", $_POST['cid|req'] );
    $page->assign( "order_id", $order_id );
    foreach ( $arr_data_country as $key => $value )
    {
        $arr_countries[$arr_data_country[$key]['countries_iso']] = $arr_data_country[$key]['countries_name'];
    }
    $page->assign( "arr_countries", $arr_countries );
    $page->assign( "Post_country", $_POST['country|req'] );
    require( "include/engine_run.php" );
}
?>
