<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

echo "\r\n\t<input type=\"hidden\" name=\"LMI_PAYEE_PURSE\" value=\"";
echo $payee_account;
echo "\" />\r\n";
if ( $amount == "ask" )
{
    echo "    Amount you want to pay: <INPUT type='text' name=\"LMI_PAYMENT_AMOUNT\">\r\n";
}
else
{
    echo "    <input type=\"hidden\" name=\"LMI_PAYMENT_AMOUNT\" value=\"";
    echo $amount;
    echo "\" />\r\n";
}
echo "\t<input type=\"hidden\" name=\"LMI_PAYMENT_NO\" value=\"";
echo $payment_id;
echo "\" />\r\n\t<input type=\"hidden\" name=\"LMI_PAYMENT_DESC\" value=\"";
echo $suggested_memo;
echo "\" />\r\n\t<input type=\"hidden\" name=\"LMI_SUCCESS_METHOD\" value=\"1\" />\r\n\t<input type=\"hidden\" name=\"LMI_FAIL_METHOD\" value=\"1\" />\r\n\t<input type=\"hidden\" name=\"LMI_RESULT_URL\" value=\"";
echo $status_url;
echo "\" />\r\n\t<input type=\"hidden\" name=\"LMI_SUCCESS_URL\" value=\"";
echo $response_ok;
echo "\" />\r\n\t<input type=\"hidden\" name=\"LMI_FAIL_URL\" value=\"";
echo $response_no;
echo "\" />\r\n\t\r\n\r\n\r\n";
?>
