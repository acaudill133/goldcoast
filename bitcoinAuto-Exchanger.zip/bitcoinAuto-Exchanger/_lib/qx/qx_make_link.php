<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_make_link( $link, $type = "", $title = "" )
{
    global $language;
    global $CONFIG;
    global $cur_page;
    if ( !$CONFIG['FRIENDLY_URL'] )
    {
        return $CONFIG['SITE_URL']."/".$link;
    }
    $pieces = explode( ".php", $link );
    $final_link = $pieces[0];
    $pieces[1] = str_replace( "&", "=", $pieces[1] );
    $link_vars = explode( "=", str_replace( "?", "", $pieces[1] ) );
    foreach ( $link_vars as $i => $value )
    {
        if ( $value )
        {
            $final_link .= "/".$value;
        }
    }
    $final_link = $CONFIG['SITE_URL']."/".$final_link."/";
    if ( $title )
    {
        $final_link .= str_replace( " ", "-", $type )."/".str_replace( " ", "-", $title )."/";
    }
    return $final_link;
}

?>
