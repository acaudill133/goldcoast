<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

function qx_number( $param )
{
    global $_CONFIG;
    if ( empty( $_CONFIG['decimal_char'] ) )
    {
        $_CONFIG['decimal_char'] = ",";
    }
    if ( empty( $_CONFIG['decimal_places'] ) )
    {
        $_CONFIG['decimal_places'] = 2;
    }
    if ( empty( $_CONFIG['thousands_sep'] ) )
    {
        $_CONFIG['thousands_sep'] = ".";
    }
    return number_format( $param, $Var_480, $_CONFIG['decimal_char'], $_CONFIG['thousands_sep'] );
}

?>
