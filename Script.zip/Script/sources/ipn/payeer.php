<?php
if ($_SERVER['REMOTE_ADDR'] != '37.59.221.230') return;

if (isset($_POST['m_operation_id']) && isset($_POST['m_sign']))
{
	$m_operation_id = $_POST['m_operation_id'];
	$m_operation_date = $_POST['m_operation_date'];
	$m_orderid = $_POST['m_orderid'];
	$m_amount = $_POST['m_amount'];
	$m_currency = $_POST['m_curr'];
	$query = $db->query("SELECT * FROM exchanges WHERE id='$m_orderid'");
	if($query->num_rows==0) { header("Location: $settings[url]"); }
	$row = $query->fetch_assoc();
	$query1 = $db->query("SELECT * FROM companies_list WHERE id='$row[c_send]'");
	$row1 = $query1->fetch_assoc();
	if(checkSession()) { $uid = $_SESSION['suid']; } else { $uid = 0; }
	$check_trans = $db->query("SELECT * FROM transactions WHERE tid='$m_operation_id' and date='$m_operation_date' and uid='$uid'");
	$m_key = $row1['a_field_1'];
	$arHash = array($_POST['m_operation_id'],
			$_POST['m_operation_ps'],
			$_POST['m_operation_date'],
			$_POST['m_operation_pay_date'],
			$_POST['m_shop'],
			$_POST['m_orderid'],
			$_POST['m_amount'],
			$_POST['m_curr'],
			$_POST['m_desc'],
			$_POST['m_status'],
			$m_key);
	$sign_hash = strtoupper(hash('sha256', implode(':', $arHash)));
	if ($_POST['m_sign'] == $sign_hash && $_POST['m_status'] == 'success')
	{
			if($m_amount == $row['a_send'] or $m_currency == $row['a_currency']) {
				if($check_trans->num_rows>0) {
					echo error($lang['error_15']);
				} else {
					$insert = $db->query("INSERT transactions (tid,from,uid,in,amount,currency,date) VALUES ('$m_operation_id','','$uid','Payeer','$m_amount','$m_currency','$m_operation_date')");
					$update = $db->query("UPDATE exchanges SET status='2' WHERE id='$row[id]'");
					echo success($lang['success_4']);
				}
			} else {
				echo error($lang['error_16']);
			}
	} else {
		$update = $db->query("UPDATE exchanges SET status='3' WHERE id='$row[id]'");
		echo error($lang['error_18']);
	}
}
?>