<?php
/**
*
* @ This file is created by AtakanCan
* @ deZender Public (PHP5 Decompiler)
*
* @	Release on		:	25.07.2011
* @	Official site	:	http://AtakanCan
*
*/

chdir( "../" );
include( "include/config.inc.php" );
$PAYMENT_ID = $_POST['MERCHANT_REF'];
$PAYEE_ACCOUNT = $_POST['PAYEE_ACCOUNT'];
$PAYMENT_AMOUNT = $_POST['PAYMENT_AMOUNT'];
$PAYMENT_BATCH_NUM = $_POST['PAYMENT_BATCH'];
$PAYMENT_CURRENCY = $_POST['PAYMENT_CURRENCY'];
$PAYER_ACCOUNT = $_POST['PAYER_ACCOUNT'];
$PAYER_ACCOUNT_NAME = $_POST['PAYER_ACCOUNT_NAME'];
$Altergold_hash = create_altergold_Token( $PAYMENT_AMOUNT, $PAYMENT_CURRENCY, $PAYMENT_ID, $PAYEE_ACCOUNT );
$Message_log[] = "Hash results: ".$Altergold_hash." = ".$_POST['VERIFICATION_HASH'];
if ( $_POST['MERCHANT_REF'] )
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    $arr_ALTERGOLD = get_currency_data( "", "altergold" );
}
if ( $Altergold_hash != $_POST['VERIFICATION_HASH'] )
{
    $Message_log[] = "Altergold FAILED!!!!!!!!!!!\n {$Altergold_hash} != {$_POST['VERIFICATION_HASH']}";
}
else
{
    if ( !$dbconn )
    {
        $dbconn = db_open( );
    }
    if ( Refrence2eid( $PAYMENT_ID ) )
    {
        if ( $PAYEE_ACCOUNT == $arr_ALTERGOLD['ACCOUNT'] && db_if_exists( "SELECT eid From {$_exchange_lines} WHERE exchange_refrence='{$PAYMENT_ID}' AND src_status='{$STATUS_ENUM_DISABLE}' AND dst_status='{$STATUS_ENUM_DISABLE}' AND src_amount='{$PAYMENT_AMOUNT}'" ) )
        {
            SEND_EXHCANGE_MAIL( $PAYMENT_ID, "receive" );
            commit_exchange( $PAYMENT_ID, $PAYMENT_BATCH_NUM, $PAYER_ACCOUNT );
            $Message_log[] = "Altergold ADD TO DATABSE EXCHANGE";
        }
    }
    else if ( $PAYEE_ACCOUNT == $arr_ALTERGOLD['ACCOUNT'] && db_if_exists( "SELECT * FROM {$_lines} WHERE id='{$PAYMENT_ID}' AND amount='{$PAYMENT_AMOUNT}' AND status='{$STATUS_ENUM_DISABLE}'" ) )
    {
        SEND_INVEST_RECEIVE_MAIL( $PAYMENT_ID, $PAYER_ACCOUNT );
        commit_transaction( $PAYMENT_ID, $PAYMENT_BATCH_NUM );
        $Message_log[] = "Altergold ADD TO DATABSE INVEST";
    }
    db_close( $dbconn );
    $Message_log[] = "Altergold ACCEPTED";
}
Write_File( );
unset( $arr_ALTERGOLD );
?>
