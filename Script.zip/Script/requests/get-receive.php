<?php
ob_start();
session_start();
error_reporting(0);
include("../includes/config.php");
$db = new mysqli($CONF['host'], $CONF['user'], $CONF['pass'], $CONF['name']);
if ($db->connect_errno) {
    echo "Failed to connect to MySQL: (" . $db->connect_errno . ") " . $db->connect_error;
}
$db->set_charset("utf8");
$settingsQuery = $db->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
$settings = $settingsQuery->fetch_assoc();
include("../includes/functions.php");
$id = protect($_GET['id']);
echo '<option value=""></option>';
$query = $db->query("SELECT * FROM companies_list_receive WHERE cid='$id' and allow_receive='1' ORDER BY id");
if($query->num_rows>0) {
	while($row = $query->fetch_assoc()) {
		echo '<option value="'.$row[id].'">'.$row[name].'</option>';
	}
}
?>