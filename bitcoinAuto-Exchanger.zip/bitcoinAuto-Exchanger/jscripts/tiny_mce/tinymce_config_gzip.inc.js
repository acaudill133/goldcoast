<script type="text/javascript" src="[SITE_URL]/jscripts/tiny_mce/tiny_mce_gzip.js"></script>
<script type="text/javascript">
tinyMCE_GZ.init({
    plugins : "style,table,contextmenu,directionality,fullscreen,media,preview",
	themes : 'simple,advanced',
	languages : 'en',
	disk_cache : true,
	debug : false
});
</script>


<script type="text/javascript">

function fileBrowserCallBack(field_name, url, type, win) {
var connector = "[SITE_URL]/jscripts/filemanager/browser.html?Connector=connectors/php/connector.php";
var enableAutoTypeSelection = true;

var cType;
tinyfck_field = field_name;
tinyfck = win;

switch (type) {
case "image":
cType = "Image";
break;
case "flash":
cType = "Flash";
break;
case "file":
cType = "File";
break;
}

if (enableAutoTypeSelection && cType) {
connector += "?Type=" + cType;
}

window.open(connector, "tinyfck", "modal,width=600,height=400");
}

	tinyMCE.init({
		mode : "textareas",
		theme : "advanced",
      	plugins : "style,table,contextmenu,directionality,fullscreen,media,preview",

		theme_advanced_buttons1 : "fullscreen,preview,|,bold,italic,underline,strikethrough,|,forecolor,backcolor,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,fontselect,fontsizeselect,media",	//,|,ltr,rtl,|
		theme_advanced_buttons2 : "outdent,indent,blockquote,bullist,numlist,|,undo,redo,|,link,unlink,anchor,image,cleanup,code,|,hr,removeformat,|,table,tablecontrols",
		theme_advanced_buttons3 : "",
		theme_advanced_toolbar_location : "top",
		extended_valid_elements : "img[class=myclass|!src|border:0|alt|title|width|height]", 
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		entity_encoding : "raw",
		content_css : "[SKIN_CSS]/style.php",
		file_browser_callback : "fileBrowserCallBack",
		theme_advanced_resize_horizontal : false,
		theme_advanced_resizing : true,
		skin : "o2k7",
		skin_variant : "silver",

		//[OPTIONAL],
    force_p_newlines : true, 
    force_br_newlines : false, 
		convert_newlines_to_brs : false, 
    auto_cleanup_word : true,
		verify_html : false,
		preformatted : false,
		apply_source_formatting : true,
		cleanup_serializer : 'xml',
		fix_nesting : false,
		relative_url : false,
		remove_script_host : false,
		elements : 'nourlconvert',
    	document_base_url : "/"


	});
	
function toggleEditor(id) { 
//<a href="javascript:toggleEditor('textfield');">Add/Remove editor</a>
	if (!tinyMCE.get(id)) 
		tinyMCE.execCommand('mceAddControl', false, id); 
	else 
		tinyMCE.execCommand('mceRemoveControl', false, id); 
} 

</script>

	